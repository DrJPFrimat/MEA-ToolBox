%% opening
function varargout = multiwell(varargin)
% MULTIWELL MATLAB code for multiwell.fig
%      MULTIWELL, by itself, creates a new MULTIWELL or raises the existing
%      singleton*.
%
%      H = MULTIWELL returns the handle to a new MULTIWELL or the handle to
%      the existing singleton*.
%
%      MULTIWELL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MULTIWELL.M with the given input arguments.
%
%      MULTIWELL('Property','Value',...) creates a new MULTIWELL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before multiwell_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to multiwell_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help multiwell

% Last Modified by GUIDE v2.5 30-Jun-2020 14:00:00

% Begin initialization code - DO NOT EDIT

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @multiwell_OpeningFcn, ...
    'gui_OutputFcn',  @multiwell_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT
end

% --- Executes just before multiwell is made visible.
function multiwell_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to multiwell (see VARARGIN)

%create new variable HITS from all the parts
global HITS selecteddata parts joost multiwell1

%     load(selecteddata,'HITS');
if joost == 1
    range2 = cell(1,24);
    UUU= 1:16;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+16;
    end
else
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
end

    for i = 2:25
        checked =sprintf('Well_%d',i);
        if contains(selecteddata,'Well')
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        else
            selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
        end
    end
    
    
    
    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    if joost == 1
        HITA = cell(2,384)';
        for i = 1:parts
            load(selecteddata,'HITS')
            HITA(range2{i}(1):range2{i}(end)) = HITS(1:16);
            HITA(range2{i}(1):range2{i}(end),2) = HITS(1:16,2);
            replace1 =sprintf('Well_%d',i);
            replace2 = sprintf('Well_%d',i+1);
            selecteddata = replace(selecteddata,replace1,replace2);
        end
        HITS = HITA;
        
        for i = 1:384
            channelss{i} = num2str(i);
        end
        HITS(:,1) = channelss;
     
    else
        HITA = cell(2,288)';
        for i = 1:parts
            load(selecteddata,'HITS')
            HITA(range2{i}(1):range2{i}(end)) = HITS(1:12);
            HITA(range2{i}(1):range2{i}(end),2) = HITS(1:12,2);
            replace1 =sprintf('Well_%d',i);
            replace2 = sprintf('Well_%d',i+1);
            selecteddata = replace(selecteddata,replace1,replace2);
        end
        HITA(:,1) = HITS(:,1);
        channelss = cell(1,288)';
        
        for i = 1:288
            channelss{i} = num2str(i);
            
        end
        
        HITA(:,1) = channelss;
        HITS = HITA;
    end

set(gcf,'units','normalized','position',[0 0 1 1])
set(gcf,'WindowState','fullscreen')
ha = axes('units','normalized', ...
    'position',[0 0 1 1]);

I=imread('turqoise.jpg');
imagesc(I);
% Turn the handlevisibility off so that we don't inadvertently plot into the axes again
% Also, make the axes invisible
set(ha,'handlevisibility','off', ...
    'visible','off')
% Move the background axes to the bottom
uistack(ha,'bottom');

% set(gcf,'color','w');

COLOR=parula(288); %max 288 colors
colmin=min(cell2mat(HITS(:,2)));
colmax=max(cell2mat(HITS(:,2)));
if joost && multiwell1 == 1
    for counter = 1 : 288 % display only the first 288 if there are more than 24 wells
        set(handles.(sprintf('togglebutton%s',HITS{counter,1})),'BackgroundColor',[1 1 1]); % set all the buttons white if its a CVS file becasue the layout doesnt match
    end
elseif joost == 1
    for counter = 1 : 288 % display only the first 288 if there are more than 24 wells
        if HITS{counter,2} > 10 % min of 10 spikes
            set(handles.(sprintf('togglebutton%s',HITS{counter,1})),'BackgroundColor',COLOR(round(288*(HITS{counter,2}-colmin)/(colmax-colmin+1)+0.5),:)); % set color to MEA
        else
            set(handles.(sprintf('togglebutton%s',HITS{counter,1})),'BackgroundColor',[1 1 1]);
        end
    end
else
    for counter = 1 : size(HITS,1)
        if HITS{counter,2} > 10 % min of 10 spikes
            set(handles.(sprintf('togglebutton%s',HITS{counter,1})),'BackgroundColor',COLOR(round(288*(HITS{counter,2}-colmin)/(colmax-colmin+1)+0.5),:)); % set color to MEA
        else
            set(handles.(sprintf('togglebutton%s',HITS{counter,1})),'BackgroundColor',[1 1 1]);
        end
    end
end

Pos = genButtonPos([0.035 0.75 0.132 0.041],.05,4);
[handles,hObject] = funControl(handles,hObject);

% PictureName = 'backroundPic.jpg';
% handles = setBackround(handles,PictureName);

Tag      = 'Menu_1'; % tag for menu
flds     = {'Home','Bursts','Connections','Spikes'}; % fields of menu
Position = [0 .951 1 .049]; % position of menu on graph
Callback = {'exampleFunction'}; % callback function

s = funBuildo('menu',Tag,Position,flds); % build structure
handles = funControl('menu',handles,s);  % build object
handles.(Tag).CallBack = Callback;       % set callback
% handles.(Tag).Visible = 'off';

loadPannelExamplemultiwell

handles.pushbutton376.Visible = 'off';
handles.pushbutton367.CData = imread('color_button.png');
handles.pushbutton367.ForegroundColor = [0.992 0.89 0.655];
handles.pushbutton377.Visible = 'off';
handles.pushbutton380.CData = imread('color_button.png');
handles.pushbutton380.ForegroundColor = [0.992 0.89 0.655];
handles.text18.Visible = 'off';
handles.text5.Visible = 'off';
handles.pushbutton365.Visible = 'off';
handles.text26.Visible = 'off';

handles = selectPage(handles.UIControl,'Home',handles);

[hObject,handles] = setDefinateMotion(handles.UIControl,hObject,handles);



% Choose default command line output for multiwell
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
clear I COLOR  HITA HITS textstrings channelss range2 UUU clomin colmax 

end

% --- Outputs from this function are returned to the command line.
function varargout = multiwell_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
end
%% the arrangements for the channels
% --- Executes on button press in togglebutton12.
function togglebutton12_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'12')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton11.
function togglebutton11_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'11')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton10.
function togglebutton10_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton9.
function togglebutton9_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton8.
function togglebutton8_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton7.
function togglebutton7_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton7.
function togglebutton6_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton8.
function togglebutton5_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton9.
function togglebutton4_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton10.
function togglebutton3_Callback(hObject, eventdata, handles)
global HITS 

INDEX=find(strcmp(HITS(:,1),'3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton11.
function togglebutton2_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'2')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton12.
function togglebutton1_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'1')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton24.
function togglebutton24_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'24')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton23.
function togglebutton23_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'23')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton22.
function togglebutton22_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'22')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton21.
function togglebutton21_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'21')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end

% --- Executes on button press in togglebutton20.
function togglebutton20_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'20')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton19.
function togglebutton19_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'19')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton19.
function togglebutton18_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'18')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton20.
function togglebutton17_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'17')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton21.
function togglebutton16_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'16')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end

% --- Executes on button press in togglebutton22.
function togglebutton15_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'15')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
% --- Executes on button press in togglebutton23.
function togglebutton14_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'14')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end

% --- Executes on button press in togglebutton24.
function togglebutton13_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'13')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton36.
function togglebutton36_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'36')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton35.
function togglebutton35_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'35')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton34.
function togglebutton34_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'34')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end

% --- Executes on button press in togglebutton33.
function togglebutton33_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'33')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton32.
function togglebutton32_Callback(hObject, eventdata, handles)
global HITS 
INDEX=find(strcmp(HITS(:,1),'32')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton31.
function togglebutton31_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'31')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton31.
function togglebutton30_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'30')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton32.
function togglebutton29_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'29')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton33.
function togglebutton28_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'28')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton34.
function togglebutton27_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'27')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton35.
function togglebutton26_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'26')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton36.
function togglebutton25_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'25')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton48.
function togglebutton48_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'48')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton47.
function togglebutton47_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'47')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton46.
function togglebutton46_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'46')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton45.
function togglebutton45_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'45')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton44.
function togglebutton44_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'44')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton43.
function togglebutton43_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'43')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton43.
function togglebutton42_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'42')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton44.
function togglebutton41_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'41')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton45.
function togglebutton40_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'40')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton46.
function togglebutton39_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'39')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton47.
function togglebutton38_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'38')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton48.
function togglebutton37_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'37')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton60.
function togglebutton60_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'60')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton59.
function togglebutton59_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'59')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton58.
function togglebutton58_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'58')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton57.
function togglebutton57_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'57')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton56.
function togglebutton56_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'56')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton55.
function togglebutton55_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'55')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton55.
function togglebutton54_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'54')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton56.
function togglebutton53_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'53')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton57.
function togglebutton52_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'52')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton58.
function togglebutton51_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'51')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton59.
function togglebutton50_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'50')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton60.
function togglebutton49_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'49')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton72.
function togglebutton72_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'72')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton71.
function togglebutton71_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'71')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton70.
function togglebutton70_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'70')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton69.
function togglebutton69_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'69')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton68.
function togglebutton68_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'68')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton67.
function togglebutton67_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'67')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton67.
function togglebutton66_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'66')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton68.
function togglebutton65_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'65')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton69.
function togglebutton64_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'64')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton70.
function togglebutton63_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'63')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton71.
function togglebutton62_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'62')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton72.
function togglebutton61_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'61')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton84.
function togglebutton84_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'84')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton83.
function togglebutton83_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'83')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton82.
function togglebutton82_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'82')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton81.
function togglebutton81_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'81')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton80.
function togglebutton80_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'80')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton79.
function togglebutton79_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'79')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton79.
function togglebutton78_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'78')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton80.
function togglebutton77_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'77')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton81.
function togglebutton76_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'76')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton82.
function togglebutton75_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'75')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton83.
function togglebutton74_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'74')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton84.
function togglebutton73_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'73')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton96.
function togglebutton96_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'96')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton95.
function togglebutton95_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'95')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton94.
function togglebutton94_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'94')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton93.
function togglebutton93_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'93')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton92.
function togglebutton92_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'92')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton91.
function togglebutton91_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'91')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton91.
function togglebutton90_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'90')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton92.
function togglebutton89_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'89')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton93.
function togglebutton88_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'88')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton94.
function togglebutton87_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'87')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton95.
function togglebutton86_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'86')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton96.
function togglebutton85_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'85')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton108.
function togglebutton108_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'108')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton107.
function togglebutton107_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'107')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton106.
function togglebutton106_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'106')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton105.
function togglebutton105_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'105')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton104.
function togglebutton104_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'104')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton103.
function togglebutton103_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'103')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton103.
function togglebutton102_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'102')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton104.
function togglebutton101_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'101')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton105.
function togglebutton100_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'100')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton106.
function togglebutton99_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'99')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton107.
function togglebutton98_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'98')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton108.
function togglebutton97_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'97')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton120.
function togglebutton120_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'120')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton119.
function togglebutton119_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'119')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton118.
function togglebutton118_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'118')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton117.
function togglebutton117_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'117')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton116.
function togglebutton116_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'116')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton115.
function togglebutton115_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'115')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton115.
function togglebutton114_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'114')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton116.
function togglebutton113_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'113')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton117.
function togglebutton112_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'112')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton118.
function togglebutton111_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'111')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton119.
function togglebutton110_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'110')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton120.
function togglebutton109_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'109')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton132.
function togglebutton132_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'132')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton131.
function togglebutton131_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'131')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton130.
function togglebutton130_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'130')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton129.
function togglebutton129_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'129')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton128.
function togglebutton128_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'128')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton127.
function togglebutton127_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'127')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton127.
function togglebutton126_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'126')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton128.
function togglebutton125_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'125')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton129.
function togglebutton124_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'124')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton130.
function togglebutton123_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'123')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton131.
function togglebutton122_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'122')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton132.
function togglebutton121_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'121')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end




% --- Executes on button press in togglebutton144.
function togglebutton144_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'144')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton143.
function togglebutton143_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'143')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton142.
function togglebutton142_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'142')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton141.
function togglebutton141_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'141')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton140.
function togglebutton140_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'140')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton139.
function togglebutton139_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'139')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton139.
function togglebutton138_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'138')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton140.
function togglebutton137_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'137')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton141.
function togglebutton136_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'136')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton142.
function togglebutton135_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'135')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton143.
function togglebutton134_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'134')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton144.
function togglebutton133_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'133')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton156.
function togglebutton156_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'156')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton155.
function togglebutton155_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'155')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton147.
function togglebutton154_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'154')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton153.
function togglebutton153_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'153')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton152.
function togglebutton152_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'152')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton151.
function togglebutton151_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'151')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton151.
function togglebutton150_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'150')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton152.
function togglebutton149_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'149')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton153.
function togglebutton148_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'148')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton147.
function togglebutton147_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'147')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton155.
function togglebutton146_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'146')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton156.
function togglebutton145_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'145')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton168.
function togglebutton168_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'168')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton167.
function togglebutton167_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'167')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton166.
function togglebutton166_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'166')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton165.
function togglebutton165_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'165')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton164.
function togglebutton164_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'164')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton163.
function togglebutton163_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'163')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton163.
function togglebutton162_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'162')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton164.
function togglebutton161_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'161')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton165.
function togglebutton160_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'160')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton166.
function togglebutton159_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'159')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton167.
function togglebutton158_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'158')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton168.
function togglebutton157_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'157')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton180.
function togglebutton180_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'180')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton179.
function togglebutton179_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'179')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton178.
function togglebutton178_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'178')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton177.
function togglebutton177_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'177')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton176.
function togglebutton176_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'176')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton175.
function togglebutton175_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'175')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton175.
function togglebutton174_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'174')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton176.
function togglebutton173_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'173')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton177.
function togglebutton172_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'172')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton178.
function togglebutton171_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'171')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton179.
function togglebutton170_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'170')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton180.
function togglebutton169_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'169')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton192.
function togglebutton192_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'192')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton191.
function togglebutton191_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'191')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton190.
function togglebutton190_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'190')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton189.
function togglebutton189_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'189')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton188.
function togglebutton188_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'188')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton187.
function togglebutton187_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'187')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton187.
function togglebutton186_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'186')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton188.
function togglebutton185_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'185')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton189.
function togglebutton184_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'184')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton190.
function togglebutton183_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'183')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton191.
function togglebutton182_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'182')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton192.
function togglebutton181_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'181')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton204.
function togglebutton204_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'204')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton203.
function togglebutton203_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'203')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton202.
function togglebutton202_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'202')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton201.
function togglebutton201_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'201')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton200.
function togglebutton200_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'200')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton199.
function togglebutton199_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'199')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton199.
function togglebutton198_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'198')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton200.
function togglebutton197_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'197')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton201.
function togglebutton196_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'196')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton202.
function togglebutton195_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'195')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton203.
function togglebutton194_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'194')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton204.
function togglebutton193_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'193')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton216.
function togglebutton216_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'216')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton215.
function togglebutton215_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'215')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton214.
function togglebutton214_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'214')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton213.
function togglebutton213_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'213')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton212.
function togglebutton212_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'212')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton211.
function togglebutton211_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'211')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton211.
function togglebutton210_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'210')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton212.
function togglebutton209_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'209')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton213.
function togglebutton208_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'208')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton214.
function togglebutton207_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'207')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton215.
function togglebutton206_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'206')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton216.
function togglebutton205_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'205')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton228.
function togglebutton228_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'228')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton227.
function togglebutton227_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'227')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton226.
function togglebutton226_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'226')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end


% --- Executes on button press in togglebutton225.
function togglebutton225_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'225')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton224.
function togglebutton224_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'224')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton223.
function togglebutton223_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'223')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton223.
function togglebutton222_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'222')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton224.
function togglebutton221_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'221')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton225.
function togglebutton220_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'220')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton226.
function togglebutton219_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'219')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton227.
function togglebutton218_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'218')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton228.
function togglebutton217_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'217')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton240.
function togglebutton240_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'240')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton239.
function togglebutton239_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'239')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton238.
function togglebutton238_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'238')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton237.
function togglebutton237_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'237')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton236.
function togglebutton236_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'236')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton235.
function togglebutton235_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'235')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton235.
function togglebutton234_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'234')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton236.
function togglebutton233_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'233')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton237.
function togglebutton232_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'232')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton238.
function togglebutton231_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'231')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton239.
function togglebutton230_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'230')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton240.
function togglebutton229_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'229')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton252.
function togglebutton252_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'252')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton251.
function togglebutton251_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'251')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton250.
function togglebutton250_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'250')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton249.
function togglebutton249_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'249')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton248.
function togglebutton248_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'248')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton247.
function togglebutton247_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'247')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton247.
function togglebutton246_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'246')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton248.
function togglebutton245_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'245')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton249.
function togglebutton244_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'244')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton250.
function togglebutton243_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'243')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton251.
function togglebutton242_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'242')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton252.
function togglebutton241_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'241')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton264.
function togglebutton264_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'264')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton263.
function togglebutton263_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'263')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton262.
function togglebutton262_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'262')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton256.
function togglebutton261_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'261')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton260.
function togglebutton260_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'260')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton259.
function togglebutton259_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'259')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton259.
function togglebutton258_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'258')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton260.
function togglebutton257_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'257')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton256.
function togglebutton256_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'256')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton262.
function togglebutton255_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'255')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton263.
function togglebutton254_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'254')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton264.
function togglebutton253_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'253')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton276.
function togglebutton276_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'276')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton275.
function togglebutton275_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'275')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton274.
function togglebutton274_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'274')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton273.
function togglebutton273_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'273')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton272.
function togglebutton272_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'272')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton271.
function togglebutton271_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'271')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton271.
function togglebutton270_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'270')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton272.
function togglebutton269_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'269')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton273.
function togglebutton268_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'268')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton274.
function togglebutton267_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'267')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton275.
function togglebutton266_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'266')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton276.
function togglebutton265_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'265')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton288.
function togglebutton288_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'288')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton287.
function togglebutton287_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'287')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton286.
function togglebutton286_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'286')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton285.
function togglebutton285_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'285')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton284.
function togglebutton284_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'284')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton283.
function togglebutton283_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'283')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton283.
function togglebutton282_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'282')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton284.
function togglebutton281_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'281')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton285.
function togglebutton280_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'280')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton286.
function togglebutton279_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'279')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton287.
function togglebutton278_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'278')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end



% --- Executes on button press in togglebutton288.
function togglebutton277_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'277')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
%% well buttons
% --- well 1
function pushbutton402_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '1'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait);
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 
% filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 1;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    if joost == 1
         range2 = cell(1,24);
        UUU= 1:16;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+16;
        end
    else
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
    end
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2);
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    if joost == 1
        correctylim = val *16;
        correctylim = [(correctylim - 16):4: correctylim+4];
    else
        correctylim = val *12;
        correctylim = [(correctylim - 12):2: correctylim+2];
    end
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2




end
% --- well 1
function pushbutton402_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.04 0.866 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 1';
end
% --- Well 2
function pushbutton403_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '2'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 2;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 2
function pushbutton403_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.128 0.866 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 2';
end
% --- Well 3
function pushbutton404_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '3'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 
filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 3;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 3
function pushbutton404_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.212 0.866 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 3';
end
% --- Well 4
function pushbutton405_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '4'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 
filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 4;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 4
function pushbutton405_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.299 0.866 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 4';
end
% --- Well 5
function pushbutton406_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '5'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 5;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 5
function pushbutton406_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.384 0.866 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 5';
end
% --- Well 6
function pushbutton407_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '6'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 6;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 6
function pushbutton407_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.47 0.866 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 6';
end
% --- Well 7
function pushbutton408_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '7'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 7;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 7
function pushbutton408_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.042 0.772 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 7';
end
% --- Well 8
function pushbutton409_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '8'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 8;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 8
function pushbutton409_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.125 0.772 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 8';
end
% --- Well 9
function pushbutton410_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '9'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 
 
filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 9;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 9
function pushbutton410_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.212 0.772 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 9';
end
% --- Well 10
function pushbutton411_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '10'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 10;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 10
function pushbutton411_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.296 0.772 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 10';
end
% --- Well 11
function pushbutton412_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '11'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 
 
filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 11;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 11
function pushbutton412_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.382 0.772 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 11';

end
% --- Well 12
function pushbutton413_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '12'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 12;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 12
function pushbutton413_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.47 0.772 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 12';
end
% --- Well 13
function pushbutton414_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '13'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 13;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 13
function pushbutton414_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.04 0.677 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 13';

end
% --- Well 14
function pushbutton415_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '14'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 14;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 14
function pushbutton415_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.124 0.677 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 14';
end
% --- Well 15
function pushbutton416_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '15'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 
 
filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 15;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2

end
% --- Well 15
function pushbutton416_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.21 0.677 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 15';
end
% --- Well 16
function pushbutton417_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '16'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 16;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2

end
% --- Well 16
function pushbutton417_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.296 0.677 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 16';

end
% --- Well 17
function pushbutton418_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '17'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';

delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 
 
filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 17;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 17
function pushbutton418_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.382 0.677 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 17';
end
% --- Well 18
function pushbutton419_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '18'; % default is well 1
clear filteredData1
tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 
% filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 18;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);

    clear M2 xpoints
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')

    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
 
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
   
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
 
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end

    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 18
function pushbutton419_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.469 0.677 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 18';
end
% --- Well 19
function pushbutton420_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '19'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 19;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 19
function pushbutton420_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.04 0.581 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 19';
end
% --- Well 20
function pushbutton421_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '20'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 20;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 20
function pushbutton421_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.124 0.581 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 20';
end
% --- Well 21
function pushbutton422_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '21'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 21;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 21
function pushbutton422_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.212 0.581 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 21';
end
% --- Well 22
function pushbutton423_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '22'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 22;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 22
function pushbutton423_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.298 0.581 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 22';
end
% --- Well 23
function pushbutton424_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '23'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 23;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 23
function pushbutton424_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.382 0.581 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 23';
end
% --- Well 24
function pushbutton425_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters cbx98 cbx99 xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

window = timesss *10000; % this is equal to full trace
jitters{2} = '24'; % default is well 1

tempo4 = findobj('Tag','uipanel4');
tempo33 = findobj('Tag','uipanel3');
cla(tempo4.Children);
cla(tempo33.Children(2));
cla(tempo33.Children(1));
dim = [0.3 0.3 0.5 0.3];
dim2 = [0.3 0.5 0.45 0.15];
% text(tempo4.Children.XLim(2)/2,tempo4.Children.YLim(2)/2,'Please Wait','Units','normalized');
pleasewait = annotation(tempo4,'textbox',dim,'String','Please Wait','Fontsize',60,'FitBoxToText','off');
pleasewait2 = annotation(tempo33,'textbox',dim2,'String','Please Wait','Fontsize',31.5,'FitBoxToText','off');
drawnow
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1=filteredData1';
delete(pleasewait)
multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1)) 

filteredData1=filteredData1';


for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end

val = 24;


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
%     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s/resolution; 
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
%     Trim out the relevant portion of the spike density
     s = s(center:end-center-1);
    t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    
    tempo3 = findobj('Tag','uipanel3');
    axes(tempo3);
    delete(pleasewait2)
    plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    correctylim = val *12;
    correctylim = [(correctylim - 12):2: correctylim+2];
     plp1.YTickLabel = correctylim;
%     set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    

    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',10);
    correctxlim = get(gca,'XLim');
    
   
    subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    %correct ylim
    
    xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
clear filteredData1 xpoints M2
end
% --- Well 24
function pushbutton425_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.468 0.581 0.023 0.016];
hObject.CData = imread('color_button.png');
hObject.BackgroundColor = [.97,.98,.98];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Well 24';
end
%% plots
function Plot_MEA_Graph(INDEX)
global selecteddata parts X2 RMS7 SCBflag filteredData1 noiseall18 noiseall2 M2 M88 fs burstsinfor HITS Spikeform3 Spikeform4 joost electrodecount channel963 burstview2 burstview3 yutp unitpersecond burstview19 burstview20 xpoints ypoints
% we have to find the correct well and channel first and load that in
hh=waitbar(0,'Please Wait');
loc2 = find(strcmp(HITS,mat2str(INDEX)));
if joost == 1
    electrodecount = 16;
else
    electrodecount = 12;
end
correctwell = ceil(loc2/electrodecount); %we found the correct well
INDEX2 = ceil((((loc2/electrodecount) - (correctwell - 1))*electrodecount)-0.000001); % the -0.0000001 is for cases when the number is an whole number like 6.00 so it decreaseses the number for the ceil to work correctly

for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',correctwell));


load(selecteddata,'RMS7');
load(selecteddata,'noiseall18');
load(selecteddata,'noiseall2');
load(selecteddata,'xpoints');
load(selecteddata,'ypoints');
load(selecteddata,'unitpersecond');
load(selecteddata,'M88');
load(selecteddata,'burstview2');
load(selecteddata,'burstview3');
load(selecteddata,'filteredData1');
load(selecteddata,'M2');
waitbar(0 + 0.5,hh,'Please Wait');

figure('units','normalized','outerposition',[0 0 1 1]);
h1=subplot(5,1,1);
if joost == 1
else
    plot(X2,filteredData1(INDEX2,:));
    
    ylabel('Microvolts');
    xlabel('Time in seconds');
    title(['Channel ', HITS{INDEX}]);
    set(gca,'Fontsize',10);
    hold on
    plot(X2,RMS7(INDEX2,1)*ones(length(X2),1)','k');
    hold on
    plot(X2,-RMS7(INDEX2,1)*ones(length(X2),1)','k');
    
    hold on
    if length(noiseall18{INDEX2,1}) > fs.filtersettings.sampling_frequency
        plot(noiseall18{INDEX2,1}(1:fs.filtersettings.sampling_frequency),noiseall2{INDEX2,1}(1:fs.filtersettings.sampling_frequency),'r')
        hold on
        plot(noiseall18{INDEX2,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{INDEX2,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
    else
        plot(noiseall18{INDEX2,1},noiseall2{INDEX2,1},'r');
    end
    legend('Filtered Channel','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',8);
    set(legend,...
        'Position',[0.725580141149337 0.937787747362246 0.0836481364816829 0.0527522921562193],...
        'FontSize',8);
end
hold on
subplot(5,1,2);
ypuo = find(ypoints == INDEX2);
xpuo = xpoints(ypuo);
ypuo1=INDEX2*ones(length(xpuo),1);
ypuo1=ypuo1';
axis([0 60 (INDEX2-0.001) (INDEX2+0.001)]);

hold on
for i=1:length(xpuo)
    line([xpuo(1,i) xpuo(1,i)],get(gca,'Ylim'),'Color',[0 0 0]);
end
set(gca,'ytick',[])
title(['Rasterplot of Channel ', HITS{INDEX}]);
xlabel('Time in Seconds');
xlim([h1.XLim]);
hold on
subplot(5,1,3);
bar(unitpersecond{INDEX2,1});
title('Units per second over the whole recording');
xlabel('Time in seconds');
ylabel('Units per second');
xlim([h1.XLim]);

hold on
subplot(5,1,4);



ISI58={}; %contains all the ISI for all channels
for i=1:length(M2)
    ISI57= diff(M2{i,1});
    ISI58{i}=ISI57;
    ISI58=ISI58';
end

dt = 0.001; % in s, because spike times are in s
isi_edges = 0:dt:0.5; % bin edges for ISI histogram
isi_centers = isi_edges(1:end-1)+dt/2; % for plotting
isih = histc(ISI58{INDEX2},isi_edges);
if isempty(isih)
else
    bar(isi_centers,isih(1:end-1))
    xlabel('ISI (s)');
    ylabel('count');
    title(['Distribution of ISI in channel ',HITS{INDEX}]);
    
    hold on
    h5 = subplot(5,1,5);
    if joost == 1
    else
        plot(M2{INDEX2},M88{INDEX2},'.','Color',[0 0 0]);
        xlim([h1.XLim]);
        ylim([h1.YLim]);
    end
end
if joost == 1
else
    ylabel('Microvolts');
    xlabel('Time in seconds');
    hold on
    channel963=filteredData1(INDEX2,:);
    for i=1:length(burstview2{INDEX2,1})
        plot(X2(burstview2{INDEX2,1}(1,i):burstview3{INDEX2,1}(1,i)),channel963(burstview2{INDEX2,1}(1,i):burstview3{INDEX2,1}(1,i)),'Color',[1 0 0]);
        hold on
    end
    
    if SCBflag == 1
        legend('Spikes','SCB(Max interval method)');
    elseif SCBflag == 0
        legend('Spikes','SCB(log ISI method)');
    end
    
    set(legend,...
        'Position',[0.735114229041202 0.0490825696275868 0.0874257942212316 0.0316513753265416]);
    title('Spike Detection and Burst detection');
end
set(gca,'Fontsize',10);
set(gcf,'color','white')
waitbar(0 + 1,hh,'Please Wait');
close(hh)
linkaxes([h1 h5],'xy')
clear RMS7 noiseall18 noiseall2 xpoints ypoints unitpersecond M88 burstview2 burstview3 filteredData1 M2 ISI58 ISI57 isi_edges isi_centers isih ypuo xpuo ypuo1 loc2 INDEX2 correctwell electrodecount
end
%% miscellaneous

% --- Executes during object creation, after setting all properties.
function text29_CreateFcn(hObject, eventdata, handles)
global HITS maxee joost
if joost == 1
else
    maxee=max([HITS{:,2}]);
    set(hObject, 'String',maxee);
end

end


% --- Executes during object creation, after setting all properties.
function pushbutton366_CreateFcn(hObject, eventdata, handles)
global selecteddata
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.992 0.89 0.655];
set(hObject, 'String', selecteddata);
end

% --- Executes durincolorbar
function pushbutton364_CreateFcn(hObject, eventdata, handles)
end
%% general Data



% --- Executes during object creation, after setting all properties.
function pushbutton367_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.626 0.455 0.086 0.041];
end


% --- Executes on button press in general Data
function pushbutton367_Callback(hObject, eventdata, handles)
global merge_t selecteddata


figure('Name',[selecteddata],'NumberTitle','off');
uitable('Data',merge_t{:,:},'ColumnName',merge_t.Properties.VariableNames,...
    'RowName',merge_t.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
filter={'*.xlsx'};
% writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
%      writetable(merge_t,uiputfile(filter),'WriteRowNames',true);
end
%% top 10 channels

% --- top 10 channel button
function pushbutton368_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.861 0.524 0.096 0.048];
end

% --- Executes on button press in top 10 channels
function pushbutton368_Callback(hObject, eventdata, handles)
global imaxch X2 filteredData1 HITS imaxch2 timesss RMS7 noiseall18 noiseall2 screen1 fs parts selecteddata

if length(filteredData1(:,1)) < 5
    msgbox('There is no voltage trace data')
else
    for i = 2:25
        checked =sprintf('Well_%d',i);
        if contains(selecteddata,'Well')
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        else
            selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
        end
    end
    
    hh=waitbar(0,'Please Wait');
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
    
    
    
    HITA = cell(2,288)';
    for i = 1:parts
        load(selecteddata,'HITS')
        HITA(range2{i}(1):range2{i}(end)) = HITS(1:12);
        HITA(range2{i}(1):range2{i}(end),2) = HITS(1:12,2);
        replace1 =sprintf('Well_%d',i);
        replace2 = sprintf('Well_%d',i+1);
        selecteddata = replace(selecteddata,replace1,replace2);
    end
    
    HITA(:,1) = HITS(:,1);
    waitbar(0 + 0.3,hh,'Please Wait');
    channelss = cell(1,288)';
    
    for i = 1:288
        channelss{i} = num2str(i);
        
    end
    
    HITA(:,1) = channelss;
    HITS = HITA;
    
    [~,indexx] = maxk(cell2mat(HITS(:,2)),10);
    figure(1);
    if parts == 24
        for i = 1:5
            %now we need to select the correct file(well)
            correctwell = ceil(indexx(i)/12); % correct well
            correctfilef = sprintf('Well_%d',correctwell);
            selecteddata = replace(selecteddata,'Well_25',correctfilef);
            load(selecteddata,'filteredData1');
            load(selecteddata,'RMS7');
            load(selecteddata,'noiseall18');
            load(selecteddata,'noiseall2');
            
            P = indexx(i) - (correctwell-1) * 12;
            subplot(5,1,i);
            plot(X2,filteredData1(P,:));
            hold on
            plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
            hold on
            plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
            hold on
            if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
                plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
                hold on
                plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
            else
                plot(noiseall18{P,1},noiseall2{P,1},'r');
            end
            ylabel(['',HITS((indexx(i)))]);
            
            if i == 5
                xlabel('Time (s)')
            end
            
            
            if i == 1
                title('Top 5 most active channels');
                oooo=legend('Trace','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',5);
                oooo.FontSize=5;
                set(legend,...
                    'Position',[1.24000978654402e-05 0.000245518612941189 0.15825374906255 0.105329946515524],...
                    'FontSize',5);
            end
            %change the name to Well 25
            selecteddata = replace(selecteddata,correctfilef,'Well_25');
            clear filteredData1 RMS7 noiseall2 noiseall18
            
        end
        close(hh)
    elseif parts == 12
        for i = 1:5
            %now we need to select the correct file(well)
            correctwell = ceil(indexx(i)/12); % correct well
            correctfilef = sprintf('Well_%d',correctwell);
            selecteddata = replace(selecteddata,'Well_13',correctfilef);
            load(selecteddata,'filteredData1');
            load(selecteddata,'RMS7');
            load(selecteddata,'noiseall18');
            load(selecteddata,'noiseall2');
            P = indexx(i) - (correctwell-1) * 12;
            subplot(5,1,i);
            plot(X2,filteredData1(P,:));
            
            hold on
            plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
            hold on
            plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
            hold on
            if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
                plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
                hold on
                plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
            else
                plot(noiseall18{P,1},noiseall2{P,1},'r');
            end
            ylabel(['',HITS((indexx(i)))]);
            
            if i == 5
                xlabel('Time (s)')
            end
            
            if i == 1
                title('Top 5 most active channels');
                oooo=legend('Trace','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',5);
                oooo.FontSize=5;
                set(legend,...
                    'Position',[1.24000978654402e-05 0.000245518612941189 0.15825374906255 0.105329946515524],...
                    'FontSize',5);
            end
            %change the name to Well 25
            selecteddata = replace(selecteddata,correctfilef,'Well_13');
            clear filteredData1 RMS7 noiseall2 noiseall18
            set(gcf,'color','white')
            
        end
        waitbar(0 + 0.5,hh,'Please Wait');
        figure(2);
        for i = 1:5
            %now we need to select the correct file(well)
            correctwell = ceil(indexx(i+5)/12); % correct well
            correctfilef = sprintf('Well_%d',correctwell);
            selecteddata = replace(selecteddata,'Well_13',correctfilef);
            load(selecteddata,'filteredData1');
            load(selecteddata,'RMS7');
            load(selecteddata,'noiseall18');
            load(selecteddata,'noiseall2');
            
            P = indexx(i+5) - (correctwell-1) * 12;
            subplot(5,1,i);
            plot(X2,filteredData1(P,:));
            hold on
            plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
            hold on
            plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
            hold on
            if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
                plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
                hold on
                plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
            else
                plot(noiseall18{P,1},noiseall2{P,1},'r');
            end
            ylabel(['',HITS((indexx(i+5)))]);
            
            
            if i == 5
                xlabel('Time (s)')
            end
            
            if i == 1
                title('Top 10 most active channels');
                oooo=legend('Trace','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',5);
                oooo.FontSize=5;
                set(legend,...
                    'Position',[1.24000978654402e-05 0.000245518612941189 0.15825374906255 0.105329946515524],...
                    'FontSize',5);
            end
            %change the name to Well 25
            selecteddata = replace(selecteddata,correctfilef,'Well_13');
            clear filteredData1 RMS7 noiseall2 noiseall18
            set(gcf,'color','white')
            
        end
        close(hh)
        
    end
    
end
end
%% rasterplot


% --- Executes during object creation, after setting all properties.
function pushbutton370_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.861 0.102 0.096 0.048];
end
% --- Executes on button press in rasterplot
function pushbutton370_Callback(hObject, eventdata, handles)
global cbx989 cbx9955 selecteddata xpoints parts ypoints xPoints cbx2000 yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

% we need to create the whole rasterplot

    val = 1; % well 1
    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    
    
    if joost == 1
        range2 = cell(1,24);
        UUU= 1:16;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+16;
        end
    else
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
    end

    %adapated from plotSPikeRaster by Jeffrey Chiou
    Rasterplot1 = figure('units','normalized','outerposition',[0 0 1 1]);
    
    %create a new xpoints variable that contains al the xpoints
    load(selecteddata,'xpoints')
    load(selecteddata,'M2')
    selecteddata2 = selecteddata;
    
    xpoints=sort(xpoints);
    timesss = ceil(max(xpoints));
    
    %     if ((ceil(xPoints(end))-10 > timesss) && (ceil(xPoints(end))+10 < timesss))
    %     else
    %         timesss = ceil(xPoints(end));
    %
    %     end
    %      postdur = double(floor(timesss));
    %     predur = 0;
    %     %
    %     %     if timesss > 120
    %     %         widMS = 10;
    %     %     else
    %     %         widMS = 1;
    %     %     end
    %     %     centersPost = [(widMS/2):widMS:postdur +(widMS/2)];
    %     %     centersPre = [-(widMS/2):(-widMS):-predur -(widMS/2)];
    %     %     centers = [fliplr(centersPre) centersPost];
    %     centers = 0:0.03:floor(timesss);
    %     widMS = 0.03;
    %
    %     %remove the first and last numbers of the vector as they are non sense
    %     %numbers
    %
    %     %     centers = centers(2:length(centers)-1);
    %     %     if widMS == 1
    %     %     centers = centers(:)-0.5;
    %     %
    %     %     end
    %     [counts,~] = hist(xpoints,centers);
    %     subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    %     %     r = ((counts/length(M2))/widMS)*1;        %% spikes/sec
    %     r = ((counts/length(M2))/widMS)*33;        %% spikes/sec
    %     %r = counts/widMS;
    %     h = bar(centers,r,1);
    %     set(h,'FaceColor','k');
    %     % set(h,'FaceColor',[0.5 0.5 0.5]);
    %     axis([-predur,postdur,0 (max(r)*1.1)]);
    
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    %     EDGES = 0:1:max(xpoints);
    N = histc(xpoints, EDGES);
    % N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    if ~isempty(N)
        s = conv(N,kernel);
        s = s/resolution;
        %Find the index of the kernel center
        center = ceil(length(edges)/2);
        % %Trim out the relevant portion of the spike density
        s = s(center:end-center-1);
        %     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
        t = (1:length(s))*resolution ;
    end
    gg = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    if ~isempty(N)
        plot(t,s,'k');
        xlim([0 timesss])
    end
    ylabel('AWFR (Hz)');
    xlabel('Time(s)','Fontsize',20);
    
    % set(gca,'XTick',[]);    % no x numbers
    correctxlim = get(gca,'XLim');
    %     set(gca,'Fontsize',20)
    
    
    % calculate the rasterplot
    kk = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    if ~isempty(N)
        nTotalSpikes = sum(cellfun(@length,M2));
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;
        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            % Save points and update current index
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        
        plot(xPoints, yPoints, 'k')
    end
    
    set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    ylabel('Channels','Fontsize',20);
    title('Array Wide Activity of Well 1');
    
    %correct ylim
    if joost == 1
        correctylim = val *16;
        correctylim = [(correctylim - 16) correctylim];
    else
        correctylim = val *12;
        correctylim = [(correctylim - 12) correctylim];
    end
    ylim(correctylim);
    %color the bursts in red for max interval method
    
    %allbursts contain all the indices of the bursts in a start followeed by
    %the end index of each burst
    % the xPoints vector are the time points of each spike sorted in a specific
    % manner each time point is represented double ending with a nan.
    %this means that one timepoint value of a spike corresponds with 3 spots
    %inteh xPoints vector
    if joost == 1
        HITA = cell(1,384)';
        for i = 1:parts
            load(selecteddata,'burst6indx')
            HITA(range2{i}(1):range2{i}(end)) = burst6indx(1:16);
            
            replace1 =sprintf('Well_%d',i);
            replace2 = sprintf('Well_%d',i+1);
            selecteddata = replace(selecteddata,replace1,replace2);
            
        end
        selecteddata = selecteddata2;
        burst6indx = HITA;
    else
        
        HITA = cell(1,288)';
        for i = 1:parts
            load(selecteddata,'burst6indx')
            HITA(range2{i}(1):range2{i}(end)) = burst6indx(1:12);
            
            replace1 =sprintf('Well_%d',i);
            replace2 = sprintf('Well_%d',i+1);
            selecteddata = replace(selecteddata,replace1,replace2);
            
        end
        selecteddata = selecteddata2;
        burst6indx = HITA;
    end
    
    %     burst6indx =burst6indx';
    
    % place them in the same configuration as the allbursts cell array
    
    maxbursts= [];
    
    max1bursts= cell(1,length(M2));
    for i = 1:length(M2)
        for j= 1:length(burst6indx{i})
            maxbursts = [burst6indx{i}{j}(1),burst6indx{i}{j}(end)];
            max1bursts{i} = [max1bursts{i},maxbursts];
        end
        
    end
    max1bursts=max1bursts';
    
    max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
    % now lets make it eaasier to index in the xPoints vector by giving each
    % number the correct index so we can just index in the xPoints vector
    
    % the try and catch statements are only temp fix but need to take a
    % look att he code for max interval
    countold = 0;
    for i=1:length(max1bursts)
        try
            countnew = (length(M2{i})*3+countold);
            countold = countnew;
            if isempty(max1bursts{(i+1)})
            else
                for j = 1:length(max1bursts{(i+1)})
                    
                    max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                end
            end
        catch
        end
    end
    linkaxes([gg kk],'x');


% Create a check box to diplay bursts in rasterplot:
cbx989 = uicontrol(Rasterplot1,'Style','checkbox','Position',[10 407 250 1000],...
    'Callback',@(cbx,event) rasterplotbutton(cbx));
cbx989.String = 'Display Single Channel Bursts';
cbx989.BackgroundColor = [1 1 1];
set(gcf,'color','white')



% Create a check box to diplay network bursts in rasterplot:
cbx9955 = uicontrol(Rasterplot1,'Style','checkbox','Position',[10 557 250 300],...
    'Callback',@(cbx,event) rasterplotbutton(cbx));
cbx9955.String = 'Display Network Bursts';
cbx9955.BackgroundColor = [1 1 1];
ylabel('Channels','Fontsize',30);
set(gca,'Fontsize',20);

%create a listbox so the user can choose which well it displays

cbx2000 = uicontrol(Rasterplot1,'Style','popupmenu',...
    'Callback',@selection);
if parts == 12
    cbx2000.String ={'Well 1','Well 2','Well 3','Well 4', 'Well 5', 'Well 6' ...
        'Well 7', 'Well 8', 'Well 9', 'Well 10', 'Well 11', 'Well 12'};
elseif parts == 24
    cbx2000.String ={'Well 1','Well 2','Well 3','Well 4', 'Well 5', 'Well 6' ...
        'Well 7', 'Well 8', 'Well 9', 'Well 10', 'Well 11', 'Well 12','Well 13','Well 14',...
        'Well 15', 'Well 16', 'Well 17', 'Well 18', 'Well 19','Well 20', 'Well 21', ...
        'Well 22', 'Well 23', 'Well 24'};
end

end
%% heatmap

% --- heatmap button
function pushbutton371_CreateFcn(hObject, eventdata, handles)
hObject.Position = [0.861 0.179 0.096 0.048];
end

% --- Executes on button press in heatmaps
function pushbutton371_Callback(hObject, eventdata, handles)
global layout ans90 HITS selecteddata textstrings parts joost
% figure('units','normalized','outerposition',[0 0 1 1]);
% imagesc(layout,'AlphaData',~isnan(layout));
% % heatmap(layout,ans90,(1:12),true,'Gridlines','-','Colorbar',true,'ShowAllTicks',true,'TickFontSize',30)
% set(gca,'Ytick',[1:12],'Yticklabel',[1:12],'Xtick',[1:12],'XtickLabel', ans90,'Fontsize',20);
% title('Spike Activity over 1 min','Fontsize',30);
% colorbar;

for i = 2:25
    checked =sprintf('Well_%d',i);
    if isempty(regexp(selecteddata,checked))
        continue
    else
        oldname = sprintf('Well_%d',i);
        selecteddata = strrep(selecteddata,oldname,'Well_1');
    end
end



if joost == 1
    range2 = cell(1,24);
    UUU= 1:16;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+16;
    end
else
    range2 = cell(1,24);
    UUU= 1:12;
    for i = 1:24
        range2{i} = UUU;
        UUU=UUU+12;
    end
end


if joost == 1
    HITA = cell(2,384)';
    for i = 1:parts
        load(selecteddata,'HITS')
        HITA(range2{i}(1):range2{i}(end)) = HITS(1:16);
        HITA(range2{i}(1):range2{i}(end),2) = HITS(1:16,2);
        replace1 =sprintf('Well_%d',i);
        replace2 = sprintf('Well_%d',i+1);
        selecteddata = replace(selecteddata,replace1,replace2);
    end
    HITS = HITA;
    
    for i = 1:384
        channelss{i} = num2str(i);
    end
    HITS(:,1) = channelss;
    
else
    HITA = cell(2,288)';
    for i = 1:parts
        load(selecteddata,'HITS')
        HITA(range2{i}(1):range2{i}(end)) = HITS(1:12);
        HITA(range2{i}(1):range2{i}(end),2) = HITS(1:12,2);
        replace1 =sprintf('Well_%d',i);
        replace2 = sprintf('Well_%d',i+1);
        selecteddata = replace(selecteddata,replace1,replace2);
    end
    HITA(:,1) = HITS(:,1);
    channelss = cell(1,288)';
    
    for i = 1:288
        channelss{i} = num2str(i);
        
    end
    
    HITA(:,1) = channelss;
    HITS = HITA;
end

if parts == 12
    %     layout=...
    %    [nan nan HITS{12,2} HITS{11,2} nan nan nan HITS{24,2} HITS{23,2} nan nan nan HITS{36,2} HITS{35,2} nan nan nan HITS{48,2} HITS{47,2} nan nan nan HITS{60,2} HITS{59,2} nan nan nan HITS{72,2} HITS{71,2} nan nan;...
    %     nan HITS{10,2} HITS{9,2} HITS{8,2} HITS{7,2} nan HITS{22,2} HITS{21,2} HITS{20,2} HITS{19,2} nan HITS{34,2} HITS{33,2} HITS{32,2} HITS{31,2} nan HITS{46,2} HITS{45,2} HITS{44,2} HITS{43,2} nan HITS{58,2} HITS{57,2} HITS{56,2} HITS{55,2} nan HITS{70,2} HITS{69,2} HITS{68,2} HITS{67,2} nan;...
    %     nan  HITS{6,2} HITS{5,2} HITS{4,2} HITS{3,2} nan HITS{18,2} HITS{17,2} HITS{16,2} HITS{15,2} nan HITS{30,2} HITS{29,2} HITS{28,2} HITS{27,2} nan HITS{42,2} HITS{41,2} HITS{40,2} HITS{39,2} nan HITS{54,2} HITS{53,2} HITS{52,2} HITS{51,2} nan HITS{66,2} HITS{65,2} HITS{64,2} HITS{63,2} nan;...
    %     nan nan HITS{2,2} HITS{1,2} nan nan nan HITS{14,2} HITS{13,2} nan nan nan HITS{26,2} HITS{25,2} nan nan nan HITS{38,2} HITS{37,2} nan nan nan HITS{50,2} HITS{49,2} nan nan nan HITS{62,2} HITS{61,2} nan nan;...
    %     nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
    %     nan nan HITS{84,2} HITS{83,2} nan nan nan HITS{96,2} HITS{95,2} nan nan nan HITS{108,2} HITS{107,2} nan nan nan HITS{120,2} HITS{119,2} nan nan nan HITS{132,2} HITS{131,2} nan nan nan HITS{144,2} HITS{143,2} nan nan;...
    %     nan HITS{82,2} HITS{81,2} HITS{80,2} HITS{79,2} nan HITS{94,2} HITS{93,2} HITS{92,2} HITS{91,2} nan HITS{106,2} HITS{105,2} HITS{104,2} HITS{103,2} nan HITS{118,2} HITS{117,2} HITS{116,2} HITS{115,2} nan HITS{130,2} HITS{129,2} HITS{128,2} HITS{127,2} nan HITS{142,2} HITS{141,2} HITS{140,2} HITS{139,2} nan;...
    %     nan HITS{78,2} HITS{77,2} HITS{76,2} HITS{75,2} nan HITS{90,2} HITS{89,2} HITS{88,2} HITS{87,2} nan HITS{102,2} HITS{101,2} HITS{100,2}  HITS{99,2} nan HITS{114,2} HITS{113,2} HITS{112,2} HITS{111,2} nan HITS{126,2} HITS{125,2} HITS{124,2} HITS{123,2} nan HITS{138,2} HITS{137,2} HITS{136,2} HITS{135,2} nan;...
    %     nan nan HITS{74,2} HITS{73,2} nan nan nan HITS{86,2} HITS{85,2} nan nan nan HITS{98,2} HITS{97,2} nan nan nan HITS{110,2} HITS{109,2} nan nan nan HITS{122,2} HITS{121,2} nan nan nan HITS{134,2} HITS{133,2} nan nan];
    layout=...
        [nan   nan     HITS{1,2} HITS{2,2} nan       nan nan        HITS{13,2} HITS{14,2} nan        nan nan        HITS{25,2} HITS{26,2} nan        nan nan        HITS{37,2} HITS{38,2} nan        nan nan        HITS{49,2} HITS{50,2} nan        nan nan        HITS{61,2} HITS{62,2} nan nan;...
        nan HITS{3,2} HITS{4,2} HITS{5,2} HITS{6,2} nan HITS{15,2} HITS{16,2} HITS{17,2} HITS{18,2} nan HITS{27,2} HITS{28,2} HITS{29,2} HITS{30,2} nan HITS{39,2} HITS{40,2} HITS{41,2} HITS{42,2} nan HITS{51,2} HITS{52,2} HITS{53,2} HITS{54,2} nan HITS{63,2} HITS{64,2} HITS{65,2} HITS{66,2} nan;...
        nan HITS{7,2} HITS{8,2} HITS{9,2} HITS{10,2} nan HITS{19,2} HITS{20,2} HITS{21,2} HITS{15,2} nan HITS{31,2} HITS{32,2} HITS{33,2} HITS{34,2} nan HITS{43,2} HITS{44,2} HITS{45,2} HITS{46,2} nan HITS{55,2} HITS{56,2} HITS{57,2} HITS{58,2} nan HITS{67,2} HITS{68,2} HITS{69,2} HITS{70,2} nan;...
        nan nan       HITS{11,2} HITS{12,2} nan     nan nan        HITS{23,2} HITS{24,2} nan        nan nan        HITS{35,2} HITS{36,2} nan        nan nan        HITS{47,2} HITS{48,2} nan        nan nan        HITS{59,2} HITS{60,2} nan        nan nan        HITS{71,2} HITS{72,2} nan nan;...
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
        nan nan        HITS{73,2} HITS{74,2} nan        nan nan        HITS{85,2} HITS{86,2} nan        nan nan         HITS{97,2} HITS{98,2} nan         nan nan         HITS{109,2} HITS{110,2} nan         nan nan         HITS{121,2} HITS{122,2} nan         nan nan         HITS{133,2} HITS{134,2} nan nan;...
        nan HITS{75,2} HITS{76,2} HITS{77,2} HITS{78,2} nan HITS{87,2} HITS{88,2} HITS{89,2} HITS{90,2} nan HITS{99,2} HITS{100,2} HITS{101,2} HITS{102,2} nan HITS{111,2} HITS{112,2} HITS{113,2} HITS{114,2} nan HITS{123,2} HITS{124,2} HITS{125,2} HITS{126,2} nan HITS{135,2} HITS{136,2} HITS{137,2} HITS{138,2} nan;...
        nan HITS{79,2} HITS{80,2} HITS{81,2} HITS{82,2} nan HITS{91,2} HITS{92,2} HITS{93,2} HITS{94,2} nan HITS{103,2} HITS{104,2} HITS{105,2}  HITS{106,2} nan HITS{115,2} HITS{116,2} HITS{117,2} HITS{118,2} nan HITS{127,2} HITS{128,2} HITS{129,2} HITS{130,2} nan HITS{139,2} HITS{140,2} HITS{141,2} HITS{142,2} nan;...
        nan nan        HITS{83,2} HITS{84,2} nan        nan nan        HITS{95,2} HITS{96,2} nan        nan nan         HITS{107,2} HITS{108,2}   nan      nan nan         HITS{119,2} HITS{120,2} nan        nan nan         HITS{131,2} HITS{132,2} nan         nan nan         HITS{143,2} HITS{144,2} nan nan];
    
elseif joost == 1 && parts == 24
       layout= [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan HITS{1,2}   HITS{2,2}   HITS{3,2}   HITS{4,2}   nan nan HITS{17,2}  HITS{18,2}  HITS{19,2}  HITS{20,2}  nan nan HITS{33,2}  HITS{34,2}  HITS{35,2}  HITS{36,2}  nan nan HITS{49,2}  HITS{50,2}  HITS{51,2}  HITS{52,2}  nan nan HITS{65,2}  HITS{66,2}  HITS{67,2}  HITS{68,2}  nan nan HITS{81,2}  HITS{82,2}  HITS{83,2}  HITS{84,2}  nan nan;
        nan nan HITS{5,2}   HITS{6,2}   HITS{7,2}   HITS{8,2}   nan nan HITS{21,2}  HITS{22,2}  HITS{23,2}  HITS{24,2}  nan nan HITS{37,2}  HITS{38,2}  HITS{39,2}  HITS{40,2}  nan nan HITS{53,2}  HITS{54,2}  HITS{55,2}  HITS{56,2}  nan nan HITS{69,2}  HITS{70,2}  HITS{71,2}  HITS{72,2}  nan nan HITS{85,2}  HITS{86,2}  HITS{87,2}  HITS{88,2}  nan nan;
        nan nan HITS{9,2}   HITS{10,2}  HITS{11,2}  HITS{12,2}  nan nan HITS{25,2}  HITS{26,2}  HITS{27,2}  HITS{28,2}  nan nan HITS{41,2}  HITS{42,2}  HITS{43,2}  HITS{44,2}  nan nan HITS{57,2}  HITS{58,2}  HITS{59,2}  HITS{60,2}  nan nan HITS{73,2}  HITS{74,2}  HITS{75,2}  HITS{76,2}  nan nan HITS{89,2}  HITS{90,2}  HITS{91,2}  HITS{92,2}  nan nan;
        nan nan HITS{13,2}  HITS{14,2}  HITS{15,2}  HITS{16,2}  nan nan HITS{29,2}  HITS{30,2}  HITS{31,2}  HITS{32,2}  nan nan HITS{45,2}  HITS{46,2}  HITS{47,2}  HITS{48,2}  nan nan HITS{61,2}  HITS{62,2}  HITS{63,2}  HITS{64,2}  nan nan HITS{77,2}  HITS{78,2}  HITS{79,2}  HITS{80,2}  nan nan HITS{93,2}  HITS{94,2}  HITS{95,2}  HITS{96,2}  nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan HITS{97,2}  HITS{98,2}  HITS{99,2}  HITS{100,2} nan nan HITS{113,2} HITS{114,2} HITS{115,2} HITS{116,2} nan nan HITS{129,2} HITS{130,2} HITS{131,2} HITS{132,2} nan nan HITS{145,2} HITS{146,2} HITS{147,2} HITS{148,2} nan nan HITS{161,2} HITS{162,2} HITS{163,2} HITS{164,2} nan nan HITS{177,2} HITS{178,2} HITS{179,2} HITS{180,2} nan nan;
        nan nan HITS{101,2} HITS{102,2} HITS{103,2} HITS{104,2} nan nan HITS{117,2} HITS{118,2} HITS{119,2} HITS{120,2} nan nan HITS{133,2} HITS{134,2} HITS{135,2} HITS{136,2} nan nan HITS{149,2} HITS{150,2} HITS{151,2} HITS{152,2} nan nan HITS{165,2} HITS{166,2} HITS{167,2} HITS{168,2} nan nan HITS{181,2} HITS{182,2} HITS{183,2} HITS{184,2} nan nan;
        nan nan HITS{105,2} HITS{106,2} HITS{107,2} HITS{108,2} nan nan HITS{121,2} HITS{122,2} HITS{123,2} HITS{124,2} nan nan HITS{137,2} HITS{138,2} HITS{139,2} HITS{140,2} nan nan HITS{153,2} HITS{154,2} HITS{155,2} HITS{156,2} nan nan HITS{169,2} HITS{170,2} HITS{171,2} HITS{172,2} nan nan HITS{185,2} HITS{186,2} HITS{187,2} HITS{188,2} nan nan;
        nan nan HITS{109,2} HITS{110,2} HITS{111,2} HITS{112,2} nan nan HITS{125,2} HITS{126,2} HITS{127,2} HITS{128,2} nan nan HITS{141,2} HITS{142,2} HITS{143,2} HITS{144,2} nan nan HITS{157,2} HITS{158,2} HITS{159,2} HITS{160,2} nan nan HITS{173,2} HITS{174,2} HITS{175,2} HITS{176,2} nan nan HITS{189,2} HITS{190,2} HITS{191,2} HITS{192,2} nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan HITS{193,2} HITS{194,2} HITS{195,2} HITS{196,2} nan nan HITS{209,2} HITS{210,2} HITS{211,2} HITS{212,2} nan nan HITS{225,2} HITS{226,2} HITS{227,2} HITS{228,2} nan nan HITS{241,2} HITS{242,2} HITS{243,2} HITS{244,2} nan nan HITS{257,2} HITS{258,2} HITS{259,2} HITS{260,2} nan nan HITS{273,2} HITS{274,2} HITS{275,2} HITS{276,2} nan nan;
        nan nan HITS{197,2} HITS{198,2} HITS{199,2} HITS{200,2} nan nan HITS{213,2} HITS{214,2} HITS{215,2} HITS{216,2} nan nan HITS{229,2} HITS{230,2} HITS{231,2} HITS{232,2} nan nan HITS{245,2} HITS{246,2} HITS{247,2} HITS{248,2} nan nan HITS{261,2} HITS{262,2} HITS{263,2} HITS{264,2} nan nan HITS{277,2} HITS{278,2} HITS{279,2} HITS{280,2} nan nan;
        nan nan HITS{201,2} HITS{202,2} HITS{203,2} HITS{204,2} nan nan HITS{217,2} HITS{218,2} HITS{219,2} HITS{220,2} nan nan HITS{233,2} HITS{234,2} HITS{235,2} HITS{236,2} nan nan HITS{249,2} HITS{250,2} HITS{251,2} HITS{252,2} nan nan HITS{265,2} HITS{266,2} HITS{267,2} HITS{268,2} nan nan HITS{281,2} HITS{282,2} HITS{283,2} HITS{284,2} nan nan;
        nan nan HITS{205,2} HITS{206,2} HITS{207,2} HITS{208,2} nan nan HITS{221,2} HITS{222,2} HITS{223,2} HITS{224,2} nan nan HITS{237,2} HITS{238,2} HITS{239,2} HITS{240,2} nan nan HITS{253,2} HITS{254,2} HITS{255,2} HITS{256,2} nan nan HITS{269,2} HITS{270,2} HITS{271,2} HITS{272,2} nan nan HITS{285,2} HITS{286,2} HITS{287,2} HITS{288,2} nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan HITS{289,2} HITS{290,2} HITS{291,2} HITS{292,2} nan nan HITS{305,2} HITS{306,2} HITS{307,2} HITS{308,2} nan nan HITS{321,2} HITS{322,2} HITS{323,2} HITS{324,2} nan nan HITS{337,2} HITS{338,2} HITS{339,2} HITS{340,2} nan nan HITS{353,2} HITS{354,2} HITS{355,2} HITS{356,2} nan nan HITS{369,2} HITS{370,2} HITS{371,2} HITS{372,2} nan nan;
        nan nan HITS{293,2} HITS{294,2} HITS{295,2} HITS{296,2} nan nan HITS{309,2} HITS{310,2} HITS{311,2} HITS{312,2} nan nan HITS{325,2} HITS{326,2} HITS{327,2} HITS{328,2} nan nan HITS{341,2} HITS{342,2} HITS{343,2} HITS{344,2} nan nan HITS{357,2} HITS{358,2} HITS{359,2} HITS{360,2} nan nan HITS{373,2} HITS{374,2} HITS{375,2} HITS{376,2} nan nan;
        nan nan HITS{297,2} HITS{298,2} HITS{299,2} HITS{300,2} nan nan HITS{313,2} HITS{314,2} HITS{315,2} HITS{316,2} nan nan HITS{329,2} HITS{330,2} HITS{331,2} HITS{332,2} nan nan HITS{345,2} HITS{346,2} HITS{347,2} HITS{348,2} nan nan HITS{361,2} HITS{362,2} HITS{363,2} HITS{364,2} nan nan HITS{377,2} HITS{378,2} HITS{379,2} HITS{380,2} nan nan;
        nan nan HITS{301,2} HITS{302,2} HITS{303,2} HITS{304,2} nan nan HITS{317,2} HITS{318,2} HITS{319,2} HITS{320,2} nan nan HITS{333,2} HITS{334,2} HITS{335,2} HITS{336,2} nan nan HITS{349,2} HITS{350,2} HITS{351,2} HITS{352,2} nan nan HITS{365,2} HITS{366,2} HITS{367,2} HITS{368,2} nan nan HITS{381,2} HITS{382,2} HITS{383,2} HITS{384,2} nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan];
else
  layout=...
        [nan nan HITS{12,2} HITS{11,2} nan nan nan HITS{24,2} HITS{23,2} nan nan nan HITS{36,2} HITS{35,2} nan nan nan HITS{48,2} HITS{47,2} nan nan nan HITS{60,2} HITS{59,2} nan nan nan HITS{72,2} HITS{71,2} nan nan;...
        nan HITS{10,2} HITS{9,2} HITS{8,2} HITS{7,2} nan HITS{22,2} HITS{21,2} HITS{20,2} HITS{19,2} nan HITS{34,2} HITS{33,2} HITS{32,2} HITS{31,2} nan HITS{46,2} HITS{45,2} HITS{44,2} HITS{43,2} nan HITS{58,2} HITS{57,2} HITS{56,2} HITS{55,2} nan HITS{70,2} HITS{69,2} HITS{68,2} HITS{67,2} nan;...
        nan  HITS{6,2} HITS{5,2} HITS{4,2} HITS{3,2} nan HITS{18,2} HITS{17,2} HITS{16,2} HITS{15,2} nan HITS{30,2} HITS{29,2} HITS{28,2} HITS{27,2} nan HITS{42,2} HITS{41,2} HITS{40,2} HITS{39,2} nan HITS{54,2} HITS{53,2} HITS{52,2} HITS{51,2} nan HITS{66,2} HITS{65,2} HITS{64,2} HITS{63,2} nan;...
        nan nan HITS{2,2} HITS{1,2} nan nan nan HITS{14,2} HITS{13,2} nan nan nan HITS{26,2} HITS{25,2} nan nan nan HITS{38,2} HITS{37,2} nan nan nan HITS{50,2} HITS{49,2} nan nan nan HITS{62,2} HITS{61,2} nan nan;...
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
        nan nan HITS{84,2} HITS{83,2} nan nan nan HITS{96,2} HITS{95,2} nan nan nan HITS{108,2} HITS{107,2} nan nan nan HITS{120,2} HITS{119,2} nan nan nan HITS{132,2} HITS{131,2} nan nan nan HITS{144,2} HITS{143,2} nan nan;...
        nan HITS{82,2} HITS{81,2} HITS{80,2} HITS{79,2} nan HITS{94,2} HITS{93,2} HITS{92,2} HITS{91,2} nan HITS{106,2} HITS{105,2} HITS{104,2} HITS{103,2} nan HITS{118,2} HITS{117,2} HITS{116,2} HITS{115,2} nan HITS{130,2} HITS{129,2} HITS{128,2} HITS{127,2} nan HITS{142,2} HITS{141,2} HITS{140,2} HITS{139,2} nan;...
        nan HITS{78,2} HITS{77,2} HITS{76,2} HITS{75,2} nan HITS{90,2} HITS{89,2} HITS{88,2} HITS{87,2} nan HITS{102,2} HITS{101,2} HITS{100,2}  HITS{99,2} nan HITS{114,2} HITS{113,2} HITS{112,2} HITS{111,2} nan HITS{126,2} HITS{125,2} HITS{124,2} HITS{123,2} nan HITS{138,2} HITS{137,2} HITS{136,2} HITS{135,2} nan;...
        nan nan HITS{74,2} HITS{73,2} nan nan nan HITS{86,2} HITS{85,2} nan nan nan HITS{98,2} HITS{97,2} nan nan nan HITS{110,2} HITS{109,2} nan nan nan HITS{122,2} HITS{121,2} nan nan nan HITS{134,2} HITS{133,2} nan nan;...
        nan nan nan  nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
        nan nan HITS{156,2} HITS{155,2} nan nan nan HITS{168,2} HITS{167,2} nan nan nan HITS{180,2} HITS{179,2} nan nan nan HITS{192,2} HITS{191,2} nan nan nan HITS{204,2} HITS{203,2} nan nan nan HITS{216,2} HITS{215,2} nan nan;...
        nan HITS{154,2} HITS{153,2} HITS{152,2} HITS{151,2} nan HITS{166,2} HITS{165,2} HITS{164,2} HITS{163,2} nan HITS{178,2} HITS{177,2} HITS{176,2} HITS{175,2} nan HITS{190,2} HITS{189,2} HITS{188,2} HITS{187,2} nan HITS{202,2} HITS{201,2} HITS{200,2} HITS{199,2} nan HITS{214,2} HITS{213,2} HITS{212,2} HITS{211,2} nan;...
        nan HITS{150,2} HITS{149,2} HITS{148,2} HITS{147,2} nan HITS{162,2} HITS{161,2} HITS{160,2} HITS{159,2} nan HITS{174,2} HITS{173,2} HITS{172,2} HITS{171,2} nan HITS{186,2} HITS{185,2} HITS{184,2} HITS{183,2} nan HITS{198,2} HITS{197,2} HITS{196,2} HITS{195,2} nan HITS{210,2} HITS{209,2} HITS{208,2} HITS{207,2} nan;...
        nan nan HITS{146,2} HITS{145,2} nan nan nan HITS{158,2} HITS{157,2} nan nan nan HITS{170,2} HITS{169,2} nan nan nan HITS{182,2} HITS{181,2} nan nan nan HITS{194,2} HITS{193,2} nan nan nan HITS{206,2} HITS{205,2} nan nan;...
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
        nan nan HITS{228,2} HITS{227,2} nan nan nan HITS{240,2} HITS{239,2} nan nan nan HITS{252,2} HITS{251,2} nan nan nan HITS{264,2} HITS{263,2} nan nan nan HITS{276,2} HITS{275,2} nan nan nan HITS{288,2} HITS{287,2} nan nan;
        nan HITS{226,2} HITS{225,2} HITS{224,2} HITS{223,2} nan HITS{238,2} HITS{237,2} HITS{236,2} HITS{235,2} nan HITS{250,2} HITS{249,2} HITS{248,2} HITS{247,2} nan HITS{262,2} HITS{261,2} HITS{260,2} HITS{259,2} nan HITS{274,2} HITS{273,2} HITS{272,2} HITS{271,2} nan HITS{286,2} HITS{285,2} HITS{284,2} HITS{283,2} nan;...
        nan HITS{222,2} HITS{221,2} HITS{220,2} HITS{219,2} nan HITS{234,2} HITS{233,2} HITS{232,2} HITS{231,2} nan HITS{246,2} HITS{245,2} HITS{244,2} HITS{243,2} nan HITS{258,2} HITS{257,2} HITS{256,2} HITS{255,2} nan HITS{270,2} HITS{269,2} HITS{268,2} HITS{267,2} nan HITS{282,2} HITS{281,2} HITS{280,2} HITS{279,2} nan;...
        nan nan HITS{218,2} HITS{217,2} nan nan nan HITS{230,2} HITS{229,2} nan nan nan HITS{242,2} HITS{241,2} nan nan nan HITS{254,2} HITS{253,2} nan nan nan HITS{266,2} HITS{265,2} nan nan nan HITS{278,2} HITS{277,2} nan nan];
end


figure('units','normalized','outerposition',[0 0 1 1]);



%// Define integer grid of coordinates for the above data
[X,Y] = meshgrid(1:size(layout,2), 1:size(layout,1));

%// Define a finer grid of points
[X88,Y88] = meshgrid(1:0.01:size(layout,2), 1:0.01:size(layout,1));

%// Interpolate the data and show the output
outData = interp2(X,Y,layout, X88, Y88,'linear');

nanvalues=isnan(outData);

layout44=layout;


for i=1:length(layout(:,1))
    for j=1:length(layout(1,:))
        if isnan(layout(i,j))
            layout44(i,j)= 0;
        else
        end
    end
end

%// Interpolate the data and show the output
outData = interp2(X,Y,layout44, X88, Y88,'cubic');

outData(nanvalues)=nan;


imagesc(outData,'AlphaData',~isnan(outData));
%imagesc(layout,'AlphaData',~isnan(layout));
mycolormap = parula(256);
mycolormap(1,:) = 1;
colormap(mycolormap);
if joost == 1
%     textstrings={...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] '1'  '5' '9'  '13'  [] [] '97'  '101' '105' '109'  [] [] '193' '197' '201' '205' [] [] '289' '293' '297' '301' [] []...
%         [] [] '2'  '6' '10' '14'  [] [] '98'  '102' '106' '110'  [] [] '194' '198' '202' '206' [] [] '290' '294' '298' '302' [] []...
%         [] [] '3'  '7' '11' '15'  [] [] '99'  '103' '107' '111'  [] [] '195' '199' '203' '207' [] [] '291' '295' '299' '303' [] []...
%         [] [] '4'  '8' '12' '16'  [] [] '100' '104' '108' '112'  [] [] '196' '200' '204' '208' [] [] '292' '296' '300' '304' [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] '17' '21' '25' '29' [] [] '113'  '117' '121' '125' [] [] '209' '213' '217' '221' [] [] '305' '309' '313' '317' [] []...
%         [] [] '18' '22' '26' '30' [] [] '114'  '118' '122' '126' [] [] '210' '214' '218' '222' [] [] '306' '310' '314' '318' [] []...
%         [] [] '19' '23' '27' '31' [] [] '115'  '119' '123' '127' [] [] '211' '215' '219' '223' [] [] '307' '311' '315' '319' [] []...
%         [] [] '20' '24' '28' '32' [] [] '116'  '120' '124' '128' [] [] '212' '216' '220' '224' [] [] '308' '312' '316' '320' [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] '33' '37' '41' '45' [] [] '129'  '133' '137' '141' [] [] '225' '229' '233' '237' [] [] '321' '325' '329' '333' [] []...
%         [] [] '34' '38' '42' '46' [] [] '130'  '134' '138' '142' [] [] '226' '230' '234' '238' [] [] '322' '326' '330' '334' [] []...
%         [] [] '35' '39' '43' '47' [] [] '131'  '135' '139' '143' [] [] '227' '231' '235' '239' [] [] '323' '327' '331' '335' [] []...
%         [] [] '36' '40' '44' '48' [] [] '132'  '136' '140' '144' [] [] '228' '232' '236' '240' [] [] '324' '328' '332' '336' [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] '49' '53' '57' '61' [] [] '145' '149' '153' '157'  [] [] '241' '245' '249' '253' [] [] '337' '341' '345' '349' [] []...
%         [] [] '50' '54' '58' '62' [] [] '146' '150' '154' '158'  [] [] '242' '246' '250' '254' [] [] '338' '342' '346' '350' [] []...
%         [] [] '51' '55' '59' '63' [] [] '147' '151' '155' '159'  [] [] '243' '247' '251' '255' [] [] '339' '343' '347' '351' [] []...
%         [] [] '52' '56' '60' '64' [] [] '148' '152' '156' '160'  [] [] '244' '248' '252' '256' [] [] '340' '344' '348' '352' [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] '65' '69' '73' '77' [] [] '161' '165' '169' '173'  [] [] '257' '261' '265' '269' [] [] '353' '357' '361' '365' [] []...
%         [] [] '66' '70' '74' '78' [] [] '162' '166' '170' '174'  [] [] '258' '262' '266' '270' [] [] '354' '358' '362' '366' [] []...
%         [] [] '67' '71' '75' '79' [] [] '163' '167' '171' '175'  [] [] '259' '263' '267' '271' [] [] '355' '359' '363' '367' [] []...
%         [] [] '68' '72' '76' '80' [] [] '164' '168' '172' '176'  [] [] '260' '264' '268' '272' [] [] '356' '360' '364' '368' [] []...
%         [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] '81' '85' '89' '93' [] [] '177' '181' '185' '189'  [] [] '273' '277' '281' '285' [] [] '369' '373' '377' '381' [] []...
%         [] [] '82' '86' '90' '94' [] [] '178' '182' '186' '190'  [] [] '274' '278' '282' '286' [] [] '370' '374' '378' '382' [] []...
%         [] [] '83' '87' '91' '95' [] [] '179' '183' '187' '191'  [] [] '275' '279' '283' '287' [] [] '371' '375' '379' '383' [] []...
%         [] [] '84' '88' '92' '96' [] [] '180' '184' '188' '192'  [] [] '276' '280' '284' '288' [] [] '372' '376' '380' '384' [] []...
%         [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
%         [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []}';

else
  textstrings={...
    [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
    [] '3' '7' [] [] [] '75' '79' [] [] [] '147' '151' [] [] [] '219' '223' [] ...
    '1' '4' '8' '11' [] '73' '76' '80' '83' [] '145' '148' '152' '155' [] '217' '220' '224' '227' ...
    '2' '5' '9' '12' [] '74' '77' '81' '84' [] '146' '149' '153' '156' [] '218' '221' '225' '228' ...
    [] '6' '10' [] [] [] '78' '82' [] [] [] '150' '154' [] [] [] '222' '226' [] ...
    [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
    [] '15' '19' [] [] [] '87' '91' [] [] [] '159' '163' [] [] [] '231' '235' [] ...
    '13' '16' '20' '23' [] '85' '88' '92' '95' [] '157' '160' '164' '167' [] '229' '232' '236' '239' ...
    '14' '17' '21' '24' [] '86' '89' '93' '96' [] '158' '161' '165' '168' [] '230' '233' '237' '240' ...
    [] '18' '22' [] [] [] '90' '94' [] [] [] '162' '166' [] [] [] '234' '238' [] ...
    [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
    [] '27' '31' [] [] [] '99' '103' [] [] [] '171' '175' [] [] [] '243' '247' [] ...
    '25' '28' '32' '35' [] '97' '100' '104' '107' [] '169' '172' '176' '179' [] '241' '244' '248' '251' ...
    '26' '29' '33' '36' [] '98' '101' '105' '108' [] '170' '173' '177' '180' [] '242' '245' '249' '252' ...
    [] '30' '34' [] [] [] '102' '106' [] [] [] '174' '178' [] [] [] '246' '250' [] ...
    [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
    [] '39' '43' [] [] [] '111' '115' [] [] [] '183' '187' [] [] [] '255' '259' [] ...
    '37' '40' '44' '47' [] '109' '112' '116' '119' [] '181' '184' '188' '191' [] '253' '256' '260' '263' ...
    '38' '41' '45' '48' [] '110' '113' '117' '120' [] '182' '185' '189' '192' [] '254' '257' '261' '264' ...
    [] '42' '46' [] [] [] '114' '118' [] [] [] '186' '190' [] [] [] '258' '262' [] ...
    [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
    [] '51' '55' [] [] [] '123' '127' [] [] [] '195' '199' [] [] [] '267' '271' [] ...
    '49' '52' '56' '59' [] '121' '124' '128' '131' [] '193' '196' '200' '203' [] '265' '268' '272' '275' ...
    '50' '53' '57' '60' [] '122' '125' '129' '132' [] '194' '197' '201' '204' [] '266' '269' '273' '276' ...
    [] '54' '58' [] [] [] '126' '130' [] [] [] '198' '202' [] [] [] '270' '274' [] ...
    [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
    [] '63' '67' [] [] [] '135' '139' [] [] [] '207' '211' [] [] [] '279' '283' [] ...
    '61' '64' '68' '71' [] '133' '136' '140' '143' [] '205' '208' '212' '215' [] '277' '280' '284' '287' ...
    '62' '65' '69' '72' [] '134' '137' '141' '144' [] '206' '209' '213' '216' [] '278' '281' '285' '288' ...
    [] '66' '70' [] [] [] '138' '142' [] [] [] '210' '214' [] [] [] '282' '286' [] ...
    [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []}';


[x, y] = meshgrid(1:38);
for i=31:-1:20
    x(i,:)=[];
    y(i,:)=[];
end
hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
    'HorizontalAlignment', 'center');

end

%// Cosmetic changes for the axes
set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
set(gca, 'XTickLabel', 1:size(X,2));
set(gca, 'YTickLabel', 1:size(X,1));

%// Add colour bar
colorbar;
% heatmap(layout,ans90,(1:12),true,'Gridlines','-','Colorbar',true,'ShowAllTicks',true,'TickFontSize',30)


if joost == 1
    ans90 = cell(1,length(layout));
    ans90{4} = '2';
    ans90{10} = '3';
    ans90{16} = '4';
    ans90{22} = '5';
    ans90{28} = '6';
    ans90{34} = '7';
    ans91 = cell(1,length(layout(:,1)));
    ans91{4} = 'B';
    ans91{10} = 'C';
    ans91{16} = 'D';
    ans91{22} = 'E';
    set(gca,'XtickLabel', ans90,'Fontsize',20);
    set(gca,'YtickLabel', ans91,'Fontsize',20);
else
    set(gca,'XtickLabel', ans90,'Fontsize',20);
end
title('Multi-Well Activity over 10 min','Fontsize',30);
set(gcf,'Color','w');

end
%% save and load buttons
% --- Executes on button press analyze again
% save
function pushbutton372_Callback(hObject, eventdata, handles)
global flag
current=pwd;
addpath(current);
if flag == 1
    run('justspiketimes')
elseif flag == 0
    run('MEAToolboxV3')
end
end


% --- Executes on button press in load
function pushbutton373_Callback(hObject, eventdata, handles)
global selecteddata filteredData1 multiwell1

clearvars 
[selecteddata,folder]=uigetfile('data.mat');
if folder == 0
    return
else
    f = waitbar(0,'Loading File...');
    addpath(folder);
    load(selecteddata);
    waitbar(.5,f,'Loading your data');

    waitbar(1,f,'Loading Complete');
    close(f)
    if multiwell1 == 1
     
        close();
        multiwell
    else
    
        close();
        MEA_Data_Plots2
    end
end

end
%% removal of channels
% --- Executes on button press in to remove channels
function pushbutton374_Callback(hObject, eventdata, handles)
global HITS M2 burst6 burst7 xpoints ypoints T electrodecount parts selecteddata merge_t Exburst M88 logburst burst6indx burst7indx ISI58 unitpersecond Spikeform3 Spikeform4 timesss fs
error1 = errordlg('The selected channel will be permanently removed and if you want to regain the deleted data, the analysis will have to be redone','Warning!!!');
uiwait(error1)
prompt = {'Enter Channel name for removal'};
title = 'Annihilation of Artifacts';
dims = [1 75];
definput = {'1'};
Totoro = inputdlg(prompt,title,dims,definput);
if isempty(Totoro)
    return
end

Imax=find(strcmp(HITS,Totoro{1}));
correctwell = ceil(Imax/electrodecount); %we found the correct well
INDEX2 = ceil((((Imax/electrodecount) - (correctwell - 1))*electrodecount)-0.000001); % the -0.0000001 is for cases when the number is an whole number like 6.00 so it decreaseses the number for the ceil to work correctly
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',correctwell));

load(selecteddata,'HITS')
load(selecteddata,'M2')
load(selecteddata,'T')
load(selecteddata,'burst6')
load(selecteddata,'burst7')
load(selecteddata,'xpoints')
load(selecteddata,'ypoints')
load(selecteddata,'M88')
load(selecteddata,'burst6indx')
load(selecteddata,'burst7indx')
load(selecteddata,'Exburst')
load(selecteddata,'ISI58')
load(selecteddata,'logburst')
load(selecteddata,'unitpersecond')
load(selecteddata,'Spikeform3')
load(selecteddata,'Spikeform4')

%delete it in HITS and M2 burst6 and burst7 and xpoints and T
HITS{INDEX2,2} = 0;
M2{INDEX2} = [];
ColIndex = find(strcmp(T.Properties.RowNames,Totoro{1}), 1);
T(ColIndex,:) =[];

% recreate variable T



if iscell(T.mean_ISI(1:end-1))
    T.mean_ISI{end} = sum(cell2mat(T.mean_ISI(1:end-1)))/(size(T,1)-1);
else
    T.mean_ISI(end) = sum(T.mean_ISI(1:end-1))/(size(T,1)-1);
end


if iscell(T.std_ISI(1:end-1))
    T.std_ISI{end} = sum(cell2mat(T.std_ISI(1:end-1)))/(size(T,1)-1);
else
    T.std_ISI(end) = sum(T.std_ISI(1:end-1))/(size(T,1)-1);
end

T.Spikes(end) = sum(T.Spikes(1:end-1))/(size(T,1)-1);
T.median_ISI(end) = sum(T.median_ISI(1:end-1))/(size(T,1)-1);
T.Bursts_max_interval(end) = sum(T.Bursts_max_interval(1:end-1))/(size(T,1)-1);
T.Bursts_log_ISI(end) = sum(T.Bursts_log_ISI(1:end-1))/(size(T,1)-1);
T.Fire_rate(end) = sum(T.Fire_rate(1:end-1))/(size(T,1)-1);
T.mean_ifr(end) = sum(T.mean_ifr(1:end-1))/(size(T,1)-1);
T.mean_CV_ISI(end) = sum(T.mean_CV_ISI(1:end-1))/(size(T,1)-1);
T.mean_CV2_ISI(end) = sum(T.mean_CV2_ISI(1:end-1))/(size(T,1)-1);
T.threshold_value(end) = sum(T.threshold_value(1:end-1))/(size(T,1)-1);

xpoints(find(ypoints==INDEX2)) = [];
ypoints(ypoints ==INDEX2) =[];
burst6{INDEX2} = [];
burst7{INDEX2} = [];
merge_t(INDEX2,:) = [];
M88{INDEX2} =[];
if isempty(Exburst{INDEX2}.number_of_bursts)
else
    Exburst{INDEX2}.number_of_bursts =[];
    Exburst{INDEX2}.duration_of_bursts =[];
    Exburst{INDEX2}.spikes_of_bursts =[];
    Exburst{INDEX2}.fr_of_bursts =[];
    Exburst{INDEX2}.mean_ISI_bursts =[];
    Exburst{INDEX2}.std_ISI_bursts =[];
    Exburst{INDEX2}.IBI =[];
end
if isempty(logburst{INDEX2}.number_of_bursts)
    logburst{INDEX2}.number_of_bursts =[];
    logburst{INDEX2}.duration_of_bursts =[];
    logburst{INDEX2}.spikes_of_bursts =[];
    logburst{INDEX2}.fr_of_bursts =[];
    logburst{INDEX2}.mean_ISI_bursts =[];
    logburst{INDEX2}.std_ISI_bursts =[];
end
burst6indx{INDEX2} =[];
burst7indx{INDEX2}=[];
ISI58{INDEX2} =[];
unitpersecond{INDEX2} =zeros(1,length(unitpersecond{INDEX2}));
Spikeform4{INDEX2} = 0;
Spikeform3{INDEX2}=0;
for i = 61:288
    HITS{i,1} = num2str(HITS{i,1});
end

% set the deleted channel to white
set(handles.(sprintf('togglebutton%s',HITS{Imax,1})),'BackgroundColor',[1 1 1]);
promptMessage = sprintf('Please Wait (this message will disappear when finished)');
button = msgbox(promptMessage);
% save(selecteddata,'HITS','xpoints','ypoints','M2','burst6','burst7','T','-append');
delete(button)
% addpath(which(selecteddata))

%% rerun network burst detection

 
        starttimesbursts2 = [];
        for i = 1:length(burst6)
            for j = 1:length(burst6{i})
                starttimesbursts = burst6{i}{j}(1);
                starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
            end
        end
        
        uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes
        
        %now we need to put all the times in a giant matrix so we can
        %search in this matrix with the unique burst start times
        
        %convert all the cells into vectors
        % all the vectors are made equal in length by adding in nans
        temp = cell(1,length(burst6))';
        for i = 1:length(burst6)
            temp{i} = cell2mat(burst6{i});
        end
        
        newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
        newc=cell2mat(newc);
        
        
        % now we need to find if there are multiple channels that start
        % bursting at the same time
        channelnumbernnbursts =cell(1,length(burst6))';
        timeofnnbursts =cell(1,length(burst6))';
        for i = 1:length(uniquestarttimesbursts)
            [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) - fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) + fs.networkburstdetection.synchronizedtimewindow );
        end
        
        
         
          
            % check for duplicate channelnumbers if so remove them
            for i =1:length(channelnumbernnbursts)
                if isempty(channelnumbernnbursts{i})
                else
                    if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                          channelnumbernnbursts{i} = [];
                        timeofnnbursts{i}=[];
                    else
                      
                    end
                end
            end
            
            
        
        % now that we the channels that are synchronzied in their bursting
        % we need to remove the channels that do not fullfull our
        % requirements of have atleast 2 synchronized channels and atleast
        % 50% of the otal amount of channels should participate in the
        % nnburst or else it gets removed
        
        
        for i = 1:length(channelnumbernnbursts)
            if length(channelnumbernnbursts{i}) <  fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                channelnumbernnbursts{i} = [];
                timeofnnbursts{i} = [];
                uniquestarttimesbursts(i) = nan;
            end
        end
        
        %clean up by removing empty cells and nan values
        uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
        channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
        timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
        
        % now we need to find the bursts that are part of the synchronized
        % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
        % synchronzied bursts in other channels and then we can see how
        % many channels are participating
        
        burst6length =burst6; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
        for i = 1:length(burst6)
            for j = 1:length(burst6{i})
                burst6length{i}{j} = length(burst6{i}{j});
            end
        end
        
        for i = 1:length(burst6) % convert the cell arrays in vectors
            burst6length{i} = cell2mat(burst6length{i});
        end
        
        
        potentialnnbursts = cell(1,length(channelnumbernnbursts))';
        burstsindexcount=[];
        for i = 1:length(potentialnnbursts)
            for j = 1:length(channelnumbernnbursts{i})
                for k = 1:cellfun(@length,(burst6(channelnumbernnbursts{i}(j))))
                    %figure out which bursts the indexes belong to
                    
                    %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
                    %                      burstsindexcount = cumsum( burstsindexcount); % old version
                    burstsindexcount = cumsum( burst6length{channelnumbernnbursts{i}(j)});
                    if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                        correctburst = k;
                        potentialnnbursts{i}{j} = burst6{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                        break
                    end
                end
            end
        end
        
        % we have to check if the times of the bursts are within
        % acceptable ranges
        
        % create variable that is the exact same varible as potentialnnbursts
        % but intead each cell contains the mean + std of that channel to
        % improve the speed
        
        potentialnnburstsmean = potentialnnbursts;
        for i =1 :length(potentialnnbursts)
            potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 25*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
        end
        
        for i = 1:length(potentialnnbursts)
            for j = 1:length(potentialnnbursts{i})
                %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                    potentialnnbursts{i}{j} = [];
                end
            end
        end
        
        
        % now we need to use the synscho bursts to find if there are bursts that
        % fall within the same duration as the synchronized bursts. if they do then
        % they are part of the  potential network bursts
        % we loop through both synchronized bursts just to extra certain we do not
        % miss anything because the starttimes might be the same but the ending
        % time might not be.
        
        mergeburstchannel = cell(1,length(potentialnnbursts))';
        mergeburstnumber  = cell(1,length(potentialnnbursts))';
        tobemergedbursts  = cell(1,length(potentialnnbursts))';
        
        % create vaiable of potneialnnbursts that have all the cells converted into
        % vectors to improve the performance
        potentialnnburstsvector = potentialnnbursts;
        potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
        
        for i = 1:length(potentialnnburstsvector)
            potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
            potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
        end
        
        for i =1:length(potentialnnbursts)
            for k = 1:length(burst6)
                for l = 1:length(burst6{k})
                    if ~isempty(find(burst6{k}{l} > potentialnnburstsvector{i,2}(1) & burst6{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                        tobemergedbursts{i}{k} =cell2mat(burst6{k}(l)) ;
                        mergeburstchannel{i}{k} = k;
                        mergeburstnumber{i}{k} = l;
                    end
                end
            end
        end
        
        % clean up the empty  cells
        
        for i =1:length(tobemergedbursts)
            tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
            mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
            mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
        end
        
        %now we need remove the nnbursts that have less than 50% of the whole wwell
        %participating in the nnbursts
        
        % find the number of active channels
       amountactivechannels = length(find(~cellfun(@isempty,M2)));
        
        mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
        tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
        mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
        % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
        % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
        % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
        
        %the last step is to find duplicates and merge them together
        findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
        
        for i = 1:length(tobemergedbursts)
            findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
        end
        
        
        
        
        
        for i = 1:length(tobemergedbursts)
            if isempty(findoverlappingnnbursts{i})
                continue
            else
                for k = 2:length(tobemergedbursts)
                    if isempty(findoverlappingnnbursts{k}) || k == i
                        continue
                    else
                        if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                            % if this is true than there is overlap. so we need to find out
                            % which one is longer and that will be the one remaining.
                            if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                findoverlappingnnbursts{k} = [];
                            else
                                findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                findoverlappingnnbursts{k} = [];
                            end
                        else
                            
                            
                        end
                    end
                end
            end
        end
        
        
        %lets use logical indezing to get rid of the overlapping nnbursts and
        %finally get our actual nnbursts
        
        tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
        mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
        mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
        findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
        
        % now that we have our nnbursts we can extract the ifnroamtion about the
        % nnbursts
        
        %struct for networkbursts
        networkburstttt =[];
        for i = 1:length(mergeburstnumber)
            
            networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
            networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
            networkburstttt.amount = length(mergeburstnumber);
            networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
            networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
            networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
            networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
        end
        
        for i = 1:length(mergeburstnumber)
            if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                networkburstttt.IBI(i,1) = 0;
                continue
            else
                networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
            end
        end
        
        % added the CV of IBI of nnbursts
        if isempty(networkburstttt)
            networkburstttt.starttime = 0;
            networkburstttt.endtime = 0;
            networkburstttt.amount = 0;
            networkburstttt.duration = 0;
            networkburstttt.spikesfr_in_nbursts = 0;
            networkburstttt.nburst_rate = 0;
            networkburstttt.ISI = 0;
            networkburstttt.IBI = 0;
            networkburstttt.CVIBI= 0;
        else
            networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
        end






save(selecteddata,'HITS','M2','T','burst6','burst7','xpoints','ypoints','M88','burst6indx','burst7indx','Exburst','logburst','unitpersecond','Spikeform3','Spikeform4','-append')

end
%% old 

% --- Executes on button press inconnectivity maps
function pushbutton375_Callback(hObject, eventdata, handles)
global Ghibli newM2 textstrings


prompt = {'Enter Channel name A:','Enter Channel name B:'};
title = 'Connectivity Map';
dims = [1 35];
definput = {'A1','A2'};
jitters = inputdlg(prompt,title,dims,definput);
Ghibli(1)=find(strcmp(textstrings(:,1),jitters(1)));
Ghibli(2)=find(strcmp(textstrings(:,1),jitters(2)));


list = {'Cross Correlation','Spike Time'};
[indx23,~] = listdlg('PromptString','Select a Method','SelectionMode','single','ListString',list);


if isempty(newM2{Ghibli(1)})
    promptMessage =sprintf('You have chosen an empty channel!');
    button = questdlg(promptMessage, 'Rerun', 'Rerun', 'Terminate', 'Rerun');
    if strcmpi(button, 'Terminate')
        close(connectivityreal1)
    else
        prompt = {'Channel name A:','Enter Channel name B:'};
        title = 'Connectivity Map';
        dims = [1 35];
        definput = {'1','2'};
        jitters = inputdlg(prompt,title,dims,definput);
        Ghibli(1)=find(strcmp(textstrings(:,1),jitters(1)));
        Ghibli(2)=find(strcmp(textstrings(:,1),jitters(2)));
    end
elseif isempty(newM2{Ghibli(2)})
    promptMessage =sprintf('You have chosen an empty channel!');
    button = questdlg(promptMessage, 'Rerun', 'Rerun', 'Terminate', 'Rerun');
    if strcmpi(button, 'Terminate')
        
    else
        prompt = {'Channel name A:','Enter Channel name B:'};
        title = 'Connectivity Map';
        dims = [1 35];
        definput = {'1','2'};
        jitters = inputdlg(prompt,title,dims,definput);
        Ghibli(1)=find(strcmp(textstrings(:,1),jitters(1)));
        Ghibli(2)=find(strcmp(textstrings(:,1),jitters(2)));
    end
    
else
end



connectivityreal1;
end


% --- Executes on button press in pushbutton376.
function pushbutton376_Callback(hObject, eventdata, handles)
global Bap
figure;
uitable('Data',Bap{:,:},'ColumnName',Bap.Properties.VariableNames,...
    'RowName',Bap.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
end


% --- Executes on button press in pushbutton377.
function pushbutton377_Callback(hObject, eventdata, handles)
global Bal
figure;
uitable('Data',Bal{:,:},'ColumnName',Bal.Properties.VariableNames,...
    'RowName',Bal.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
end
%% tables
% --- Executes during object creation, after setting all properties.
function uitable1_CreateFcn(hObject, eventdata, handles)
global T Bak Bab BI GG joost parts selecteddata merge_t
hObject.Visible= 'off';


    
    for i = 2:25
        checked =sprintf('Well_%d',i);
        if contains(selecteddata,'Well')
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        else
            selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
        end
    end
    
    
    for i = 1:parts
        load(selecteddata,'T')
        T.mean_ISI = cell2mat(T.mean_ISI);
        T.std_ISI = cell2mat(T.std_ISI);
        TT = T(1:end-1,:);
        if i == 1
            merge_t = TT;
        else
            merge_t = [merge_t;TT];
        end
        replace1 =sprintf('Well_%d',i);
        replace2 = sprintf('Well_%d',i+1);
        selecteddata = replace(selecteddata,replace1,replace2);
    end
    
    % add new sum at the end of the table
    
%     newsum = T(end,:);
%     for i = 1:width(T)
%         newsum.(i) = mean( merge_t.(i));
%     end
%     
%     merge_t = [merge_t;newsum];
%     
    
    % sorting it correctly using natsort
   [~,correctindxx,~] = natsort(merge_t.Properties.RowNames);
    merge_t3=[];
    for i = 1:size(merge_t,1)
        j = correctindxx(i);
        merge_t2 = merge_t(j,:);
        merge_t3 = [merge_t3;merge_t2];
    end
    
    merge_t = merge_t3;
    
    
    GG=hObject;
    % h=findobj('Tag','uitable10');
    
%     hObject.Data{1,1}=num2str(merge_t.Spikes(end));
%     hObject.Data{1,2}=num2str(merge_t.pospeaks(end));
%     hObject.Data{1,3}=num2str(merge_t.Truehits(end));
%     hObject.Data{1,4}=num2str(merge_t.number_of_bursts1(end));
%     hObject.Data{1,5}=num2str(merge_t.number_of_burstsNeuroEx(end));
%     hObject.Data{1,6}=num2str(merge_t.number_of_burstslog(end));
%     hObject.Data{1,7}=num2str(Bak.activeelecamount);
%     hObject.Data{1,8}=num2str(Bab.silentelecamount);
    %     hObject.Data{1,9}=num2str(.BI);

end

% --- Executes during object creation, after setting all properties.
function pushbutton380_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
end
% --- Executes on button press save table
function pushbutton380_Callback(hObject, eventdata, handles)
global GG merge_t

%
% yeeha=str2double(GG.Data);
% yeehat=table(yeeha(1,1),yeeha(1,2),yeeha(1,3),yeeha(1,4),yeeha(1,5),yeeha(1,6),yeeha(1,7),yeeha(1,8),yeeha(1,9),'VariableNames',{'Neg_Units', 'Pos_Units', 'Com_Units', 'Bursts', 'Bursts_Max', 'Bursts_LogISI', 'Active_Electrodes', 'Silent_Electrodes','BI'});

try
    filter={'*.xlsx'};
    % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
    writetable(merge_t,uiputfile(filter),'WriteRowNames',true);
catch
end
end
%% others/neural endpoints

% --- Executes during object creation, after setting all properties.
function pushbutton381_CreateFcn(hObject, eventdata, handles)
hObject.String = 'Neuro Endpoints';
end

% --- Executes on button press in neural endpoints
function pushbutton381_Callback(hObject, eventdata, handles)

global looo12 selecteddata total17 total16 X2 M2 cbx32 arrayfiringrate filteredData1 Exburst semfiringrate meanfiringrate meantotal1 semtotal1 meantotal2 semtotal2 meantotal3 semtotal3 meantotal4 semtotal4 meantotal5 semtotal5 meantotal6 semtotal6 meantotal13 semtotal13 meantotal15 semtotal15 files timesss divdate

localpath=pwd;
addpath(localpath);
message1=sprintf('If your analyzed files are not placed in one folder then please press Terminate otherwise press Continue');
button = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');
if isempty(button)
    return
end

if strcmpi(button, 'Continue')
    correctfolder=uigetdir; %lets the user select  a folder for analysis
    cd(correctfolder) ; %change the current folder to the user slected one
    files = dir('*.mat');
    
    %preallocation
    total2=cell(1,length(files));
    total3=cell(1,length(files));
    total4=cell(1,length(files));
    total1=cell(1,length(files));
    total5=cell(1,length(files));
    total6=cell(1,length(files));
    total13=cell(1,length(files));
    total15=cell(1,length(files));
    arrayfiringrate = cell(1,length(files));
    total16=cell(1,length(files));
    total17=cell(1,length(files));
    h = waitbar(0,'Collecting all files');
    
   
    
    for i=1:length(files)
        waitbar(i/length(files))
        selecteddata1=files(i).name;
        total1{i}=load(selecteddata1,'HITS');
        ppp=cell2mat(total1{i}.HITS(:,2));
        ppp=sum(ppp);
        total1{i}=ppp;

        total3{i}=load(selecteddata1,'BLog');
        total3{i}=total3{i}.BLog;
        
        total4{i}=load(selecteddata1,'BNeuro');
        total4{i}=total4{i}.BNeuro;
        
        total5{i}=load(selecteddata1,'negunits');
        total5{i}=total5{i}.negunits;
        
        total6{i}=load(selecteddata1,'posunits');
        total6{i}=total6{i}.posunits;
        
        total13{i}=load(selecteddata1,'Connections');
        total13{i}=total13{i}.Connections;
        
        total15{i}=load(selecteddata1,'timesss');
        total15{i}=total15{i}.timesss;
        
        total16{i}=load(selecteddata1,'Exburst');
        
        total17{i} = load(selecteddata1,'M2');
        
        arrayfiringrate{i} = load(selecteddata1,'T');
        if arrayfiringrate{i}.T.Fire_rate(end) == inf
            arrayfiringrate{i} = arrayfiringrate{i}.T.Fire_rate(1);
        else
            arrayfiringrate{i} = arrayfiringrate{i}.T.Fire_rate(end);
            % arrayfiringrate{i} = mean(arrayfiringrate{i}.T.maxamplitude_in_volt(1:end-1));
            
        end
        
    end
    close(h)
    %Units_per_second
    %adjust total16 for burst statistics
    %first remove any empty structs
    for j=1:length(total16)
        for i =1:length(Exburst)
            if isempty(total16{j}.Exburst{i}.number_of_bursts)
                total16{j}.Exburst{i} = [];
            end
        end
    end
    
    %remove any empty cells
    for i = 1:length(total16)
        total16{i}.Exburst=total16{i}.Exburst(~cellfun('isempty',total16{i}.Exburst));
    end
    
    for i=1:length(total16)
        total16{i} = total16{i}.Exburst; % this contains the amount of channels that contain bursts per file
    end
    total16=total16';
    
    %now we need to average across channels within each file
    %convert inner structs into cells
    %the fieldnames will disspear but it will be easier to work it the
    %numbers
    %fieldnames in order were
    %number_of_bursts
    %duration_of_bursts
    %spikes_in_bursts
    %fr_of_bursts
    %mean_ISI_bursts
    %std_ISI_bursts
    %IBI
    
    for i =1:length(total16)
        for j=1:length(total16{i})
            if isempty(total16{i})
                total16{i} = 0;
            else
                total16{i}{j}=struct2cell(total16{i}{j});
            end
            
        end
    end
    
    %check to see if every if aligned in the same dimensions
    for i =1:length(total16)
        if isempty(total16{i})
        else
            for j =1:length(total16{i})
                if size(total16{i}{j}{4},1) == 1
                    total16{i}{j}{4} = total16{i}{j}{4}';
                end
            end
        end
    end
    
    % concatenated all the bursts together per file
    for i =1:length(total16)
        if isempty(total16{i})
        elseif size(total16{i},1) == 1
            total16{i} = total16{i}{1};
        else
            total16{i} = cellfun(@vertcat, total16{i}{:}, 'UniformOutput',false);
        end
    end
    
    %now we average
    
    for i=1:length(total16)
        if isempty(total16{i})
        else
            total16{i}{1}=size(total16{i}{1},1);
            for j=2:length(total16{i})
                total16{i}{j}=mean(total16{i}{j});
            end
        end
    end
    
    run('cBoxChanged')
    
elseif strcmpi(button, 'Terminate')
    
    prompt = {'Name the folder'};
    title1 = 'Select the folder to hold the analyzed files';
    dims = [1 75];
    definput = {'All_Analyzed_Files'};
    Jigglypuff = inputdlg(prompt,title1,dims,definput);
    
    correctfolder=uigetdir; %lets the user select  a folder where the new fodler will be created
    cd(correctfolder) ; %change the current folder to the user selected one
    mkdir([Jigglypuff{1}]);
    cd(Jigglypuff{1});
    ppp=pwd;
    
    
    message1=sprintf(['Select the folders to move the analyzed files from to your the newly created ', definput{1}]);
    button2 = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');
    
    
    while strcmpi(button2,'Continue')
        
        correctfolder2=uigetdir; %lets the user select  a folder to move
        cd(correctfolder2) ;
        files1 = dir('*.mat');
        
        for n=1:numel(files1)
            movefile([files1(n).name],ppp);
        end
        
        message1=sprintf(['Select the folders to move the analyzed files from to your the newly created ', definput{1}]);
        button2 = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');
        
        
        
        
        if strcmpi(button2,'Terminate')
            message1=sprintf(['You have put all the analyzed files to make the graphs into ', definput{1}]);
            button3 = questdlg(message1, 'Question', 'Yes', 'No', 'Continue');
            if strcmpi(button3,'Yes')
                cd(ppp);
                files = dir('*.mat');
                
                yuuuu=cell(1,length(files));
                for i=1:length(files)
                    yuuuu{i}=files(i).name;
                end
                
                out=regexp(yuuuu,'\d+','match');
                out=out';
                
                for i=1:length(files)
                    out{i}=cell2mat(out{i});
                end
                
                
                [~,I]=sort(out);
                files=files(I);
                out=out(I);
                avrrr={};
                j=0;
                
                for i=1:length(files)
                    try
                        i=j+1;
                        avrrr{i}=find(contains(out,out{i}));
                        j=avrrr{i}(end);
                    catch
                    end
                    
                    
                end
                
                avrrr=avrrr(~cellfun('isempty',avrrr));  %remove empty spaces  this cell array contains the indices that need to be avaraged
                
                
                clear promptMessage totaldura button incc I out j i
                
                
               %preallocation
    total2=cell(1,length(files));
    total3=cell(1,length(files));
    total4=cell(1,length(files));
    total1=cell(1,length(files));
    total5=cell(1,length(files));
    total6=cell(1,length(files));
    total13=cell(1,length(files));
    total15=cell(1,length(files));
    arrayfiringrate = cell(1,length(files));
    total16=cell(1,length(files));
    total17=cell(1,length(files));
    h = waitbar(0,'Collecting all files');
    
  
    
    for i=1:length(files)
        waitbar(i/length(files))
        selecteddata1=files(i).name;
        total1{i}=load(selecteddata1,'HITS');
        ppp=cell2mat(total1{i}.HITS(:,2));
        ppp=sum(ppp);
        total1{i}=ppp;
        
        total2{i}=load(selecteddata1,'BD');
        total2{i}=total2{i}.BD;
        
        total3{i}=load(selecteddata1,'BLog');
        total3{i}=total3{i}.BLog;
        
        total4{i}=load(selecteddata1,'BNeuro');
        total4{i}=total4{i}.BNeuro;
        
        total5{i}=load(selecteddata1,'negunits');
        total5{i}=total5{i}.negunits;
        
        total6{i}=load(selecteddata1,'posunits');
        total6{i}=total6{i}.posunits;
        
        total13{i}=load(selecteddata1,'Connections');
        total13{i}=total13{i}.Connections;
        
        total15{i}=load(selecteddata1,'timesss');
        total15{i}=total15{i}.timesss;
        
        total16{i}=load(selecteddata1,'Exburst');
        
        total17{i} = load(selecteddata1,'M2');
        
        arrayfiringrate{i} = load(selecteddata1,'T');
        if arrayfiringrate{i}.T.Units_per_second(end) == inf
            arrayfiringrate{i} = arrayfiringrate{i}.T.Units_per_second(1);
        else
            arrayfiringrate{i} = arrayfiringrate{i}.T.Units_per_second(end);
            % arrayfiringrate{i} = mean(arrayfiringrate{i}.T.maxamplitude_in_volt(1:end-1));
            
        end
        
    end
    close(h)
    %Units_per_second
    %adjust total16 for burst statistics
    %first remove any empty structs
    for j=1:length(total16)
        for i =1:length(Exburst)
            if isempty(total16{j}.Exburst{i}.number_of_bursts)
                total16{j}.Exburst{i} = [];
            end
        end
    end
    
    %remove any empty cells
    for i = 1:length(total16)
        total16{i}.Exburst=total16{i}.Exburst(~cellfun('isempty',total16{i}.Exburst));
    end
    
    for i=1:length(total16)
        total16{i} = total16{i}.Exburst; % this contains the amount of channels that contain bursts per file
    end
    total16=total16';
    
    %now we need to average across channels within each file
    %convert inner structs into cells
    %the fieldnames will disspear but it will be easier to work it the
    %numbers
    %fieldnames in order were
    %number_of_bursts
    %duration_of_bursts
    %spikes_in_bursts
    %fr_of_bursts
    %mean_ISI_bursts
    %std_ISI_bursts
    %IBI
    
    for i =1:length(total16)
        for j=1:length(total16{i})
            if isempty(total16{i})
                total16{i} = 0;
            else
                total16{i}{j}=struct2cell(total16{i}{j});
            end
            
        end
    end
    
    %check to see if every if aligned in the same dimensions
    for i =1:length(total16)
        if isempty(total16{i})
        else
            for j =1:length(total16{i})
                if size(total16{i}{j}{4},1) == 1
                    total16{i}{j}{4} = total16{i}{j}{4}';
                end
            end
        end
    end
    
    % concatenated all the bursts together per file
    for i =1:length(total16)
        if isempty(total16{i})
        elseif size(total16{i},1) == 1
            total16{i} = total16{i}{1};
        else
            total16{i} = cellfun(@vertcat, total16{i}{:}, 'UniformOutput',false);
        end
    end
    
    %now we average
    
    for i=1:length(total16)
        if isempty(total16{i})
        else
            total16{i}{1}=size(total16{i}{1},1);
            for j=2:length(total16{i})
                total16{i}{j}=mean(total16{i}{j});
            end
        end
    end

    run('cBoxChanged')
    %                 run('select_parameters')
    
    
    
    
    
            else
                %do something like going back to previous statement?
            end
        end
        
        
        
        
        
        
        
        
        
    end
end

end


% --- Executes on button press in cnn
function pushbutton382_Callback(hObject, eventdata, handles)
end
%% Trace view
% --- Executes on button press in trace view
function pushbutton383_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata parts fs


prompt = {'Enter window length (s)','Enter Well Number'};
title = 'Check all the channels';
dims = [1 35];
definput = {'1','1'};
jitters = inputdlg(prompt,title,dims,definput);

if isempty(jitters)
    return
end

window=str2double(jitters{1})*fs.filtersettings.sampling_frequency;
% load in the c orrect filtereddata1 based on the input provided in
% jitters{2}
hh=waitbar(0,'Please Wait');
for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
load(selecteddata,'filteredData1')
% filteredData1=hlp_deserialize(filteredData1);
waitbar(0 + 0.5,hh,'Please Wait');
filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
filteredData1 = filteredData1';
close(hh)

if length(filteredData1(:,1)) < 5
    msgbox('There is no voltage trace data')
else
    multichanplot(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1))
end% filteredData1=filteredData1';
clear filteredData1
end
%% movie
% --- Executes on button press in movie of activity
function pushbutton384_Callback(hObject, eventdata, handles)
global imaxch layout2 bincountssec filteredData1 HITS binranges4567 ans90 X2 timesss selecteddata

% first ask which well should be visualized

prompt = {'Enter Well Number'};
title = 'Visualize activity over time';
dims = [1 35];
definput = {'1'};
wellnumber = inputdlg(prompt,title,dims,definput);

for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',['Well_',wellnumber{1}]);
load(selecteddata,'bincountssec');
load(selecteddata,'binranges4567');
load(selecteddata,'filteredData1');
% filteredData1=hlp_deserialize(filteredData1);

if timesss > 100
    x=1:length(bincountssec);
    [x y] = meshgrid(x,x);
    figure('position', [0,0, 640, 640]);
    vidfile = VideoWriter('HEATMAP.avi','Motion JPEG AVI');
    open(vidfile);
    for i= 1:length(bincountssec)
        if length(filteredData1(:,2)) == 60
                        layout2= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan bincountssec(7,i) bincountssec(15,i) bincountssec(23,i) bincountssec(31,i) bincountssec(39,i) bincountssec(47,i) nan nan nan; nan nan bincountssec(1,i) bincountssec(8,i) bincountssec(16,i) bincountssec(24,i) bincountssec(32,i) bincountssec(40,i) bincountssec(48,i) bincountssec(55,i) nan nan; nan nan bincountssec(2,i) bincountssec(9,i) bincountssec(17,i) bincountssec(25,i) bincountssec(33,i) bincountssec(41,i) bincountssec(49,i) bincountssec(56,i) nan nan; nan nan bincountssec(3,i) bincountssec(10,i) bincountssec(18,i) bincountssec(26,i) bincountssec(34,i) bincountssec(42,i) bincountssec(50,i) bincountssec(57,i) nan nan; nan nan bincountssec(4,i) bincountssec(11,i) bincountssec(19,i) bincountssec(27,i) bincountssec(35,i) bincountssec(43,i) bincountssec(51,i) bincountssec(58,i) nan nan; nan nan bincountssec(5,i) bincountssec(12,i) bincountssec(20,i) bincountssec(28,i) bincountssec(36,i) bincountssec(44,i) bincountssec(52,i) bincountssec(59,i) nan nan; nan nan bincountssec(6,i) bincountssec(13,i) bincountssec(21,i) bincountssec(29,i) bincountssec(37,i) bincountssec(45,i) bincountssec(53,i) bincountssec(60,i) nan nan;nan nan nan bincountssec(14,i) bincountssec(22,i) bincountssec(30,i) bincountssec(38,i) bincountssec(46,i) bincountssec(54,i) nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
%             layout2=[nan bincountssec(12,i) bincountssec(11,i) nan nan bincountssec(24,i) bincountssec(23,i) nan nan bincountssec(36,i) bincountssec(35,i) nan nan bincountssec(48,i) bincountssec(47,i) nan nan bincountssec(60,i) bincountssec(59,i) nan nan bincountssec(72,i) bincountssec(71,i) nan;bincountssec(10,i) bincountssec(9,i) bincountssec(8,i) bincountssec(7,i) bincountssec(22,i) bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(34,i) bincountssec(33,i) bincountssec(32,i) bincountssec(31,i) bincountssec(46,i) bincountssec(45,i) bincountssec(44,i) bincountssec(43,i) bincountssec(58,i) bincountssec(57,i) bincountssec(56,i) bincountssec(55,i) bincountssec(70,i) bincountssec(69,i) bincountssec(68,i) bincountssec(67,i);bincountssec(6,i) bincountssec(5,i) bincountssec(4,i) bincountssec(3,i) bincountssec(18,i) bincountssec(17,i) bincountssec(16,i) bincountssec(15,i) bincountssec(30,i) bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(42,i) bincountssec(41,i) bincountssec(40,i) bincountssec(39,i) bincountssec(54,i) bincountssec(53,i) bincountssec(52,i) bincountssec(51,i) bincountssec(66,i) bincountssec(65,i) bincountssec(64,i) bincountssec(63,i);nan bincountssec(2,i) bincountssec(1,i) nan nan bincountssec(14,i) bincountssec(13,i) nan nan bincountssec(26,i) bincountssec(25,i) nan nan bincountssec(38,i) bincountssec(37,i) nan nan bincountssec(50,i) bincountssec(49,i) nan nan bincountssec(62,i) bincountssec(61,i) nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan bincountssec(84,i) bincountssec(83,i) nan nan bincountssec(96,i) bincountssec(95,i) nan nan bincountssec(108,i) bincountssec(107,i) nan nan bincountssec(120,i) bincountssec(119,i) nan nan bincountssec(132,i) bincountssec(131,i) nan nan bincountssec(144,i) bincountssec(143,i) nan; bincountssec(82,i) bincountssec(81,i) bincountssec(80,i) bincountssec(79,i) bincountssec(94,i) bincountssec(93,i) bincountssec(92,i) bincountssec(91,i) bincountssec(106,i) bincountssec(105,i) bincountssec(104,i) bincountssec(103,i) bincountssec(118,i) bincountssec(117,i) bincountssec(116,i) bincountssec(115,i) bincountssec(130,i) bincountssec(129,i) bincountssec(128,i) bincountssec(127,i) bincountssec(142,i) bincountssec(141,i) bincountssec(140,i) bincountssec(139,i); bincountssec(78,i) bincountssec(77,i) bincountssec(76,i) bincountssec(75,i) bincountssec(90,i) bincountssec(89,i) bincountssec(88,i) bincountssec(87,i) bincountssec(102,i) bincountssec(101,i) bincountssec(100,i) bincountssec(99,i) bincountssec(114,i) bincountssec(113,i) bincountssec(112,i) bincountssec(111,i) bincountssec(126,i) bincountssec(125,i) bincountssec(124,i) bincountssec(123,i) bincountssec(138,i) bincountssec(137,i) bincountssec(136,i) bincountssec(135,i); nan bincountssec(74,i) bincountssec(73,i) nan nan bincountssec(86,i) bincountssec(85,i) nan nan bincountssec(98,i) bincountssec(97,i) nan nan bincountssec(110,i) bincountssec(109,i) nan nan bincountssec(122,i) bincountssec(121,i) nan nan bincountssec(134,i) bincountssec(133,i) nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan bincountssec(156,i) bincountssec(155,i) nan nan bincountssec(168,i) bincountssec(167,i) nan nan bincountssec(180,i) bincountssec(179,i) nan nan bincountssec(192,i) bincountssec(191,i) nan nan bincountssec(204,i) bincountssec(203,i) nan nan bincountssec(216,i) bincountssec(215,i) nan; bincountssec(154,i) bincountssec(153,i) bincountssec(152,i) bincountssec(151,i) bincountssec(166,i) bincountssec(165,i) bincountssec(164,i) bincountssec(163,i) bincountssec(178,i) bincountssec(177,i) bincountssec(176,i) bincountssec(175,i) bincountssec(190,i) bincountssec(189,i) bincountssec(188,i) bincountssec(187,i) bincountssec(202,i) bincountssec(201,i) bincountssec(200,i) bincountssec(199,i) bincountssec(214,i) bincountssec(213,i) bincountssec(212,i) bincountssec(211,i); bincountssec(150,i) bincountssec(149,i) bincountssec(148,i) bincountssec(147,i) bincountssec(162,i) bincountssec(161,i) bincountssec(160,i) bincountssec(159,i) bincountssec(174,i) bincountssec(173,i) bincountssec(172,i) bincountssec(171,i) bincountssec(186,i) bincountssec(185,i) bincountssec(184,i) bincountssec(183,i) bincountssec(198,i) bincountssec(197,i) bincountssec(196,i) bincountssec(195,i) bincountssec(210,i) bincountssec(209,i) bincountssec(208,i) bincountssec(207,i); nan bincountssec(146,i) bincountssec(145,i) nan nan bincountssec(158,i) bincountssec(157,i) nan nan bincountssec(170,i) bincountssec(169,i) nan nan bincountssec(182,i) bincountssec(181,i) nan nan bincountssec(194,i) bincountssec(193,i) nan nan bincountssec(206,i) bincountssec(205,i) nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan bincountssec(228,i) bincountssec(227,i) nan nan bincountssec(240,i) bincountssec(239,i) nan nan bincountssec(252,i) bincountssec(251,i) nan nan bincountssec(264,i) bincountssec(263,i) nan nan bincountssec(276,i) bincountssec(275,i) nan nan bincountssec(288,i) bincountssec(287,i) nan; bincountssec(226,i) bincountssec(225,i) bincountssec(224,i) bincountssec(223,i) bincountssec(238,i) bincountssec(237,i) bincountssec(236,i) bincountssec(235,i) bincountssec(250,i) bincountssec(249,i) bincountssec(248,i) bincountssec(247,i) bincountssec(262,i) bincountssec(261,i) bincountssec(260,i) bincountssec(259,i) bincountssec(274,i) bincountssec(273,i) bincountssec(272,i) bincountssec(271,i) bincountssec(286,i) bincountssec(285,i) bincountssec(284,i) bincountssec(283,i); bincountssec(222,i) bincountssec(221,i) bincountssec(220,i) bincountssec(219,i) bincountssec(234,i) bincountssec(233,i) bincountssec(232,i) bincountssec(231,i) bincountssec(246,i) bincountssec(245,i) bincountssec(244,i) bincountssec(243,i) bincountssec(258,i) bincountssec(257,i) bincountssec(256,i) bincountssec(255,i) bincountssec(270,i) bincountssec(269,i) bincountssec(268,i) bincountssec(267,i) bincountssec(282,i) bincountssec(281,i) bincountssec(280,i) bincountssec(279,i); nan bincountssec(218,i) bincountssec(217,i) nan nan bincountssec(230,i) bincountssec(229,i) nan nan bincountssec(242,i) bincountssec(241,i) nan nan bincountssec(254,i) bincountssec(253,i) nan nan bincountssec(266,i) bincountssec(265,i) nan nan bincountssec(278,i) bincountssec(277,i) nan];             %// Define integer grid of coordinates for the above data
            [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
            

            
            %// Define a finer grid of points
            [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
            
            %// Interpolate the data and show the output
            outData = interp2(X, Y, layout2, X88, Y88, 'linear');
            
            
            nanvalues=isnan(outData);
            
            layout44=layout2;
            
            
            for i=1:length(layout2(:,1))
                for j=1:length(layout2(1,:))
                    if isnan(layout2(i,j))
                        layout44(i,j)= 0;
                    else
                    end
                end
            end
            
            %// Interpolate the data and show the output
            outData = interp2(X,Y,layout44, X88, Y88,'cubic');
            
            outData(nanvalues)=nan;
            
            
            imagesc(outData,'AlphaData',~isnan(outData));
            
            %// Cosmetic changes for the axes
            set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
            set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
            set(gca, 'XTickLabel', 1:size(X,2));
            set(gca, 'YTickLabel', 1:size(X,1));
            
            set(gca,'XtickLabel', ans90,'Fontsize',20);
            colorbar; 
% title('Spike Activity over 5 min','Fontsize',20);
           
            caxis([0 5]);
            drawnow
            F(i) = getframe(gcf);
            writeVideo(vidfile,F(i));
            
        else
            %layout2= [-50 -50 -50 bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) -50 -50 -50;-50 -50 bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) -50 -50;-50 bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) -50; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);-50 bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) -50;-50 -50 bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) -50 -50;-50 -50 -50 bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) -50 -50 -50];
            %             layout2= [nan nan nan bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) nan nan nan; nan nan bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) nan nan; nan bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) nan; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);nan bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) nan; nan nan bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) nan nan; nan nan nan bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) nan nan nan];
            layout2=[nan bincountssec(12,i) bincountssec(11,i) nan nan bincountssec(24,i) bincountssec(23,i) nan nan bincountssec(36,i) bincountssec(35,i) nan nan bincountssec(48,i) bincountssec(47,i) nan nan bincountssec(60,i) bincountssec(59,i) nan nan bincountssec(72,i) bincountssec(71,i) nan;bincountssec(10,i) bincountssec(9,i) bincountssec(8,i) bincountssec(7,i) bincountssec(22,i) bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(34,i) bincountssec(33,i) bincountssec(32,i) bincountssec(31,i) bincountssec(46,i) bincountssec(45,i) bincountssec(44,i) bincountssec(43,i) bincountssec(58,i) bincountssec(57,i) bincountssec(56,i) bincountssec(55,i) bincountssec(70,i) bincountssec(69,i) bincountssec(68,i) bincountssec(67,i);bincountssec(6,i) bincountssec(5,i) bincountssec(4,i) bincountssec(3,i) bincountssec(18,i) bincountssec(17,i) bincountssec(16,i) bincountssec(15,i) bincountssec(30,i) bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(42,i) bincountssec(41,i) bincountssec(40,i) bincountssec(39,i) bincountssec(54,i) bincountssec(53,i) bincountssec(52,i) bincountssec(51,i) bincountssec(66,i) bincountssec(65,i) bincountssec(64,i) bincountssec(63,i);nan bincountssec(2,i) bincountssec(1,i) nan nan bincountssec(14,i) bincountssec(13,i) nan nan bincountssec(26,i) bincountssec(25,i) nan nan bincountssec(38,i) bincountssec(37,i) nan nan bincountssec(50,i) bincountssec(49,i) nan nan bincountssec(62,i) bincountssec(61,i) nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan bincountssec(84,i) bincountssec(83,i) nan nan bincountssec(96,i) bincountssec(95,i) nan nan bincountssec(108,i) bincountssec(107,i) nan nan bincountssec(120,i) bincountssec(119,i) nan nan bincountssec(132,i) bincountssec(131,i) nan nan bincountssec(144,i) bincountssec(143,i) nan; bincountssec(82,i) bincountssec(81,i) bincountssec(80,i) bincountssec(79,i) bincountssec(94,i) bincountssec(93,i) bincountssec(92,i) bincountssec(91,i) bincountssec(106,i) bincountssec(105,i) bincountssec(104,i) bincountssec(103,i) bincountssec(118,i) bincountssec(117,i) bincountssec(116,i) bincountssec(115,i) bincountssec(130,i) bincountssec(129,i) bincountssec(128,i) bincountssec(127,i) bincountssec(142,i) bincountssec(141,i) bincountssec(140,i) bincountssec(139,i); bincountssec(78,i) bincountssec(77,i) bincountssec(76,i) bincountssec(75,i) bincountssec(90,i) bincountssec(89,i) bincountssec(88,i) bincountssec(87,i) bincountssec(102,i) bincountssec(101,i) bincountssec(100,i) bincountssec(99,i) bincountssec(114,i) bincountssec(113,i) bincountssec(112,i) bincountssec(111,i) bincountssec(126,i) bincountssec(125,i) bincountssec(124,i) bincountssec(123,i) bincountssec(138,i) bincountssec(137,i) bincountssec(136,i) bincountssec(135,i); nan bincountssec(74,i) bincountssec(73,i) nan nan bincountssec(86,i) bincountssec(85,i) nan nan bincountssec(98,i) bincountssec(97,i) nan nan bincountssec(110,i) bincountssec(109,i) nan nan bincountssec(122,i) bincountssec(121,i) nan nan bincountssec(134,i) bincountssec(133,i) nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan bincountssec(156,i) bincountssec(155,i) nan nan bincountssec(168,i) bincountssec(167,i) nan nan bincountssec(180,i) bincountssec(179,i) nan nan bincountssec(192,i) bincountssec(191,i) nan nan bincountssec(204,i) bincountssec(203,i) nan nan bincountssec(216,i) bincountssec(215,i) nan; bincountssec(154,i) bincountssec(153,i) bincountssec(152,i) bincountssec(151,i) bincountssec(166,i) bincountssec(165,i) bincountssec(164,i) bincountssec(163,i) bincountssec(178,i) bincountssec(177,i) bincountssec(176,i) bincountssec(175,i) bincountssec(190,i) bincountssec(189,i) bincountssec(188,i) bincountssec(187,i) bincountssec(202,i) bincountssec(201,i) bincountssec(200,i) bincountssec(199,i) bincountssec(214,i) bincountssec(213,i) bincountssec(212,i) bincountssec(211,i); bincountssec(150,i) bincountssec(149,i) bincountssec(148,i) bincountssec(147,i) bincountssec(162,i) bincountssec(161,i) bincountssec(160,i) bincountssec(159,i) bincountssec(174,i) bincountssec(173,i) bincountssec(172,i) bincountssec(171,i) bincountssec(186,i) bincountssec(185,i) bincountssec(184,i) bincountssec(183,i) bincountssec(198,i) bincountssec(197,i) bincountssec(196,i) bincountssec(195,i) bincountssec(210,i) bincountssec(209,i) bincountssec(208,i) bincountssec(207,i); nan bincountssec(146,i) bincountssec(145,i) nan nan bincountssec(158,i) bincountssec(157,i) nan nan bincountssec(170,i) bincountssec(169,i) nan nan bincountssec(182,i) bincountssec(181,i) nan nan bincountssec(194,i) bincountssec(193,i) nan nan bincountssec(206,i) bincountssec(205,i) nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan bincountssec(228,i) bincountssec(227,i) nan nan bincountssec(240,i) bincountssec(239,i) nan nan bincountssec(252,i) bincountssec(251,i) nan nan bincountssec(264,i) bincountssec(263,i) nan nan bincountssec(276,i) bincountssec(275,i) nan nan bincountssec(288,i) bincountssec(287,i) nan; bincountssec(226,i) bincountssec(225,i) bincountssec(224,i) bincountssec(223,i) bincountssec(238,i) bincountssec(237,i) bincountssec(236,i) bincountssec(235,i) bincountssec(250,i) bincountssec(249,i) bincountssec(248,i) bincountssec(247,i) bincountssec(262,i) bincountssec(261,i) bincountssec(260,i) bincountssec(259,i) bincountssec(274,i) bincountssec(273,i) bincountssec(272,i) bincountssec(271,i) bincountssec(286,i) bincountssec(285,i) bincountssec(284,i) bincountssec(283,i); bincountssec(222,i) bincountssec(221,i) bincountssec(220,i) bincountssec(219,i) bincountssec(234,i) bincountssec(233,i) bincountssec(232,i) bincountssec(231,i) bincountssec(246,i) bincountssec(245,i) bincountssec(244,i) bincountssec(243,i) bincountssec(258,i) bincountssec(257,i) bincountssec(256,i) bincountssec(255,i) bincountssec(270,i) bincountssec(269,i) bincountssec(268,i) bincountssec(267,i) bincountssec(282,i) bincountssec(281,i) bincountssec(280,i) bincountssec(279,i); nan bincountssec(218,i) bincountssec(217,i) nan nan bincountssec(230,i) bincountssec(229,i) nan nan bincountssec(242,i) bincountssec(241,i) nan nan bincountssec(254,i) bincountssec(253,i) nan nan bincountssec(266,i) bincountssec(265,i) nan nan bincountssec(278,i) bincountssec(277,i) nan];             %// Define integer grid of coordinates for the above data
            [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
            
            
            
            %// Define a finer grid of points
            [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
            
            %// Interpolate the data and show the output
            outData = interp2(X, Y, layout2, X88, Y88, 'linear');
            
            nanvalues=isnan(outData);
            
            layout44=layout2;
            
            
            for i=1:length(layout2(:,1))
                for j=1:length(layout2(1,:))
                    if isnan(layout2(i,j))
                        layout44(i,j)= 0;
                    else
                    end
                end
            end
            
            %// Interpolate the data and show the output
            outData = interp2(X,Y,layout44, X88, Y88,'cubic');
            
            outData(nanvalues)=nan;
            
            
            imagesc(outData,'AlphaData',~isnan(outData));
            
            %// Cosmetic changes for the axes
            set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
            set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
            set(gca, 'XTickLabel', 1:size(X,2));
            set(gca, 'YTickLabel', 1:size(X,1));
            
            
            
            
            
            
            
            
            set(gca,'XtickLabel', ans90,'Fontsize',20);
            colorbar;
%             title('Spike Activity over 5 min','Fontsize',20);
            caxis([0 5]);
            drawnow
            F(i) = getframe(gcf);
            writeVideo(vidfile,F(i));
        end
    end
    close(vidfile)
    
    
else
    x=1:1800;
    [x y] = meshgrid(x,x);
    figure('position', [0,0, 640, 640]);
    vidfile = VideoWriter('HEATMAP.avi','Motion JPEG AVI');
    open(vidfile);
    for i= 1:1800
        if length(filteredData1(:,2)) == 60
            layout2= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan bincountssec(7,i) bincountssec(15,i) bincountssec(23,i) bincountssec(31,i) bincountssec(39,i) bincountssec(47,i) nan nan nan; nan nan bincountssec(1,i) bincountssec(8,i) bincountssec(16,i) bincountssec(24,i) bincountssec(32,i) bincountssec(40,i) bincountssec(48,i) bincountssec(55,i) nan nan; nan nan bincountssec(2,i) bincountssec(9,i) bincountssec(17,i) bincountssec(25,i) bincountssec(33,i) bincountssec(41,i) bincountssec(49,i) bincountssec(56,i) nan nan; nan nan bincountssec(3,i) bincountssec(10,i) bincountssec(18,i) bincountssec(26,i) bincountssec(34,i) bincountssec(42,i) bincountssec(50,i) bincountssec(57,i) nan nan; nan nan bincountssec(4,i) bincountssec(11,i) bincountssec(19,i) bincountssec(27,i) bincountssec(35,i) bincountssec(43,i) bincountssec(51,i) bincountssec(58,i) nan nan; nan nan bincountssec(5,i) bincountssec(12,i) bincountssec(20,i) bincountssec(28,i) bincountssec(36,i) bincountssec(44,i) bincountssec(52,i) bincountssec(59,i) nan nan; nan nan bincountssec(6,i) bincountssec(13,i) bincountssec(21,i) bincountssec(29,i) bincountssec(37,i) bincountssec(45,i) bincountssec(53,i) bincountssec(60,i) nan nan;nan nan nan bincountssec(14,i) bincountssec(22,i) bincountssec(30,i) bincountssec(38,i) bincountssec(46,i) bincountssec(54,i) nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
            
            %// Define integer grid of coordinates for the above data
            [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
            
            
            %// Define a finer grid of points
            [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
            
            %// Interpolate the data and show the output
            outData = interp2(X, Y, layout2, X88, Y88, 'linear');
            
            nanvalues=isnan(outData);
            
            layout44=layout2;
            
            
            for i=1:length(layout2(:,1))
                for j=1:length(layout2(1,:))
                    if isnan(layout2(i,j))
                        layout44(i,j)= 0;
                    else
                    end
                end
            end
            
            %// Interpolate the data and show the output
            outData = interp2(X,Y,layout44, X88, Y88,'cubic');
            
            outData(nanvalues)=nan;
            
            
            
            imagesc(outData,'AlphaData',~isnan(outData));
            
            %// Cosmetic changes for the axes
            set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
            set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
            set(gca, 'XTickLabel', 1:size(X,2));
            set(gca, 'YTickLabel', 1:size(X,1));
            
            
            
            
            
            
            
            set(gca,'XtickLabel', ans90,'Fontsize',20);
            colorbar;
            title('Spike Activity over 1 min','Fontsize',20);
            caxis([0 5]);
            drawnow
            F(i) = getframe(gcf);
            writeVideo(vidfile,F(i));
            
        else
            %layout2= [-50 -50 -50 bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) -50 -50 -50;-50 -50 bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) -50 -50;-50 bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) -50; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);-50 bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) -50;-50 -50 bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) -50 -50;-50 -50 -50 bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) -50 -50 -50];
            layout2= [nan nan nan bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) nan nan nan; nan nan bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) nan nan; nan bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) nan; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);nan bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) nan; nan nan bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) nan nan; nan nan nan bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) nan nan nan];
            
            
            
            
            [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
            
            %// Define a finer grid of points
            [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
            
            %// Interpolate the data and show the output
            outData = interp2(X, Y, layout2, X88, Y88, 'linear');
            
            nanvalues=isnan(outData);
            
            layout44=layout2;
            
            
            for i=1:length(layout2(:,1))
                for j=1:length(layout2(1,:))
                    if isnan(layout2(i,j))
                        layout44(i,j)= 0;
                    else
                    end
                end
            end
            
            %// Interpolate the data and show the output
            outData = interp2(X,Y,layout44, X88, Y88,'cubic');
            
            outData(nanvalues)=nan;
            
            imagesc(outData,'AlphaData',~isnan(outData));
            
            %// Cosmetic changes for the axes
            set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
            set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
            set(gca, 'XTickLabel', 1:size(X,2));
            set(gca, 'YTickLabel', 1:size(X,1));
            set(gca,'XtickLabel', ans90,'Fontsize',20);
            colorbar;
            title('Spike Activity over 1 min','Fontsize',20);
            caxis([0 5]);
            drawnow
            F(i) = getframe(gcf);
            writeVideo(vidfile,F(i));
        end
    end
    close(vidfile)
end



%create new variable that replaces imaxch becasue the old vraible contains
%the top 10 channels of the whole multiwell. We ned to find the top 5 of
%the selected well
[imaxch2,~]= maxk(cell2mat(HITS((str2double(wellnumber{1})*12)- 11:str2double(wellnumber{1})*12,2)),5);


figure('position', [0,0, 640, 640]);
vidfile=VideoWriter('MEA activity.avi','Motion JPEG AVI');
open(vidfile);
h1=subplot(5,1,1);
hold on
plot(X2,filteredData1(imaxch2(1,1),:));
if timesss > 100
    xlim([0 timesss]);
else
    xlim([0 timesss]);
end

ylabel(['Channel',HITS(imaxch2(1,1))]);
xlabel('Time in Seconds');
hold on
h2=subplot(5,1,2);
plot(X2,filteredData1(imaxch2(2,1),:));
if timesss > 100
    xlim([0 timesss]);
else
    xlim([0 timesss]);
end

ylabel(['Channel',HITS(imaxch2(2,1))]);
xlabel('Time in Seconds');
hold on
h3=subplot(5,1,3);
plot(X2,filteredData1(imaxch2(3,1),:));
if timesss > 100
    xlim([0 timesss]);
else
    xlim([0 timesss]);
end

ylabel(['Channel',HITS(imaxch2(3,1))]);
xlabel('Time in Seconds');
hold on
h4=subplot(5,1,4);
plot(X2,filteredData1(imaxch2(4,1),:));
if timesss > 100
    xlim([0 timesss]);
else
    xlim([0 timesss]);
end

ylabel(['Channel',HITS(imaxch2(4,1))]);
xlabel('Time in Seconds');
hold on
h5=subplot(5,1,5);
plot(X2,filteredData1(imaxch2(5,1),:));
if timesss > 100
    xlim([0 timesss]);
else
    xlim([0 timesss]);
end

ylabel(['Channel',HITS(imaxch2(5,1))]);
xlabel('Time in Seconds');
hold on
for j=1:length(binranges4567)
    axes(h1)
    b1=line([binranges4567(1,j) binranges4567(1,j)],get(h1,'Ylim'),'Color',[1 0 0]);
    axes(h2)
    b2=line([binranges4567(1,j) binranges4567(1,j)],get(h2,'Ylim'),'Color',[1 0 0]);
    axes(h3)
    b3=line([binranges4567(1,j) binranges4567(1,j)],get(h3,'Ylim'),'Color',[1 0 0]);
    axes(h4)
    b4=line([binranges4567(1,j) binranges4567(1,j)],get(h4,'Ylim'),'Color',[1 0 0]);
    axes(h5)
    b5=line([binranges4567(1,j) binranges4567(1,j)],get(h5,'Ylim'),'Color',[1 0 0]);
    F(j)=getframe(gcf);
    writeVideo(vidfile,F(j));
    delete(b1);
    delete(b2);
    delete(b3);
    delete(b4);
    delete(b5);
end
close(vidfile)

vid1 = VideoReader('HEATMAP.avi');
vid2 = VideoReader('MEA activity.avi');
% new video
outputVideo = VideoWriter('Combined.avi');
outputVideo.FrameRate = vid1.FrameRate;
open(outputVideo);

while hasFrame(vid1) && hasFrame(vid2)
    img1 = readFrame(vid1);
    img2 = readFrame(vid2);
    
    imgt = horzcat(img1, img2);
    
    
    % record new video
    writeVideo(outputVideo, imgt);
end

close(outputVideo);
delete('HEATMAP.avi');
delete('MEA activity.avi');
message1=sprintf(['Finished making the movie']);
msgbox(message1);
clear message1

end
%% top 10 channel panel changed into trace view 


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
global filteredData1 selecteddata jitters timesss joost
hh=waitbar(0,'Please Wait');
correctwell = hObject.Value;
window = timesss*10000; % this is equal to full trace
jitters{2} = mat2str(correctwell); % default is well 1
if joost == 1
else
    
    for i = 2:25
        checked =sprintf('Well_%d',i);
        if contains(selecteddata,'Well')
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        else
            selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
        end
    end % change the name to well 1
    
    selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
    load(selecteddata,'filteredData1')
    % filteredData1=hlp_deserialize(filteredData1);
    filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
    filteredData1=filteredData1';
    close(hh)
    multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1))
    title(['Voltage trace view of well ',jitters{2}],'Fontsize',12);
    % filteredData1=filteredData1';
    
    clear filteredData1
end
end

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
global parts
hObject.String
hObject.Position = [0.25 0.009 0.067 0.023];

if parts == 12
    hObject.String ={'Well 1','Well 2','Well 3','Well 4', 'Well 5', 'Well 6' ...
        'Well 7', 'Well 8', 'Well 9', 'Well 10', 'Well 11', 'Well 12'};
elseif parts == 24
    hObject.String ={'Well 1','Well 2','Well 3','Well 4', 'Well 5', 'Well 6' ...
        'Well 7', 'Well 8', 'Well 9', 'Well 10', 'Well 11', 'Well 12','Well 13','Well 14',...
        'Well 15', 'Well 16', 'Well 17', 'Well 18', 'Well 19','Well 20', 'Well 21', ...
        'Well 22', 'Well 23', 'Well 24'};
end
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end

% --- Executes during object creation, after setting all properties.
function uipanel4_CreateFcn(hObject, eventdata, handles)
global filteredData1 selecteddata parts jitters timesss joost

hObject.Position=[.01 .037 .514 .358];
window = timesss *10000; % this is equal to full trace
jitters{2} = '1'; % default is well 1
if joost == 1
else
    for i = 2:25
        checked =sprintf('Well_%d',i);
        if contains(selecteddata,'Well')
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        else
            selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
        end
    end % change the name to well 1
    
    selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',str2double(jitters{2})));
    load(selecteddata,'filteredData1')
    % filteredData1=hlp_deserialize(filteredData1);
    filteredData1(((str2double(jitters{2})-1)*12)+1:(str2double(jitters{2})*12),:) = filteredData1(1:12,:);
    filteredData1=double(filteredData1)';
    multichanplotaltered(filteredData1,window,'channels',(((str2double(jitters{2})*12)-1:-1:(str2double(jitters{2})-1)*12)+1))
    title(['Voltage trace view of well ',jitters{2}],'Fontsize',12);
    filteredData1=filteredData1';
    clear filteredData1 window
end

%% old function
% global X2 HITS timesss joost indexx selecteddata fs parts
% 
% ax = axes(hObject);
% hObject.Title={};
% 
% hObject.BackgroundColor=[1 1 1];
% hObject.Position=[.01 .037 .398 .358];
% ax.Position = [0.0487253242795294 0.0370287057730822 0.948071613075621 0.926208651399492];
% 
% if joost == 1
% else
%     
%     for i = 2:25
%         checked =sprintf('Well_%d',i);
%         if contains(selecteddata,'Well')
%             if isempty(regexp(selecteddata,checked))
%                 continue
%             else
%                 oldname = sprintf('Well_%d',i);
%                 selecteddata = strrep(selecteddata,oldname,'Well_1');
%             end
%         else
%             selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
%         end
%     end
%     
%     
%     range2 = cell(1,24);
%     UUU= 1:12;
%     for i = 1:24
%         range2{i} = UUU;
%         UUU=UUU+12;
%     end
%     
%     
%     
%     HITA = cell(2,288)';
%     for i = 1:parts
%         load(selecteddata,'HITS')
%         HITA(range2{i}(1):range2{i}(end)) = HITS(1:12);
%         HITA(range2{i}(1):range2{i}(end),2) = HITS(1:12,2);
%         replace1 =sprintf('Well_%d',i);
%         replace2 = sprintf('Well_%d',i+1);
%         selecteddata = replace(selecteddata,replace1,replace2);
%     end
%     
%     HITA(:,1) = HITS(:,1);
%     
%     channelss = cell(1,288)';
%     
%     for i = 1:288
%         channelss{i} = num2str(i);
%         
%     end
%     
%     HITA(:,1) = channelss;
%     
%     
%         for i = 1:288
%             HITA{i,1} = num2str(HITA{i,1});
%         end
%     HITS = HITA;
%     
%     [~,indexx] = maxk(cell2mat(HITS(:,2)),5);
%     
%     if parts == 24
%         for i = 1:5
%             now we need to select the correct file(well)
%             correctwell = ceil(indexx(i)/12); % correct well
%             correctfilef = sprintf('Well_%d',correctwell);
%             selecteddata = replace(selecteddata,'Well_25',correctfilef);
%             load(selecteddata,'filteredData1');
%             load(selecteddata,'RMS7');
%             load(selecteddata,'noiseall18');
%             load(selecteddata,'noiseall2');
%             filteredData1=hlp_deserialize(filteredData1);
%             P = indexx(i) - (correctwell-1) * 12;
%             subplot(5,1,i);
%             plot(X2,filteredData1(P,:));
%                 if timesss > 100
%                     axis([0 timesss -500 500]);
%                 else
%                     axis([0 timesss -500 500]);
%                 end
%             hold on
%                 plot(X2,RMS8(INDEX,:),'k');
%             plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
%             hold on
%             plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
%                 plot(X2,-RMS8(INDEX,:),'k');
%             hold on
%             if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
%                 plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
%                 hold on
%                 plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
%             else
%                 plot(noiseall18{P,1},noiseall2{P,1},'r');
%             end
%             ylabel(['',HITS((indexx(i)))]);
%             if i == 1
%                 set(gca,'xtick',[])
%             end
%             
%             if i == 2
%                 set(gca,'xtick',[])
%             end
%             
%             if i == 2
%                 set(gca,'xtick',[])
%             end
%             if i == 3
%                 set(gca,'xtick',[])
%             end
%             if i == 4
%                 set(gca,'xtick',[])
%             end
%             
%             if i == 5
%                 xlabel('Time (s)')
%             end
%             
%             if i == 1
%                 title('Top 5 most active channels');
%                 oooo=legend('Trace','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',5);
%                 oooo.FontSize=5;
%                 set(legend,...
%                     'Position',[1.24000978654402e-05 0.000245518612941189 0.15825374906255 0.105329946515524],...
%                     'FontSize',5);   
%             end
%             change the name to Well 25
%             selecteddata = replace(selecteddata,correctfilef,'Well_25');
%             clear filteredData1 RMS7 noiseall2 noiseall18
%         end
%     elseif parts == 12
%         for i = 1:5
%             now we need to select the correct file(well)
%             correctwell = ceil(indexx(i)/12); % correct well
%             correctfilef = sprintf('Well_%d',correctwell);
%             selecteddata = replace(selecteddata,'Well_13',correctfilef);
%             load(selecteddata,'filteredData1');
%             load(selecteddata,'RMS7');
%             load(selecteddata,'noiseall18');
%             load(selecteddata,'noiseall2');
%             filteredData1=hlp_deserialize(filteredData1);
%             P = indexx(i) - (correctwell-1) * 12;
%             subplot(5,1,i);
%             plot(X2,filteredData1(P,:));
%                 if timesss > 100
%                     axis([0 timesss -500 500]);
%                 else
%                     axis([0 timesss -500 500]);
%                 end
%             hold on
%                 plot(X2,RMS8(INDEX,:),'k');
%             plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
%             hold on
%             plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
%                 plot(X2,-RMS8(INDEX,:),'k');
%             hold on
%             if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
%                 plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
%                 hold on
%                 plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
%             else
%                 plot(noiseall18{P,1},noiseall2{P,1},'r');
%             end
%             ylabel(['',HITS((indexx(i)))]);
%             
%             if i == 1 
%                set(gca,'xtick',[])
%             end
%             
%             if i == 2
%                 set(gca,'xtick',[])
%             end
%             
%             if i == 2
%                 set(gca,'xtick',[])
%             end
%             if i == 3
%                 set(gca,'xtick',[])
%             end
%             if i == 4
%                 set(gca,'xtick',[])
%             end
% 
%             if i == 5
%                 xlabel('Time (s)')
%             end
%             
%             if i == 1
%                 title('Top 5 most active channels');
%                 oooo=legend('Trace','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',5);
%                 oooo.FontSize=5;
%                 set(legend,...
%                     'Position',[1.24000978654402e-05 0.000245518612941189 0.15825374906255 0.105329946515524],...
%                     'FontSize',5);
%             end
%             change the name to Well 25
%             selecteddata = replace(selecteddata,correctfilef,'Well_13');
%             clear filteredData1 RMS7 noiseall2 noiseall18
%         end
%     end
%     
% end
end
%% heatmap panel changed to use for rasterplot (can be used for something else)
% --- Executes during object creation, after setting all properties.
function uipanel2_CreateFcn(hObject, eventdata, handles)
global selecteddata xpoints parts xPoints yPoints timesss M2 

 hObject.Title={};
 hObject.BackgroundColor=[1 1 1];
 hObject.Position = [ 0.418 0.038 0.176 0.358];
hObject.Visible = 'off';
%  ax= axes(hObject);
% 
% for i = 2:25
%     checked =sprintf('Well_%d',i);
%     if contains(selecteddata,'Well')
%         if isempty(regexp(selecteddata,checked))
%             continue
%         else
%             oldname = sprintf('Well_%d',i);
%             selecteddata = strrep(selecteddata,oldname,'Well_1');
%         end
%     else
%         selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
%     end
% end
% 
% val = 1;
% 
% 
%     for i = 2:25
%         checked =sprintf('Well_%d',i);
%         if isempty(regexp(selecteddata,checked))
%             continue
%         else
%             oldname = sprintf('Well_%d',i);
%             selecteddata = strrep(selecteddata,oldname,'Well_1');
%         end
%     end
%     
%     
%     range2 = cell(1,24);
%     UUU= 1:12;
%     for i = 1:24
%         range2{i} = UUU;
%         UUU=UUU+12;
%     end
%     
%     selecteddata2 = selecteddata;
%     replace1 = sprintf('Well_%d',1);
%     replace2 = sprintf('Well_%d',val);
%     selecteddata = replace(selecteddata,replace1,replace2);
%     load(selecteddata,'M2')
%     load(selecteddata,'xpoints')
%     xpoints=sort(xpoints);
%     selecteddata = selecteddata2;
%    
%     %create a new xpoints variable that contains al the xpoints
%     if ~isempty(xpoints)
%         timesss = ceil(max(xpoints));
%     end
%     
%     resolution = 0.001; %binsize of 1 ms
%     sigma = 0.1 ; %100 ms STD of gaussian
%     % Use hist to bin
%     EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
%     N = histc(xpoints, EDGES);
% %     N = N ./timesss; %normalize for total duration to get firing rate
%     %Time ranges form -3*st. dev. to 3*st. dev.
%     edges = (-3*sigma:resolution:3*sigma);
%     %Evaluate the Gaussian kernel
%     kernel = normpdf(edges,0,sigma);
%     %Multiply by bin width so the probabilities sum to 1?
%     kernel = kernel.*resolution;
%     %Convolve spike data with the kernel
%     s = conv(N,kernel);
%     s = s/resolution; 
%     %Find the index of the kernel center
%     center = ceil(length(edges)/2);
% %     Trim out the relevant portion of the spike density
%      s = s(center:end-center-1);
%     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
%     
%     
%     plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
%     
%     nTotalSpikes = sum(cellfun(@length,M2));
%     
%     
%     xPoints = NaN(nTotalSpikes*3,1);
%     yPoints = xPoints;
%     currentInd = 1;
%     
%     
%     halfSpikeHeight = 1/2;
%     for trials = 1:length(M2)
%         nSpikes = length(M2{trials});
%         nanSeparator = NaN(1,nSpikes);
%         
%         trialXPoints = [ M2{trials} + 0;...
%             M2{trials} + 0; nanSeparator ];
%         trialXPoints = trialXPoints(:);
%         
%         trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
%             (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
%         trialYPoints = trialYPoints(:);
%         
%         xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
%         yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
%         currentInd = currentInd + nSpikes*3;
%     end
%     
%     plot(xPoints, yPoints, 'k')
%     correctylim = val *12;
%     correctylim = [(correctylim - 12):2: correctylim+2];
%      plp1.YTickLabel = correctylim;
% %     set(gca,'XLim',correctxlim);
%     set(gca,'XTick',[]);
%     
% 
%     yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
%     cla(yy);
%     plot(t,s,'k');
%     xlim([0 timesss])
%     ylabel('AWFR (Hz)');
%     xlabel('Time(s)','Fontsize',10);
%     correctxlim = get(gca,'XLim');
%     
%    
%     subplot('position',[0.2 0.35 0.7 0.6]); hold on;
%     %correct ylim
%     
%     xlim(correctxlim);
%     title(sprintf('Array Wide Activity of Well %d',val));


%% old function
% global layout ans90 selecteddata textstrings parts
% % figure('units','normalized','outerposition',[0 0 1 1]);
% % imagesc(layout,'AlphaData',~isnan(layout));
% % % heatmap(layout,ans90,(1:12),true,'Gridlines','-','Colorbar',true,'ShowAllTicks',true,'TickFontSize',30)
% % set(gca,'Ytick',[1:12],'Yticklabel',[1:12],'Xtick',[1:12],'XtickLabel', ans90,'Fontsize',20);
% % title('Spike Activity over 1 min','Fontsize',30);
% % colorbar;
% hObject.Title={};
% hObject.Position = [ 0.418 0.038 0.176 0.358];
% hObject.BackgroundColor=[1 1 1];
% 
% for i = 2:25
%     checked =sprintf('Well_%d',i);
%     if contains(selecteddata,'Well')
%         if isempty(regexp(selecteddata,checked))
%             continue
%         else
%             oldname = sprintf('Well_%d',i);
%             selecteddata = strrep(selecteddata,oldname,'Well_1');
%         end
%     else
%         selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
%     end
% end
% 
% range2 = cell(1,24);
% UUU= 1:12;
% for i = 1:24
%     range2{i} = UUU;
%     UUU=UUU+12;
% end
% 
% 
% 
% HITA = cell(2,288)';
% for i = 1:parts
%     load(selecteddata,'HITS')
%     HITA(range2{i}(1):range2{i}(end)) = HITS(1:12);
%     HITA(range2{i}(1):range2{i}(end),2) = HITS(1:12,2);
%     replace1 =sprintf('Well_%d',i);
%     replace2 = sprintf('Well_%d',i+1);
%     selecteddata = replace(selecteddata,replace1,replace2);
%     
% end
% HITA(:,1) = HITS(:,1);
% 
% 
% channelss = cell(1,288)';
% 
% for i = 1:288
%     channelss{i} = num2str(i);
%     
% end
% 
% HITA(:,1) = channelss;
% % for i = 61:288
% %
% %     HITA{i,1} = num2str(HITA{i,1});
% % end
% HITS = HITA;
% 
% for i = 1:length(HITS)
%     
%     HITS{i,1} = str2double(HITS{i,1});
%     
% end
% 
% HITS = sortrows(HITS,[1]);
% if parts ==12
%     layout=...
%         [nan   nan     HITS{1,2} HITS{2,2} nan       nan nan        HITS{13,2} HITS{14,2} nan        nan nan        HITS{25,2} HITS{26,2} nan        nan nan        HITS{37,2} HITS{38,2} nan        nan nan        HITS{49,2} HITS{50,2} nan        nan nan        HITS{61,2} HITS{62,2} nan nan;...
%         nan HITS{3,2} HITS{4,2} HITS{5,2} HITS{6,2} nan HITS{15,2} HITS{16,2} HITS{17,2} HITS{18,2} nan HITS{27,2} HITS{28,2} HITS{29,2} HITS{30,2} nan HITS{39,2} HITS{40,2} HITS{41,2} HITS{42,2} nan HITS{51,2} HITS{52,2} HITS{53,2} HITS{54,2} nan HITS{63,2} HITS{64,2} HITS{65,2} HITS{66,2} nan;...
%         nan HITS{7,2} HITS{8,2} HITS{9,2} HITS{10,2} nan HITS{19,2} HITS{20,2} HITS{21,2} HITS{15,2} nan HITS{31,2} HITS{32,2} HITS{33,2} HITS{34,2} nan HITS{43,2} HITS{44,2} HITS{45,2} HITS{46,2} nan HITS{55,2} HITS{56,2} HITS{57,2} HITS{58,2} nan HITS{67,2} HITS{68,2} HITS{69,2} HITS{70,2} nan;...
%         nan nan       HITS{11,2} HITS{12,2} nan     nan nan        HITS{23,2} HITS{24,2} nan        nan nan        HITS{35,2} HITS{36,2} nan        nan nan        HITS{47,2} HITS{48,2} nan        nan nan        HITS{59,2} HITS{60,2} nan        nan nan        HITS{71,2} HITS{72,2} nan nan;...
%         nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
%         nan nan        HITS{73,2} HITS{74,2} nan        nan nan        HITS{85,2} HITS{86,2} nan        nan nan         HITS{97,2} HITS{98,2} nan         nan nan         HITS{109,2} HITS{110,2} nan         nan nan         HITS{121,2} HITS{122,2} nan         nan nan         HITS{133,2} HITS{134,2} nan nan;...
%         nan HITS{75,2} HITS{76,2} HITS{77,2} HITS{78,2} nan HITS{87,2} HITS{88,2} HITS{89,2} HITS{90,2} nan HITS{99,2} HITS{100,2} HITS{101,2} HITS{102,2} nan HITS{111,2} HITS{112,2} HITS{113,2} HITS{114,2} nan HITS{123,2} HITS{124,2} HITS{125,2} HITS{126,2} nan HITS{135,2} HITS{136,2} HITS{137,2} HITS{138,2} nan;...
%         nan HITS{79,2} HITS{80,2} HITS{81,2} HITS{82,2} nan HITS{91,2} HITS{92,2} HITS{93,2} HITS{94,2} nan HITS{103,2} HITS{104,2} HITS{105,2}  HITS{106,2} nan HITS{115,2} HITS{116,2} HITS{117,2} HITS{118,2} nan HITS{127,2} HITS{128,2} HITS{129,2} HITS{130,2} nan HITS{139,2} HITS{140,2} HITS{141,2} HITS{142,2} nan;...
%         nan nan        HITS{83,2} HITS{84,2} nan        nan nan        HITS{95,2} HITS{96,2} nan        nan nan         HITS{107,2} HITS{108,2}   nan      nan nan         HITS{119,2} HITS{120,2} nan        nan nan         HITS{131,2} HITS{132,2} nan         nan nan         HITS{143,2} HITS{144,2} nan nan];
%     
%     
% else
%     if isempty(HITS{61,2})
%         dex1 = cellfun('isempty',HITS);
%         HITS(dex1) = {0};
%     else
%     end
%     layout=...
%         [nan   nan     HITS{1,2} HITS{2,2} nan       nan nan        HITS{13,2} HITS{14,2} nan        nan nan        HITS{25,2} HITS{26,2} nan        nan nan        HITS{37,2} HITS{38,2} nan        nan nan        HITS{49,2} HITS{50,2} nan        nan nan        HITS{61,2} HITS{62,2} nan nan;...
%         nan HITS{3,2} HITS{4,2} HITS{5,2} HITS{6,2} nan HITS{15,2} HITS{16,2} HITS{17,2} HITS{18,2} nan HITS{27,2} HITS{28,2} HITS{29,2} HITS{30,2} nan HITS{39,2} HITS{40,2} HITS{41,2} HITS{42,2} nan HITS{51,2} HITS{52,2} HITS{53,2} HITS{54,2} nan HITS{63,2} HITS{64,2} HITS{65,2} HITS{66,2} nan;...
%         nan HITS{7,2} HITS{8,2} HITS{9,2} HITS{10,2} nan HITS{19,2} HITS{20,2} HITS{21,2} HITS{15,2} nan HITS{31,2} HITS{32,2} HITS{33,2} HITS{34,2} nan HITS{43,2} HITS{44,2} HITS{45,2} HITS{46,2} nan HITS{55,2} HITS{56,2} HITS{57,2} HITS{58,2} nan HITS{67,2} HITS{68,2} HITS{69,2} HITS{70,2} nan;...
%         nan nan       HITS{11,2} HITS{12,2} nan     nan nan        HITS{23,2} HITS{24,2} nan        nan nan        HITS{35,2} HITS{36,2} nan        nan nan        HITS{47,2} HITS{48,2} nan        nan nan        HITS{59,2} HITS{60,2} nan        nan nan        HITS{71,2} HITS{72,2} nan nan;...
%         nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
%         nan nan        HITS{73,2} HITS{74,2} nan        nan nan        HITS{85,2} HITS{86,2} nan        nan nan         HITS{97,2} HITS{98,2} nan         nan nan         HITS{109,2} HITS{110,2} nan         nan nan         HITS{121,2} HITS{122,2} nan         nan nan         HITS{133,2} HITS{134,2} nan nan;...
%         nan HITS{75,2} HITS{76,2} HITS{77,2} HITS{78,2} nan HITS{87,2} HITS{88,2} HITS{89,2} HITS{90,2} nan HITS{99,2} HITS{100,2} HITS{101,2} HITS{102,2} nan HITS{111,2} HITS{112,2} HITS{113,2} HITS{114,2} nan HITS{123,2} HITS{124,2} HITS{125,2} HITS{126,2} nan HITS{135,2} HITS{136,2} HITS{137,2} HITS{138,2} nan;...
%         nan HITS{79,2} HITS{80,2} HITS{81,2} HITS{82,2} nan HITS{91,2} HITS{92,2} HITS{93,2} HITS{94,2} nan HITS{103,2} HITS{104,2} HITS{105,2}  HITS{106,2} nan HITS{115,2} HITS{116,2} HITS{117,2} HITS{118,2} nan HITS{127,2} HITS{128,2} HITS{129,2} HITS{130,2} nan HITS{139,2} HITS{140,2} HITS{141,2} HITS{142,2} nan;...
%         nan nan        HITS{83,2} HITS{84,2} nan        nan nan        HITS{95,2} HITS{96,2} nan        nan nan         HITS{107,2} HITS{108,2}   nan      nan nan         HITS{119,2} HITS{120,2} nan        nan nan         HITS{131,2} HITS{132,2} nan         nan nan         HITS{143,2} HITS{144,2} nan nan;...
%         nan nan nan  nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
%         nan nan         HITS{145,2} HITS{146,2} nan         nan nan         HITS{157,2} HITS{158,2} nan         nan nan         HITS{169,2} HITS{170,2} nan         nan nan         HITS{181,2} HITS{182,2} nan         nan nan         HITS{193,2} HITS{194,2} nan         nan nan         HITS{205,2} HITS{206,2} nan nan;...
%         nan HITS{147,2} HITS{148,2} HITS{149,2} HITS{150,2} nan HITS{159,2} HITS{160,2} HITS{161,2} HITS{162,2} nan HITS{171,2} HITS{172,2} HITS{173,2} HITS{174,2} nan HITS{183,2} HITS{184,2} HITS{185,2} HITS{186,2} nan HITS{195,2} HITS{196,2} HITS{197,2} HITS{198,2} nan HITS{207,2} HITS{208,2} HITS{209,2} HITS{210,2} nan;...
%         nan HITS{151,2} HITS{152,2} HITS{153,2} HITS{154,2} nan HITS{163,2} HITS{164,2} HITS{165,2} HITS{166,2} nan HITS{175,2} HITS{176,2} HITS{177,2} HITS{178,2} nan HITS{187,2} HITS{188,2} HITS{189,2} HITS{190,2} nan HITS{199,2} HITS{200,2} HITS{201,2} HITS{202,2} nan HITS{211,2} HITS{212,2} HITS{213,2} HITS{214,2} nan;...
%         nan nan         HITS{155,2} HITS{156,2} nan         nan nan         HITS{167,2} HITS{168,2} nan         nan nan         HITS{179,2} HITS{180,2} nan         nan nan         HITS{191,2} HITS{192,2} nan         nan nan         HITS{203,2} HITS{204,2} nan         nan nan         HITS{215,2} HITS{216,2} nan nan;...
%         nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
%         nan nan         HITS{217,2} HITS{218,2} nan         nan nan         HITS{229,2} HITS{230,2} nan         nan nan         HITS{241,2} HITS{242,2} nan         nan nan         HITS{253,2} HITS{254,2} nan         nan nan         HITS{265,2} HITS{266,2} nan         nan nan         HITS{277,2} HITS{278,2} nan nan;
%         nan HITS{219,2} HITS{220,2} HITS{221,2} HITS{222,2} nan HITS{231,2} HITS{232,2} HITS{233,2} HITS{234,2} nan HITS{243,2} HITS{244,2} HITS{245,2} HITS{246,2} nan HITS{255,2} HITS{256,2} HITS{257,2} HITS{258,2} nan HITS{267,2} HITS{268,2} HITS{269,2} HITS{270,2} nan HITS{279,2} HITS{280,2} HITS{281,2} HITS{282,2} nan;...
%         nan HITS{223,2} HITS{224,2} HITS{225,2} HITS{226,2} nan HITS{235,2} HITS{236,2} HITS{237,2} HITS{238,2} nan HITS{247,2} HITS{248,2} HITS{249,2} HITS{250,2} nan HITS{259,2} HITS{260,2} HITS{261,2} HITS{262,2} nan HITS{271,2} HITS{272,2} HITS{273,2} HITS{274,2} nan HITS{283,2} HITS{284,2} HITS{285,2} HITS{286,2} nan;...
%         nan nan         HITS{227,2} HITS{228,2} nan         nan nan         HITS{239,2} HITS{240,2} nan         nan nan         HITS{251,2} HITS{252,2} nan         nan nan         HITS{263,2} HITS{264,2} nan         nan nan         HITS{275,2} HITS{276,2} nan         nan nan         HITS{287,2} HITS{288,2} nan nan];
%     
% end
% 
% 
% 
% 
% %// Define integer grid of coordinates for the above data
% [X,Y] = meshgrid(1:size(layout,2), 1:size(layout,1));
% 
% %// Define a finer grid of points
% [X88,Y88] = meshgrid(1:0.01:size(layout,2), 1:0.01:size(layout,1));
% 
% %// Interpolate the data and show the output
% outData = interp2(X,Y,layout, X88, Y88,'linear');
% 
% nanvalues=isnan(outData);
% 
% layout44=layout;
% 
% 
% for i=1:length(layout(:,1))
%     for j=1:length(layout(1,:))
%         if isnan(layout(i,j))
%             layout44(i,j)= 0;
%         else
%         end
%     end
% end
% 
% %// Interpolate the data and show the output
% outData = interp2(X,Y,layout44, X88, Y88,'cubic');
% 
% outData(nanvalues)=nan;
% 
% 
% ax =axes(hObject);
% imagesc(layout,'AlphaData',~isnan(layout));
% mycolormap = parula(256);
% mycolormap(1,:) = 1;
% colormap(mycolormap);
% % textstrings={...
% %      [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
% %      [] '3' '7' [] [] [] '75' '79' [] [] [] '147' '151' [] [] [] '219' '223' [] ...
% %      '1' '4' '8' '11' [] '73' '76' '80' '83' [] '145' '148' '152' '155' [] '217' '220' '224' '227' ...
% %      '2' '5' '9' '12' [] '74' '77' '81' '84' [] '146' '149' '153' '156' [] '218' '221' '225' '228' ...
% %      [] '6' '10' [] [] [] '78' '82' [] [] [] '150' '154' [] [] [] '222' '226' [] ...
% %      [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
% %      [] '15' '19' [] [] [] '87' '91' [] [] [] '159' '163' [] [] [] '231' '235' [] ...
% %      '13' '16' '20' '23' [] '85' '88' '92' '95' [] '157' '160' '164' '167' [] '229' '232' '236' '239' ...
% %      '14' '17' '21' '24' [] '86' '89' '93' '96' [] '158' '161' '165' '168' [] '230' '233' '237' '240' ...
% %      [] '18' '22' [] [] [] '90' '94' [] [] [] '162' '166' [] [] [] '234' '238' [] ...
% %      [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
% %      [] '27' '31' [] [] [] '99' '103' [] [] [] '171' '175' [] [] [] '243' '247' [] ...
% %      '25' '28' '32' '35' [] '97' '100' '104' '107' [] '169' '172' '176' '179' [] '241' '244' '248' '251' ...
% %      '26' '29' '33' '36' [] '98' '101' '105' '108' [] '170' '173' '177' '180' [] '242' '245' '249' '252' ...
% %      [] '30' '34' [] [] [] '102' '106' [] [] [] '174' '178' [] [] [] '246' '250' [] ...
% %      [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
% %      [] '39' '43' [] [] [] '111' '115' [] [] [] '183' '187' [] [] [] '255' '259' [] ...
% %      '37' '40' '44' '47' [] '109' '112' '116' '119' [] '181' '184' '188' '191' [] '253' '256' '260' '263' ...
% %      '38' '41' '45' '48' [] '110' '113' '117' '120' [] '182' '185' '189' '192' [] '254' '257' '261' '264' ...
% %      [] '42' '46' [] [] [] '114' '118' [] [] [] '186' '190' [] [] [] '258' '262' [] ...
% %      [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
% %      [] '51' '55' [] [] [] '123' '127' [] [] [] '195' '199' [] [] [] '267' '271' [] ...
% %      '49' '52' '56' '59' [] '121' '124' '128' '131' [] '193' '196' '200' '203' [] '265' '268' '272' '275' ...
% %      '50' '53' '57' '60' [] '122' '125' '129' '132' [] '194' '197' '201' '204' [] '266' '269' '273' '276' ...
% %      [] '54' '58' [] [] [] '126' '130' [] [] [] '198' '202' [] [] [] '270' '274' [] ...
% %      [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
% %      [] '63' '67' [] [] [] '135' '139' [] [] [] '207' '211' [] [] [] '279' '283' [] ...
% %      '61' '64' '68' '71' [] '133' '136' '140' '143' [] '205' '208' '212' '215' [] '277' '280' '284' '287' ...
% %      '62' '65' '69' '72' [] '134' '137' '141' '144' [] '206' '209' '213' '216' [] '278' '281' '285' '288' ...
% %      [] '66' '70' [] [] [] '135' '142' [] [] [] '210' '214' [] [] [] '282' '286' [] ...
% %      [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []}';
% 
% %
% % [x, y] = meshgrid(1:31);
% % for i=31:-1:20
% %     x(i,:)=[];
% %     y(i,:)=[];
% % end
% % hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
% %     'HorizontalAlignment', 'center');
% 
% %// Cosmetic changes for the axes
% % set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
% % set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
% set(gca, 'XTickLabel', []);
% set(gca, 'YTickLabel', []);
% 
% %// Add colour bar
% % colorbar;
% % heatmap(layout,ans90,(1:12),true,'Gridlines','-','Colorbar',true,'ShowAllTicks',true,'TickFontSize',30)
% % set(gca,'XtickLabel', ans90,'Fontsize',20);
% title('Multi-Well Activity over 10 min','Fontsize',10);
% set(gcf,'Color','w');
end
%% rasterplot panel
% --- Executes during object creation, after setting all properties.
function uipanel3_CreateFcn(hObject, eventdata, handles)
global cbx98 cbx99 parts selecteddata xpoints ypoints xPoints yPoints ends2 starts2 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1

hObject.Title={};
hObject.BackgroundColor=[1 1 1];
% hObject.Position = [0.64 0.038 0.176 0.358]; % old possiiton
hObject.Position = [0.535 0.038 0.280 0.358];
hObject.Visible = 'on';
ax= axes(hObject);


    for i = 2:25
        checked =sprintf('Well_%d',i);
        if contains(selecteddata,'Well')
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        else
            selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
        end
    end
    
    val = 1;
    
    
    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    if joost == 1
        range2 = cell(1,24);
        UUU= 1:16;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+16;
        end
    else
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
    end
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;


    if ~isempty(xpoints)
        %create a new xpoints variable that contains al the xpoints
        if ~isempty(xpoints)
            timesss = ceil(max(xpoints));
        end
        
        resolution = 0.001; %binsize of 1 ms
        sigma = 0.1 ; %100 ms STD of gaussian
        % Use hist to bin
        EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
        N = histc(xpoints, EDGES);
        %     N = N ./timesss; %normalize for total duration to get firing rate
        %Time ranges form -3*st. dev. to 3*st. dev.
        edges = (-3*sigma:resolution:3*sigma);
        %Evaluate the Gaussian kernel
        kernel = normpdf(edges,0,sigma);
        %Multiply by bin width so the probabilities sum to 1?
        kernel = kernel.*resolution;
        %Convolve spike data with the kernel
        s = conv(N,kernel);
        s = s/resolution;
        %Find the index of the kernel center
        center = ceil(length(edges)/2);
        %     Trim out the relevant portion of the spike density
        s = s(center:end-center-1);
        %     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
        t = (1:length(s))*resolution ;
        
        plp1 = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
        
        
        %adapated from plotSPikeRaster by Jeffrey Chiou
        nTotalSpikes = sum(cellfun(@length,M2));
        
        
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;
        
        
        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        
        plot(xPoints, yPoints, 'k')
        xlim([0 timesss])
        if joost ==1
             correctylim = val *16;
           correctylim = [(correctylim - 16):4: correctylim+4];
        else
        correctylim = val *12;
        correctylim = [(correctylim - 12):2: correctylim+2];
        end
        plp1.YTickLabel = correctylim;
        %     set(gca,'XLim',correctxlim);
        set(gca,'XTick',[]);
        
        
        yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
        cla(yy);
        plot(t,s,'k');
        xlim([0 timesss])
        ylabel('AWFR (Hz)');
        xlabel('Time(s)','Fontsize',10);
        correctxlim = get(gca,'XLim');
        
        
        subplot('position',[0.2 0.35 0.7 0.6]); hold on;
        %correct ylim
        
        
        title(sprintf('Array Wide Activity of Well %d',val));
    end
clear M2 xpoints

%% old function
% 
% %'preprocessing'
% 
% %create a new M2 variable that contains all xpoints
% 
% range2 = cell(1,24);
% UUU= 1:12;
% for i = 1:24
%     range2{i} = UUU;
%     UUU=UUU+12;
% end
% 
% %     selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
% selecteddata2 = selecteddata;
% HITA = cell(1,288)';
% for i = 1:parts
%     load(selecteddata,'M2')
%     HITA(range2{i}(1):range2{i}(end)) = M2(1:12);
% 
%     replace1 =sprintf('Well_%d',i);
%     replace2 = sprintf('Well_%d',i+1);
%     selecteddata = replace(selecteddata,replace1,replace2);
% 
% end
% 
% M2 = HITA;
% selecteddata = selecteddata2;
% 
% 
% %create a new xpoints variable that contains al the xpoints
% 
% 
% selecteddata2 = selecteddata;
% HITA = [];
% for i = 1:parts
%     load(selecteddata,'xpoints')
%     HITA = [HITA xpoints];
% 
%     replace1 =sprintf('Well_%d',i);
%     replace2 = sprintf('Well_%d',i+1);
%     selecteddata = replace(selecteddata,replace1,replace2);
% 
% end
% 
% xpoints = HITA;
% xpoints=sort(xpoints);
% selecteddata = selecteddata2;
% 
% 
% timesss = ceil(max(xpoints));
% 
% %adapated from plotSPikeRaster by Jeffrey Chiou
% 
% resolution = 0.001; %binsize of 1 ms
% sigma = 0.1 ; %100 ms STD of gaussian
% % Use hist to bin
% EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
% N = histc(xpoints, EDGES);
% %     N = N ./timesss; %normalize for total duration to get firing rate
% %Time ranges form -3*st. dev. to 3*st. dev.
% edges = (-3*sigma:resolution:3*sigma);
% %Evaluate the Gaussian kernel
% kernel = normpdf(edges,0,sigma);
% %Multiply by bin width so the probabilities sum to 1?
% kernel = kernel.*resolution;
% %Convolve spike data with the kernel
% s = conv(N,kernel);
% s = s/resolution;
% %Find the index of the kernel center
% %     center = ceil(length(edges)/2);
% %     %Trim out the relevant portion of the spike density
% %     s = s(center:end-center-1);
% if isempty(xpoints)
% else
%     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
% 
%     subplot('position',[0.2 0.15 0.7 0.15]); hold on;
%     plot(t,s,'k');
%     xlim([0 timesss])
% 
%     ylabel('AWFR');
%     xlabel('Time (s)');
% 
%     % set(gca,'XTick',[]);    % no x numbers
%     correctxlim = get(gca,'XLim');
%     %     set(gca,'Fontsize',20)
% 
% 
%     % calculate the rasterplot
%     subplot('position',[0.2 0.35 0.7 0.6]); hold on;
% 
%     nTotalSpikes = sum(cellfun(@length,M2));
% 
% 
%     xPoints = NaN(nTotalSpikes*3,1);
%     yPoints = xPoints;
%     currentInd = 1;
% 
% 
%     halfSpikeHeight = 1/2;
%     for trials = 1:length(M2)
%         nSpikes = length(M2{trials});
%         nanSeparator = NaN(1,nSpikes);
% 
%         trialXPoints = [ M2{trials} + 0;...
%             M2{trials} + 0; nanSeparator ];
%         trialXPoints = trialXPoints(:);
% 
%         trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
%             (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
%         trialYPoints = trialYPoints(:);
% 
%         % Save points and update current index
%         xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
%         yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
%         currentInd = currentInd + nSpikes*3;
%     end
% 
%     plot(xPoints, yPoints, 'k')
%     title('Multi Well Activity over Time')
%     set(gca,'XLim',correctxlim);
%     set(gca,'XTick',[]);
%     if parts == 24
% 
%         ylim([0 288]);
%     else
%         ylim([0 144]);
%     end
% end
end
%% Connections Panel

% all connections
function uipanel6_CreateFcn(hObject, eventdata, handles)
hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.01 .54 .398 .358];
end

function uipanel6_ButtonDownFcn(hObject, eventdata, handles)


end

% --- all connections
function pushbutton62_Callback(hObject, eventdata, handles)
global supa only200 newM2 looo12 parts electrodecount textstrings selecteddata indx23 timesss finalssss thrconnec HITS filteredData1 M2 arrowss Ghibli  jitters M joost multiwell1
noconnections = 0;
if indx23 == 2
    
    supa1 = supa;
    %gotta turn the numbers around for the max function
    for i=1:length(M2)
        supa1{i}=supa1{i}';
    end
    
    for i=1:length(M2)
        supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
    end
    
    
    HITS48=HITS;
    
    lp=rand(1,length(HITS))+rand(1,length(HITS));
    kp=rand(1,length(HITS))+rand(1,length(HITS));
    ml=rand(1,length(HITS))+0.68;
    lp=lp+kp+ml;
    lp=lp';
    for i=1:length(HITS)
        HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
    end
    
    
    if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
        layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
    elseif length(filteredData1(:,1)) > 121
        layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
    else %% for 120 channel MEA
        layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
    end
    
    %     ax = axes(hObject);
    imagesc(layout4,'AlphaData',~isnan(layout4));
    
    if length(textstrings) > 400
        [x, y] = meshgrid(1:24);
        for i=[24 23 22 21 20]
            x(i,:)=[];
            y(i,:)=[];
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    else
        [x, y] = meshgrid(1:12);
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    end
    
    
    %         waitbar(0 + 0.9,hh,'Drawing the Connections');
    top60=cell2mat(supa1);
    top60(top60 < thrconnec) = 0;
    % change nan values into zeros
    
    %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
    
    [B,I]=sort(top60,'descend');   % order them
    ghg=find(B == 0); %remove all the zeros
    I(ghg)=[];
    
    
    if length(filteredData1(:,1)) == 60
        I=I(:)/60;
    else
        I=I(:)/120;
    end
    
    if only200 == 1 %display only the top 200 connections
        if length(I) > 200
            I=I(1:200);
        end
    end
    
    %each 120 elements belong to one channel
    %firsst column will be the origin of the line
    %2nd column will be the destination of the line
    I(:,2)=floor(I(:,1));
    I(:,3)=I(:,1) - I(:,2);
    
    if length(filteredData1(:,1)) == 60
        I(:,3)=I(:,3)*60;
    else
        I(:,3)=I(:,3)*120;
    end
    
    I(:,3)=round(I(:,3));
    I(:,2)=ceil(I(:,1));
    I(I<1) = 1;
    ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
    removeindx = find(cell2mat(HITS(:,2)) <= 10);
    
    I(ismember(I(:,2),removeindx)) =0;
    I(ismember(I(:,2),removeindx),3) =0;
    I(ismember(I(:,2),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),1) =0;
    I(ismember(I(:,3),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),3) =0;
    
    for i = length(I):-1:1
        if I(i,1) == 0
            I(i,:) = [];
        end
    end
    
    for i=1:size(I,1)
        yutr=I(i,2);
        
        kk=ag(ag==yutr); % added for joosts method
        lll=find(layout4 == HITS48{kk,2});
        [r,c] = ind2sub(size(layout4),lll);
        
        k=I(i,3);
        llll=find(layout4 == HITS48{k,2});
        [rr,cc] = ind2sub(size(layout4),llll);
        hold on
        if arrowss == 1
            nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
        elseif arrowss == 0
            nnn=line([c cc],[r rr],'Color','r');
        end
        drawnow;
        colmin=min(top60(:));
        colmax=max(top60(:));
        COLOR1=parula(length(top60));
        goodcolor=COLOR1(round(length(top60)*(top60(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
        nnn.Color=goodcolor;
        cbn=colorbar;
        cbn.Colormap=parula(length(top60));
        %         cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        %         cbn.TickLabels = [0.73 0.76 0.79 0.82 0.85 0.88 0.91 094 0.97 1];
    end
    
    set(gca,'visible','off');
    set(gca,'Colormap',[1 1 1]);
    %     save([selecteddata '.mat'],'looo12','-append','-v6')
else
    
    if joost && multiwell1 == 1
        if ~isempty(M)
            supa1=cell(1,length(M2))';
            for i = 1:length(M2) % added for joost's method
                supa1{i} = M(i,:)';
            end
        else
            msgbox('There are no connections!')
            noconnections = 1;
        end
    else
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
        
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        end
        
        supa1=cell(1,length(M2))';
        j = 1;
        load(selecteddata,'M');
        
        for i = 1:(electrodecount*parts)
            if isempty(M)
                continue
            else
                supa1{i} = M(1:electrodecount)';
                if i == 12
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 24
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 36
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 48
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 60
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 72
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 84
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 96
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 108
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 120
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 132
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                end
            end
        end
        
    end
    %higher than 70% we will draw a line (spikecode did this aswell
    %so now the only thing we need to do is draw a line if the number exceeds
    %0.7 or 70% SPYCODE threshhold
    
    %use the below layout structure to get the correct position
    
    %So what needs to happen is 3 things, we will first check if in supa
    %soemthing has passed the 0.7 mark and if it does the next thing it will do
    %is search in the layout for the correct position and the last step is to
    %draw a line
    
    %we have to make the numbers uin HITS all unqiue so we won't have issues with duplicates
    if noconnections == 1
    else
        HITS48=HITS;
        lp=rand(1,length(HITS))+rand(1,length(HITS));
        kp=rand(1,length(HITS))+rand(1,length(HITS));
        ml=rand(1,length(HITS))+0.68;
        lp=lp+kp+ml;
        lp=lp';
        
        for i=1:length(HITS)
            HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
        end
        
        
        if parts == 12
            layout4=...
                [nan   nan     HITS48{1,2} HITS48{2,2} nan       nan nan        HITS48{13,2} HITS48{14,2} nan        nan nan        HITS48{25,2} HITS48{26,2} nan        nan nan        HITS48{37,2} HITS48{38,2} nan        nan nan        HITS48{49,2} HITS48{50,2} nan        nan nan        HITS48{61,2} HITS48{62,2} nan nan;...
                nan HITS48{3,2} HITS48{4,2} HITS48{5,2} HITS48{6,2} nan HITS48{15,2} HITS48{16,2} HITS48{17,2} HITS48{18,2} nan HITS48{27,2} HITS48{28,2} HITS48{29,2} HITS48{30,2} nan HITS48{39,2} HITS48{40,2} HITS48{41,2} HITS48{42,2} nan HITS48{51,2} HITS48{52,2} HITS48{53,2} HITS48{54,2} nan HITS48{63,2} HITS48{64,2} HITS48{65,2} HITS48{66,2} nan;...
                nan HITS48{7,2} HITS48{8,2} HITS48{9,2} HITS48{10,2} nan HITS48{19,2} HITS48{20,2} HITS48{21,2} HITS48{15,2} nan HITS48{31,2} HITS48{32,2} HITS48{33,2} HITS48{34,2} nan HITS48{43,2} HITS48{44,2} HITS48{45,2} HITS48{46,2} nan HITS48{55,2} HITS48{56,2} HITS48{57,2} HITS48{58,2} nan HITS48{67,2} HITS48{68,2} HITS48{69,2} HITS48{70,2} nan;...
                nan nan       HITS48{11,2} HITS48{12,2} nan     nan nan        HITS48{23,2} HITS48{24,2} nan        nan nan        HITS48{35,2} HITS48{36,2} nan        nan nan        HITS48{47,2} HITS48{48,2} nan        nan nan        HITS48{59,2} HITS48{60,2} nan        nan nan        HITS48{71,2} HITS48{72,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan        HITS48{73,2} HITS48{74,2} nan        nan nan        HITS48{85,2} HITS48{86,2} nan        nan nan         HITS48{97,2} HITS48{98,2} nan         nan nan         HITS48{109,2} HITS48{110,2} nan         nan nan         HITS48{121,2} HITS48{122,2} nan         nan nan         HITS48{133,2} HITS48{134,2} nan nan;...
                nan HITS48{75,2} HITS48{76,2} HITS48{77,2} HITS48{78,2} nan HITS48{87,2} HITS48{88,2} HITS48{89,2} HITS48{90,2} nan HITS48{99,2} HITS48{100,2} HITS48{101,2} HITS48{102,2} nan HITS48{111,2} HITS48{112,2} HITS48{113,2} HITS48{114,2} nan HITS48{123,2} HITS48{124,2} HITS48{125,2} HITS48{126,2} nan HITS48{135,2} HITS48{136,2} HITS48{137,2} HITS48{138,2} nan;...
                nan HITS48{79,2} HITS48{80,2} HITS48{81,2} HITS48{82,2} nan HITS48{91,2} HITS48{92,2} HITS48{93,2} HITS48{94,2} nan HITS48{103,2} HITS48{104,2} HITS48{105,2}  HITS48{106,2} nan HITS48{115,2} HITS48{116,2} HITS48{117,2} HITS48{118,2} nan HITS48{127,2} HITS48{128,2} HITS48{129,2} HITS48{130,2} nan HITS48{139,2} HITS48{140,2} HITS48{141,2} HITS48{142,2} nan;...
                nan nan        HITS48{83,2} HITS48{84,2} nan        nan nan        HITS48{95,2} HITS48{96,2} nan        nan nan         HITS48{107,2} HITS48{108,2}   nan      nan nan         HITS48{119,2} HITS48{120,2} nan        nan nan         HITS48{131,2} HITS48{132,2} nan         nan nan         HITS48{143,2} HITS48{144,2} nan nan];
            
        elseif joost && multiwell1 == 1
            
              layout4= [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{1,2}   HITS48{2,2}   HITS48{3,2}   HITS48{4,2}   nan nan HITS48{17,2}  HITS48{18,2}  HITS48{19,2}  HITS48{20,2}  nan nan HITS48{33,2}  HITS48{34,2}  HITS48{35,2}  HITS48{36,2}  nan nan HITS48{49,2}  HITS48{50,2}  HITS48{51,2}  HITS48{52,2}  nan nan HITS48{65,2}  HITS48{66,2}  HITS48{67,2}  HITS48{68,2}  nan nan HITS48{81,2}  HITS48{82,2}  HITS48{83,2}  HITS48{84,2}  nan nan;
                nan nan HITS48{5,2}   HITS48{6,2}   HITS48{7,2}   HITS48{8,2}   nan nan HITS48{21,2}  HITS48{22,2}  HITS48{23,2}  HITS48{24,2}  nan nan HITS48{37,2}  HITS48{38,2}  HITS48{39,2}  HITS48{40,2}  nan nan HITS48{53,2}  HITS48{54,2}  HITS48{55,2}  HITS48{56,2}  nan nan HITS48{69,2}  HITS48{70,2}  HITS48{71,2}  HITS48{72,2}  nan nan HITS48{85,2}  HITS48{86,2}  HITS48{87,2}  HITS48{88,2}  nan nan;
                nan nan HITS48{9,2}   HITS48{10,2}  HITS48{11,2}  HITS48{12,2}  nan nan HITS48{25,2}  HITS48{26,2}  HITS48{27,2}  HITS48{28,2}  nan nan HITS48{41,2}  HITS48{42,2}  HITS48{43,2}  HITS48{44,2}  nan nan HITS48{57,2}  HITS48{58,2}  HITS48{59,2}  HITS48{60,2}  nan nan HITS48{73,2}  HITS48{74,2}  HITS48{75,2}  HITS48{76,2}  nan nan HITS48{89,2}  HITS48{90,2}  HITS48{91,2}  HITS48{92,2}  nan nan;
                nan nan HITS48{13,2}  HITS48{14,2}  HITS48{15,2}  HITS48{16,2}  nan nan HITS48{29,2}  HITS48{30,2}  HITS48{31,2}  HITS48{32,2}  nan nan HITS48{45,2}  HITS48{46,2}  HITS48{47,2}  HITS48{48,2}  nan nan HITS48{61,2}  HITS48{62,2}  HITS48{63,2}  HITS48{64,2}  nan nan HITS48{77,2}  HITS48{78,2}  HITS48{79,2}  HITS48{80,2}  nan nan HITS48{93,2}  HITS48{94,2}  HITS48{95,2}  HITS48{96,2}  nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{97,2}  HITS48{98,2}  HITS48{99,2}  HITS48{100,2} nan nan HITS48{113,2} HITS48{114,2} HITS48{115,2} HITS48{116,2} nan nan HITS48{129,2} HITS48{130,2} HITS48{131,2} HITS48{132,2} nan nan HITS48{145,2} HITS48{146,2} HITS48{147,2} HITS48{148,2} nan nan HITS48{161,2} HITS48{162,2} HITS48{163,2} HITS48{164,2} nan nan HITS48{177,2} HITS48{178,2} HITS48{179,2} HITS48{180,2} nan nan;
                nan nan HITS48{101,2} HITS48{102,2} HITS48{103,2} HITS48{104,2} nan nan HITS48{117,2} HITS48{118,2} HITS48{119,2} HITS48{120,2} nan nan HITS48{133,2} HITS48{134,2} HITS48{135,2} HITS48{136,2} nan nan HITS48{149,2} HITS48{150,2} HITS48{151,2} HITS48{152,2} nan nan HITS48{165,2} HITS48{166,2} HITS48{167,2} HITS48{168,2} nan nan HITS48{181,2} HITS48{182,2} HITS48{183,2} HITS48{184,2} nan nan;
                nan nan HITS48{105,2} HITS48{106,2} HITS48{107,2} HITS48{108,2} nan nan HITS48{121,2} HITS48{122,2} HITS48{123,2} HITS48{124,2} nan nan HITS48{137,2} HITS48{138,2} HITS48{139,2} HITS48{140,2} nan nan HITS48{153,2} HITS48{154,2} HITS48{155,2} HITS48{156,2} nan nan HITS48{169,2} HITS48{170,2} HITS48{171,2} HITS48{172,2} nan nan HITS48{185,2} HITS48{186,2} HITS48{187,2} HITS48{188,2} nan nan;
                nan nan HITS48{109,2} HITS48{110,2} HITS48{111,2} HITS48{112,2} nan nan HITS48{125,2} HITS48{126,2} HITS48{127,2} HITS48{128,2} nan nan HITS48{141,2} HITS48{142,2} HITS48{143,2} HITS48{144,2} nan nan HITS48{157,2} HITS48{158,2} HITS48{159,2} HITS48{160,2} nan nan HITS48{173,2} HITS48{174,2} HITS48{175,2} HITS48{176,2} nan nan HITS48{189,2} HITS48{190,2} HITS48{191,2} HITS48{192,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{193,2} HITS48{194,2} HITS48{195,2} HITS48{196,2} nan nan HITS48{209,2} HITS48{210,2} HITS48{211,2} HITS48{212,2} nan nan HITS48{225,2} HITS48{226,2} HITS48{227,2} HITS48{228,2} nan nan HITS48{241,2} HITS48{242,2} HITS48{243,2} HITS48{244,2} nan nan HITS48{257,2} HITS48{258,2} HITS48{259,2} HITS48{260,2} nan nan HITS48{273,2} HITS48{274,2} HITS48{275,2} HITS48{276,2} nan nan;
                nan nan HITS48{197,2} HITS48{198,2} HITS48{199,2} HITS48{200,2} nan nan HITS48{213,2} HITS48{214,2} HITS48{215,2} HITS48{216,2} nan nan HITS48{229,2} HITS48{230,2} HITS48{231,2} HITS48{232,2} nan nan HITS48{245,2} HITS48{246,2} HITS48{247,2} HITS48{248,2} nan nan HITS48{261,2} HITS48{262,2} HITS48{263,2} HITS48{264,2} nan nan HITS48{277,2} HITS48{278,2} HITS48{279,2} HITS48{280,2} nan nan;
                nan nan HITS48{201,2} HITS48{202,2} HITS48{203,2} HITS48{204,2} nan nan HITS48{217,2} HITS48{218,2} HITS48{219,2} HITS48{220,2} nan nan HITS48{233,2} HITS48{234,2} HITS48{235,2} HITS48{236,2} nan nan HITS48{249,2} HITS48{250,2} HITS48{251,2} HITS48{252,2} nan nan HITS48{265,2} HITS48{266,2} HITS48{267,2} HITS48{268,2} nan nan HITS48{281,2} HITS48{282,2} HITS48{283,2} HITS48{284,2} nan nan;
                nan nan HITS48{205,2} HITS48{206,2} HITS48{207,2} HITS48{208,2} nan nan HITS48{221,2} HITS48{222,2} HITS48{223,2} HITS48{224,2} nan nan HITS48{237,2} HITS48{238,2} HITS48{239,2} HITS48{240,2} nan nan HITS48{253,2} HITS48{254,2} HITS48{255,2} HITS48{256,2} nan nan HITS48{269,2} HITS48{270,2} HITS48{271,2} HITS48{272,2} nan nan HITS48{285,2} HITS48{286,2} HITS48{287,2} HITS48{288,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{289,2} HITS48{290,2} HITS48{291,2} HITS48{292,2} nan nan HITS48{305,2} HITS48{306,2} HITS48{307,2} HITS48{308,2} nan nan HITS48{321,2} HITS48{322,2} HITS48{323,2} HITS48{324,2} nan nan HITS48{337,2} HITS48{338,2} HITS48{339,2} HITS48{340,2} nan nan HITS48{353,2} HITS48{354,2} HITS48{355,2} HITS48{356,2} nan nan HITS48{369,2} HITS48{370,2} HITS48{371,2} HITS48{372,2} nan nan;
                nan nan HITS48{293,2} HITS48{294,2} HITS48{295,2} HITS48{296,2} nan nan HITS48{309,2} HITS48{310,2} HITS48{311,2} HITS48{312,2} nan nan HITS48{325,2} HITS48{326,2} HITS48{327,2} HITS48{328,2} nan nan HITS48{341,2} HITS48{342,2} HITS48{343,2} HITS48{344,2} nan nan HITS48{357,2} HITS48{358,2} HITS48{359,2} HITS48{360,2} nan nan HITS48{373,2} HITS48{374,2} HITS48{375,2} HITS48{376,2} nan nan;
                nan nan HITS48{297,2} HITS48{298,2} HITS48{299,2} HITS48{300,2} nan nan HITS48{313,2} HITS48{314,2} HITS48{315,2} HITS48{316,2} nan nan HITS48{329,2} HITS48{330,2} HITS48{331,2} HITS48{332,2} nan nan HITS48{345,2} HITS48{346,2} HITS48{347,2} HITS48{348,2} nan nan HITS48{361,2} HITS48{362,2} HITS48{363,2} HITS48{364,2} nan nan HITS48{377,2} HITS48{378,2} HITS48{379,2} HITS48{380,2} nan nan;
                nan nan HITS48{301,2} HITS48{302,2} HITS48{303,2} HITS48{304,2} nan nan HITS48{317,2} HITS48{318,2} HITS48{319,2} HITS48{320,2} nan nan HITS48{333,2} HITS48{334,2} HITS48{335,2} HITS48{336,2} nan nan HITS48{349,2} HITS48{350,2} HITS48{351,2} HITS48{352,2} nan nan HITS48{365,2} HITS48{366,2} HITS48{367,2} HITS48{368,2} nan nan HITS48{381,2} HITS48{382,2} HITS48{383,2} HITS48{384,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan];
        else
            layout4=...
                [nan nan HITS48{12,2} HITS48{11,2} nan nan nan HITS48{24,2} HITS48{23,2} nan nan nan HITS48{36,2} HITS48{35,2} nan nan nan HITS48{48,2} HITS48{47,2} nan nan nan HITS48{60,2} HITS48{59,2} nan nan nan HITS48{72,2} HITS48{71,2} nan nan;...
                nan HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} nan HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} nan HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} nan HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} nan HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} nan HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2} nan;...
                nan  HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} nan HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} nan HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} nan HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} nan HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} nan HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2} nan;...
                nan nan HITS48{2,2} HITS48{1,2} nan nan nan HITS48{14,2} HITS48{13,2} nan nan nan HITS48{26,2} HITS48{25,2} nan nan nan HITS48{38,2} HITS48{37,2} nan nan nan HITS48{50,2} HITS48{49,2} nan nan nan HITS48{62,2} HITS48{61,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{84,2} HITS48{83,2} nan nan nan HITS48{96,2} HITS48{95,2} nan nan nan HITS48{108,2} HITS48{107,2} nan nan nan HITS48{120,2} HITS48{119,2} nan nan nan HITS48{132,2} HITS48{131,2} nan nan nan HITS48{144,2} HITS48{143,2} nan nan;...
                nan HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} nan HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} nan HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} nan HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} nan HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} nan HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2} nan;...
                nan HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} nan HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} nan HITS48{102,2} HITS48{101,2} HITS48{100,2}  HITS48{99,2} nan HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} nan HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} nan HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2} nan;...
                nan nan HITS48{74,2} HITS48{73,2} nan nan nan HITS48{86,2} HITS48{85,2} nan nan nan HITS48{98,2} HITS48{97,2} nan nan nan HITS48{110,2} HITS48{109,2} nan nan nan HITS48{122,2} HITS48{121,2} nan nan nan HITS48{134,2} HITS48{133,2} nan nan;...
                nan nan nan  nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{156,2} HITS48{155,2} nan nan nan HITS48{168,2} HITS48{167,2} nan nan nan HITS48{180,2} HITS48{179,2} nan nan nan HITS48{192,2} HITS48{191,2} nan nan nan HITS48{204,2} HITS48{203,2} nan nan nan HITS48{216,2} HITS48{215,2} nan nan;...
                nan HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} nan HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} nan HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} nan HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} nan HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} nan HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2} nan;...
                nan HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} nan HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} nan HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} nan HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} nan HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} nan HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2} nan;...
                nan nan HITS48{146,2} HITS48{145,2} nan nan nan HITS48{158,2} HITS48{157,2} nan nan nan HITS48{170,2} HITS48{169,2} nan nan nan HITS48{182,2} HITS48{181,2} nan nan nan HITS48{194,2} HITS48{193,2} nan nan nan HITS48{206,2} HITS48{205,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{228,2} HITS48{227,2} nan nan nan HITS48{240,2} HITS48{239,2} nan nan nan HITS48{252,2} HITS48{251,2} nan nan nan HITS48{264,2} HITS48{263,2} nan nan nan HITS48{276,2} HITS48{275,2} nan nan nan HITS48{288,2} HITS48{287,2} nan nan;
                nan HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} nan HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} nan HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} nan HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} nan HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} nan HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2} nan;...
                nan HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} nan HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} nan HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} nan HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} nan HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} nan HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2} nan;...
                nan nan HITS48{218,2} HITS48{217,2} nan nan nan HITS48{230,2} HITS48{229,2} nan nan nan HITS48{242,2} HITS48{241,2} nan nan nan HITS48{254,2} HITS48{253,2} nan nan nan HITS48{266,2} HITS48{265,2} nan nan nan HITS48{278,2} HITS48{277,2} nan nan];
        end
        
        axes22 = axes(handles.uipanel6);
        %     ax = axes(hObject);
        imagesc(layout4,'AlphaData',~isnan(layout4));
        if joost && multiwell1 == 1
            textstrings={...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '1'  '5' '9'  '13'  [] [] '97'  '101' '105' '109'  [] [] '193' '197' '201' '205' [] [] '289' '293' '297' '301' [] []...
                [] [] '2'  '6' '10' '14'  [] [] '98'  '102' '106' '110'  [] [] '194' '198' '202' '206' [] [] '290' '294' '298' '302' [] []...
                [] [] '3'  '7' '11' '15'  [] [] '99'  '103' '107' '111'  [] [] '195' '199' '203' '207' [] [] '291' '295' '299' '303' [] []...
                [] [] '4'  '8' '12' '16'  [] [] '100' '104' '108' '112'  [] [] '196' '200' '204' '208' [] [] '292' '296' '300' '304' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '17' '21' '25' '29' [] [] '113'  '117' '121' '125' [] [] '209' '213' '217' '221' [] [] '305' '309' '313' '317' [] []...
                [] [] '18' '22' '26' '30' [] [] '114'  '118' '122' '126' [] [] '210' '214' '218' '222' [] [] '306' '310' '314' '318' [] []...
                [] [] '19' '23' '27' '31' [] [] '115'  '119' '123' '127' [] [] '211' '215' '219' '223' [] [] '307' '311' '315' '319' [] []...
                [] [] '20' '24' '28' '32' [] [] '116'  '120' '124' '128' [] [] '212' '216' '220' '224' [] [] '308' '312' '316' '320' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '33' '37' '41' '45' [] [] '129'  '133' '137' '141' [] [] '225' '229' '233' '237' [] [] '321' '325' '329' '333' [] []...
                [] [] '34' '38' '42' '46' [] [] '130'  '134' '138' '142' [] [] '226' '230' '234' '238' [] [] '322' '326' '330' '334' [] []...
                [] [] '35' '39' '43' '47' [] [] '131'  '135' '139' '143' [] [] '227' '231' '235' '239' [] [] '323' '327' '331' '335' [] []...
                [] [] '36' '40' '44' '48' [] [] '132'  '136' '140' '144' [] [] '228' '232' '236' '240' [] [] '324' '328' '332' '336' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '49' '53' '57' '61' [] [] '145' '149' '153' '157'  [] [] '241' '245' '249' '253' [] [] '337' '341' '345' '349' [] []...
                [] [] '50' '54' '58' '62' [] [] '146' '150' '154' '158'  [] [] '242' '246' '250' '254' [] [] '338' '342' '346' '350' [] []...
                [] [] '51' '55' '59' '63' [] [] '147' '151' '155' '159'  [] [] '243' '247' '251' '255' [] [] '339' '343' '347' '351' [] []...
                [] [] '52' '56' '60' '64' [] [] '148' '152' '156' '160'  [] [] '244' '248' '252' '256' [] [] '340' '344' '348' '352' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '65' '69' '73' '77' [] [] '161' '165' '169' '173'  [] [] '257' '261' '265' '269' [] [] '353' '357' '361' '365' [] []...
                [] [] '66' '70' '74' '78' [] [] '162' '166' '170' '174'  [] [] '258' '262' '266' '270' [] [] '354' '358' '362' '366' [] []...
                [] [] '67' '71' '75' '79' [] [] '163' '167' '171' '175'  [] [] '259' '263' '267' '271' [] [] '355' '359' '363' '367' [] []...
                [] [] '68' '72' '76' '80' [] [] '164' '168' '172' '176'  [] [] '260' '264' '268' '272' [] [] '356' '360' '364' '368' [] []...
                [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '81' '85' '89' '93' [] [] '177' '181' '185' '189'  [] [] '273' '277' '281' '285' [] [] '369' '373' '377' '381' [] []...
                [] [] '82' '86' '90' '94' [] [] '178' '182' '186' '190'  [] [] '274' '278' '282' '286' [] [] '370' '374' '378' '382' [] []...
                [] [] '83' '87' '91' '95' [] [] '179' '183' '187' '191'  [] [] '275' '279' '283' '287' [] [] '371' '375' '379' '383' [] []...
                [] [] '84' '88' '92' '96' [] [] '180' '184' '188' '192'  [] [] '276' '280' '284' '288' [] [] '372' '376' '380' '384' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []}';
            
            
            [x, y] = meshgrid(1:38);
            for i=31:-1:20
                x(i,:)=[];
                y(i,:)=[];
            end
        else
            textstrings={...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '3' '7' [] [] [] '75' '79' [] [] [] '147' '151' [] [] [] '219' '223' [] ...
                '1' '4' '8' '11' [] '73' '76' '80' '83' [] '145' '148' '152' '155' [] '217' '220' '224' '227' ...
                '2' '5' '9' '12' [] '74' '77' '81' '84' [] '146' '149' '153' '156' [] '218' '221' '225' '228' ...
                [] '6' '10' [] [] [] '78' '82' [] [] [] '150' '154' [] [] [] '222' '226' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '15' '19' [] [] [] '87' '91' [] [] [] '159' '163' [] [] [] '231' '235' [] ...
                '13' '16' '20' '23' [] '85' '88' '92' '95' [] '157' '160' '164' '167' [] '229' '232' '236' '239' ...
                '14' '17' '21' '24' [] '86' '89' '93' '96' [] '158' '161' '165' '168' [] '230' '233' '237' '240' ...
                [] '18' '22' [] [] [] '90' '94' [] [] [] '162' '166' [] [] [] '234' '238' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '27' '31' [] [] [] '99' '103' [] [] [] '171' '175' [] [] [] '243' '247' [] ...
                '25' '28' '32' '35' [] '97' '100' '104' '107' [] '169' '172' '176' '179' [] '241' '244' '248' '251' ...
                '26' '29' '33' '36' [] '98' '101' '105' '108' [] '170' '173' '177' '180' [] '242' '245' '249' '252' ...
                [] '30' '34' [] [] [] '102' '106' [] [] [] '174' '178' [] [] [] '246' '250' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '39' '43' [] [] [] '111' '115' [] [] [] '183' '187' [] [] [] '255' '259' [] ...
                '37' '40' '44' '47' [] '109' '112' '116' '119' [] '181' '184' '188' '191' [] '253' '256' '260' '263' ...
                '38' '41' '45' '48' [] '110' '113' '117' '120' [] '182' '185' '189' '192' [] '254' '257' '261' '264' ...
                [] '42' '46' [] [] [] '114' '118' [] [] [] '186' '190' [] [] [] '258' '262' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '51' '55' [] [] [] '123' '127' [] [] [] '195' '199' [] [] [] '267' '271' [] ...
                '49' '52' '56' '59' [] '121' '124' '128' '131' [] '193' '196' '200' '203' [] '265' '268' '272' '275' ...
                '50' '53' '57' '60' [] '122' '125' '129' '132' [] '194' '197' '201' '204' [] '266' '269' '273' '276' ...
                [] '54' '58' [] [] [] '126' '130' [] [] [] '198' '202' [] [] [] '270' '274' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '63' '67' [] [] [] '135' '139' [] [] [] '207' '211' [] [] [] '279' '283' [] ...
                '61' '64' '68' '71' [] '133' '136' '140' '143' [] '205' '208' '212' '215' [] '277' '280' '284' '287' ...
                '62' '65' '69' '72' [] '134' '137' '141' '144' [] '206' '209' '213' '216' [] '278' '281' '285' '288' ...
                [] '66' '70' [] [] [] '138' '142' [] [] [] '210' '214' [] [] [] '282' '286' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []}';
            
            [x, y] = meshgrid(1:31);
            for i=31:-1:20
                x(i,:)=[];
                y(i,:)=[];
            end
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center','Fontsize',6);
        
        
        
        
        top60=cell2mat(supa1);
        
        %     top60(top60 < mean(maxk(top60,10)) + (2*std(maxk(top60,10))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
        %     top60(top60 < 0.7) = 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
        if handles.pushbutton60.Value == 1
            top60(top60 < (mean(M,'all','omitnan') + thrconnec*std(M,1,'all','omitnan'))) = 0; % new
        end
        
        top60(isnan(top60)) =0; %new
        %     top60(top60 == 0) =[];
        
        
        [B,I]=sort(top60,'descend');   % order them
        ghg=find(B == 0); %remove all the zeros
        I(ghg)=[];
        
        if only200 == 1 %display only the top 200 connections
            if length(I) > 200
                I=I(1:200);
                B = B(1:200);
            end
        end
        
        
        
        %each 120 elements belong to one channel
        %firsst column will be the origin of the line
        %2nd column will be the destination of the line
        I(:,2)=ceil(I(:)/electrodecount); % there are 12 electrodes per well ( this will give us the correct well number
        I(:,3)= electrodecount-((I(:,2)*electrodecount)-I(:,1)); % this will give us the correct channel number
        I(:,3) =  I(:,3) .* ceil(I(:,2)/electrodecount);
        I(I<1) = 1;
        ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
        removeindx = find(cell2mat(HITS(:,2)) <= 10);
        % these are checks to find if ther are nonsense numbers
        I(ismember(I(:,2),removeindx)) =0;
        I(ismember(I(:,2),removeindx),3) =0;
        I(ismember(I(:,2),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),1) =0;
        I(ismember(I(:,3),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),3) =0;
        
        for i = length(I):-1:1
            if I(i,1) == 0
                I(i,:) = [];
            end
        end
        
        looo12 = size(I,1);
        
        for i=1:size(I,1)
            yutr=I(i,2);
            %         kk=ag(ag == yutr); %new
            lll=find(layout4 == HITS48{yutr,2});
            [r,c] = ind2sub(size(layout4),lll);
            
            k=I(i,3);
            llll=find(layout4 == HITS48{k,2});
            [rr,cc] = ind2sub(size(layout4),llll);
            hold on
            if arrowss == 1
                nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
            elseif arrowss == 0
                nnn = line([c cc],[r rr],'Color','r');
            end
            drawnow;
            colmin=0;
            %         colmin=min(B(:));
            colmax=max(B(:));
            COLOR1=parula(length(B));
            goodcolor=COLOR1(round(length(B)*(B(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
            nnn.Color=goodcolor;
            cbn=colorbar;
            cbn.Colormap=parula(length(B));
            cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
            %         cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
            %         cbn.TickLabels = [0.73 0.76 0.79 0.82 0.85 0.88 0.91 094 0.97 1];
        end
        
        set(gca,'visible','off');
        set(gca,'Colormap',[1 1 1]);
        %     save([selecteddata '.mat'],'looo12','-append','-v6')
        
    end
    
    text84_ButtonDownFcn(handles.text84,eventdata,handles)
    handles.text84.Visible = 'on';
    clear supa1 supa
end
clear nocconnections
end

% --- Executes during object creation, after setting all properties.
function pushbutton62_CreateFcn(hObject, eventdata, handles)
hObject.Visible ='off';
hObject.Position =[0.009 0.513 0.111 0.027];
hObject.CData = imread('color_button.png');
hObject.FontWeight = 'bold';
hObject.String = 'Visualize';
hObject.ForegroundColor = [0.992 0.89 0.655];

end

% 60 strongest connections
function uipanel7_CreateFcn(hObject, eventdata, handles)
hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
%hObject.Position=[.01 .037 .398 .358];
hObject.Position=[.418 .54 .398 .358];
end

function uipanel7_ButtonDownFcn(hObject, eventdata, handles)

end

% --- 60 strongest connections
function pushbutton63_Callback(hObject, eventdata, handles)
global supa newM2 looo textstrings  electrodecount indx23 parts selecteddata timesss finalssss thrconnec HITS filteredData1 M2 M arrowss joost multiwell1
noconnections = 0;
%% cross correlation method
if indx23 == 2 % cross correlation
    supa1 = supa;
    %gotta turn the numbers around for the max function
    for i=1:length(M2)
        supa1{i}=supa1{i}';
    end
    
    for i=1:length(M2)
        supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
    end
    
    
    HITS48=HITS;
    
    lp=rand(1,length(HITS))+rand(1,length(HITS));
    kp=rand(1,length(HITS))+rand(1,length(HITS));
    ml=rand(1,length(HITS))+0.68;
    lp=lp+kp+ml;
    lp=lp';
    for i=1:length(HITS)
        HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
    end
    
    
    if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
        layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
    elseif length(filteredData1(:,1)) > 121
        layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
    else %% for 120 channel MEA
        layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
    end
    
    ax = axes(hObject);
    imagesc(layout4,'AlphaData',~isnan(layout4));
    
    if length(textstrings) > 400
        [x, y] = meshgrid(1:24);
        for i=[24 23 22 21 20]
            x(i,:)=[];
            y(i,:)=[];
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    else
        [x, y] = meshgrid(1:12);
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    end
    
    
    %         waitbar(0 + 0.9,hh,'Drawing the Connections');
    top60=cell2mat(supa1);
    top60(top60 < thrconnec) = 0;
    
    
    %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
    
    [B,I]=sort(top60,'descend');   % order them
    ghg=find(B == 0); %remove all the zeros
    I(ghg)=[];
    
    %get the top60 connections if the length of I is longer than 60
    if length(I) > 60
        I=I(1:60);
    end
    
    if length(filteredData1(:,1)) == 60
        I=I(:)/60;
    else
        I=I(:)/120;
    end
    
    
    %each 120 elements belong to one channel
    %firsst column will be the origin of the line
    %2nd column will be the destination of the line
    I(:,2)=floor(I(:,1));
    I(:,3)=I(:,1) - I(:,2);
    
    if length(filteredData1(:,1)) == 60
        I(:,3)=I(:,3)*60;
    else
        I(:,3)=I(:,3)*120;
    end
    
    I(:,3)=round(I(:,3));
    I(:,2)=ceil(I(:,1));
    I(I<1) = 1;
    ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
    removeindx = find(cell2mat(HITS(:,2)) <= 10);
    
    I(ismember(I(:,2),removeindx)) =0;
    I(ismember(I(:,2),removeindx),3) =0;
    I(ismember(I(:,2),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),1) =0;
    I(ismember(I(:,3),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),3) =0;
    
    for i = length(I):-1:1
        if I(i,1) == 0
            I(i,:) = [];
        end
    end
    
    for i=1:size(I,1)
        yutr=I(i,2);
        
        kk=ag(ag==yutr); % added for joosts method
        lll=find(layout4 == HITS48{kk,2});
        [r,c] = ind2sub(size(layout4),lll);
        
        k=I(i,3);
        llll=find(layout4 == HITS48{k,2});
        [rr,cc] = ind2sub(size(layout4),llll);
        hold on
        if arrowss == 1
            nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
        elseif arrowss == 0
            nnn=line([c cc],[r rr],'Color','r');
        end
        drawnow;
        colmin=min(top60(:));
        colmax=max(top60(:));
        COLOR1=parula(length(top60));
        goodcolor=COLOR1(round(length(top60)*(top60(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
        nnn.Color=goodcolor;
        cbn=colorbar;
        cbn.Colormap=parula(length(top60));
        %         cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        %         cbn.TickLabels = [0.73 0.76 0.79 0.82 0.85 0.88 0.91 094 0.97 1];
    end
    
    set(gca,'visible','off');
    set(gca,'Colormap',[1 1 1]);
else
    
    %% CFP method
    if joost && multiwell1 == 1
        if ~isempty(M)
            supa1=cell(1,length(M2))';
            for i = 1:length(M2) % added for joost's method
                supa1{i} = M(i,:)';
            end
        else
            msgbox('There are no connections!')
            noconnections = 1;
        end
    else
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
        
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        end
        
        supa1=cell(1,length(M2))';
        j = 1;
        load(selecteddata,'M');
        for i = 1:(electrodecount*parts)
            if isempty(M)
                continue
            else
                supa1{i} = M(1:electrodecount)';
                if i == 12
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 24
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 36
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 48
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 60
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 72
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 84
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 96
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 108
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 120
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 132
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                end
            end
        end
        
        
    end
    
    % this is the multiwell version and therefore we first have to ask the
    % user for which
    
    
    
    %higher than 70% we will draw a line (spikecode this this aswell
    %so now the only thing we need to do is draw a line if the number exceeds
    %0.7 or 70% SPYCODE threshhold
    
    %use the below layout structure to get the correct position
    
    %So what needs to happen is 3 things, we will first check if in supa
    %soemthing has passed the 0.7 mark and if it does the next thing it will do
    %is search in the layout for the correct position and the last step is to
    %draw a line
    
    %we have to make the numbers uin HITS all unqiue so we won't have issues with duplicates
    if noconnections == 1
    else
        HITS48=HITS;
        
        lp=rand(1,length(HITS))+rand(1,length(HITS));
        kp=rand(1,length(HITS))+rand(1,length(HITS));
        ml=rand(1,length(HITS))+0.68;
        lp=lp+kp+ml;
        lp=lp';
        for i=1:length(HITS)
            HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
        end
        
        
        if parts == 12
            layout4=...
                [nan   nan     HITS48{1,2} HITS48{2,2} nan       nan nan        HITS48{13,2} HITS48{14,2} nan        nan nan        HITS48{25,2} HITS48{26,2} nan        nan nan        HITS48{37,2} HITS48{38,2} nan        nan nan        HITS48{49,2} HITS48{50,2} nan        nan nan        HITS48{61,2} HITS48{62,2} nan nan;...
                nan HITS48{3,2} HITS48{4,2} HITS48{5,2} HITS48{6,2} nan HITS48{15,2} HITS48{16,2} HITS48{17,2} HITS48{18,2} nan HITS48{27,2} HITS48{28,2} HITS48{29,2} HITS48{30,2} nan HITS48{39,2} HITS48{40,2} HITS48{41,2} HITS48{42,2} nan HITS48{51,2} HITS48{52,2} HITS48{53,2} HITS48{54,2} nan HITS48{63,2} HITS48{64,2} HITS48{65,2} HITS48{66,2} nan;...
                nan HITS48{7,2} HITS48{8,2} HITS48{9,2} HITS48{10,2} nan HITS48{19,2} HITS48{20,2} HITS48{21,2} HITS48{22,2} nan HITS48{31,2} HITS48{32,2} HITS48{33,2} HITS48{34,2} nan HITS48{43,2} HITS48{44,2} HITS48{45,2} HITS48{46,2} nan HITS48{55,2} HITS48{56,2} HITS48{57,2} HITS48{58,2} nan HITS48{67,2} HITS48{68,2} HITS48{69,2} HITS48{70,2} nan;...
                nan nan       HITS48{11,2} HITS48{12,2} nan     nan nan        HITS48{23,2} HITS48{24,2} nan        nan nan        HITS48{35,2} HITS48{36,2} nan        nan nan        HITS48{47,2} HITS48{48,2} nan        nan nan        HITS48{59,2} HITS48{60,2} nan        nan nan        HITS48{71,2} HITS48{72,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan        HITS48{73,2} HITS48{74,2} nan        nan nan        HITS48{85,2} HITS48{86,2} nan        nan nan         HITS48{97,2} HITS48{98,2} nan         nan nan         HITS48{109,2} HITS48{110,2} nan         nan nan         HITS48{121,2} HITS48{122,2} nan         nan nan         HITS48{133,2} HITS48{134,2} nan nan;...
                nan HITS48{75,2} HITS48{76,2} HITS48{77,2} HITS48{78,2} nan HITS48{87,2} HITS48{88,2} HITS48{89,2} HITS48{90,2} nan HITS48{99,2} HITS48{100,2} HITS48{101,2} HITS48{102,2} nan HITS48{111,2} HITS48{112,2} HITS48{113,2} HITS48{114,2} nan HITS48{123,2} HITS48{124,2} HITS48{125,2} HITS48{126,2} nan HITS48{135,2} HITS48{136,2} HITS48{137,2} HITS48{138,2} nan;...
                nan HITS48{79,2} HITS48{80,2} HITS48{81,2} HITS48{82,2} nan HITS48{91,2} HITS48{92,2} HITS48{93,2} HITS48{94,2} nan HITS48{103,2} HITS48{104,2} HITS48{105,2}  HITS48{106,2} nan HITS48{115,2} HITS48{116,2} HITS48{117,2} HITS48{118,2} nan HITS48{127,2} HITS48{128,2} HITS48{129,2} HITS48{130,2} nan HITS48{139,2} HITS48{140,2} HITS48{141,2} HITS48{142,2} nan;...
                nan nan        HITS48{83,2} HITS48{84,2} nan        nan nan        HITS48{95,2} HITS48{96,2} nan        nan nan         HITS48{107,2} HITS48{108,2}   nan      nan nan         HITS48{119,2} HITS48{120,2} nan        nan nan         HITS48{131,2} HITS48{132,2} nan         nan nan         HITS48{143,2} HITS48{144,2} nan nan];
            
        elseif joost && multiwell1 == 1
            
        layout4= [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{1,2}   HITS48{2,2}   HITS48{3,2}   HITS48{4,2}   nan nan HITS48{17,2}  HITS48{18,2}  HITS48{19,2}  HITS48{20,2}  nan nan HITS48{33,2}  HITS48{34,2}  HITS48{35,2}  HITS48{36,2}  nan nan HITS48{49,2}  HITS48{50,2}  HITS48{51,2}  HITS48{52,2}  nan nan HITS48{65,2}  HITS48{66,2}  HITS48{67,2}  HITS48{68,2}  nan nan HITS48{81,2}  HITS48{82,2}  HITS48{83,2}  HITS48{84,2}  nan nan;
                nan nan HITS48{5,2}   HITS48{6,2}   HITS48{7,2}   HITS48{8,2}   nan nan HITS48{21,2}  HITS48{22,2}  HITS48{23,2}  HITS48{24,2}  nan nan HITS48{37,2}  HITS48{38,2}  HITS48{39,2}  HITS48{40,2}  nan nan HITS48{53,2}  HITS48{54,2}  HITS48{55,2}  HITS48{56,2}  nan nan HITS48{69,2}  HITS48{70,2}  HITS48{71,2}  HITS48{72,2}  nan nan HITS48{85,2}  HITS48{86,2}  HITS48{87,2}  HITS48{88,2}  nan nan;
                nan nan HITS48{9,2}   HITS48{10,2}  HITS48{11,2}  HITS48{12,2}  nan nan HITS48{25,2}  HITS48{26,2}  HITS48{27,2}  HITS48{28,2}  nan nan HITS48{41,2}  HITS48{42,2}  HITS48{43,2}  HITS48{44,2}  nan nan HITS48{57,2}  HITS48{58,2}  HITS48{59,2}  HITS48{60,2}  nan nan HITS48{73,2}  HITS48{74,2}  HITS48{75,2}  HITS48{76,2}  nan nan HITS48{89,2}  HITS48{90,2}  HITS48{91,2}  HITS48{92,2}  nan nan;
                nan nan HITS48{13,2}  HITS48{14,2}  HITS48{15,2}  HITS48{16,2}  nan nan HITS48{29,2}  HITS48{30,2}  HITS48{31,2}  HITS48{32,2}  nan nan HITS48{45,2}  HITS48{46,2}  HITS48{47,2}  HITS48{48,2}  nan nan HITS48{61,2}  HITS48{62,2}  HITS48{63,2}  HITS48{64,2}  nan nan HITS48{77,2}  HITS48{78,2}  HITS48{79,2}  HITS48{80,2}  nan nan HITS48{93,2}  HITS48{94,2}  HITS48{95,2}  HITS48{96,2}  nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{97,2}  HITS48{98,2}  HITS48{99,2}  HITS48{100,2} nan nan HITS48{113,2} HITS48{114,2} HITS48{115,2} HITS48{116,2} nan nan HITS48{129,2} HITS48{130,2} HITS48{131,2} HITS48{132,2} nan nan HITS48{145,2} HITS48{146,2} HITS48{147,2} HITS48{148,2} nan nan HITS48{161,2} HITS48{162,2} HITS48{163,2} HITS48{164,2} nan nan HITS48{177,2} HITS48{178,2} HITS48{179,2} HITS48{180,2} nan nan;
                nan nan HITS48{101,2} HITS48{102,2} HITS48{103,2} HITS48{104,2} nan nan HITS48{117,2} HITS48{118,2} HITS48{119,2} HITS48{120,2} nan nan HITS48{133,2} HITS48{134,2} HITS48{135,2} HITS48{136,2} nan nan HITS48{149,2} HITS48{150,2} HITS48{151,2} HITS48{152,2} nan nan HITS48{165,2} HITS48{166,2} HITS48{167,2} HITS48{168,2} nan nan HITS48{181,2} HITS48{182,2} HITS48{183,2} HITS48{184,2} nan nan;
                nan nan HITS48{105,2} HITS48{106,2} HITS48{107,2} HITS48{108,2} nan nan HITS48{121,2} HITS48{122,2} HITS48{123,2} HITS48{124,2} nan nan HITS48{137,2} HITS48{138,2} HITS48{139,2} HITS48{140,2} nan nan HITS48{153,2} HITS48{154,2} HITS48{155,2} HITS48{156,2} nan nan HITS48{169,2} HITS48{170,2} HITS48{171,2} HITS48{172,2} nan nan HITS48{185,2} HITS48{186,2} HITS48{187,2} HITS48{188,2} nan nan;
                nan nan HITS48{109,2} HITS48{110,2} HITS48{111,2} HITS48{112,2} nan nan HITS48{125,2} HITS48{126,2} HITS48{127,2} HITS48{128,2} nan nan HITS48{141,2} HITS48{142,2} HITS48{143,2} HITS48{144,2} nan nan HITS48{157,2} HITS48{158,2} HITS48{159,2} HITS48{160,2} nan nan HITS48{173,2} HITS48{174,2} HITS48{175,2} HITS48{176,2} nan nan HITS48{189,2} HITS48{190,2} HITS48{191,2} HITS48{192,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{193,2} HITS48{194,2} HITS48{195,2} HITS48{196,2} nan nan HITS48{209,2} HITS48{210,2} HITS48{211,2} HITS48{212,2} nan nan HITS48{225,2} HITS48{226,2} HITS48{227,2} HITS48{228,2} nan nan HITS48{241,2} HITS48{242,2} HITS48{243,2} HITS48{244,2} nan nan HITS48{257,2} HITS48{258,2} HITS48{259,2} HITS48{260,2} nan nan HITS48{273,2} HITS48{274,2} HITS48{275,2} HITS48{276,2} nan nan;
                nan nan HITS48{197,2} HITS48{198,2} HITS48{199,2} HITS48{200,2} nan nan HITS48{213,2} HITS48{214,2} HITS48{215,2} HITS48{216,2} nan nan HITS48{229,2} HITS48{230,2} HITS48{231,2} HITS48{232,2} nan nan HITS48{245,2} HITS48{246,2} HITS48{247,2} HITS48{248,2} nan nan HITS48{261,2} HITS48{262,2} HITS48{263,2} HITS48{264,2} nan nan HITS48{277,2} HITS48{278,2} HITS48{279,2} HITS48{280,2} nan nan;
                nan nan HITS48{201,2} HITS48{202,2} HITS48{203,2} HITS48{204,2} nan nan HITS48{217,2} HITS48{218,2} HITS48{219,2} HITS48{220,2} nan nan HITS48{233,2} HITS48{234,2} HITS48{235,2} HITS48{236,2} nan nan HITS48{249,2} HITS48{250,2} HITS48{251,2} HITS48{252,2} nan nan HITS48{265,2} HITS48{266,2} HITS48{267,2} HITS48{268,2} nan nan HITS48{281,2} HITS48{282,2} HITS48{283,2} HITS48{284,2} nan nan;
                nan nan HITS48{205,2} HITS48{206,2} HITS48{207,2} HITS48{208,2} nan nan HITS48{221,2} HITS48{222,2} HITS48{223,2} HITS48{224,2} nan nan HITS48{237,2} HITS48{238,2} HITS48{239,2} HITS48{240,2} nan nan HITS48{253,2} HITS48{254,2} HITS48{255,2} HITS48{256,2} nan nan HITS48{269,2} HITS48{270,2} HITS48{271,2} HITS48{272,2} nan nan HITS48{285,2} HITS48{286,2} HITS48{287,2} HITS48{288,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{289,2} HITS48{290,2} HITS48{291,2} HITS48{292,2} nan nan HITS48{305,2} HITS48{306,2} HITS48{307,2} HITS48{308,2} nan nan HITS48{321,2} HITS48{322,2} HITS48{323,2} HITS48{324,2} nan nan HITS48{337,2} HITS48{338,2} HITS48{339,2} HITS48{340,2} nan nan HITS48{353,2} HITS48{354,2} HITS48{355,2} HITS48{356,2} nan nan HITS48{369,2} HITS48{370,2} HITS48{371,2} HITS48{372,2} nan nan;
                nan nan HITS48{293,2} HITS48{294,2} HITS48{295,2} HITS48{296,2} nan nan HITS48{309,2} HITS48{310,2} HITS48{311,2} HITS48{312,2} nan nan HITS48{325,2} HITS48{326,2} HITS48{327,2} HITS48{328,2} nan nan HITS48{341,2} HITS48{342,2} HITS48{343,2} HITS48{344,2} nan nan HITS48{357,2} HITS48{358,2} HITS48{359,2} HITS48{360,2} nan nan HITS48{373,2} HITS48{374,2} HITS48{375,2} HITS48{376,2} nan nan;
                nan nan HITS48{297,2} HITS48{298,2} HITS48{299,2} HITS48{300,2} nan nan HITS48{313,2} HITS48{314,2} HITS48{315,2} HITS48{316,2} nan nan HITS48{329,2} HITS48{330,2} HITS48{331,2} HITS48{332,2} nan nan HITS48{345,2} HITS48{346,2} HITS48{347,2} HITS48{348,2} nan nan HITS48{361,2} HITS48{362,2} HITS48{363,2} HITS48{364,2} nan nan HITS48{377,2} HITS48{378,2} HITS48{379,2} HITS48{380,2} nan nan;
                nan nan HITS48{301,2} HITS48{302,2} HITS48{303,2} HITS48{304,2} nan nan HITS48{317,2} HITS48{318,2} HITS48{319,2} HITS48{320,2} nan nan HITS48{333,2} HITS48{334,2} HITS48{335,2} HITS48{336,2} nan nan HITS48{349,2} HITS48{350,2} HITS48{351,2} HITS48{352,2} nan nan HITS48{365,2} HITS48{366,2} HITS48{367,2} HITS48{368,2} nan nan HITS48{381,2} HITS48{382,2} HITS48{383,2} HITS48{384,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan];
        else
            layout4=...
                [nan nan HITS48{12,2} HITS48{11,2} nan nan nan HITS48{24,2} HITS48{23,2} nan nan nan HITS48{36,2} HITS48{35,2} nan nan nan HITS48{48,2} HITS48{47,2} nan nan nan HITS48{60,2} HITS48{59,2} nan nan nan HITS48{72,2} HITS48{71,2} nan nan;...
                nan HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} nan HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} nan HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} nan HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} nan HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} nan HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2} nan;...
                nan  HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} nan HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} nan HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} nan HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} nan HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} nan HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2} nan;...
                nan nan HITS48{2,2} HITS48{1,2} nan nan nan HITS48{14,2} HITS48{13,2} nan nan nan HITS48{26,2} HITS48{25,2} nan nan nan HITS48{38,2} HITS48{37,2} nan nan nan HITS48{50,2} HITS48{49,2} nan nan nan HITS48{62,2} HITS48{61,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{84,2} HITS48{83,2} nan nan nan HITS48{96,2} HITS48{95,2} nan nan nan HITS48{108,2} HITS48{107,2} nan nan nan HITS48{120,2} HITS48{119,2} nan nan nan HITS48{132,2} HITS48{131,2} nan nan nan HITS48{144,2} HITS48{143,2} nan nan;...
                nan HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} nan HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} nan HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} nan HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} nan HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} nan HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2} nan;...
                nan HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} nan HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} nan HITS48{102,2} HITS48{101,2} HITS48{100,2}  HITS48{99,2} nan HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} nan HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} nan HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2} nan;...
                nan nan HITS48{74,2} HITS48{73,2} nan nan nan HITS48{86,2} HITS48{85,2} nan nan nan HITS48{98,2} HITS48{97,2} nan nan nan HITS48{110,2} HITS48{109,2} nan nan nan HITS48{122,2} HITS48{121,2} nan nan nan HITS48{134,2} HITS48{133,2} nan nan;...
                nan nan nan  nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{156,2} HITS48{155,2} nan nan nan HITS48{168,2} HITS48{167,2} nan nan nan HITS48{180,2} HITS48{179,2} nan nan nan HITS48{192,2} HITS48{191,2} nan nan nan HITS48{204,2} HITS48{203,2} nan nan nan HITS48{216,2} HITS48{215,2} nan nan;...
                nan HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} nan HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} nan HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} nan HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} nan HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} nan HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2} nan;...
                nan HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} nan HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} nan HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} nan HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} nan HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} nan HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2} nan;...
                nan nan HITS48{146,2} HITS48{145,2} nan nan nan HITS48{158,2} HITS48{157,2} nan nan nan HITS48{170,2} HITS48{169,2} nan nan nan HITS48{182,2} HITS48{181,2} nan nan nan HITS48{194,2} HITS48{193,2} nan nan nan HITS48{206,2} HITS48{205,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{228,2} HITS48{227,2} nan nan nan HITS48{240,2} HITS48{239,2} nan nan nan HITS48{252,2} HITS48{251,2} nan nan nan HITS48{264,2} HITS48{263,2} nan nan nan HITS48{276,2} HITS48{275,2} nan nan nan HITS48{288,2} HITS48{287,2} nan nan;
                nan HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} nan HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} nan HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} nan HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} nan HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} nan HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2} nan;...
                nan HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} nan HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} nan HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} nan HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} nan HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} nan HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2} nan;...
                nan nan HITS48{218,2} HITS48{217,2} nan nan nan HITS48{230,2} HITS48{229,2} nan nan nan HITS48{242,2} HITS48{241,2} nan nan nan HITS48{254,2} HITS48{253,2} nan nan nan HITS48{266,2} HITS48{265,2} nan nan nan HITS48{278,2} HITS48{277,2} nan nan];
        end
        
        %     ax = axes(hObject);
        axes23 = axes(handles.uipanel7);
        imagesc(layout4,'AlphaData',~isnan(layout4));
        if joost && multiwell1 == 1
            textstrings={...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '1'  '5' '9'  '13'  [] [] '97'  '101' '105' '109'  [] [] '193' '197' '201' '205' [] [] '289' '293' '297' '301' [] []...
                [] [] '2'  '6' '10' '14'  [] [] '98'  '102' '106' '110'  [] [] '194' '198' '202' '206' [] [] '290' '294' '298' '302' [] []...
                [] [] '3'  '7' '11' '15'  [] [] '99'  '103' '107' '111'  [] [] '195' '199' '203' '207' [] [] '291' '295' '299' '303' [] []...
                [] [] '4'  '8' '12' '16'  [] [] '100' '104' '108' '112'  [] [] '196' '200' '204' '208' [] [] '292' '296' '300' '304' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '17' '21' '25' '29' [] [] '113'  '117' '121' '125' [] [] '209' '213' '217' '221' [] [] '305' '309' '313' '317' [] []...
                [] [] '18' '22' '26' '30' [] [] '114'  '118' '122' '126' [] [] '210' '214' '218' '222' [] [] '306' '310' '314' '318' [] []...
                [] [] '19' '23' '27' '31' [] [] '115'  '119' '123' '127' [] [] '211' '215' '219' '223' [] [] '307' '311' '315' '319' [] []...
                [] [] '20' '24' '28' '32' [] [] '116'  '120' '124' '128' [] [] '212' '216' '220' '224' [] [] '308' '312' '316' '320' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '33' '37' '41' '45' [] [] '129'  '133' '137' '141' [] [] '225' '229' '233' '237' [] [] '321' '325' '329' '333' [] []...
                [] [] '34' '38' '42' '46' [] [] '130'  '134' '138' '142' [] [] '226' '230' '234' '238' [] [] '322' '326' '330' '334' [] []...
                [] [] '35' '39' '43' '47' [] [] '131'  '135' '139' '143' [] [] '227' '231' '235' '239' [] [] '323' '327' '331' '335' [] []...
                [] [] '36' '40' '44' '48' [] [] '132'  '136' '140' '144' [] [] '228' '232' '236' '240' [] [] '324' '328' '332' '336' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '49' '53' '57' '61' [] [] '145' '149' '153' '157'  [] [] '241' '245' '249' '253' [] [] '337' '341' '345' '349' [] []...
                [] [] '50' '54' '58' '62' [] [] '146' '150' '154' '158'  [] [] '242' '246' '250' '254' [] [] '338' '342' '346' '350' [] []...
                [] [] '51' '55' '59' '63' [] [] '147' '151' '155' '159'  [] [] '243' '247' '251' '255' [] [] '339' '343' '347' '351' [] []...
                [] [] '52' '56' '60' '64' [] [] '148' '152' '156' '160'  [] [] '244' '248' '252' '256' [] [] '340' '344' '348' '352' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '65' '69' '73' '77' [] [] '161' '165' '169' '173'  [] [] '257' '261' '265' '269' [] [] '353' '357' '361' '365' [] []...
                [] [] '66' '70' '74' '78' [] [] '162' '166' '170' '174'  [] [] '258' '262' '266' '270' [] [] '354' '358' '362' '366' [] []...
                [] [] '67' '71' '75' '79' [] [] '163' '167' '171' '175'  [] [] '259' '263' '267' '271' [] [] '355' '359' '363' '367' [] []...
                [] [] '68' '72' '76' '80' [] [] '164' '168' '172' '176'  [] [] '260' '264' '268' '272' [] [] '356' '360' '364' '368' [] []...
                [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '81' '85' '89' '93' [] [] '177' '181' '185' '189'  [] [] '273' '277' '281' '285' [] [] '369' '373' '377' '381' [] []...
                [] [] '82' '86' '90' '94' [] [] '178' '182' '186' '190'  [] [] '274' '278' '282' '286' [] [] '370' '374' '378' '382' [] []...
                [] [] '83' '87' '91' '95' [] [] '179' '183' '187' '191'  [] [] '275' '279' '283' '287' [] [] '371' '375' '379' '383' [] []...
                [] [] '84' '88' '92' '96' [] [] '180' '184' '188' '192'  [] [] '276' '280' '284' '288' [] [] '372' '376' '380' '384' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []}';
            
            
            [x, y] = meshgrid(1:38);
            for i=31:-1:20
                x(i,:)=[];
                y(i,:)=[];
            end
            
        else
            textstrings={...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '3' '7' [] [] [] '75' '79' [] [] [] '147' '151' [] [] [] '219' '223' [] ...
                '1' '4' '8' '11' [] '73' '76' '80' '83' [] '145' '148' '152' '155' [] '217' '220' '224' '227' ...
                '2' '5' '9' '12' [] '74' '77' '81' '84' [] '146' '149' '153' '156' [] '218' '221' '225' '228' ...
                [] '6' '10' [] [] [] '78' '82' [] [] [] '150' '154' [] [] [] '222' '226' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '15' '19' [] [] [] '87' '91' [] [] [] '159' '163' [] [] [] '231' '235' [] ...
                '13' '16' '20' '23' [] '85' '88' '92' '95' [] '157' '160' '164' '167' [] '229' '232' '236' '239' ...
                '14' '17' '21' '24' [] '86' '89' '93' '96' [] '158' '161' '165' '168' [] '230' '233' '237' '240' ...
                [] '18' '22' [] [] [] '90' '94' [] [] [] '162' '166' [] [] [] '234' '238' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '27' '31' [] [] [] '99' '103' [] [] [] '171' '175' [] [] [] '243' '247' [] ...
                '25' '28' '32' '35' [] '97' '100' '104' '107' [] '169' '172' '176' '179' [] '241' '244' '248' '251' ...
                '26' '29' '33' '36' [] '98' '101' '105' '108' [] '170' '173' '177' '180' [] '242' '245' '249' '252' ...
                [] '30' '34' [] [] [] '102' '106' [] [] [] '174' '178' [] [] [] '246' '250' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '39' '43' [] [] [] '111' '115' [] [] [] '183' '187' [] [] [] '255' '259' [] ...
                '37' '40' '44' '47' [] '109' '112' '116' '119' [] '181' '184' '188' '191' [] '253' '256' '260' '263' ...
                '38' '41' '45' '48' [] '110' '113' '117' '120' [] '182' '185' '189' '192' [] '254' '257' '261' '264' ...
                [] '42' '46' [] [] [] '114' '118' [] [] [] '186' '190' [] [] [] '258' '262' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '51' '55' [] [] [] '123' '127' [] [] [] '195' '199' [] [] [] '267' '271' [] ...
                '49' '52' '56' '59' [] '121' '124' '128' '131' [] '193' '196' '200' '203' [] '265' '268' '272' '275' ...
                '50' '53' '57' '60' [] '122' '125' '129' '132' [] '194' '197' '201' '204' [] '266' '269' '273' '276' ...
                [] '54' '58' [] [] [] '126' '130' [] [] [] '198' '202' [] [] [] '270' '274' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '63' '67' [] [] [] '135' '139' [] [] [] '207' '211' [] [] [] '279' '283' [] ...
                '61' '64' '68' '71' [] '133' '136' '140' '143' [] '205' '208' '212' '215' [] '277' '280' '284' '287' ...
                '62' '65' '69' '72' [] '134' '137' '141' '144' [] '206' '209' '213' '216' [] '278' '281' '285' '288' ...
                [] '66' '70' [] [] [] '138' '142' [] [] [] '210' '214' [] [] [] '282' '286' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []}';
            
            [x, y] = meshgrid(1:31);
            for i=31:-1:20
                x(i,:)=[];
                y(i,:)=[];
            end
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center','Fontsize',6);
        
        %         waitbar(0 + 0.9,hh,'Drawing the Connections');
        top60=cell2mat(supa1);
        if handles.pushbutton60.Value == 1
            top60(top60 < (mean(M,'all','omitnan') + thrconnec*std(M,1,'all','omitnan'))) = 0; % new
        end
        % change nan values into zeros
        top60(isnan(top60)) =0; %% new added for joost's method
        %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
        
        [B,I]=sort(top60,'descend');   % order them
        ghg=find(B == 0); %remove all the zeros
        I(ghg)=[];
        
        %get the top60 connections if the length of I is longer than 60
        if length(I) > 60
            I=I(1:60);
            B = B(1:60);
        end
        
        
        %each 120 elements belong to one channel depending on the dataset
        %firsst column will be the origin of the line
        %2nd column will be the destination of the line
        I(:,2)=ceil(I(:)/electrodecount); % there are 12 electrodes per well ( this will give us the correct channel number ) 6 this is where the connections starts from
        %     I(:,3) = ceil(I(:,2)/parts)*12; % this is the correct channelnumber to where the connection goes to
        I(:,3)= electrodecount-((I(:,2)*electrodecount)-I(:,1)); % this will give us the correct channel number
        I(:,4) = ceil(I(:,2)/electrodecount); % correct well number
        I(:,3) =  I(:,3) + I(:,4)*electrodecount-electrodecount; % now we need to get the correct channel number where the connection goes to
        I(I<1) = 1;
        ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
        removeindx = find(cell2mat(HITS(:,2)) <= 10);
        % these are checks to find if ther are nonsense numbers
        I(ismember(I(:,2),removeindx)) =0;
        I(ismember(I(:,2),removeindx),3) =0;
        I(ismember(I(:,2),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),1) =0;
        I(ismember(I(:,3),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),3) =0;
        
        for i = size(I,1):-1:1
            if I(i,1) == 0
                I(i,:) = [];
            end
        end
        
        for ii=1:size(I,1)
            yutr=I(ii,2);
            
            %         kk=ag(ag==yutr); % added for joosts method
            lll=find(layout4 == HITS48{yutr,2});
            [r,c] = ind2sub(size(layout4),lll);
            
            k=I(ii,3);
            llll=find(layout4 == HITS48{k,2});
            [rr,cc] = ind2sub(size(layout4),llll);
            hold on
            if arrowss == 1
                nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
            elseif arrowss == 0
                nnn=line([c cc],[r rr],'Color','r');
            end
            drawnow;
            colmin=0;
            %         colmin=min(B(:));
            colmax=max(B(:));
            COLOR1=parula(length(B));
            goodcolor=COLOR1(round(length(B)*(B(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
            nnn.Color=goodcolor;
            cbn=colorbar;
            cbn.Colormap=parula(length(B));
            cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
            
        end
        
        set(gca,'visible','off');
        set(gca,'Colormap',[1 1 1]);
        
        
        
    end
    clear supa1 supa
end
clear noconnections
end

% --- Executes during object creation, after setting all properties.
function pushbutton63_CreateFcn(hObject, eventdata, handles)
hObject.Visible ='off';
hObject.Position =[0.418 0.513 0.111 0.027];
hObject.CData = imread('color_button.png');
hObject.FontWeight = 'bold';
hObject.String = 'Visualize';
hObject.ForegroundColor = [0.992 0.89 0.655];

end

% --- Channel A
function uipanel8_CreateFcn(hObject, eventdata, handles)
hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.01 .037 .398 .358];
end

function uipanel8_ButtonDownFcn(hObject, eventdata, handles)

end

% --- Executes on button press in pushbutton39.
function pushbutton39_Callback(hObject, eventdata, handles)
global jitters Ghibli parts electrodecount selecteddata textstrings HITS indx23 supa  newM2 looop  filteredData1 M2  thrconnec timesss finalssss M arrowss joost multiwell1

noconnections = 0;
prompt = {'Enter Channel name A:'};
title = 'Connectivity Map';
dims = [1 35];
definput = {'A1'};
jitters{1} = inputdlg(prompt,title,dims,definput);

if indx23 == 1
    Ghibli(1)=find(strcmp(textstrings(:,1),jitters{1}));
elseif  indx23 == 2
    textstrings1 = HITS(:,1);
    Ghibli(1)=find(strcmp(textstrings1(:,1),jitters{1}));
end

% yup=input('Which channel do you want to cross correlate?');
% Ghibli=find(strncmpi(HITS,yup,3));
if indx23 == 2
    
    
    supa1 = supa;
    %gotta turn the numbers around for the max function
    for i=1:length(M2)
        supa1{i}=supa1{i}';
    end
    
    for i=1:length(M2)
        supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
    end
    
    
    HITS48=HITS;
    
    lp=rand(1,length(HITS))+rand(1,length(HITS));
    kp=rand(1,length(HITS))+rand(1,length(HITS));
    ml=rand(1,length(HITS))+0.68;
    lp=lp+kp+ml;
    lp=lp';
    for i=1:length(HITS)
        HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
    end
    
    
    if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
        layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
    elseif length(filteredData1(:,1)) > 121
        layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
    else %% for 120 channel MEA
        layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
    end
    
    ax = axes(hObject);
    imagesc(layout4,'AlphaData',~isnan(layout4));
    
    if length(textstrings) > 400
        [x, y] = meshgrid(1:24);
        for i=[24 23 22 21 20]
            x(i,:)=[];
            y(i,:)=[];
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    else
        [x, y] = meshgrid(1:12);
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    end
    
    
    %         waitbar(0 + 0.9,hh,'Drawing the Connections');
    top60=cell2mat(supa1);
    top60(top60 < thrconnec) = 0;
    % change nan values into zeros
    
    %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
    
    [B,I]=sort(top60,'descend');   % order them
    ghg=find(B == 0); %remove all the zeros
    I(ghg)=[];
    
    %get the top60 connections if the length of I is longer than 60
    if length(I) > 60
        I=I(1:60);
    end
    
    if length(filteredData1(:,1)) == 60
        I=I(:)/60;
    else
        I=I(:)/120;
    end
    
    
    %each 120 elements belong to one channel
    %firsst column will be the origin of the line
    %2nd column will be the destination of the line
    I(:,2)=floor(I(:,1));
    I(:,3)=I(:,1) - I(:,2);
    
    if length(filteredData1(:,1)) == 60
        I(:,3)=I(:,3)*60;
    else
        I(:,3)=I(:,3)*120;
    end
    
    I(:,3)=round(I(:,3));
    I(:,2)=ceil(I(:,1));
    I(I<1) = 1;
    ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
    removeindx = find(cell2mat(HITS(:,2)) <= 10);
    
    I(ismember(I(:,2),removeindx)) =0;
    I(ismember(I(:,2),removeindx),3) =0;
    I(ismember(I(:,2),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),1) =0;
    I(ismember(I(:,3),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),3) =0;
    
    for i = length(I):-1:1
        if I(i,1) == 0
            I(i,:) = [];
        end
    end
    
    %also delete connections that do not involve the channel of interest
    %     correctindex = find(I(:,2) == Ghibli(1));
    %     correctindex2 = find(I(:,3) == Ghibli(1));
    %     indexfull = [correctindex;correctindex2]; % this contains the indeices that have connections with the channel of interest
    %
    for i = length(I):-1:1
        if I(i,2) == Ghibli(1) || I(i,3) == Ghibli(1)
        else
            I(i,:) = [];
        end
    end
    
    
    
    
    looop= 0 ;
    
    for i=1:size(I,1)
        yutr=I(i,2);
        looop = looop+1;
        kk=ag(ag==yutr); % added for joosts method
        lll=find(layout4 == HITS48{kk,2});
        [r,c] = ind2sub(size(layout4),lll);
        
        k=I(i,3);
        llll=find(layout4 == HITS48{k,2});
        [rr,cc] = ind2sub(size(layout4),llll);
        hold on
        if arrowss == 1
            nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
        elseif arrowss == 0
            nnn=line([c cc],[r rr],'Color','r');
        end
        drawnow;
        colmin=min(top60(:));
        colmax=max(top60(:));
        COLOR1=parula(length(top60));
        goodcolor=COLOR1(round(length(top60)*(top60(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
        nnn.Color=goodcolor;
        cbn=colorbar;
        cbn.Colormap=parula(length(top60));
        %         cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        %         cbn.TickLabels = [0.73 0.76 0.79 0.82 0.85 0.88 0.91 094 0.97 1];
    end
    
    
    set(gca,'visible','off');
    set(gca,'Colormap',[1 1 1]);
    
else
    if joost && multiwell1 == 1
        if ~isempty(M)
            supa1=cell(1,length(M2))';
            for i = 1:length(M2) % added for joost's method
                supa1{i} = M(i,:)';
            end
        else
            msgbox('There are no connections!')
            noconnections = 1;
        end
    else
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
        
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        end
        
        supa1=cell(1,length(M2))';
        j = 1;
        load(selecteddata,'M');
        for i = 1:(electrodecount*parts)
            if isempty(M)
                continue
            else
                supa1{i} = M(1:electrodecount)';
                if i == 12
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 24
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 36
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 48
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 60
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 72
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 84
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 96
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 108
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 120
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 132
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                end
            end
        end
    end
    % need to change the numbers from the user input as the index doesnt
    % match anymore
    
    Ghibli(1)=find(strcmp(HITS(:,1),jitters{1}));
    
    
    %higher than 70% we will draw a line (spikecode this this aswell
    %so now the only thing we need to do is draw a line if the number exceeds
    %0.7 or 70% SPYCODE threshhold
    
    %use the below layout structure to get the correct position
    
    %So what needs to happen is 3 things, we will first check if in supa
    %soemthing has passed the 0.7 mark and if it does the next thing it will do
    %is search in the layout for the correct position and the last step is to
    %draw a line
    
    %we have to make the numbers uin HITS all unqiue so we won't have issues with duplicates
    if noconnections ==1
    else
        HITS48=HITS;
        lp=rand(1,length(HITS))+rand(1,length(HITS));
        kp=rand(1,length(HITS))+rand(1,length(HITS));
        ml=rand(1,length(HITS))+0.68;
        lp=lp+kp+ml;
        lp=lp';
        for i=1:length(HITS)
            HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
        end
        
        
        
        if parts == 12
            layout4=...
                [nan   nan     HITS48{1,2} HITS48{2,2} nan       nan nan        HITS48{13,2} HITS48{14,2} nan        nan nan        HITS48{25,2} HITS48{26,2} nan        nan nan        HITS48{37,2} HITS48{38,2} nan        nan nan        HITS48{49,2} HITS48{50,2} nan        nan nan        HITS48{61,2} HITS48{62,2} nan nan;...
                nan HITS48{3,2} HITS48{4,2} HITS48{5,2} HITS48{6,2} nan HITS48{15,2} HITS48{16,2} HITS48{17,2} HITS48{18,2} nan HITS48{27,2} HITS48{28,2} HITS48{29,2} HITS48{30,2} nan HITS48{39,2} HITS48{40,2} HITS48{41,2} HITS48{42,2} nan HITS48{51,2} HITS48{52,2} HITS48{53,2} HITS48{54,2} nan HITS48{63,2} HITS48{64,2} HITS48{65,2} HITS48{66,2} nan;...
                nan HITS48{7,2} HITS48{8,2} HITS48{9,2} HITS48{10,2} nan HITS48{19,2} HITS48{20,2} HITS48{21,2} HITS48{15,2} nan HITS48{31,2} HITS48{32,2} HITS48{33,2} HITS48{34,2} nan HITS48{43,2} HITS48{44,2} HITS48{45,2} HITS48{46,2} nan HITS48{55,2} HITS48{56,2} HITS48{57,2} HITS48{58,2} nan HITS48{67,2} HITS48{68,2} HITS48{69,2} HITS48{70,2} nan;...
                nan nan       HITS48{11,2} HITS48{12,2} nan     nan nan        HITS48{23,2} HITS48{24,2} nan        nan nan        HITS48{35,2} HITS48{36,2} nan        nan nan        HITS48{47,2} HITS48{48,2} nan        nan nan        HITS48{59,2} HITS48{60,2} nan        nan nan        HITS48{71,2} HITS48{72,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan        HITS48{73,2} HITS48{74,2} nan        nan nan        HITS48{85,2} HITS48{86,2} nan        nan nan         HITS48{97,2} HITS48{98,2} nan         nan nan         HITS48{109,2} HITS48{110,2} nan         nan nan         HITS48{121,2} HITS48{122,2} nan         nan nan         HITS48{133,2} HITS48{134,2} nan nan;...
                nan HITS48{75,2} HITS48{76,2} HITS48{77,2} HITS48{78,2} nan HITS48{87,2} HITS48{88,2} HITS48{89,2} HITS48{90,2} nan HITS48{99,2} HITS48{100,2} HITS48{101,2} HITS48{102,2} nan HITS48{111,2} HITS48{112,2} HITS48{113,2} HITS48{114,2} nan HITS48{123,2} HITS48{124,2} HITS48{125,2} HITS48{126,2} nan HITS48{135,2} HITS48{136,2} HITS48{137,2} HITS48{138,2} nan;...
                nan HITS48{79,2} HITS48{80,2} HITS48{81,2} HITS48{82,2} nan HITS48{91,2} HITS48{92,2} HITS48{93,2} HITS48{94,2} nan HITS48{103,2} HITS48{104,2} HITS48{105,2}  HITS48{106,2} nan HITS48{115,2} HITS48{116,2} HITS48{117,2} HITS48{118,2} nan HITS48{127,2} HITS48{128,2} HITS48{129,2} HITS48{130,2} nan HITS48{139,2} HITS48{140,2} HITS48{141,2} HITS48{142,2} nan;...
                nan nan        HITS48{83,2} HITS48{84,2} nan        nan nan        HITS48{95,2} HITS48{96,2} nan        nan nan         HITS48{107,2} HITS48{108,2}   nan      nan nan         HITS48{119,2} HITS48{120,2} nan        nan nan         HITS48{131,2} HITS48{132,2} nan         nan nan         HITS48{143,2} HITS48{144,2} nan nan];
            
        elseif joost && multiwell1 == 1
            
              layout4= [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{1,2}   HITS48{2,2}   HITS48{3,2}   HITS48{4,2}   nan nan HITS48{17,2}  HITS48{18,2}  HITS48{19,2}  HITS48{20,2}  nan nan HITS48{33,2}  HITS48{34,2}  HITS48{35,2}  HITS48{36,2}  nan nan HITS48{49,2}  HITS48{50,2}  HITS48{51,2}  HITS48{52,2}  nan nan HITS48{65,2}  HITS48{66,2}  HITS48{67,2}  HITS48{68,2}  nan nan HITS48{81,2}  HITS48{82,2}  HITS48{83,2}  HITS48{84,2}  nan nan;
                nan nan HITS48{5,2}   HITS48{6,2}   HITS48{7,2}   HITS48{8,2}   nan nan HITS48{21,2}  HITS48{22,2}  HITS48{23,2}  HITS48{24,2}  nan nan HITS48{37,2}  HITS48{38,2}  HITS48{39,2}  HITS48{40,2}  nan nan HITS48{53,2}  HITS48{54,2}  HITS48{55,2}  HITS48{56,2}  nan nan HITS48{69,2}  HITS48{70,2}  HITS48{71,2}  HITS48{72,2}  nan nan HITS48{85,2}  HITS48{86,2}  HITS48{87,2}  HITS48{88,2}  nan nan;
                nan nan HITS48{9,2}   HITS48{10,2}  HITS48{11,2}  HITS48{12,2}  nan nan HITS48{25,2}  HITS48{26,2}  HITS48{27,2}  HITS48{28,2}  nan nan HITS48{41,2}  HITS48{42,2}  HITS48{43,2}  HITS48{44,2}  nan nan HITS48{57,2}  HITS48{58,2}  HITS48{59,2}  HITS48{60,2}  nan nan HITS48{73,2}  HITS48{74,2}  HITS48{75,2}  HITS48{76,2}  nan nan HITS48{89,2}  HITS48{90,2}  HITS48{91,2}  HITS48{92,2}  nan nan;
                nan nan HITS48{13,2}  HITS48{14,2}  HITS48{15,2}  HITS48{16,2}  nan nan HITS48{29,2}  HITS48{30,2}  HITS48{31,2}  HITS48{32,2}  nan nan HITS48{45,2}  HITS48{46,2}  HITS48{47,2}  HITS48{48,2}  nan nan HITS48{61,2}  HITS48{62,2}  HITS48{63,2}  HITS48{64,2}  nan nan HITS48{77,2}  HITS48{78,2}  HITS48{79,2}  HITS48{80,2}  nan nan HITS48{93,2}  HITS48{94,2}  HITS48{95,2}  HITS48{96,2}  nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{97,2}  HITS48{98,2}  HITS48{99,2}  HITS48{100,2} nan nan HITS48{113,2} HITS48{114,2} HITS48{115,2} HITS48{116,2} nan nan HITS48{129,2} HITS48{130,2} HITS48{131,2} HITS48{132,2} nan nan HITS48{145,2} HITS48{146,2} HITS48{147,2} HITS48{148,2} nan nan HITS48{161,2} HITS48{162,2} HITS48{163,2} HITS48{164,2} nan nan HITS48{177,2} HITS48{178,2} HITS48{179,2} HITS48{180,2} nan nan;
                nan nan HITS48{101,2} HITS48{102,2} HITS48{103,2} HITS48{104,2} nan nan HITS48{117,2} HITS48{118,2} HITS48{119,2} HITS48{120,2} nan nan HITS48{133,2} HITS48{134,2} HITS48{135,2} HITS48{136,2} nan nan HITS48{149,2} HITS48{150,2} HITS48{151,2} HITS48{152,2} nan nan HITS48{165,2} HITS48{166,2} HITS48{167,2} HITS48{168,2} nan nan HITS48{181,2} HITS48{182,2} HITS48{183,2} HITS48{184,2} nan nan;
                nan nan HITS48{105,2} HITS48{106,2} HITS48{107,2} HITS48{108,2} nan nan HITS48{121,2} HITS48{122,2} HITS48{123,2} HITS48{124,2} nan nan HITS48{137,2} HITS48{138,2} HITS48{139,2} HITS48{140,2} nan nan HITS48{153,2} HITS48{154,2} HITS48{155,2} HITS48{156,2} nan nan HITS48{169,2} HITS48{170,2} HITS48{171,2} HITS48{172,2} nan nan HITS48{185,2} HITS48{186,2} HITS48{187,2} HITS48{188,2} nan nan;
                nan nan HITS48{109,2} HITS48{110,2} HITS48{111,2} HITS48{112,2} nan nan HITS48{125,2} HITS48{126,2} HITS48{127,2} HITS48{128,2} nan nan HITS48{141,2} HITS48{142,2} HITS48{143,2} HITS48{144,2} nan nan HITS48{157,2} HITS48{158,2} HITS48{159,2} HITS48{160,2} nan nan HITS48{173,2} HITS48{174,2} HITS48{175,2} HITS48{176,2} nan nan HITS48{189,2} HITS48{190,2} HITS48{191,2} HITS48{192,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{193,2} HITS48{194,2} HITS48{195,2} HITS48{196,2} nan nan HITS48{209,2} HITS48{210,2} HITS48{211,2} HITS48{212,2} nan nan HITS48{225,2} HITS48{226,2} HITS48{227,2} HITS48{228,2} nan nan HITS48{241,2} HITS48{242,2} HITS48{243,2} HITS48{244,2} nan nan HITS48{257,2} HITS48{258,2} HITS48{259,2} HITS48{260,2} nan nan HITS48{273,2} HITS48{274,2} HITS48{275,2} HITS48{276,2} nan nan;
                nan nan HITS48{197,2} HITS48{198,2} HITS48{199,2} HITS48{200,2} nan nan HITS48{213,2} HITS48{214,2} HITS48{215,2} HITS48{216,2} nan nan HITS48{229,2} HITS48{230,2} HITS48{231,2} HITS48{232,2} nan nan HITS48{245,2} HITS48{246,2} HITS48{247,2} HITS48{248,2} nan nan HITS48{261,2} HITS48{262,2} HITS48{263,2} HITS48{264,2} nan nan HITS48{277,2} HITS48{278,2} HITS48{279,2} HITS48{280,2} nan nan;
                nan nan HITS48{201,2} HITS48{202,2} HITS48{203,2} HITS48{204,2} nan nan HITS48{217,2} HITS48{218,2} HITS48{219,2} HITS48{220,2} nan nan HITS48{233,2} HITS48{234,2} HITS48{235,2} HITS48{236,2} nan nan HITS48{249,2} HITS48{250,2} HITS48{251,2} HITS48{252,2} nan nan HITS48{265,2} HITS48{266,2} HITS48{267,2} HITS48{268,2} nan nan HITS48{281,2} HITS48{282,2} HITS48{283,2} HITS48{284,2} nan nan;
                nan nan HITS48{205,2} HITS48{206,2} HITS48{207,2} HITS48{208,2} nan nan HITS48{221,2} HITS48{222,2} HITS48{223,2} HITS48{224,2} nan nan HITS48{237,2} HITS48{238,2} HITS48{239,2} HITS48{240,2} nan nan HITS48{253,2} HITS48{254,2} HITS48{255,2} HITS48{256,2} nan nan HITS48{269,2} HITS48{270,2} HITS48{271,2} HITS48{272,2} nan nan HITS48{285,2} HITS48{286,2} HITS48{287,2} HITS48{288,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{289,2} HITS48{290,2} HITS48{291,2} HITS48{292,2} nan nan HITS48{305,2} HITS48{306,2} HITS48{307,2} HITS48{308,2} nan nan HITS48{321,2} HITS48{322,2} HITS48{323,2} HITS48{324,2} nan nan HITS48{337,2} HITS48{338,2} HITS48{339,2} HITS48{340,2} nan nan HITS48{353,2} HITS48{354,2} HITS48{355,2} HITS48{356,2} nan nan HITS48{369,2} HITS48{370,2} HITS48{371,2} HITS48{372,2} nan nan;
                nan nan HITS48{293,2} HITS48{294,2} HITS48{295,2} HITS48{296,2} nan nan HITS48{309,2} HITS48{310,2} HITS48{311,2} HITS48{312,2} nan nan HITS48{325,2} HITS48{326,2} HITS48{327,2} HITS48{328,2} nan nan HITS48{341,2} HITS48{342,2} HITS48{343,2} HITS48{344,2} nan nan HITS48{357,2} HITS48{358,2} HITS48{359,2} HITS48{360,2} nan nan HITS48{373,2} HITS48{374,2} HITS48{375,2} HITS48{376,2} nan nan;
                nan nan HITS48{297,2} HITS48{298,2} HITS48{299,2} HITS48{300,2} nan nan HITS48{313,2} HITS48{314,2} HITS48{315,2} HITS48{316,2} nan nan HITS48{329,2} HITS48{330,2} HITS48{331,2} HITS48{332,2} nan nan HITS48{345,2} HITS48{346,2} HITS48{347,2} HITS48{348,2} nan nan HITS48{361,2} HITS48{362,2} HITS48{363,2} HITS48{364,2} nan nan HITS48{377,2} HITS48{378,2} HITS48{379,2} HITS48{380,2} nan nan;
                nan nan HITS48{301,2} HITS48{302,2} HITS48{303,2} HITS48{304,2} nan nan HITS48{317,2} HITS48{318,2} HITS48{319,2} HITS48{320,2} nan nan HITS48{333,2} HITS48{334,2} HITS48{335,2} HITS48{336,2} nan nan HITS48{349,2} HITS48{350,2} HITS48{351,2} HITS48{352,2} nan nan HITS48{365,2} HITS48{366,2} HITS48{367,2} HITS48{368,2} nan nan HITS48{381,2} HITS48{382,2} HITS48{383,2} HITS48{384,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan];
        else
            layout4=...
                [nan nan HITS48{12,2} HITS48{11,2} nan nan nan HITS48{24,2} HITS48{23,2} nan nan nan HITS48{36,2} HITS48{35,2} nan nan nan HITS48{48,2} HITS48{47,2} nan nan nan HITS48{60,2} HITS48{59,2} nan nan nan HITS48{72,2} HITS48{71,2} nan nan;...
                nan HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} nan HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} nan HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} nan HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} nan HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} nan HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2} nan;...
                nan  HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} nan HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} nan HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} nan HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} nan HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} nan HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2} nan;...
                nan nan HITS48{2,2} HITS48{1,2} nan nan nan HITS48{14,2} HITS48{13,2} nan nan nan HITS48{26,2} HITS48{25,2} nan nan nan HITS48{38,2} HITS48{37,2} nan nan nan HITS48{50,2} HITS48{49,2} nan nan nan HITS48{62,2} HITS48{61,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{84,2} HITS48{83,2} nan nan nan HITS48{96,2} HITS48{95,2} nan nan nan HITS48{108,2} HITS48{107,2} nan nan nan HITS48{120,2} HITS48{119,2} nan nan nan HITS48{132,2} HITS48{131,2} nan nan nan HITS48{144,2} HITS48{143,2} nan nan;...
                nan HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} nan HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} nan HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} nan HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} nan HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} nan HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2} nan;...
                nan HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} nan HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} nan HITS48{102,2} HITS48{101,2} HITS48{100,2}  HITS48{99,2} nan HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} nan HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} nan HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2} nan;...
                nan nan HITS48{74,2} HITS48{73,2} nan nan nan HITS48{86,2} HITS48{85,2} nan nan nan HITS48{98,2} HITS48{97,2} nan nan nan HITS48{110,2} HITS48{109,2} nan nan nan HITS48{122,2} HITS48{121,2} nan nan nan HITS48{134,2} HITS48{133,2} nan nan;...
                nan nan nan  nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{156,2} HITS48{155,2} nan nan nan HITS48{168,2} HITS48{167,2} nan nan nan HITS48{180,2} HITS48{179,2} nan nan nan HITS48{192,2} HITS48{191,2} nan nan nan HITS48{204,2} HITS48{203,2} nan nan nan HITS48{216,2} HITS48{215,2} nan nan;...
                nan HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} nan HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} nan HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} nan HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} nan HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} nan HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2} nan;...
                nan HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} nan HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} nan HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} nan HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} nan HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} nan HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2} nan;...
                nan nan HITS48{146,2} HITS48{145,2} nan nan nan HITS48{158,2} HITS48{157,2} nan nan nan HITS48{170,2} HITS48{169,2} nan nan nan HITS48{182,2} HITS48{181,2} nan nan nan HITS48{194,2} HITS48{193,2} nan nan nan HITS48{206,2} HITS48{205,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{228,2} HITS48{227,2} nan nan nan HITS48{240,2} HITS48{239,2} nan nan nan HITS48{252,2} HITS48{251,2} nan nan nan HITS48{264,2} HITS48{263,2} nan nan nan HITS48{276,2} HITS48{275,2} nan nan nan HITS48{288,2} HITS48{287,2} nan nan;
                nan HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} nan HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} nan HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} nan HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} nan HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} nan HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2} nan;...
                nan HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} nan HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} nan HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} nan HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} nan HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} nan HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2} nan;...
                nan nan HITS48{218,2} HITS48{217,2} nan nan nan HITS48{230,2} HITS48{229,2} nan nan nan HITS48{242,2} HITS48{241,2} nan nan nan HITS48{254,2} HITS48{253,2} nan nan nan HITS48{266,2} HITS48{265,2} nan nan nan HITS48{278,2} HITS48{277,2} nan nan];
        end
        
        ax24 = axes(handles.uipanel8);
        %     ax=axes(hObject);
        imagesc(layout4,'AlphaData',~isnan(layout4));
        if joost && multiwell1 == 1
            textstrings={...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '1'  '5' '9'  '13'  [] [] '97'  '101' '105' '109'  [] [] '193' '197' '201' '205' [] [] '289' '293' '297' '301' [] []...
                [] [] '2'  '6' '10' '14'  [] [] '98'  '102' '106' '110'  [] [] '194' '198' '202' '206' [] [] '290' '294' '298' '302' [] []...
                [] [] '3'  '7' '11' '15'  [] [] '99'  '103' '107' '111'  [] [] '195' '199' '203' '207' [] [] '291' '295' '299' '303' [] []...
                [] [] '4'  '8' '12' '16'  [] [] '100' '104' '108' '112'  [] [] '196' '200' '204' '208' [] [] '292' '296' '300' '304' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '17' '21' '25' '29' [] [] '113'  '117' '121' '125' [] [] '209' '213' '217' '221' [] [] '305' '309' '313' '317' [] []...
                [] [] '18' '22' '26' '30' [] [] '114'  '118' '122' '126' [] [] '210' '214' '218' '222' [] [] '306' '310' '314' '318' [] []...
                [] [] '19' '23' '27' '31' [] [] '115'  '119' '123' '127' [] [] '211' '215' '219' '223' [] [] '307' '311' '315' '319' [] []...
                [] [] '20' '24' '28' '32' [] [] '116'  '120' '124' '128' [] [] '212' '216' '220' '224' [] [] '308' '312' '316' '320' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '33' '37' '41' '45' [] [] '129'  '133' '137' '141' [] [] '225' '229' '233' '237' [] [] '321' '325' '329' '333' [] []...
                [] [] '34' '38' '42' '46' [] [] '130'  '134' '138' '142' [] [] '226' '230' '234' '238' [] [] '322' '326' '330' '334' [] []...
                [] [] '35' '39' '43' '47' [] [] '131'  '135' '139' '143' [] [] '227' '231' '235' '239' [] [] '323' '327' '331' '335' [] []...
                [] [] '36' '40' '44' '48' [] [] '132'  '136' '140' '144' [] [] '228' '232' '236' '240' [] [] '324' '328' '332' '336' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '49' '53' '57' '61' [] [] '145' '149' '153' '157'  [] [] '241' '245' '249' '253' [] [] '337' '341' '345' '349' [] []...
                [] [] '50' '54' '58' '62' [] [] '146' '150' '154' '158'  [] [] '242' '246' '250' '254' [] [] '338' '342' '346' '350' [] []...
                [] [] '51' '55' '59' '63' [] [] '147' '151' '155' '159'  [] [] '243' '247' '251' '255' [] [] '339' '343' '347' '351' [] []...
                [] [] '52' '56' '60' '64' [] [] '148' '152' '156' '160'  [] [] '244' '248' '252' '256' [] [] '340' '344' '348' '352' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '65' '69' '73' '77' [] [] '161' '165' '169' '173'  [] [] '257' '261' '265' '269' [] [] '353' '357' '361' '365' [] []...
                [] [] '66' '70' '74' '78' [] [] '162' '166' '170' '174'  [] [] '258' '262' '266' '270' [] [] '354' '358' '362' '366' [] []...
                [] [] '67' '71' '75' '79' [] [] '163' '167' '171' '175'  [] [] '259' '263' '267' '271' [] [] '355' '359' '363' '367' [] []...
                [] [] '68' '72' '76' '80' [] [] '164' '168' '172' '176'  [] [] '260' '264' '268' '272' [] [] '356' '360' '364' '368' [] []...
                [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '81' '85' '89' '93' [] [] '177' '181' '185' '189'  [] [] '273' '277' '281' '285' [] [] '369' '373' '377' '381' [] []...
                [] [] '82' '86' '90' '94' [] [] '178' '182' '186' '190'  [] [] '274' '278' '282' '286' [] [] '370' '374' '378' '382' [] []...
                [] [] '83' '87' '91' '95' [] [] '179' '183' '187' '191'  [] [] '275' '279' '283' '287' [] [] '371' '375' '379' '383' [] []...
                [] [] '84' '88' '92' '96' [] [] '180' '184' '188' '192'  [] [] '276' '280' '284' '288' [] [] '372' '376' '380' '384' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []}';
            
            
            [x, y] = meshgrid(1:38);
            for i=31:-1:20
                x(i,:)=[];
                y(i,:)=[];
            end
        else
            textstrings={...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '3' '7' [] [] [] '75' '79' [] [] [] '147' '151' [] [] [] '219' '223' [] ...
                '1' '4' '8' '11' [] '73' '76' '80' '83' [] '145' '148' '152' '155' [] '217' '220' '224' '227' ...
                '2' '5' '9' '12' [] '74' '77' '81' '84' [] '146' '149' '153' '156' [] '218' '221' '225' '228' ...
                [] '6' '10' [] [] [] '78' '82' [] [] [] '150' '154' [] [] [] '222' '226' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '15' '19' [] [] [] '87' '91' [] [] [] '159' '163' [] [] [] '231' '235' [] ...
                '13' '16' '20' '23' [] '85' '88' '92' '95' [] '157' '160' '164' '167' [] '229' '232' '236' '239' ...
                '14' '17' '21' '24' [] '86' '89' '93' '96' [] '158' '161' '165' '168' [] '230' '233' '237' '240' ...
                [] '18' '22' [] [] [] '90' '94' [] [] [] '162' '166' [] [] [] '234' '238' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '27' '31' [] [] [] '99' '103' [] [] [] '171' '175' [] [] [] '243' '247' [] ...
                '25' '28' '32' '35' [] '97' '100' '104' '107' [] '169' '172' '176' '179' [] '241' '244' '248' '251' ...
                '26' '29' '33' '36' [] '98' '101' '105' '108' [] '170' '173' '177' '180' [] '242' '245' '249' '252' ...
                [] '30' '34' [] [] [] '102' '106' [] [] [] '174' '178' [] [] [] '246' '250' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '39' '43' [] [] [] '111' '115' [] [] [] '183' '187' [] [] [] '255' '259' [] ...
                '37' '40' '44' '47' [] '109' '112' '116' '119' [] '181' '184' '188' '191' [] '253' '256' '260' '263' ...
                '38' '41' '45' '48' [] '110' '113' '117' '120' [] '182' '185' '189' '192' [] '254' '257' '261' '264' ...
                [] '42' '46' [] [] [] '114' '118' [] [] [] '186' '190' [] [] [] '258' '262' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '51' '55' [] [] [] '123' '127' [] [] [] '195' '199' [] [] [] '267' '271' [] ...
                '49' '52' '56' '59' [] '121' '124' '128' '131' [] '193' '196' '200' '203' [] '265' '268' '272' '275' ...
                '50' '53' '57' '60' [] '122' '125' '129' '132' [] '194' '197' '201' '204' [] '266' '269' '273' '276' ...
                [] '54' '58' [] [] [] '126' '130' [] [] [] '198' '202' [] [] [] '270' '274' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '63' '67' [] [] [] '135' '139' [] [] [] '207' '211' [] [] [] '279' '283' [] ...
                '61' '64' '68' '71' [] '133' '136' '140' '143' [] '205' '208' '212' '215' [] '277' '280' '284' '287' ...
                '62' '65' '69' '72' [] '134' '137' '141' '144' [] '206' '209' '213' '216' [] '278' '281' '285' '288' ...
                [] '66' '70' [] [] [] '138' '142' [] [] [] '210' '214' [] [] [] '282' '286' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []}';
            
            [x, y] = meshgrid(1:31);
            for i=31:-1:20
                x(i,:)=[];
                y(i,:)=[];
            end
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center','Fontsize',6);
        
        
        
        top60=cell2mat(supa1);
        if handles.pushbutton60.Value == 1
            top60(top60 < (mean(M,'all','omitnan') + thrconnec*std(M,1,'all','omitnan'))) = 0; % new
        end
        top60(isnan(top60)) =0; %% new added for joost's method
        
        [B,I]=sort(top60,'descend');   % order them
        ghg=find(B == 0); %remove all the zeros
        I(ghg)=[];
        
        
        
        %each 120 elements belong to one channel
        %firsst column will be the origin of the line
        %2nd column will be the destination of the line
        I(:,2)=ceil(I(:)/electrodecount); % there are 12 electrodes per well ( this will give us the correct well number
        I(:,3)= electrodecount-((I(:,2)*electrodecount)-I(:,1)); % this will give us the correct channel number
        I(:,3) =  I(:,3) .* ceil(I(:,2)/electrodecount);
        I(I<1) = 1;
        ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
        removeindx = find(cell2mat(HITS(:,2)) <= 10);
        
        I(ismember(I(:,2),removeindx)) =0;
        I(ismember(I(:,2),removeindx),3) =0;
        I(ismember(I(:,2),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),1) =0;
        I(ismember(I(:,3),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),3) =0;
        
        for i = length(I):-1:1
            if I(i,1) == 0
                I(i,:) = [];
            end
        end
        %also delete connections that do not involve the channel of interest
        
        for i = length(I):-1:1
            if I(i,2) == Ghibli(1) || I(i,3) == Ghibli(1)
            else
                I(i,:) = [];
            end
        end
        
        looop=0;
        
        for i=1:size(I,1)
            yutr=I(i,2);
            looop =looop+1;
            %         kk=ag(ag==yutr); % added for joosts method
            lll=find(layout4 == HITS48{yutr,2});
            [r,c] = ind2sub(size(layout4),lll);
            
            k=I(i,3);
            llll=find(layout4 == HITS48{k,2});
            [rr,cc] = ind2sub(size(layout4),llll);
            hold on
            if arrowss == 1
                nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
            elseif arrowss == 0
                nnn=line([c cc],[r rr],'Color','r');
            end
            drawnow;
            colmin=0;
            %         colmin=min(B(:));
            colmax=max(B(:));
            COLOR1=parula(length(B));
            goodcolor=COLOR1(round(length(B)*(B(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
            nnn.Color=goodcolor;
            cbn=colorbar;
            cbn.Colormap=parula(length(B));
            cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        end
        
        
        set(gca,'visible','off');
        set(gca,'Colormap',[1 1 1]);
    end
    clear supa1 supa
    
    text82_ButtonDownFcn(handles.text82,eventdata,handles)
    handles.text82.Visible = 'on';
    set(handles.Pannel_9.Text,'String',strjoin(['The Connectivity Map for Channel', jitters{1}]));
end
clear noconnections
end

% --- Executes during object creation, after setting all properties.
function pushbutton39_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.Position = [0.1685 0.0124 0.0851 0.0238];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.FontWeight = 'bold';
hObject.String = 'Select Channel';
hObject.CData = imread('color_button.png');

end

% --- Channel B
function uipanel9_CreateFcn(hObject, eventdata, handles)
hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.418 .037 .398 .358];
end

function uipanel9_ButtonDownFcn(hObject, eventdata, handles)
end

% --- Executes on button press in pushbutton41.
function pushbutton41_Callback(hObject, eventdata, handles)
global jitters Ghibli selecteddata electrodecount textstrings parts HITS indx23 supa newM2  looop2  filteredData1 M2 thrconnec timesss finalssss M arrowss joost multiwell1

noconnections = 0;
prompt = {'Enter Channel name B:'};
title = 'Connectivity Map';
dims = [1 35];
definput = {'B1'};
jitters{2} = inputdlg(prompt,title,dims,definput);

if indx23 == 1
    Ghibli(2)=find(strcmp(textstrings(:,1),jitters{2}));
elseif  indx23 == 2
    textstrings1 = HITS(:,1);
    Ghibli(2)=find(strcmp(textstrings1(:,1),jitters{2}));
end

% yup=input('Which channel do you want to cross correlate?');
% Ghibli=find(strncmpi(HITS,yup,3));

if indx23 == 2
    
    supa1 = supa;
    %gotta turn the numbers around for the max function
    for i=1:length(M2)
        supa1{i}=supa1{i}';
    end
    
    for i=1:length(M2)
        supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
    end
    
    
    HITS48=HITS;
    
    lp=rand(1,length(HITS))+rand(1,length(HITS));
    kp=rand(1,length(HITS))+rand(1,length(HITS));
    ml=rand(1,length(HITS))+0.68;
    lp=lp+kp+ml;
    lp=lp';
    for i=1:length(HITS)
        HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
    end
    
    
    if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
        layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
    elseif length(filteredData1(:,1)) > 121
        layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
    else %% for 120 channel MEA
        layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
    end
    
    ax = axes(hObject);
    imagesc(layout4,'AlphaData',~isnan(layout4));
    
    if length(textstrings) > 400
        [x, y] = meshgrid(1:24);
        for i=[24 23 22 21 20]
            x(i,:)=[];
            y(i,:)=[];
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    else
        [x, y] = meshgrid(1:12);
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    end
    
    
    %         waitbar(0 + 0.9,hh,'Drawing the Connections');
    top60=cell2mat(supa1);
    top60(top60 < thrconnec) = 0;
    % change nan values into zeros
    
    %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
    
    [B,I]=sort(top60,'descend');   % order them
    ghg=find(B == 0); %remove all the zeros
    I(ghg)=[];
    
    %get the top60 connections if the length of I is longer than 60
    if length(I) > 60
        I=I(1:60);
    end
    
    if length(filteredData1(:,1)) == 60
        I=I(:)/60;
    else
        I=I(:)/120;
    end
    
    
    %each 120 elements belong to one channel
    %firsst column will be the origin of the line
    %2nd column will be the destination of the line
    I(:,2)=floor(I(:,1));
    I(:,3)=I(:,1) - I(:,2);
    
    if length(filteredData1(:,1)) == 60
        I(:,3)=I(:,3)*60;
    else
        I(:,3)=I(:,3)*120;
    end
    
    I(:,3)=round(I(:,3));
    I(:,2)=ceil(I(:,1));
    I(I<1) = 1;
    ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
    removeindx = find(cell2mat(HITS(:,2)) <= 10);
    
    I(ismember(I(:,2),removeindx)) =0;
    I(ismember(I(:,2),removeindx),3) =0;
    I(ismember(I(:,2),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),1) =0;
    I(ismember(I(:,3),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),3) =0;
    
    for i = length(I):-1:1
        if I(i,1) == 0
            I(i,:) = [];
        end
    end
    
    %also delete connections that do not involve the channel of interest
    %     correctindex = find(I(:,2) == Ghibli(1));
    %     correctindex2 = find(I(:,3) == Ghibli(1));
    %     indexfull = [correctindex;correctindex2]; % this contains the indeices that have connections with the channel of interest
    %
    for i = length(I):-1:1
        if I(i,2) == Ghibli(2) || I(i,3) == Ghibli(2)
        else
            I(i,:) = [];
        end
    end
    
    
    
    
    looop2= 0 ;
    
    for i=1:size(I,1)
        yutr=I(i,2);
        looop2 = looop2+1;
        kk=ag(ag==yutr); % added for joosts method
        lll=find(layout4 == HITS48{kk,2});
        [r,c] = ind2sub(size(layout4),lll);
        
        k=I(i,3);
        llll=find(layout4 == HITS48{k,2});
        [rr,cc] = ind2sub(size(layout4),llll);
        hold on
        if arrowss == 1
            nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
        elseif arrowss == 0
            nnn=line([c cc],[r rr],'Color','r');
        end
        drawnow;
        colmin=min(top60(:));
        colmax=max(top60(:));
        COLOR1=parula(length(top60));
        goodcolor=COLOR1(round(length(top60)*(top60(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
        nnn.Color=goodcolor;
        cbn=colorbar;
        cbn.Colormap=parula(length(top60));
        %         cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        %         cbn.TickLabels = [0.73 0.76 0.79 0.82 0.85 0.88 0.91 094 0.97 1];
    end
    
    
    
    set(gca,'visible','off');
    set(gca,'Colormap',[1 1 1]);
else
    if joost && multiwell1 == 1
        if ~isempty(M)
            supa1=cell(1,length(M2))';
            for i = 1:length(M2) % added for joost's method
                supa1{i} = M(i,:)';
            end
        else
            msgbox('There are no connections!')
            noconnections = 1;
        end
    else
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
        
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        end
        
        supa1=cell(1,length(M2))';
        j = 1;
        load(selecteddata,'M');
        for i = 1:(electrodecount*parts)
            if isempty(M)
                continue
            else
                supa1{i} = M(1:electrodecount)';
                if i == 12
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 24
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 36
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 48
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 60
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                elseif i == 72
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 84
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 96
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 108
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 120
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                elseif i == 132
                    
                    replace1 =sprintf('Well_%d',j);
                    replace2 = sprintf('Well_%d',j+1);
                    selecteddata = replace(selecteddata,replace1,replace2);
                    load(selecteddata,'M');
                    j = j+1;
                    
                end
            end
        end
        
    end
    if noconnections == 1
    else
        % need to change the numbers from the user input as the index doesnt
        % match anymore
        if length(filteredData1(:,1)) > 121
            Ghibli(2)=find(strcmp(textstrings(:,1),jitters{2}));
        else
            Ghibli(2)=find(strcmp(HITS(:,1),jitters{2}));
        end
        
        
        %higher than 70% we will draw a line (spikecode this this aswell
        %so now the only thing we need to do is draw a line if the number exceeds
        %0.7 or 70% SPYCODE threshhold
        
        %use the below layout structure to get the correct position
        
        %So what needs to happen is 3 things, we will first check if in supa
        %soemthing has passed the 0.7 mark and if it does the next thing it will do
        %is search in the layout for the correct position and the last step is to
        %draw a line
        
        %we have to make the numbers uin HITS all unqiue so we won't have issues with duplicates
        
        HITS48=HITS;
        lp=rand(1,length(HITS))+rand(1,length(HITS));
        kp=rand(1,length(HITS))+rand(1,length(HITS));
        ml=rand(1,length(HITS))+0.68;
        lp=lp+kp+ml;
        lp=lp';
        for i=1:length(HITS)
            HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
        end
        
        
        % it seems that you cannot leave the other channel empty
        %i will put zeros in the empty spaces
        
        if parts == 12
            layout4=...
                [nan   nan     HITS48{1,2} HITS48{2,2} nan       nan nan        HITS48{13,2} HITS48{14,2} nan        nan nan        HITS48{25,2} HITS48{26,2} nan        nan nan        HITS48{37,2} HITS48{38,2} nan        nan nan        HITS48{49,2} HITS48{50,2} nan        nan nan        HITS48{61,2} HITS48{62,2} nan nan;...
                nan HITS48{3,2} HITS48{4,2} HITS48{5,2} HITS48{6,2} nan HITS48{15,2} HITS48{16,2} HITS48{17,2} HITS48{18,2} nan HITS48{27,2} HITS48{28,2} HITS48{29,2} HITS48{30,2} nan HITS48{39,2} HITS48{40,2} HITS48{41,2} HITS48{42,2} nan HITS48{51,2} HITS48{52,2} HITS48{53,2} HITS48{54,2} nan HITS48{63,2} HITS48{64,2} HITS48{65,2} HITS48{66,2} nan;...
                nan HITS48{7,2} HITS48{8,2} HITS48{9,2} HITS48{10,2} nan HITS48{19,2} HITS48{20,2} HITS48{21,2} HITS48{15,2} nan HITS48{31,2} HITS48{32,2} HITS48{33,2} HITS48{34,2} nan HITS48{43,2} HITS48{44,2} HITS48{45,2} HITS48{46,2} nan HITS48{55,2} HITS48{56,2} HITS48{57,2} HITS48{58,2} nan HITS48{67,2} HITS48{68,2} HITS48{69,2} HITS48{70,2} nan;...
                nan nan       HITS48{11,2} HITS48{12,2} nan     nan nan        HITS48{23,2} HITS48{24,2} nan        nan nan        HITS48{35,2} HITS48{36,2} nan        nan nan        HITS48{47,2} HITS48{48,2} nan        nan nan        HITS48{59,2} HITS48{60,2} nan        nan nan        HITS48{71,2} HITS48{72,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan        HITS48{73,2} HITS48{74,2} nan        nan nan        HITS48{85,2} HITS48{86,2} nan        nan nan         HITS48{97,2} HITS48{98,2} nan         nan nan         HITS48{109,2} HITS48{110,2} nan         nan nan         HITS48{121,2} HITS48{122,2} nan         nan nan         HITS48{133,2} HITS48{134,2} nan nan;...
                nan HITS48{75,2} HITS48{76,2} HITS48{77,2} HITS48{78,2} nan HITS48{87,2} HITS48{88,2} HITS48{89,2} HITS48{90,2} nan HITS48{99,2} HITS48{100,2} HITS48{101,2} HITS48{102,2} nan HITS48{111,2} HITS48{112,2} HITS48{113,2} HITS48{114,2} nan HITS48{123,2} HITS48{124,2} HITS48{125,2} HITS48{126,2} nan HITS48{135,2} HITS48{136,2} HITS48{137,2} HITS48{138,2} nan;...
                nan HITS48{79,2} HITS48{80,2} HITS48{81,2} HITS48{82,2} nan HITS48{91,2} HITS48{92,2} HITS48{93,2} HITS48{94,2} nan HITS48{103,2} HITS48{104,2} HITS48{105,2}  HITS48{106,2} nan HITS48{115,2} HITS48{116,2} HITS48{117,2} HITS48{118,2} nan HITS48{127,2} HITS48{128,2} HITS48{129,2} HITS48{130,2} nan HITS48{139,2} HITS48{140,2} HITS48{141,2} HITS48{142,2} nan;...
                nan nan        HITS48{83,2} HITS48{84,2} nan        nan nan        HITS48{95,2} HITS48{96,2} nan        nan nan         HITS48{107,2} HITS48{108,2}   nan      nan nan         HITS48{119,2} HITS48{120,2} nan        nan nan         HITS48{131,2} HITS48{132,2} nan         nan nan         HITS48{143,2} HITS48{144,2} nan nan];
            
        elseif joost && multiwell1 == 1
            
             layout4= [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{1,2}   HITS48{2,2}   HITS48{3,2}   HITS48{4,2}   nan nan HITS48{17,2}  HITS48{18,2}  HITS48{19,2}  HITS48{20,2}  nan nan HITS48{33,2}  HITS48{34,2}  HITS48{35,2}  HITS48{36,2}  nan nan HITS48{49,2}  HITS48{50,2}  HITS48{51,2}  HITS48{52,2}  nan nan HITS48{65,2}  HITS48{66,2}  HITS48{67,2}  HITS48{68,2}  nan nan HITS48{81,2}  HITS48{82,2}  HITS48{83,2}  HITS48{84,2}  nan nan;
                nan nan HITS48{5,2}   HITS48{6,2}   HITS48{7,2}   HITS48{8,2}   nan nan HITS48{21,2}  HITS48{22,2}  HITS48{23,2}  HITS48{24,2}  nan nan HITS48{37,2}  HITS48{38,2}  HITS48{39,2}  HITS48{40,2}  nan nan HITS48{53,2}  HITS48{54,2}  HITS48{55,2}  HITS48{56,2}  nan nan HITS48{69,2}  HITS48{70,2}  HITS48{71,2}  HITS48{72,2}  nan nan HITS48{85,2}  HITS48{86,2}  HITS48{87,2}  HITS48{88,2}  nan nan;
                nan nan HITS48{9,2}   HITS48{10,2}  HITS48{11,2}  HITS48{12,2}  nan nan HITS48{25,2}  HITS48{26,2}  HITS48{27,2}  HITS48{28,2}  nan nan HITS48{41,2}  HITS48{42,2}  HITS48{43,2}  HITS48{44,2}  nan nan HITS48{57,2}  HITS48{58,2}  HITS48{59,2}  HITS48{60,2}  nan nan HITS48{73,2}  HITS48{74,2}  HITS48{75,2}  HITS48{76,2}  nan nan HITS48{89,2}  HITS48{90,2}  HITS48{91,2}  HITS48{92,2}  nan nan;
                nan nan HITS48{13,2}  HITS48{14,2}  HITS48{15,2}  HITS48{16,2}  nan nan HITS48{29,2}  HITS48{30,2}  HITS48{31,2}  HITS48{32,2}  nan nan HITS48{45,2}  HITS48{46,2}  HITS48{47,2}  HITS48{48,2}  nan nan HITS48{61,2}  HITS48{62,2}  HITS48{63,2}  HITS48{64,2}  nan nan HITS48{77,2}  HITS48{78,2}  HITS48{79,2}  HITS48{80,2}  nan nan HITS48{93,2}  HITS48{94,2}  HITS48{95,2}  HITS48{96,2}  nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{97,2}  HITS48{98,2}  HITS48{99,2}  HITS48{100,2} nan nan HITS48{113,2} HITS48{114,2} HITS48{115,2} HITS48{116,2} nan nan HITS48{129,2} HITS48{130,2} HITS48{131,2} HITS48{132,2} nan nan HITS48{145,2} HITS48{146,2} HITS48{147,2} HITS48{148,2} nan nan HITS48{161,2} HITS48{162,2} HITS48{163,2} HITS48{164,2} nan nan HITS48{177,2} HITS48{178,2} HITS48{179,2} HITS48{180,2} nan nan;
                nan nan HITS48{101,2} HITS48{102,2} HITS48{103,2} HITS48{104,2} nan nan HITS48{117,2} HITS48{118,2} HITS48{119,2} HITS48{120,2} nan nan HITS48{133,2} HITS48{134,2} HITS48{135,2} HITS48{136,2} nan nan HITS48{149,2} HITS48{150,2} HITS48{151,2} HITS48{152,2} nan nan HITS48{165,2} HITS48{166,2} HITS48{167,2} HITS48{168,2} nan nan HITS48{181,2} HITS48{182,2} HITS48{183,2} HITS48{184,2} nan nan;
                nan nan HITS48{105,2} HITS48{106,2} HITS48{107,2} HITS48{108,2} nan nan HITS48{121,2} HITS48{122,2} HITS48{123,2} HITS48{124,2} nan nan HITS48{137,2} HITS48{138,2} HITS48{139,2} HITS48{140,2} nan nan HITS48{153,2} HITS48{154,2} HITS48{155,2} HITS48{156,2} nan nan HITS48{169,2} HITS48{170,2} HITS48{171,2} HITS48{172,2} nan nan HITS48{185,2} HITS48{186,2} HITS48{187,2} HITS48{188,2} nan nan;
                nan nan HITS48{109,2} HITS48{110,2} HITS48{111,2} HITS48{112,2} nan nan HITS48{125,2} HITS48{126,2} HITS48{127,2} HITS48{128,2} nan nan HITS48{141,2} HITS48{142,2} HITS48{143,2} HITS48{144,2} nan nan HITS48{157,2} HITS48{158,2} HITS48{159,2} HITS48{160,2} nan nan HITS48{173,2} HITS48{174,2} HITS48{175,2} HITS48{176,2} nan nan HITS48{189,2} HITS48{190,2} HITS48{191,2} HITS48{192,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{193,2} HITS48{194,2} HITS48{195,2} HITS48{196,2} nan nan HITS48{209,2} HITS48{210,2} HITS48{211,2} HITS48{212,2} nan nan HITS48{225,2} HITS48{226,2} HITS48{227,2} HITS48{228,2} nan nan HITS48{241,2} HITS48{242,2} HITS48{243,2} HITS48{244,2} nan nan HITS48{257,2} HITS48{258,2} HITS48{259,2} HITS48{260,2} nan nan HITS48{273,2} HITS48{274,2} HITS48{275,2} HITS48{276,2} nan nan;
                nan nan HITS48{197,2} HITS48{198,2} HITS48{199,2} HITS48{200,2} nan nan HITS48{213,2} HITS48{214,2} HITS48{215,2} HITS48{216,2} nan nan HITS48{229,2} HITS48{230,2} HITS48{231,2} HITS48{232,2} nan nan HITS48{245,2} HITS48{246,2} HITS48{247,2} HITS48{248,2} nan nan HITS48{261,2} HITS48{262,2} HITS48{263,2} HITS48{264,2} nan nan HITS48{277,2} HITS48{278,2} HITS48{279,2} HITS48{280,2} nan nan;
                nan nan HITS48{201,2} HITS48{202,2} HITS48{203,2} HITS48{204,2} nan nan HITS48{217,2} HITS48{218,2} HITS48{219,2} HITS48{220,2} nan nan HITS48{233,2} HITS48{234,2} HITS48{235,2} HITS48{236,2} nan nan HITS48{249,2} HITS48{250,2} HITS48{251,2} HITS48{252,2} nan nan HITS48{265,2} HITS48{266,2} HITS48{267,2} HITS48{268,2} nan nan HITS48{281,2} HITS48{282,2} HITS48{283,2} HITS48{284,2} nan nan;
                nan nan HITS48{205,2} HITS48{206,2} HITS48{207,2} HITS48{208,2} nan nan HITS48{221,2} HITS48{222,2} HITS48{223,2} HITS48{224,2} nan nan HITS48{237,2} HITS48{238,2} HITS48{239,2} HITS48{240,2} nan nan HITS48{253,2} HITS48{254,2} HITS48{255,2} HITS48{256,2} nan nan HITS48{269,2} HITS48{270,2} HITS48{271,2} HITS48{272,2} nan nan HITS48{285,2} HITS48{286,2} HITS48{287,2} HITS48{288,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan HITS48{289,2} HITS48{290,2} HITS48{291,2} HITS48{292,2} nan nan HITS48{305,2} HITS48{306,2} HITS48{307,2} HITS48{308,2} nan nan HITS48{321,2} HITS48{322,2} HITS48{323,2} HITS48{324,2} nan nan HITS48{337,2} HITS48{338,2} HITS48{339,2} HITS48{340,2} nan nan HITS48{353,2} HITS48{354,2} HITS48{355,2} HITS48{356,2} nan nan HITS48{369,2} HITS48{370,2} HITS48{371,2} HITS48{372,2} nan nan;
                nan nan HITS48{293,2} HITS48{294,2} HITS48{295,2} HITS48{296,2} nan nan HITS48{309,2} HITS48{310,2} HITS48{311,2} HITS48{312,2} nan nan HITS48{325,2} HITS48{326,2} HITS48{327,2} HITS48{328,2} nan nan HITS48{341,2} HITS48{342,2} HITS48{343,2} HITS48{344,2} nan nan HITS48{357,2} HITS48{358,2} HITS48{359,2} HITS48{360,2} nan nan HITS48{373,2} HITS48{374,2} HITS48{375,2} HITS48{376,2} nan nan;
                nan nan HITS48{297,2} HITS48{298,2} HITS48{299,2} HITS48{300,2} nan nan HITS48{313,2} HITS48{314,2} HITS48{315,2} HITS48{316,2} nan nan HITS48{329,2} HITS48{330,2} HITS48{331,2} HITS48{332,2} nan nan HITS48{345,2} HITS48{346,2} HITS48{347,2} HITS48{348,2} nan nan HITS48{361,2} HITS48{362,2} HITS48{363,2} HITS48{364,2} nan nan HITS48{377,2} HITS48{378,2} HITS48{379,2} HITS48{380,2} nan nan;
                nan nan HITS48{301,2} HITS48{302,2} HITS48{303,2} HITS48{304,2} nan nan HITS48{317,2} HITS48{318,2} HITS48{319,2} HITS48{320,2} nan nan HITS48{333,2} HITS48{334,2} HITS48{335,2} HITS48{336,2} nan nan HITS48{349,2} HITS48{350,2} HITS48{351,2} HITS48{352,2} nan nan HITS48{365,2} HITS48{366,2} HITS48{367,2} HITS48{368,2} nan nan HITS48{381,2} HITS48{382,2} HITS48{383,2} HITS48{384,2} nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan];
        else
            layout4=...
                [nan nan HITS48{12,2} HITS48{11,2} nan nan nan HITS48{24,2} HITS48{23,2} nan nan nan HITS48{36,2} HITS48{35,2} nan nan nan HITS48{48,2} HITS48{47,2} nan nan nan HITS48{60,2} HITS48{59,2} nan nan nan HITS48{72,2} HITS48{71,2} nan nan;...
                nan HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} nan HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} nan HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} nan HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} nan HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} nan HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2} nan;...
                nan  HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} nan HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} nan HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} nan HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} nan HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} nan HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2} nan;...
                nan nan HITS48{2,2} HITS48{1,2} nan nan nan HITS48{14,2} HITS48{13,2} nan nan nan HITS48{26,2} HITS48{25,2} nan nan nan HITS48{38,2} HITS48{37,2} nan nan nan HITS48{50,2} HITS48{49,2} nan nan nan HITS48{62,2} HITS48{61,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{84,2} HITS48{83,2} nan nan nan HITS48{96,2} HITS48{95,2} nan nan nan HITS48{108,2} HITS48{107,2} nan nan nan HITS48{120,2} HITS48{119,2} nan nan nan HITS48{132,2} HITS48{131,2} nan nan nan HITS48{144,2} HITS48{143,2} nan nan;...
                nan HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} nan HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} nan HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} nan HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} nan HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} nan HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2} nan;...
                nan HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} nan HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} nan HITS48{102,2} HITS48{101,2} HITS48{100,2}  HITS48{99,2} nan HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} nan HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} nan HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2} nan;...
                nan nan HITS48{74,2} HITS48{73,2} nan nan nan HITS48{86,2} HITS48{85,2} nan nan nan HITS48{98,2} HITS48{97,2} nan nan nan HITS48{110,2} HITS48{109,2} nan nan nan HITS48{122,2} HITS48{121,2} nan nan nan HITS48{134,2} HITS48{133,2} nan nan;...
                nan nan nan  nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{156,2} HITS48{155,2} nan nan nan HITS48{168,2} HITS48{167,2} nan nan nan HITS48{180,2} HITS48{179,2} nan nan nan HITS48{192,2} HITS48{191,2} nan nan nan HITS48{204,2} HITS48{203,2} nan nan nan HITS48{216,2} HITS48{215,2} nan nan;...
                nan HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} nan HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} nan HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} nan HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} nan HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} nan HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2} nan;...
                nan HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} nan HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} nan HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} nan HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} nan HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} nan HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2} nan;...
                nan nan HITS48{146,2} HITS48{145,2} nan nan nan HITS48{158,2} HITS48{157,2} nan nan nan HITS48{170,2} HITS48{169,2} nan nan nan HITS48{182,2} HITS48{181,2} nan nan nan HITS48{194,2} HITS48{193,2} nan nan nan HITS48{206,2} HITS48{205,2} nan nan;...
                nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
                nan nan HITS48{228,2} HITS48{227,2} nan nan nan HITS48{240,2} HITS48{239,2} nan nan nan HITS48{252,2} HITS48{251,2} nan nan nan HITS48{264,2} HITS48{263,2} nan nan nan HITS48{276,2} HITS48{275,2} nan nan nan HITS48{288,2} HITS48{287,2} nan nan;
                nan HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} nan HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} nan HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} nan HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} nan HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} nan HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2} nan;...
                nan HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} nan HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} nan HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} nan HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} nan HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} nan HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2} nan;...
                nan nan HITS48{218,2} HITS48{217,2} nan nan nan HITS48{230,2} HITS48{229,2} nan nan nan HITS48{242,2} HITS48{241,2} nan nan nan HITS48{254,2} HITS48{253,2} nan nan nan HITS48{266,2} HITS48{265,2} nan nan nan HITS48{278,2} HITS48{277,2} nan nan];
        end
        
        ax33 = axes(handles.uipanel9);
        %     ax=axes(hObject);
        imagesc(layout4,'AlphaData',~isnan(layout4));
        set(gca,'visible','off');
        set(gca,'Colormap',[1 1 1]);
        if joost && multiwell1 == 1
            textstrings={...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '1'  '5' '9'  '13'  [] [] '97'  '101' '105' '109'  [] [] '193' '197' '201' '205' [] [] '289' '293' '297' '301' [] []...
                [] [] '2'  '6' '10' '14'  [] [] '98'  '102' '106' '110'  [] [] '194' '198' '202' '206' [] [] '290' '294' '298' '302' [] []...
                [] [] '3'  '7' '11' '15'  [] [] '99'  '103' '107' '111'  [] [] '195' '199' '203' '207' [] [] '291' '295' '299' '303' [] []...
                [] [] '4'  '8' '12' '16'  [] [] '100' '104' '108' '112'  [] [] '196' '200' '204' '208' [] [] '292' '296' '300' '304' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '17' '21' '25' '29' [] [] '113'  '117' '121' '125' [] [] '209' '213' '217' '221' [] [] '305' '309' '313' '317' [] []...
                [] [] '18' '22' '26' '30' [] [] '114'  '118' '122' '126' [] [] '210' '214' '218' '222' [] [] '306' '310' '314' '318' [] []...
                [] [] '19' '23' '27' '31' [] [] '115'  '119' '123' '127' [] [] '211' '215' '219' '223' [] [] '307' '311' '315' '319' [] []...
                [] [] '20' '24' '28' '32' [] [] '116'  '120' '124' '128' [] [] '212' '216' '220' '224' [] [] '308' '312' '316' '320' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '33' '37' '41' '45' [] [] '129'  '133' '137' '141' [] [] '225' '229' '233' '237' [] [] '321' '325' '329' '333' [] []...
                [] [] '34' '38' '42' '46' [] [] '130'  '134' '138' '142' [] [] '226' '230' '234' '238' [] [] '322' '326' '330' '334' [] []...
                [] [] '35' '39' '43' '47' [] [] '131'  '135' '139' '143' [] [] '227' '231' '235' '239' [] [] '323' '327' '331' '335' [] []...
                [] [] '36' '40' '44' '48' [] [] '132'  '136' '140' '144' [] [] '228' '232' '236' '240' [] [] '324' '328' '332' '336' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '49' '53' '57' '61' [] [] '145' '149' '153' '157'  [] [] '241' '245' '249' '253' [] [] '337' '341' '345' '349' [] []...
                [] [] '50' '54' '58' '62' [] [] '146' '150' '154' '158'  [] [] '242' '246' '250' '254' [] [] '338' '342' '346' '350' [] []...
                [] [] '51' '55' '59' '63' [] [] '147' '151' '155' '159'  [] [] '243' '247' '251' '255' [] [] '339' '343' '347' '351' [] []...
                [] [] '52' '56' '60' '64' [] [] '148' '152' '156' '160'  [] [] '244' '248' '252' '256' [] [] '340' '344' '348' '352' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '65' '69' '73' '77' [] [] '161' '165' '169' '173'  [] [] '257' '261' '265' '269' [] [] '353' '357' '361' '365' [] []...
                [] [] '66' '70' '74' '78' [] [] '162' '166' '170' '174'  [] [] '258' '262' '266' '270' [] [] '354' '358' '362' '366' [] []...
                [] [] '67' '71' '75' '79' [] [] '163' '167' '171' '175'  [] [] '259' '263' '267' '271' [] [] '355' '359' '363' '367' [] []...
                [] [] '68' '72' '76' '80' [] [] '164' '168' '172' '176'  [] [] '260' '264' '268' '272' [] [] '356' '360' '364' '368' [] []...
                [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] '81' '85' '89' '93' [] [] '177' '181' '185' '189'  [] [] '273' '277' '281' '285' [] [] '369' '373' '377' '381' [] []...
                [] [] '82' '86' '90' '94' [] [] '178' '182' '186' '190'  [] [] '274' '278' '282' '286' [] [] '370' '374' '378' '382' [] []...
                [] [] '83' '87' '91' '95' [] [] '179' '183' '187' '191'  [] [] '275' '279' '283' '287' [] [] '371' '375' '379' '383' [] []...
                [] [] '84' '88' '92' '96' [] [] '180' '184' '188' '192'  [] [] '276' '280' '284' '288' [] [] '372' '376' '380' '384' [] []...
                [] [] [] [] []       []   [] [] [] [] []        []       [] [] []    [] []       []    [] [] [] [] []          [] [] []...
                [] [] [] [] []       []   [] [] []    [] []       []     [] [] []    [] []       []    [] [] [] [] []          [] [] []}';
            
            
            [x, y] = meshgrid(1:38);
            for i=31:-1:20
                x(i,:)=[];
                y(i,:)=[];
            end
        else
            textstrings={...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '3' '7' [] [] [] '75' '79' [] [] [] '147' '151' [] [] [] '219' '223' [] ...
                '1' '4' '8' '11' [] '73' '76' '80' '83' [] '145' '148' '152' '155' [] '217' '220' '224' '227' ...
                '2' '5' '9' '12' [] '74' '77' '81' '84' [] '146' '149' '153' '156' [] '218' '221' '225' '228' ...
                [] '6' '10' [] [] [] '78' '82' [] [] [] '150' '154' [] [] [] '222' '226' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '15' '19' [] [] [] '87' '91' [] [] [] '159' '163' [] [] [] '231' '235' [] ...
                '13' '16' '20' '23' [] '85' '88' '92' '95' [] '157' '160' '164' '167' [] '229' '232' '236' '239' ...
                '14' '17' '21' '24' [] '86' '89' '93' '96' [] '158' '161' '165' '168' [] '230' '233' '237' '240' ...
                [] '18' '22' [] [] [] '90' '94' [] [] [] '162' '166' [] [] [] '234' '238' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '27' '31' [] [] [] '99' '103' [] [] [] '171' '175' [] [] [] '243' '247' [] ...
                '25' '28' '32' '35' [] '97' '100' '104' '107' [] '169' '172' '176' '179' [] '241' '244' '248' '251' ...
                '26' '29' '33' '36' [] '98' '101' '105' '108' [] '170' '173' '177' '180' [] '242' '245' '249' '252' ...
                [] '30' '34' [] [] [] '102' '106' [] [] [] '174' '178' [] [] [] '246' '250' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '39' '43' [] [] [] '111' '115' [] [] [] '183' '187' [] [] [] '255' '259' [] ...
                '37' '40' '44' '47' [] '109' '112' '116' '119' [] '181' '184' '188' '191' [] '253' '256' '260' '263' ...
                '38' '41' '45' '48' [] '110' '113' '117' '120' [] '182' '185' '189' '192' [] '254' '257' '261' '264' ...
                [] '42' '46' [] [] [] '114' '118' [] [] [] '186' '190' [] [] [] '258' '262' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '51' '55' [] [] [] '123' '127' [] [] [] '195' '199' [] [] [] '267' '271' [] ...
                '49' '52' '56' '59' [] '121' '124' '128' '131' [] '193' '196' '200' '203' [] '265' '268' '272' '275' ...
                '50' '53' '57' '60' [] '122' '125' '129' '132' [] '194' '197' '201' '204' [] '266' '269' '273' '276' ...
                [] '54' '58' [] [] [] '126' '130' [] [] [] '198' '202' [] [] [] '270' '274' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []...
                [] '63' '67' [] [] [] '135' '139' [] [] [] '207' '211' [] [] [] '279' '283' [] ...
                '61' '64' '68' '71' [] '133' '136' '140' '143' [] '205' '208' '212' '215' [] '277' '280' '284' '287' ...
                '62' '65' '69' '72' [] '134' '137' '141' '144' [] '206' '209' '213' '216' [] '278' '281' '285' '288' ...
                [] '66' '70' [] [] [] '138' '142' [] [] [] '210' '214' [] [] [] '282' '286' [] ...
                [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []}';
            
            [x, y] = meshgrid(1:31);
            for i=31:-1:20
                x(i,:)=[];
                y(i,:)=[];
            end
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center','Fontsize',6);
        
        
        top60=cell2mat(supa1);
        if handles.pushbutton60.Value == 1
            top60(top60 < (mean(M,'all','omitnan') + thrconnec*std(M,1,'all','omitnan'))) = 0; % new
        end
        top60(isnan(top60)) =0; %% new added for joost's method
        
        [B,I]=sort(top60,'descend');   % order them
        ghg=find(B == 0); %remove all the zeros
        I(ghg)=[];
        
        %each 120 elements belong to one channel
        %firsst column will be the origin of the line
        %2nd column will be the destination of the line
        I(:,2)=ceil(I(:)/electrodecount); % there are 12 electrodes per well ( this will give us the correct well number
        I(:,3)= electrodecount-((I(:,2)*electrodecount)-I(:,1)); % this will give us the correct channel number
        I(:,3) =  I(:,3) .* ceil(I(:,2)/electrodecount);
        I(I<1) = 1;
        ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
        removeindx = find(cell2mat(HITS(:,2)) <= 10);
        
        I(ismember(I(:,2),removeindx)) =0;
        I(ismember(I(:,2),removeindx),3) =0;
        I(ismember(I(:,2),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),1) =0;
        I(ismember(I(:,3),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),3) =0;
        
        for i = length(I):-1:1
            if I(i,1) == 0
                I(i,:) = [];
            end
        end
        %also delete connections that do not involve the channel of interest
        correctindex = find(I(:,2) == Ghibli(2));
        correctindex2 = find(I(:,3) == Ghibli(2));
        indexfull = [correctindex;correctindex2]; % this contains the indeices that have connections with the channel of interest
        
        for i = length(I):-1:1
            if I(i,2) == Ghibli(2) || I(i,3) == Ghibli(2)
            else
                I(i,:) = [];
            end
        end
        
        
        
        looop2 = 0;
        
        for i=1:size(I,1)
            looop2 = looop2+1;
            yutr=I(i,2);
            
            %         kk=ag(ag==yutr); % added for joosts method
            lll=find(layout4 == HITS48{yutr,2});
            [r,c] = ind2sub(size(layout4),lll);
            
            k=I(i,3);
            llll=find(layout4 == HITS48{k,2});
            [rr,cc] = ind2sub(size(layout4),llll);
            hold on
            if arrowss == 1
                nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
            elseif arrowss == 0
                nnn=line([c cc],[r rr],'Color','r');
            end
            drawnow;
            colmin=0;
            %         colmin=min(B(:));
            colmax=max(B(:));
            COLOR1=parula(length(B));
            goodcolor=COLOR1(round(length(B)*(B(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
            nnn.Color=goodcolor;
            cbn=colorbar;
            cbn.Colormap=parula(length(B));
            cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        end
        
    end
    
    
    clear supa1 supa
    
    
    text83_ButtonDownFcn(handles.text83,eventdata,handles)
    handles.text83.Visible = 'on';
    set(handles.Pannel_11.Text,'String',strjoin(['The Connectivity Map for Channel', jitters{2}]));
end
clear noconnections
end

% --- Executes during object creation, after setting all properties.
function pushbutton41_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.Position = [0.5772 0.0143 0.0851 0.0238];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.FontWeight = 'bold';
hObject.String = 'Select Channel';
hObject.CData = imread('color_button.png');
end

%Buttons

% --- Save figure
function pushbutton65_Callback(hObject, eventdata, handles)

startingFolder = userpath;
defaultFileName = fullfile(startingFolder, '*.*');
[baseFileName, folder] = uiputfile(defaultFileName, 'Specify a name');
if baseFileName == 0
    return;
else
    f=figure('visible','off');
    copyobj(handles.uipanel7.Children(2), f);
    print(f,baseFileName,'-dtiff','-r1200')
    extension1 = '.tif';
    movefile(strcat(baseFileName,extension1),folder,'f');
    close(f);
end

end

% --- Executes during object creation, after setting all properties.
function pushbutton65_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Export Figure';
hObject.Position = [0.7045 0.513 0.111 0.027];
hObject.FontWeight = 'bold';
end

% --- Save figure
function pushbutton66_Callback(hObject, eventdata, handles)
startingFolder = userpath;
defaultFileName = fullfile(startingFolder, '*.*');
[baseFileName, folder] = uiputfile(defaultFileName, 'Specify a name');
if baseFileName == 0
    return;
else
    f=figure('visible','off');
    copyobj(handles.uipanel6.Children(2), f);
    print(f,baseFileName,'-dtiff','-r1200')
    extension1 = '.tif';
    movefile(strcat(baseFileName,extension1),folder);
    close(f);
end
end

% --- Executes during object creation, after setting all properties.
function pushbutton66_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Export Figure';
hObject.Position = [0.296 0.513 0.111 0.027];
hObject.FontWeight = 'bold';
end

% --- Visualize the cross correlation
function pushbutton12_Callback(hObject, eventdata, handles)
global Imax HITS yup finalssss supa



prompt = {'Which channel do you want to cross correlate with the other channels?'};
title1 = 'Cross Correlation';
dims = [1 75];
definput = {'A8'};
yup = inputdlg(prompt,title1,dims,definput);
Imax=find(strncmpi(HITS,yup,3));

figure('units','normalized','outerposition',[0 0 1 1]);
%stem3(xaxiss,1:120,finalssss);

%
% resolution = 0.1; %binsize of 100 ms
% sigma = 0.1 ; %100 ms STD of gaussian
% % Use hist to bin
% EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
% N = histc(xpoints, EDGES);
% %         N = N ./timesss; %normalize for total duration to get firing rate
% %Time ranges form -3*st. dev. to 3*st. dev.
% edges = (-3*sigma:resolution:3*sigma);
% %Evaluate the Gaussian kernel
% kernel = normpdf(edges,0,sigma);
% %Multiply by bin width so the probabilities sum to 1?
% kernel = kernel.*resolution;
% %Convolve spike data with the kernel
% s = conv(N,kernel);
% s=s/resolution;
% %Find the index of the kernel center
% center = ceil(length(edges)/2);
% %         %Trim out the relevant portion of the spike density
% s = s(center:end-center-1);
% t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
%
%
%

%
% for i = 1:size(supa{Imax},1)
%     hold on
%     plot(supa{Imax}(i,:));
% end
%
%




b=bar3(supa{Imax});
xlabel('Time in milliseconds')
zlabel('Xcrosscorrrelation(%)')
ylabel('Channels')
set(gca,'Xticklabel',[-100:50:150]);
title(['Xcrosscorrelation between all the channels vs channel ', HITS{Imax}]);

for k = 1:length(b)  %change the color to match the heights of the bars
    zdata = b(k).ZData;
    b(k).CData = zdata;
    b(k).FaceColor = 'interp';
end
set(gcf,'color','white')
end

% --- Executes during object creation, after setting all properties.
function pushbutton12_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.Position = [0.861 0.333 0.096 0.048];
hObject.BackgroundColor = [.97,.98,.98];
hObject.CData = imread('color_button.png');
hObject.String = 'Cross Correlation';
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.FontWeight = 'bold';
end

% --- Change threshold connectivity matrix
function pushbutton60_Callback(hObject, eventdata, handles)
global thrconnec indx23


prompt = {'Threshold Value for the connectivity matrix'};
dlgtitle = 'Connectivity Matrix Threshold';
if indx23 == 1
    definput = {'1'};
elseif indx23 == 2
    definput = {'0.7'};
end
opts.Interpreter = 'tex';
answer = inputdlg(prompt,dlgtitle,[1 55],definput,opts);

if thrconnec ~= str2double(answer)
    thrconnec = str2double(answer);
else
    if indx23 == 1
        thrconnec = 1;
    elseif indx23 == 2
        thrconnec = 0.7;
    end
end

end

% --- Executes during object creation, after setting all properties.
function pushbutton60_CreateFcn(hObject, eventdata, handles)
global thrconnec indx23
hObject.Visible = 'off';
hObject.Position = [0.861 0.755 0.096 0.048];
hObject.String = 'Threshold';
hObject.CData = imread('color_button.png');
hObject.FontWeight = 'bold';
hObject.ForegroundColor = [0.992 0.89 0.655];

if indx23 == 1
    thrconnec = 1;
elseif indx23 == 2
    thrconnec = 0.7;
end

end

% --- save button for connections
function pushbutton61_Callback(hObject, eventdata, handles)
global Connections looo12

if hObject.Value == 1
    Connections = looo12;
end

end

% --- Executes during object creation, after setting all properties.
function pushbutton61_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.BackgroundColor = [.97,.98,.98];
hObject.String = 'Save';
hObject.Position = [0.861 0.678 0.096 0.048];
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.FontWeight = 'bold';
hObject.CData = imread('color_button.png');
end

% --- Checkbox for arrows or lines
function checkbox2_Callback(hObject, eventdata, handles)
global arrowss

if hObject.Value == 1
    arrowss = 1;
elseif hObject.Value == 0
    arrowss = 0;
end

end

% --- Executes during object creation, after setting all properties.
function checkbox2_CreateFcn(hObject, eventdata, handles)
global arrowss
arrowss = 0;

hObject.BackgroundColor = [.97,.98,.98];
set(hObject,'Visible', 'off');
hObject.String = 'Display Direction';
hObject.Position = [0.878 0.608 0.059 0.028];
end

% --- checkbox for displaying only the top 200 connections
function checkbox3_Callback(hObject, eventdata, handles)
global only200
if hObject.Value == 1
    only200 = 1;
elseif hObject.Value == 0
    only200 = 0;
end

end

% --- Executes during object creation, after setting all properties.
function checkbox3_CreateFcn(hObject, eventdata, handles)
global only200

only200 = 0;
set(hObject,'Visible', 'off');
hObject.String = 'Display Max 200';
hObject.BackgroundColor = [0.97 0.98 0.98];
hObject.Position = [0.878 0.544 0.059 0.048];
end

% --- ESelect the method of visualization
function pushbutton38_Callback(hObject, eventdata, handles)
global indx23 thrconnec
% add cross correlation
% list = {'Conditional firing probabilities'};
% [indx23,~] = listdlg('PromptString','Select a Method','SelectionMode','single','ListString',list);
indx23 = 1; %CFP

if indx23 == 1
    thrconnec = 1;
elseif indx23 == 2
    thrconnec = 0.7;
end


hObject.Visible = 'off';
handles.pushbutton39.Visible = 'on' ;
handles.pushbutton41.Visible = 'on' ;
handles.checkbox2.Visible = 'on';
handles.pushbutton60.Visible ='off';
handles.pushbutton61.Visible = 'off';
handles.checkbox3.Visible = 'on';
handles.pushbutton12.Visible ='off';
handles.pushbutton62.Visible ='on';
handles.pushbutton63.Visible ='on';
handles.pushbutton65.Visible ='on';
handles.pushbutton66.Visible ='on';
% handles.pushbutton67.Visible ='on';
% handles.pushbutton68.Visible ='on';
end

% --- Executes during object creation, after setting all properties.
function pushbutton38_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off' ;
hObject.Position = [0.8610 0.8320 0.0960 0.0480];
hObject.String = 'Load';
end

%Text

% --- Executes during object creation, after setting all properties.
function text82_CreateFcn(hObject, eventdata, handles)
hObject.String = {};
hObject.Visible = 'off' ;
hObject.Position = [0.0100 0.0133 0.1573 0.0200];
hObject.BackgroundColor = [0.9800 0.9800 0.9700];
end

function text82_ButtonDownFcn(hObject, eventdata, handles)
global looop PorcoRosso jitters
PorcoRosso=[];
PorcoRosso =(['Connections for Channel: ',jitters{1},'is', num2str(looop)]);
PorcoRosso = strjoin(PorcoRosso);
set(hObject, 'String', PorcoRosso);

end

function text84_ButtonDownFcn(hObject, eventdata, handles)
global looo12 PorcoRosso

PorcoRosso=[];
PorcoRosso =(['Amount of Connections for all Channels is ',num2str(looo12)]);
set(hObject, 'String', PorcoRosso);
end

% --- Executes during object creation, after setting all properties.
function text84_CreateFcn(hObject, eventdata, handles)
hObject.String = {};
hObject.Visible = 'off' ;
hObject.Position = [0.12 0.5152 0.148 0.02];
hObject.BackgroundColor = [0.9800 0.9800 0.9700];
end

% --- Executes during object creation, after setting all properties.
function text83_CreateFcn(hObject, eventdata, handles)
hObject.String = {};
hObject.Visible = 'off' ;
hObject.Position = [0.4180 0.0152 0.1573 0.0200];
hObject.BackgroundColor = [0.9800 0.9800 0.9700];
end

function text83_ButtonDownFcn(hObject, eventdata, handles)
global looop2 PorcoRosso jitters
PorcoRosso=[];
PorcoRosso =(['Connections for Channel: ',jitters{2},'is', num2str(looop2)]);
PorcoRosso = strjoin(PorcoRosso);
set(hObject, 'String', PorcoRosso);
end
%% Single and Network Bursts Panel 

% --- panel to rerun burst detection
function uipanel20_CreateFcn(hObject, eventdata, handles)
global maxinterval cbox1 cbox2 logISI fs parts electrodecount text1 xpoints multiwell1 text2 networkbursttttold networkburstttt timesss text3 text4 text5 text6 text7 text8 text9 text10 push1 push2 push3 push4 push5 edit1 edit2 edit3 edit4 edit5 edit6 edit7 edit8 edit9 edit10 M2 Totoro ISI58 Exburst burst6 burst7 maxinterval1 logisi1 logburst burst6old burst7old Exburstold logburstold pushed pushed1 Imax ...
    table2 table3 Table680 Table139 Table679 HITS X2 overlap overlapp filteredData1 dx INDEX2 selecteddata cbox101

hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Title = {};
hObject.Position=[.009 .009 .806 .224];

% Create a check box to display max interval method
cbox1 = uicontrol(hObject,'Style','checkbox','Position',[10 167 200 25],...
    'Callback',@(cbx,event) Chan(cbx));
cbox1.String = 'Max Interval Method';
cbox1.FontSize = 12;
cbox1.BackgroundColor = [1 1 1];

% Create a check box to display log isi method
cbox2 = uicontrol(hObject,'Style','checkbox','Position',[10 107 200 25],...
    'Callback',@(cbx,event) Chan2(cbx));
cbox2.String = 'Log ISI Method';
cbox2.FontSize = 12;
cbox2.BackgroundColor = [1 1 1];

% Create a check box to basing the nb detection on the overlapping bursts
cbox101 = uicontrol(hObject,'Style','checkbox','Position',[10 47 200 25],...
    'Callback',@(cbx,event) Chan3(cbx));
cbox101.String = 'Overlapping SCBs';
cbox101.FontSize = 12;
cbox101.BackgroundColor = [1 1 1];
cbox101.Visible = 'off';

%% max interval buttons
% Create a edit box to start interval
edit1 = uicontrol(hObject,'Style','edit','Position',[250 187 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.start),'Callback',@(cbx,event) editChan(cbx));
edit1.FontSize = 12;
edit1.BackgroundColor = [1 1 1];

text1 = uicontrol(hObject,'Style','text','Position',[250 207 50 19],...
    'Enable','on','String','Start','Tooltip','Burst Start Interval (s)');
text1.FontSize = 12;
text1.BackgroundColor = [1 1 1];


% Create a edit box to n spikes max
edit2 = uicontrol(hObject,'Style','edit','Position',[250 127 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.nspikes),'Callback',@(cbx,event) editChan(cbx));
edit2.FontSize = 12;
edit2.BackgroundColor = [1 1 1];

text2 = uicontrol(hObject,'Style','text','Position',[250 147 50 19],...
    'Enable','on','String','Spikes','Tooltip','Number of spikes (n)');
text2.FontSize = 12;
text2.BackgroundColor = [1 1 1];


% Create a edit box to IBI duration
edit3 = uicontrol(hObject,'Style','edit','Position',[350 187 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.IBI),'Callback',@(cbx,event) editChan(cbx));
edit3.FontSize = 12;
edit3.BackgroundColor = [1 1 1];

text3 = uicontrol(hObject,'Style','text','Position',[350 207 50 19],...
    'Enable','on','String','Inter','Tooltip','Inter Burst Interval (s)');
text3.FontSize = 12;
text3.BackgroundColor = [1 1 1];


% Create a edit box to intraburst interval
edit4 = uicontrol(hObject,'Style','edit','Position',[350 127 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.intraBI),'Callback',@(cbx,event) editChan(cbx));
edit4.FontSize = 12;
edit4.BackgroundColor = [1 1 1];

text4 = uicontrol(hObject,'Style','text','Position',[350 147 50 19],...
    'Enable','on','String','Intra','Tooltip','Intra Burst Interval (s)');
text4.FontSize = 12;
text4.BackgroundColor = [1 1 1];



% Create a edit box to minimum duration
edit5 = uicontrol(hObject,'Style','edit','Position',[450 157 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.mindur),'Callback',@(cbx,event) editChan(cbx));
edit5.FontSize = 12;
edit5.BackgroundColor = [1 1 1];

text5 = uicontrol(hObject,'Style','text','Position',[450 177 70 19],...
    'Enable','on','String','Duration','Tooltip','Minimum Burst Duration (s)');
text5.FontSize = 12;
text5.BackgroundColor = [1 1 1];

%% logISI buttons

% Create a edit box to nspikes logisi
edit6 = uicontrol(hObject,'Style','edit','Position',[250 67 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionlogisi.nspikes),'Callback',@(cbx,event) editChan(cbx));
edit6.FontSize = 12;
edit6.BackgroundColor = [1 1 1];

text6 = uicontrol(hObject,'Style','text','Position',[250 87 50 19],...
    'Enable','on','String','Spikes','Tooltip','Number of spikes (n)');
text6.FontSize = 12;
text6.BackgroundColor = [1 1 1];


% Create a edit box to void
edit7 = uicontrol(hObject,'Style','edit','Position',[250 7 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionlogisi.void),'Callback',@(cbx,event) editChan(cbx));
edit7.FontSize = 12;
edit7.BackgroundColor = [1 1 1];

text7 = uicontrol(hObject,'Style','text','Position',[250 27 50 19],...
    'Enable','on','String','Void','Tooltip','Void Threshold');
text7.FontSize = 12;
text7.BackgroundColor = [1 1 1];

%% Rerun buttons

% Create a pushbutton for rerun
push1 = uicontrol(hObject,'Style','pushbutton','Position',[700 27 200 19],...
    'Visible','off','String','Burst Detection','Callback',@(cbx,event) rerun(cbx));
push1.FontSize = 12;
push1.BackgroundColor = [1 1 1];

%revert back to default settings
push2 = uicontrol(hObject,'Style','pushbutton','Position',[1100 27 200 19],...
    'Visible','off','String','Revert to Default','Callback',@(cbx,event) revertback(cbx));
push2.FontSize = 12;
push2.BackgroundColor = [1 1 1];

%select channel
push3 = uicontrol(hObject,'Style','pushbutton','Position',[700 57 200 19],...
    'Visible','off','String','Select Channel','Callback',@(cbx,event) selectch(cbx));
push3.FontSize = 12;
push3.BackgroundColor = [1 1 1];


%statistics
push4 = uicontrol(hObject,'Style','pushbutton','Position',[1100 57 200 19],...
    'Visible','off','String','Statistics','Callback',@(cbx,event) stats1(cbx));
push4.FontSize = 12;
push4.BackgroundColor = [1 1 1];

push5 = uicontrol(hObject,'Style','pushbutton','Position',[700 27 200 19],...
    'Visible','off','String','Network Burst Detection','Callback',@(cbx,event) rerunnnbursts(cbx));
push5.FontSize = 12;
push5.BackgroundColor = [1 1 1];

%% rerun network burst buttons

edit8 = uicontrol(hObject,'Style','edit','Position',[250 7 50 15],...
    'Enable','off','String',mat2str(  fs.networkburstdetection.synchronizedtimewindow),'Callback',@(cbx,event) editChan(cbx));
edit8.FontSize = 12;
edit8.BackgroundColor = [1 1 1];

text8 = uicontrol(hObject,'Style','text','Position',[250 27 50 19],...
    'Enable','on','String','Time window','Tooltip','Time window for synchronized bursts (s)');
text8.FontSize = 12;
text8.BackgroundColor = [1 1 1];

edit9 = uicontrol(hObject,'Style','edit','Position',[350 7 50 15],...
    'Enable','off','String',mat2str( fs.networkburstdetection.minimumsynchronizedburstcount),'Callback',@(cbx,event) editChan(cbx));
edit9.FontSize = 12;
edit9.BackgroundColor = [1 1 1];
text9 = uicontrol(hObject,'Style','text','Position',[350 27 50 19],...
    'Enable','on','String','Synchronized bursts','Tooltip','Minimum synchronzied burst amount (n)');
text9.FontSize = 12;
text9.BackgroundColor = [1 1 1];

edit10 = uicontrol(hObject,'Style','edit','Position',[450 7 50 15],...
    'Enable','off','String',mat2str( fs.networkburstdetection.minimumchannelparticipation),'Callback',@(cbx,event) editChan(cbx));
edit10.FontSize = 12;
edit10.BackgroundColor = [1 1 1];

text10 = uicontrol(hObject,'Style','text','Position',[450 27 50 19],...
    'Enable','on','String','Channels','Tooltip','Minimum amount of channels participating (%)');
text10.FontSize = 12;
text10.BackgroundColor = [1 1 1];

    function rerun(source,handles,eventdata)
        %% max interval method
        if maxinterval == 1
            %we have to get the ISI first
            test2=cell(1,length(M2));
            for i=1:length(M2)
                test=diff(M2{i,1});
                test2{i}=test;
            end
            test2=test2'; %contain the ISI all of the channels
            
            for i =1:length(test2)
                test2{i}(2,:)=1:length(test2{i});    %add the index of the ISI in each cell
            end
            
            % remove any cell that has less than 3 spikes
            
            for i=1:length(test2)
                if size(test2{i},2) < 3
                    test2{i}=[];
                end
            end
            %first part would be to detect the start of the bursts
            
            %maximum start of the burst is 170 ms between the first two spikes of a
            %burst
            hh = waitbar(0,'Recalculating the bursts according to the max interval method');
            
            burst6=cell(1,length(M2));
            for ii=1:length(M2)
                waitbar(ii/length(M2))
                if isempty(test2{ii})
                    burst6{ii} = [];
                else
                    idx = find(test2{ii}(1,:) < fs.burstdetectionmaxinterval.start);
                    maxbursts=round(length(test2{ii})/fs.burstdetectionmaxinterval.nspikes); %you have to have atleast 3 spikes per burst and therefore you have a max limit on the maount of bursts
                    
                    %check to see if the amount of bursts is normal if not remove it
                    
                    burst4=cell(1,length(idx));
                    for j=1:length(idx)
                        burst3=[];
                        for i=idx(j):length(test2{ii})
                            if test2{ii}(1,i) < fs.burstdetectionmaxinterval.IBI     %max ISI of interburstspikes is 300 ms
                                burst = test2{ii}(2,i);    %get the indices of the spikes so its easier to work it
                                burst3{i} = burst;
                            else
                                break;
                            end
                        end
                        
                        if isempty(burst3)
                        else
                            burst3 = vertcat(burst3{:});
                        end
                        burst4{j}=burst3;    %now we have our found our bursts that start with a ISI of 170 ms and have a ISI wihtin the bursts of max 300 ms
                    end
                    clear burst burst3
                    
                    for i=1:length(burst4)
                        if length(burst4{1,i}) < fs.burstdetectionmaxinterval.nspikes   %removed any burst that had less than 3 spikes
                            burst4{1,i}=[];
                        end
                    end
                    burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                    
                    %merging/removal of duplicates
                    
                    NewVector = cellfun(@(x) x(end), burst4); % get all the last number of each detected burst
                    
                    for i = 1:length(NewVector)
                        try
                            if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them (its based on the last number as in the duplicated bursts they are the same)
                                burst4{i+1} = [];
                            end
                        catch
                        end
                    end
                    
                    burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                    
                    %now we need to get the real spike times for the other parameters
                    %now we need to check if the time between the bursts is a minimal
                    %of 200 ms otherwise merge
                    
                    burst5={};
                    for i=1:length(burst4)-1
                        j=i+1;
                        if M2{ii,1}(burst4{1,j}(1,1))- M2{ii,1}(burst4{1,i}(end)) < fs.burstdetectionmaxinterval.intraBI   %if the distance between the last spike of the previous burst is not longer than 200 ms comapred to the first spike of the next bursts it will be merged into one bursts
                            burst5{i}=vertcat(burst4{1,i},burst4{1,j});
                        else
                            
                            burst5{i}=burst4{1,i};
                            burst5{j}=burst4{1,j};
                        end
                    end
                    
                    clear burst4
                    %last check is to see if the total duration of the bursts is atleast 10 ms
                    for i=1:length(burst5)
                        if M2{ii,1}(burst5{1,i}(end)) - M2{ii,1}(burst5{1,i}(1,1)) < fs.burstdetectionmaxinterval.mindur
                            burst5{1,i}=[];
                        end
                    end
                    burst5=burst5(~cellfun('isempty',burst5)); %sort the correct amount of bursts
                    burst6{ii}=burst5;
                end
            end
            close(hh)
            clear burst5 test2 idx test maxbursts messsage1
            burst6=burst6';  %these are the indices of the spikes
            %we have to convert them to their actual spike timings
            burst6indx= burst6;
            
            for i=1:length(M2)
                for j=1:length(burst6{i,1})
                    burst6{i,1}{1,j}=M2{i,1}(burst6{i,1}{1,j});  %now we have the correct spike timings!
                end
            end
            
            Exburst=cell(1,length(M2));
            for jj=1:length(M2)
                Exburst{jj}.number_of_bursts=1:length(burst6{jj,1});
                
                for i=1:length(burst6{jj,1})
                    Exburst{jj}.duration_of_bursts(i)=burst6{jj,1}{1,i}(end)-burst6{jj,1}{1,i}(1,1);
                end
                
                for i=1:length(burst6{jj,1})
                    Exburst{jj}.spikes_in_bursts(i)=length(burst6{jj,1}{1,i});
                end
            end
            Exburst=Exburst';   %contains data about the bursts for the table
            
            for i=1:length(M2)
                Exburst{i,1}.number_of_bursts=Exburst{i,1}.number_of_bursts'; %flip everything for the table
            end
            
            for i=1:length(M2)
                if sum(strcmp(fieldnames(Exburst{i,1}), 'spikes_in_bursts')) == 1
                    Exburst{i,1}.spikes_in_bursts=Exburst{i,1}.spikes_in_bursts'; %flip everything for the table
                end
            end
            
            for i=1:length(M2)
                if sum(strcmp(fieldnames(Exburst{i,1}), 'duration_of_bursts')) == 1
                    Exburst{i,1}.duration_of_bursts=Exburst{i,1}.duration_of_bursts'; %flip everything for the table
                end
            end
            
            clear mona
            
            %get the firing frequency (Hz) per burst per electrode
            
            fr_of_bursts = zeros(1,length(M2))';
            for i = 1:length(M2)
                if isempty(Exburst{i}.number_of_bursts)
                    Exburst{i}.fr_of_bursts = [];
                else
                    for j = 1:length(Exburst{i}.spikes_in_bursts)
                        Exburst{i}.fr_of_bursts(j) = Exburst{i}.spikes_in_bursts(j)/ Exburst{i}.duration_of_bursts(j);
                        Exburst{i}.fr_of_bursts = Exburst{i}.fr_of_bursts';
                    end
                end
            end
            
            
            %get the mean ISI of the spikes inside of a burst
            %the timings are located in burst6 for max interval
            
            
            mISIbursts = cell(1,length(M2));
            for i=1:length(M2)
                if isempty(Exburst{i}.number_of_bursts)
                    mISIbursts{i} = 0;
                else
                    mISIbursts{i} = cellfun(@diff,burst6{i},'UniformOutput',0);
                end
                
            end
            
            
            mISIbursts=cell(1,length(burst6))'; %contains the average ISI of the bursts in each electrode
            for i=1:length(M2)
                mISIbursts{i}=zeros(1,length(burst6{i}));
                if isempty(Exburst{i}.number_of_bursts)
                    mISIbursts{i} = 0;
                else
                    for j = 1:length(burst6{i})
                        mISIbursts{i}(j) = mean(diff(cell2mat(burst6{i}(j))));
                        Exburst{i}.mean_ISI_bursts = mISIbursts{i}';
                    end
                end
            end
            
            clear mISIbursts
            
            stdISIbursts=cell(1,length(burst6))'; %contains the std of the ISI of  bursts in each electrode
            for i=1:length(M2)
                stdISIbursts{i}=zeros(1,length(burst6{i}));
                if isempty(Exburst{i}.number_of_bursts)
                    stdISIbursts{i} = 0;
                else
                    for j = 1:length(burst6{i})
                        stdISIbursts{i}(j) = std(diff(cell2mat(burst6{i}(j))));
                        Exburst{i}.std_ISI_bursts = stdISIbursts{i}';
                    end
                end
            end
            
            clear stdISIbursts
            
            %calculate the IBI
            
            IBI2=[];
            for i =1:length(burst6)
                if isempty(burst6{i})
                    continue
                else
                    for j =1:length(burst6{i})-1
                        IBI = burst6{i}{j+1}(1) - burst6{i}{j}(end);
                        IBI2=[IBI2,IBI];
                    end
                end
                Exburst{i}.IBI = IBI2';  %this contains all the IBI's per electrode
                IBI2 =[];
            end
            
            
            % create a conditional to produce a error if burst6 and burst6indx
            % are not the same
            
            assert( length(find(~cellfun(@isempty,burst6))) == length(find(~cellfun(@isempty,burst6indx))));
            clear i j jj IBI2 ii fr_of_bursts burst6indx IBI
            maxinterval1 = 1;
            if isempty(Exburst{INDEX2}.number_of_bursts)
                push4.Visible = 'on';
                push4.Enable = 'off';
            else
                push4.Enable = 'on';
            end
            %     msgbox('Max Interval Burst Detection Finished')
            
            
            % saving the newly found bursts
            save(selecteddata,'Exburst','burst6','','-append');
        elseif logISI == 1
            %% log ISI method
            %first thing we need to do is make the log ISI histograms
            logisi1 = 1;
            
            
            logISI_hist = cell(1,length(M2));
            binsss= cell(1,length(M2));
            for i = 1:length(ISI58)
                if isempty(ISI58{i})
                    logISI_hist{i} = [];
                    continue
                else
                    maxWin = ceil(log10(max(ISI58{i})));
                    binss = logspace(0,maxWin,maxWin*10);           % equally spaced logarithmic bins using logspace
                    ISIlog_hist = histc(ISI58{i},binss);                     % this is the actual log ISI histogram
                    ISIlog_hist_area = sum(ISIlog_hist);
                    ISIlog_hist_norm = ISIlog_hist./ISIlog_hist_area;    % normalization
                    ISIlog_hist_norm = ISIlog_hist_norm(:);
                    binss = binss(:);
                end
                logISI_hist{i} = ISIlog_hist_norm;
                binsss{i} = binss ;
            end
            clear binss ISIlog_hist_norm  ISIlog_hist maxWin
            logISI_hist = logISI_hist';
            binsss = binsss';  % remember this is in ms!
            
            
            %smooth the log ISI histograms
            smoothed_logISI = cell(1,length(M2));
            for i = 1:length(ISI58)
                if isempty(logISI_hist{i})
                    smoothed_logISI{i} = [];
                    continue
                else
                    smoothed_logISI{i} = smooth(logISI_hist{i},5,'lowess') ;   % smooth the logISI histograms
                end
            end
            smoothed_logISI = smoothed_logISI';
            
            %now we need to find the peaks in the smoothed ISI log
            %histograms throw away channels that do not have a peak before
            %100 ms
            
            
            intraburstpeaks = cell(1,length(M2));
            logISIpeaks = cell(1,length(M2));
            logISIlocs = cell(1,length(M2));
            
            for i =1:length(ISI58)
                if isempty(smoothed_logISI{i})
                    intraburstpeaks{i} =[];
                    continue
                else
                    [peaks,locs] = findpeaks(smoothed_logISI{i},'minpeakdistance',2); %2 points from 'A self-adapting approach for the detection of burstsand network bursts in neuronal cultures'
                end
                
                temp1 = binsss{i}(locs);
                %now we need to check if there is peak before 100 ms
                if numel(peaks) == 1
                    intraburstpeaks{i} = [];
                elseif numel(find(temp1 < 100)) > 1 %if we have more than 1 peak then take the biggest value
                    [~,I] = max(peaks(find(temp1 < 100)));
                    intraburstpeaks{i} =  temp1(I);
                    %                 elseif find(temp1 < 100) == 1   %there is one peak before 100 ms
                    %                     intraburstpeaks{i} = temp1(find(temp1 < 100));
                elseif numel(find(temp1 < 100)) == 1
                    [~,I] = find(temp1 < 100);
                    intraburstpeaks{i} =  temp1(I);
                    
                else % no peaks before 100 ms so we discontinue the burst analysis
                    intraburstpeaks{i} = [];
                end
                
                if isempty(intraburstpeaks{i})
                    logISIlocs{i} = [];
                    logISIpeaks{i} =[];
                else
                    logISIpeaks{i} = peaks;
                    logISIlocs{i} = binsss{i}(locs);
                end
            end
            intraburstpeaks = intraburstpeaks'; % this cell contains all the intraburst peaks in ms!
            logISIpeaks =  logISIpeaks'; %y coordinates of the peaks in counts
            logISIlocs = logISIlocs'; %x coordinates of the peaks in ms
            clear locs peaks temp1 I
            
            %Now we need to find the correct interburst interval using the void parameter if that
            %fails than we set it at 100 ms
            % We do this by comparing the first peak or the intraburst peak with the
            % subsequent peaks
            
            
            interburstlogISI = cell(1,length(M2));
            
            for i = 1:length(ISI58)
                if isempty(logISIlocs{i})
                    interburstlogISI{i} = [];
                    continue
                else
                    %lets find the min value between each peak pair
                    % we can find the index in the locs cells
                    maxiterations = numel(logISIlocs{i});
                    index_intraburst = find(logISIlocs{i} == intraburstpeaks{i});
                    for j = (index_intraburst+1):length(logISIlocs{i})
                        
                        temp1 = min(smoothed_logISI{i}(find(smoothed_logISI{i} == logISIpeaks{i}(index_intraburst)):find(smoothed_logISI{i} == logISIpeaks{i}(j))));
                        %calculate how well the peaks are seperated
                        void =  1 - (temp1 / sqrt(logISIpeaks{i}(index_intraburst) * logISIpeaks{i}(j)));
                        if void > fs.burstdetectionlogisi.void
                            if temp1 == 0 %if the lowest number is equal to zero
                                temp2 = find(smoothed_logISI{i} == 0,find(find(smoothed_logISI{i} == 0) > find(smoothed_logISI{i} == logISIpeaks{i}(index_intraburst),1),1)) ;
                                temp2 = temp2(end);
                                interburstlogISI{i} = binsss{i}(temp2);
                            else
                                interburstlogISI{i} = binsss{i}(find(smoothed_logISI{i} == temp1,1)); %this is in ms
                                break
                            end
                        else
                            interburstlogISI{i} = 100; %if the method cant find any peaks that are well seperated it will be put at 100 ms
                        end
                    end
                end
            end
            interburstlogISI =interburstlogISI';   %this contains all the interburst intervals in ms
            
            %combine both numbers in one cell
            
            ISIthh = cell(2,length(M2))';
            
            for i =1:length(ISI58)
                
                ISIthh{i,1} = interburstlogISI{i}/1000; %convert in seconds
                ISIthh{i,2} = intraburstpeaks{i}/1000;  %convert in seconds
                
            end
            
            % add a extra criteria because getting values of above 1s for
            % interburst intervals is too high
            
            
            for i = 1:length(ISI58)
                if isempty(ISIthh)
                    continue
                else
                    if ISIthh{i,1} > 1
                        ISIthh{i,1} = 0.1;
                    end
                end
            end
            
            
            
            %Added an extra control to esnure that both the intraburst
            %ISI's and interburst ISI are complete
            
            
            for i = 1:length(ISI58)
                if isempty(ISIthh{i,1})
                    if isempty(ISIthh{i,2})
                    else
                        ISIthh{i,1} = 0.1;
                    end
                else
                end
            end
            
            %the first column of ISIthh contains the interburst ISI thresholds and the
            %2nd column contains the intrasburst ISI thresholds (everything is in
            %seconds
            
            test2=cell(1,length(M2));
            for i=1:length(M2)
                test=diff(M2{i,1});
                test2{i}=test;
            end
            test2=test2'; %contain the ISI all of the channels % in seconds
            
            
            
            %first part would be to detect the start of the bursts
            
            %maximum start of the burst is the isi of the first peak found before
            %the found intraburst peak
            hh = waitbar(0,'Recalculating the bursts according to the log ISI method');
            burst7=cell(1,length(M2));
            for ii=1:length(ISI58)
                waitbar(ii/length(M2))
                if isempty(M2{ii}) || length(M2{ii}) < 3
                    burst7{ii}={};
                elseif isempty(ISIthh{ii,2})
                    burst7{ii}={};
                else
                    test=test2{ii,1};
                    test(2,:)=1:length(test);
                    
                    idx = find(test(1,:) < ISIthh{ii,2}(1));   % here we find the indexes of potential burst cores
                    length(idx);
                    
                    maxbursts=round(length(test)/3); %you have to have atleast 3 spikes per burst and therefore you have a max limit on the maount of bursts
                    
                    %check to see if the amount of bursts is normal if not remove it
                    
                    burst4={};
                    for j=1:length(idx)
                        burst3=[];
                        for i=idx(j):length(test(1,:))
                            if test(1,i) < ISIthh{ii,1}    %max ISI of interburstspikes is the found interburst interval with the void parameter if not than it is set at 100 ms
                                burst = test(2,i);    %get the indices of the spike so its easier to work it
                                burst3{i} = burst;
                                %         burst3{i}=burst;
                            else
                                break;
                            end
                        end
                        if isempty(burst3)
                        else
                            burst3 = vertcat(burst3{:});
                        end
                        burst4{j}=burst3;    %now we have our found our bursts with a max intraburst ISI of the first peak of the logISI
                        
                    end
                    clear burst burst3
                    
                    for i=1:length(burst4)
                        if length(burst4{1,i}) < fs.burstdetectionlogisi.nspikes   %removed any burst that had less than 3 spikes
                            burst4{1,i}=[];
                        else
                            
                        end
                    end
                    
                    burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                    
                    %merging/removal of duplicates
                    
                    
                    NewVector = cellfun(@(x) x(end), burst4); % get all the last number of each detected burst
                    
                    
                    for i = 1:length(NewVector)
                        try
                            if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them ( its based on the last number as in the duplicated bursts they are the same)
                                burst4{i+1} = [];
                            else
                                
                            end
                        catch
                        end
                    end
                    
                    burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                    
                    %now we need to check if the time between the found bursts is
                    %not below the interbursts ISI thresholds if it is lower than
                    %we will merge them
                    
                    
                    burst5={};
                    
                    for i=1:length(burst4)-1
                        j=i+1;
                        if M2{ii,1}(burst4{1,j}(1,1))- M2{ii,1}(burst4{1,i}(end)) < ISIthh{ii,1}(1)   %if the distance between the last spike of the previous burst is not longer than the ISI threshold found of the interburst compared to the first spike of the next bursts it will be merged into one burst
                            burst5{i}=vertcat(burst4{1,i},burst4{1,j});
                        else
                            
                            burst5{i}=burst4{1,i};
                            burst5{j}=burst4{1,j};
                        end
                    end
                    
                    clear burst4
                    
                    
                    NewVector = cellfun(@(x) x(end), burst5); % get all the last number of each detected burst
                    
                    
                    for i = 1:length(NewVector)
                        try
                            if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them ( its based on the last number as in the duplicated bursts they are the same)
                                burst5{i+1} = [];
                            else
                                
                            end
                        catch
                        end
                    end
                    
                    burst5=burst5(~cellfun('isempty',burst5)); %remove any empty cell
                    %
                    burst7{ii}=burst5;
                end
                
            end
            close(hh)
            clear burst5 test2 idx test maxbursts ISIthh yy ii NewVector
            burst7=burst7'; %these contain the burst according to the log ISI method
            burst7indx=burst7;
            
            for i=1:length(M2)
                for j=1:length(burst7{i,1})
                    burst7{i,1}{1,j}=M2{i,1}(burst7{i,1}{1,j});  %now we have the correct spike timings!
                end
            end
            
            logburst=cell(1,length(M2));
            for jj=1:length(M2)
                logburst{jj}.number_of_bursts=1:length(burst7{jj,1});
                
                for i=1:length(burst7{jj,1})
                    logburst{jj}.duration_of_bursts(i)=burst7{jj,1}{1,i}(end)-burst7{jj,1}{1,i}(1,1);
                end
                
                
                for i=1:length(burst7{jj,1})
                    logburst{jj}.spikes_in_bursts(i)=length(burst7{jj,1}{1,i});
                end
            end
            logburst=logburst';   %contains data about the bursts for the table
            
            for i=1:length(M2)
                logburst{i,1}.number_of_bursts=logburst{i,1}.number_of_bursts'; %flip everything for the table
            end
            
            for i=1:length(M2)
                if sum(strcmp(fieldnames(logburst{i,1}), 'spikes_in_bursts')) == 1
                    logburst{i,1}.spikes_in_bursts=logburst{i,1}.spikes_in_bursts'; %flip everything for the table
                else
                end
            end
            
            for i=1:length(M2)
                if sum(strcmp(fieldnames(logburst{i,1}), 'duration_of_bursts')) == 1
                    logburst{i,1}.duration_of_bursts=logburst{i,1}.duration_of_bursts'; %flip everything for the table
                else
                end
            end
            
            
            %get the firing frequency (Hz) per burst per electrode
            
            fr_of_bursts = zeros(1,length(M2))';
            for i = 1:length(M2)
                if isempty(logburst{i}.number_of_bursts)
                    logburst{i}.fr_of_bursts = [];
                else
                    for j = 1:length(logburst{i}.spikes_in_bursts)
                        logburst{i}.fr_of_bursts(j) = logburst{i}.spikes_in_bursts(j)/ logburst{i}.duration_of_bursts(j);
                        logburst{i}.fr_of_bursts = logburst{i}.fr_of_bursts';
                    end
                end
            end
            
            
            %get the mean ISI of the spikes inside of a burst
            %the timings are located in burst6 for max interval
            
            
            mISIbursts = cell(1,length(M2));
            for i=1:length(M2)
                if isempty(logburst{i}.number_of_bursts)
                    mISIbursts{i} = 0;
                else
                    mISIbursts{i} = cellfun(@diff,burst7{i},'UniformOutput',0);
                    %         mISIbursts{i} = diff(burst7{i})
                end
                
            end
            
            
            mISIbursts=cell(1,length(burst7))'; %contains the average ISI of the bursts in each electrode
            for i=1:length(M2)
                mISIbursts{i}=zeros(1,length(burst7{i}));
                if isempty(logburst{i}.number_of_bursts)
                    mISIbursts{i} = 0;
                else
                    for j = 1:length(burst7{i})
                        mISIbursts{i}(j) = mean(diff(cell2mat(burst7{i}(j))));
                        logburst{i}.mean_ISI_bursts = mISIbursts{i}';
                    end
                end
            end
            
            clear mISIbursts
            
            stdISIbursts=cell(1,length(burst7))'; %contains the std of the ISI of  bursts in each electrode
            for i=1:length(M2)
                stdISIbursts{i}=zeros(1,length(burst7{i}));
                if isempty(logburst{i}.number_of_bursts)
                    stdISIbursts{i} = 0;
                else
                    for j = 1:length(burst7{i})
                        stdISIbursts{i}(j) = std(diff(cell2mat(burst7{i}(j))));
                        logburst{i}.std_ISI_bursts = stdISIbursts{i}';
                    end
                end
            end
            
            if isempty(logburst{INDEX2}.number_of_bursts)
                handles.pushbutton4.Enable = 'off';
                handles.pushbutton4.Visible = 'on';
            else
                handles.pushbutton4.Enable = 'on';
            end
            clear stdISIbursts binss ISIlog_hist_area j jj i maxiterations smoothed_logISI temp1 temp2 void logISIpeaks logISIlocs logISI_hist
            %     msgbox('Log ISI Burst Detection Finished')
            % saving the newly found bursts
            save(selecteddata,'burst7','logburst','-append')
            
        end
        
        
        
        
        
        
        
        
        push3.Visible = 'on';
        push4.Visible = 'on';
        
        %% plotting
        
        x=X2;
        y=filteredData1(INDEX2,:);
        
        if logISI == 1 && maxinterval == 0
            panel11 = findobj('Tag','uipanel11');
            axes(panel11(1));
            tt = subplot(2,1,1);
            %            tt =  handles.uipanel11.Children
            cla(tt)
            plot(tt,x,y);
            hold on
            channel963=filteredData1(INDEX2,:);
            hold on;
            title('Default log ISI Bursts Detected');
            xlabel('Time(s)')
            ylabel('Voltage(uV)')
            for i=1:length(burst7old{INDEX2,1})
                plot(X2(find(X2 == burst7old{INDEX2,1}{1,i}(1,1)): find(X2 == burst7old{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst7old{INDEX2,1}{1,i}(1,1)): find(X2 == burst7old{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold on
            end
            pp = subplot(2,1,2);
            cla(pp)
            plot(pp,x,y);
            hold on
            title('New log ISI Bursts Detected');
            xlabel('Time(s)')
            ylabel('Voltage(uV)')
            for i=1:length(burst7{INDEX2,1})
                plot(X2(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold on
            end
            linkaxes([pp tt],'xy');
            
        elseif maxinterval == 1 && logISI == 0
            panel11 = findobj('Tag','uipanel11');
            axes(panel11(1));
            tt = subplot(2,1,1);
            cla(tt)
            plot(tt,x,y);
            hold on
            channel963=filteredData1(INDEX2,:);
            hold on;
            title('Default Max Interval Bursts Detected');
            xlabel('Time(s)')
            ylabel('Voltage(uV)')
            
            for i=1:length(burst6old{INDEX2,1})
                plot(X2(find(X2 == burst6old{INDEX2,1}{1,i}(1,1)): find(X2 == burst6old{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst6old{INDEX2,1}{1,i}(1,1)): find(X2 == burst6old{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold on
            end
            
            pp = subplot(2,1,2);
            cla(pp)
            plot(pp,x,y);
            hold on
            title('New Max Interval Bursts Detected');
            xlabel('Time(s)')
            ylabel('Voltage(uV)')
            for i=1:length(burst6{INDEX2,1})
                plot(X2(find(X2 == burst6{INDEX2,1}{1,i}(1,1)): find(X2 == burst6{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst6{INDEX2,1}{1,i}(1,1)): find(X2 == burst6{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold on
            end
            %     plot(x,y)
            %     title('New Max Interval Bursts Detected');
            %     xlabel('Time(s)')
            %     ylabel('Voltage(uV)')
            %     hold on
            %     plot(
            linkaxes([pp tt],'xy');
        end
        
        
        dx=1; % this is the window in which the slide will operate (Seconds)
        % cla
        % plot(ax,x,y);
        axes1=gca;
        %         Xlim11=axes1.XLim;
        %         Ylim11=axes1.YLim;
        ylabel('Voltage(uV)');
        xlabel('Time(s)');
        % xlabel('Time in seconds');
        % title(['Channel ', HITS{Imax}]);
        set(gca,'Fontsize',10);
        
        % Set appropriate axis limits and settings
        set(gcf,'doublebuffer','on');
        [tb,~] = axtoolbar(tt,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        [tb,~] = axtoolbar(pp,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        % % This avoids flickering when updating the axis
        % set(axes1,'xlim',[0 dx]); % window
        % % find the values that is the largest for the axis and set the limit to the
        % % highest
        %
        if abs(min(y)) > max(y)
            set(axes1,'ylim',[min(y) abs(min(y))]);
        else
            set(axes1,'ylim',[-max(y) max(y)]);
        end
        %
        %         axes1.XLim=Xlim11;
        %         axes1.YLim=Ylim11;
    end

    function rerunnnbursts(source,handles,eventdata)
        
        if maxinterval == 1
            
            hh = waitbar(0,'Recalculating the network burst using the max interval detected bursts');
            starttimesbursts2 = [];
            for i = 1:length(burst6)
                for j = 1:length(burst6{i})
                    starttimesbursts = burst6{i}{j}(1);
                    starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
                end
            end
            
            uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes
            
            %now we need to put all the times in a giant matrix so we can
            %search in this matrix with the unique burst start times
            
            %convert all the cells into vectors
            % all the vectors are made equal in length by adding in nans
            temp = cell(1,length(burst6))';
            for i = 1:length(burst6)
                temp{i} = cell2mat(burst6{i});
            end
            
            newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
            newc=cell2mat(newc);
            
            
            % now we need to find if there are multiple channels that start
            % bursting at the same time
            channelnumbernnbursts =cell(1,length(burst6))';
            timeofnnbursts =cell(1,length(burst6))';
            for i = 1:length(uniquestarttimesbursts)
                [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) -  fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) +  fs.networkburstdetection.synchronizedtimewindow );
            end
            
            
            
         
            % check for duplicate channelnumbers if so remove them
            for i =1:length(channelnumbernnbursts)
                if isempty(channelnumbernnbursts{i})
                else
                    if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                          channelnumbernnbursts{i} = [];
                        timeofnnbursts{i}=[];
                    else
                      
                    end
                end
            end
            
            
            % now that we the channels that are synchronzied in their bursting
            % we need to remove the channels that do not fullfull our
            % requirements of have atleast 2 synchronized channels and atleast
            % 50% of the otal amount of channels should participate in the
            % nnburst or else it gets removed
            
            
            for i = 1:length(channelnumbernnbursts)
                if length(channelnumbernnbursts{i}) < fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                    channelnumbernnbursts{i} = [];
                    timeofnnbursts{i} = [];
                    uniquestarttimesbursts(i) = nan;
                end
            end
            
            %clean up by removing empty cells and nan values
            uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
            channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
            timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
            
            % now we need to find the bursts that are part of the synchronized
            % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
            % synchronzied bursts in other channels and then we can see how
            % many channels are participating
            waitbar(0 + 0.2,hh,'Recalculating the network burst using the max interval detected bursts');
            
            burst6length =burst6; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
            for i = 1:length(burst6)
                for j = 1:length(burst6{i})
                    burst6length{i}{j} = length(burst6{i}{j});
                end
            end
            
            for i = 1:length(burst6) % convert the cell arrays in vectors
                burst6length{i} = cell2mat(burst6length{i});
            end
            
            
            potentialnnbursts = cell(1,length(channelnumbernnbursts))';
            burstsindexcount=[];
            for i = 1:length(potentialnnbursts)
                for j = 1:length(channelnumbernnbursts{i})
                    for k = 1:cellfun(@length,(burst6(channelnumbernnbursts{i}(j))))
                        %figure out which bursts the indexes belong to
                        
                        %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
                        %                      burstsindexcount = cumsum( burstsindexcount); % old version
                        burstsindexcount = cumsum( burst6length{channelnumbernnbursts{i}(j)});
                        if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                            correctburst = k;
                            potentialnnbursts{i}{j} = burst6{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                            break
                        end
                    end
                end
            end
            % we have to check if the times of the bursts are within acceptable
            % ( check for nana values
            
                   
            %remove empty cells
              potentialnnbursts(cellfun('isempty',potentialnnbursts))=[];
            
            % create variable that is the exact same varible as potentialnnbursts
            % but intead each cell contains the mean + std of that channel to
            % improve the speed
            
            
       potentialnnburstsmean = potentialnnbursts;
       for i =1 :length(potentialnnbursts)
           potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 25*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
       end
       
       for i = 1:length(potentialnnbursts)
           for j = 1:length(potentialnnbursts{i})
               %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
               if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                   potentialnnbursts{i}{j} = [];
               end
           end
       end
            
            waitbar(0 + 0.6,hh,'Recalculating the network burst using the max interval detected bursts');
            
            % now we need to use the synscho bursts to find if there are bursts that
            % fall within the same duration as the synchronized bursts. if they do then
            % they are part of the  potential network bursts
            % we loop through both synchronized bursts just to extra certain we do not
            % miss anything because the starttimes might be the same but the ending
            % time might not be.
            
            mergeburstchannel = cell(1,length(potentialnnbursts))';
            mergeburstnumber  = cell(1,length(potentialnnbursts))';
            tobemergedbursts  = cell(1,length(potentialnnbursts))';
            
            
            
            % create vaiable of potneialnnbursts that have all the cells converted into
            % vectors to improve the performance
            potentialnnburstsvector = potentialnnbursts;
            potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
            
            
            for i = 1:length(potentialnnburstsvector)
                potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
                potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
            end
            
            for i =1:length(potentialnnbursts)
                for k = 1:length(burst6)
                    for l = 1:length(burst6{k})
                        if ~isempty(find(burst6{k}{l} > potentialnnburstsvector{i,2}(1) & burst6{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                            tobemergedbursts{i}{k} =cell2mat(burst6{k}(l)) ;
                            mergeburstchannel{i}{k} = k;
                            mergeburstnumber{i}{k} = l;
                        end
                    end
                end
            end
            
            
            % clean up the empty  cells
            
            for i =1:length(tobemergedbursts)
                tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
                mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
                mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
            end
            
            %now we need remove the nnbursts that have less than 50% of the whole wwell
            %participating in the nnbursts
            
            % find the number of active channels
            amountactivechannels = length(find(~cellfun(@isempty,M2)));
            
            mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
            % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
            % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
            
            %the last step is to find duplicates and merge them together
            findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
            
            for i = 1:length(tobemergedbursts)
                findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
            end
            
            
            waitbar(0 + 0.8,hh,'Recalculating the network burst using the max interval detected bursts');
            
            for i = 1:length(tobemergedbursts)
                if isempty(findoverlappingnnbursts{i})
                    continue
                else
                    for k = 2:length(tobemergedbursts)
                        if isempty(findoverlappingnnbursts{k}) || k == i
                            continue
                        else
                            if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                                % if this is true than there is overlap. so we need to find out
                                % which one is longer and that will be the one remaining.
                                if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                    findoverlappingnnbursts{k} = [];
                                else
                                    findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                    findoverlappingnnbursts{k} = [];
                                end
                            else
                                
                                
                            end
                        end
                    end
                end
            end
            
            %lets use logical indezing to get rid of the overlapping nnbursts and
            %finally get our actual nnbursts
            
            tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
            findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            
            % now that we have our nnbursts we can extract the ifnroamtion about the
            % nnbursts
            
            if isempty(findoverlappingnnbursts)
                networkburstttt.amount = 0;
                networkburstttt.duration = 0;
                networkburstttt.spikesfr_in_nbursts = 0;
                networkburstttt.nburst_rate = 0;
                networkburstttt.ISI = 0 ;
                networkburstttt.IBI = 0;
                networkburstttt.CVIBI = 0;
            else
                %struct for networkbursts
                networkburstttt =[];
                for i = 1:length(mergeburstnumber)
                    
                    networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
                    networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
                    networkburstttt.amount = length(mergeburstnumber);
                    networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
                    networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
                    networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
                    networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
                end
                
                for i = 1:length(mergeburstnumber)
                    if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                        networkburstttt.IBI(i,1) = 0;
                        networkburstttt.CVIBI = 0;
                        continue
                    else
                        networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
                    end
                end
                
                if isempty(networkburstttt)
                else
                    networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
                end
                
                
            end
            
            save(selecteddata,'networkburstttt','-append')
            close(hh)
        elseif logISI == 1
            hh = waitbar(0,'Recalculating the network burst using the log ISI detcted bursts');
            starttimesbursts2 = [];
            for i = 1:length(burst7)
                for j = 1:length(burst7{i})
                    starttimesbursts = burst7{i}{j}(1);
                    starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
                end
            end
            
            uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes
            
            %now we need to put all the times in a giant matrix so we can
            %search in this matrix with the unique burst start times
            
            %convert all the cells into vectors
            % all the vectors are made equal in length by adding in nans
            temp = cell(1,length(burst7))';
            for i = 1:length(burst7)
                temp{i} = cell2mat(burst7{i});
            end
            
            newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
            newc=cell2mat(newc);
            
            
            % now we need to find if there are multiple channels that start
            % bursting at the same time
            channelnumbernnbursts =cell(1,length(burst7))';
            timeofnnbursts =cell(1,length(burst7))';
            for i = 1:length(uniquestarttimesbursts)
                [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) -  fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) +  fs.networkburstdetection.synchronizedtimewindow );
            end
            
            
             
            
            % check for duplicate channelnumbers if so remove them
            for i =1:length(channelnumbernnbursts)
                if isempty(channelnumbernnbursts{i})
                else
                    if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                          channelnumbernnbursts{i} = [];
                        timeofnnbursts{i}=[];
                    else
                      
                    end
                end
            end
            
            
            % now that we the channels that are synchronzied in their bursting
            % we need to remove the channels that do not fullfull our
            % requirements of have atleast 2 synchronized channels and atleast
            % 50% of the otal amount of channels should participate in the
            % nnburst or else it gets removed
            
            
            for i = 1:length(channelnumbernnbursts)
                if length(channelnumbernnbursts{i}) < fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                    channelnumbernnbursts{i} = [];
                    timeofnnbursts{i} = [];
                    uniquestarttimesbursts(i) = nan;
                end
            end
            
            %clean up by removing empty cells and nan values
            uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
            channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
            timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
            
            % now we need to find the bursts that are part of the synchronized
            % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
            % synchronzied bursts in other channels and then we can see how
            % many channels are participating
            
            waitbar(0 + 0.2,hh,'Recalculating the network burst using the log ISI detected bursts');
            
            burst7length =burst7; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
            for i = 1:length(burst7)
                for j = 1:length(burst7{i})
                    burst7length{i}{j} = length(burst7{i}{j});
                end
            end
            
            for i = 1:length(burst7) % convert the cell arrays in vectors
                burst7length{i} = cell2mat(burst7length{i});
            end
            
            
            potentialnnbursts = cell(1,length(channelnumbernnbursts))';
            burstsindexcount=[];
            for i = 1:length(potentialnnbursts)
                for j = 1:length(channelnumbernnbursts{i})
                    for k = 1:cellfun(@length,(burst6(channelnumbernnbursts{i}(j))))
                        %figure out which bursts the indexes belong to
                        
                        %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
                        %                      burstsindexcount = cumsum( burstsindexcount); % old version
                        burstsindexcount = cumsum( burst7length{channelnumbernnbursts{i}(j)});
                        if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                            correctburst = k;
                            potentialnnbursts{i}{j} = burst7{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                            break
                        end
                    end
                end
            end
            
            % we have to check if the times of the bursts are within acceptable
            % ( check for nana values
            
            %remove empty cells
      
            potentialnnbursts(cellfun('isempty',potentialnnbursts))=[];
           
      
            
            % create variable that is the exact same varible as potentialnnbursts
            % but intead each cell contains the mean + std of that channel to
            % improve the speed
            
            
            potentialnnburstsmean = potentialnnbursts;
            for i =1 :length(potentialnnbursts)
                potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 25*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
            end
            
            for i = 1:length(potentialnnbursts)
                for j = 1:length(potentialnnbursts{i})
                    %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                    if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                        potentialnnbursts{i}{j} = [];
                    end
                end
            end
            
            
            % now we need to use the synscho bursts to find if there are bursts that
            % fall within the same duration as the synchronized bursts. if they do then
            % they are part of the  potential network bursts
            % we loop through both synchronized bursts just to extra certain we do not
            % miss anything because the starttimes might be the same but the ending
            % time might not be.
            
            mergeburstchannel = cell(1,length(potentialnnbursts))';
            mergeburstnumber  = cell(1,length(potentialnnbursts))';
            tobemergedbursts  = cell(1,length(potentialnnbursts))';
            
            % create vaiable of potneialnnbursts that have all the cells converted into
            % vectors to improve the performance
            potentialnnburstsvector = potentialnnbursts;
            potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
            
            
            for i = 1:length(potentialnnburstsvector)
                potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
                potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
            end
            
            for i =1:length(potentialnnbursts)
                for k = 1:length(burst7)
                    for l = 1:length(burst7{k})
                        if ~isempty(find(burst7{k}{l} > potentialnnburstsvector{i,2}(1) & burst7{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                            tobemergedbursts{i}{k} =cell2mat(burst7{k}(l)) ;
                            mergeburstchannel{i}{k} = k;
                            mergeburstnumber{i}{k} = l;
                        end
                    end
                end
            end
            
            
            % clean up the empty  cells
            
            for i =1:length(tobemergedbursts)
                tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
                mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
                mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
            end
            
            %now we need remove the nnbursts that have less than 50% of the whole wwell
            %participating in the nnbursts
            
            % find the number of active channels
            amountactivechannels = length(find(~cellfun(@isempty,M2)));
            
            mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
            % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
            % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
            
            %the last step is to find duplicates and merge them together
            findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
            
            for i = 1:length(tobemergedbursts)
                findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
            end
            
            waitbar(0 + 0.6,hh,'Recalculating the network burst using the log ISI detected bursts');
            
            for i = 1:length(tobemergedbursts)
                if isempty(findoverlappingnnbursts{i})
                    continue
                else
                    for k = 2:length(tobemergedbursts)
                        if isempty(findoverlappingnnbursts{k}) || k == i
                            continue
                        else
                            if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                                % if this is true than there is overlap. so we need to find out
                                % which one is longer and that will be the one remaining.
                                if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                    findoverlappingnnbursts{k} = [];
                                else
                                    findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                    findoverlappingnnbursts{k} = [];
                                end
                            else
                                
                                
                            end
                        end
                    end
                end
            end
            
            %lets use logical indezing to get rid of the overlapping nnbursts and
            %finally get our actual nnbursts
            
            tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
            findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            
            % now that we have our nnbursts we can extract the ifnroamtion about the
            % nnbursts
            waitbar(0 + 0.8,hh,'Recalculating the network burst using the log ISI detected bursts');
            if isempty(findoverlappingnnbursts)
                networkburstttt.amount = 0;
                networkburstttt.duration = 0;
                networkburstttt.spikesfr_in_nbursts = 0;
                networkburstttt.nburst_rate = 0;
                networkburstttt.ISI = 0 ;
                networkburstttt.IBI = 0;
                networkburstttt.CVIBI = 0;
            else
                %struct for networkbursts
                networkburstttt =[];
                for i = 1:length(mergeburstnumber)
                    
                    networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
                    networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
                    networkburstttt.amount = length(mergeburstnumber);
                    networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
                    networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
                    networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
                    networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
                end
                
                for i = 1:length(mergeburstnumber)
                    if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                        networkburstttt.IBI(i,1) = 0;
                        networkburstttt.CVIBI = 0;
                        continue
                    else
                        networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
                    end
                end
                
                if isempty(networkburstttt)
                else
                    networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
                end
                
            end
            save(selecteddata,'networkburstttt','-append')
            close(hh)
        elseif overlapp == 1
           hh = waitbar(0,'Recalculating the network burst based on overlapping SCBs');
            starttimesbursts2 = [];
            for i = 1:length(overlap)
                for j = 1:length(overlap{i})
                    starttimesbursts = overlap{i}{j}(1);
                    starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
                end
            end
            
            uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes
            
            %now we need to put all the times in a giant matrix so we can
            %search in this matrix with the unique burst start times
            
            %convert all the cells into vectors
            % all the vectors are made equal in length by adding in nans
            temp = cell(1,length(overlap))';
            for i = 1:length(overlap)
                temp{i} = cell2mat(overlap{i});
            end
            
            newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
            newc=cell2mat(newc);
            
            
            % now we need to find if there are multiple channels that start
            % bursting at the same time
            channelnumbernnbursts =cell(1,length(overlap))';
            timeofnnbursts =cell(1,length(overlap))';
            for i = 1:length(uniquestarttimesbursts)
                [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) -  fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) +  fs.networkburstdetection.synchronizedtimewindow );
            end
            
            
                
            % check for duplicate channelnumbers if so remove them
            for i =1:length(channelnumbernnbursts)
                if isempty(channelnumbernnbursts{i})
                else
                    if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                          channelnumbernnbursts{i} = [];
                        timeofnnbursts{i}=[];
                    else
                      
                    end
                end
            end
            
            
            
            % now that we the channels that are synchronzied in their bursting
            % we need to remove the channels that do not fullfull our
            % requirements of have atleast 2 synchronized channels and atleast
            % 50% of the otal amount of channels should participate in the
            % nnburst or else it gets removed
            
            
            for i = 1:length(channelnumbernnbursts)
                if length(channelnumbernnbursts{i}) < fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                    channelnumbernnbursts{i} = [];
                    timeofnnbursts{i} = [];
                    uniquestarttimesbursts(i) = nan;
                end
            end
            
            %clean up by removing empty cells and nan values
            uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
            channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
            timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
            
            % now we need to find the bursts that are part of the synchronized
            % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
            % synchronzied bursts in other channels and then we can see how
            % many channels are participating
            
            waitbar(0 + 0.2,hh,'Recalculating the network burst based on overlapping SCBs');
            
            overlaplength =overlap; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
            for i = 1:length(overlap)
                for j = 1:length(overlap{i})
                    overlaplength{i}{j} = length(overlap{i}{j});
                end
            end
            
            for i = 1:length(overlap) % convert the cell arrays in vectors
                overlaplength{i} = cell2mat(overlaplength{i});
            end
            
            
            potentialnnbursts = cell(1,length(channelnumbernnbursts))';
            burstsindexcount=[];
            for i = 1:length(potentialnnbursts)
                for j = 1:length(channelnumbernnbursts{i})
                    for k = 1:cellfun(@length,(overlap(channelnumbernnbursts{i}(j))))
                        %figure out which bursts the indexes belong to
                        
                        %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
                        %                      burstsindexcount = cumsum( burstsindexcount); % old version
                        burstsindexcount = cumsum( overlaplength{channelnumbernnbursts{i}(j)});
                        if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                            correctburst = k;
                            potentialnnbursts{i}{j} = overlap{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                            break
                        end
                    end
                end
            end
            
            % we have to check if the times of the bursts are within acceptable
            % ( check for nana values
            
                   
            %remove empty cells
            potentialnnbursts(cellfun('isempty',potentialnnbursts))=[];
            % create variable that is the exact same varible as potentialnnbursts
            % but intead each cell contains the mean + std of that channel to
            % improve the speed
            
            
            potentialnnburstsmean = potentialnnbursts;
            for i =1 :length(potentialnnbursts)
                potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 25*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
            end
            
            for i = 1:length(potentialnnbursts)
                for j = 1:length(potentialnnbursts{i})
                    %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                    if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                        potentialnnbursts{i}{j} = [];
                    end
                end
            end
            
            
            % now we need to use the synscho bursts to find if there are bursts that
            % fall within the same duration as the synchronized bursts. if they do then
            % they are part of the  potential network bursts
            % we loop through both synchronized bursts just to extra certain we do not
            % miss anything because the starttimes might be the same but the ending
            % time might not be.
            
            mergeburstchannel = cell(1,length(potentialnnbursts))';
            mergeburstnumber  = cell(1,length(potentialnnbursts))';
            tobemergedbursts  = cell(1,length(potentialnnbursts))';
            
            % create vaiable of potneialnnbursts that have all the cells converted into
            % vectors to improve the performance
            potentialnnburstsvector = potentialnnbursts;
            potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
            
            
            for i = 1:length(potentialnnburstsvector)
                potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
                potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
            end
            
            for i =1:length(potentialnnbursts)
                for k = 1:length(overlap)
                    for l = 1:length(overlap{k})
                        if ~isempty(find(overlap{k}{l} > potentialnnburstsvector{i,2}(1) & overlap{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                            tobemergedbursts{i}{k} =cell2mat(overlap{k}(l)) ;
                            mergeburstchannel{i}{k} = k;
                            mergeburstnumber{i}{k} = l;
                        end
                    end
                end
            end
            
            
            % clean up the empty  cells
            
            for i =1:length(tobemergedbursts)
                tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
                mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
                mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
            end
            
            %now we need remove the nnbursts that have less than 50% of the whole wwell
            %participating in the nnbursts
            
            % find the number of active channels
            amountactivechannels = length(find(~cellfun(@isempty,M2)));
            
            mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
            % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
            % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
            
            %the last step is to find duplicates and merge them together
            findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
            
            for i = 1:length(tobemergedbursts)
                findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
            end
            
            waitbar(0 + 0.6,hh,'Recalculating the network burst based on overlapping SCBs');
            
            for i = 1:length(tobemergedbursts)
                if isempty(findoverlappingnnbursts{i})
                    continue
                else
                    for k = 2:length(tobemergedbursts)
                        if isempty(findoverlappingnnbursts{k}) || k == i
                            continue
                        else
                            if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                                % if this is true than there is overlap. so we need to find out
                                % which one is longer and that will be the one remaining.
                                if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                    findoverlappingnnbursts{k} = [];
                                else
                                    findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                    findoverlappingnnbursts{k} = [];
                                end
                            else
                                
                                
                            end
                        end
                    end
                end
            end
            
            %lets use logical indezing to get rid of the overlapping nnbursts and
            %finally get our actual nnbursts
            
            tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
            findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            
            % now that we have our nnbursts we can extract the ifnroamtion about the
            % nnbursts
            waitbar(0 + 0.8,hh,'Recalculating the network burst based on overlapping SCBs');
            if isempty(findoverlappingnnbursts)
                networkburstttt.amount = 0;
                networkburstttt.duration = 0;
                networkburstttt.spikesfr_in_nbursts = 0;
                networkburstttt.nburst_rate = 0;
                networkburstttt.ISI = 0 ;
                networkburstttt.IBI = 0;
                networkburstttt.CVIBI = 0;
            else
                %struct for networkbursts
                networkburstttt =[];
                for i = 1:length(mergeburstnumber)
                    
                    networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
                    networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
                    networkburstttt.amount = length(mergeburstnumber);
                    networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
                    networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
                    networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
                    networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
                end
                
                for i = 1:length(mergeburstnumber)
                    if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                        networkburstttt.IBI(i,1) = 0;
                        networkburstttt.CVIBI = 0;
                        continue
                    else
                        networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
                    end
                end
                
                if isempty(networkburstttt)
                else
                    networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
                end
                
            end
            save(selecteddata,'networkburstttt','-append')
            close(hh)  
            
        end
        
        nTotalSpikes = sum(cellfun(@length,M2));
        
        
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;
        
        
        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            % Save points and update current index
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        
        
        %% plotting
        if logISI == 1 && maxinterval == 0
            %% default paramaters
            panel11 = findobj('Tag','uipanel11');
            pp = subplot(2,1,1,'Parent',panel11);
            nnetworkburstdisp = cell(1,length(M2));
            
            if networkbursttttold.amount == 0
                cla(pp)
            else
                for i = 1:length(networkbursttttold.starttime)
                    for j = 1:length(M2)
                        if isempty(burst7{j})
                            continue
                        else
                            temp = find(M2{j} > networkbursttttold.starttime(i) &  M2{j} < networkbursttttold.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(pp,'YTickLabel',correctylim)
                    pp.YTickLabel{end} =[];
                    title(['Network bursts detected with default parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(pp)
                
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end
            
            %% new paramaters
            tt = subplot(2,1,2,'Parent',panel11);
            if networkburstttt.amount == 0
                cla(tt)
            else
                for i = 1:length(networkburstttt.starttime)
                    for j = 1:length(M2)
                        if isempty(burst7{j})
                            continue
                        else
                            temp = find(M2{j} > networkburstttt.starttime(i) &  M2{j} < networkburstttt.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(tt,'YTickLabel',correctylim)
                    tt.YTickLabel{end} =[];
                    title(['Network bursts detected with new parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(tt)
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end

        elseif maxinterval == 1 && logISI == 0
            %% old parameters
            panel11 = findobj('Tag','uipanel11');
            pp = subplot(2,1,1,'Parent',panel11);
            
            nnetworkburstdisp = cell(1,length(M2));
            if networkbursttttold.amount == 0
                cla(pp)
            else
                for i = 1:length(networkbursttttold.starttime)
                    for j = 1:length(M2)
                        if isempty(burst6{j})
                            continue
                        else
                            temp = find(M2{j} > networkbursttttold.starttime(i) &  M2{j} < networkbursttttold.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(pp,'YTickLabel',correctylim)
                    pp.YTickLabel{end} =[];
                    title(['Network bursts detected with default parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(pp)
                
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end

            %% new parameters
            nnetworkburstdisp = cell(1,length(M2));
            tt = subplot(2,1,2,'Parent',panel11);
            if networkburstttt.amount == 0
                cla(tt)
            else
                for i = 1:length(networkburstttt.starttime)
                    for j = 1:length(M2)
                        if isempty(burst6{j})
                            continue
                        else
                            temp = find(M2{j} > networkburstttt.starttime(i) &  M2{j} < networkburstttt.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(tt,'YTickLabel',correctylim)
                    tt.YTickLabel{end} =[];
                    title(['Network bursts detected with new parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(tt)
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end
        elseif overlapp == 1 && maxinterval == 0 && logISI == 0
             %% old parameters
            panel11 = findobj('Tag','uipanel11');
            pp = subplot(2,1,1,'Parent',panel11);
            
            nnetworkburstdisp = cell(1,length(M2));
            if networkbursttttold.amount == 0
                cla(pp)
            else
                for i = 1:length(networkbursttttold.starttime)
                    for j = 1:length(M2)
                        if isempty(burst6{j})
                            continue
                        else
                            temp = find(M2{j} > networkbursttttold.starttime(i) &  M2{j} < networkbursttttold.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(pp,'YTickLabel',correctylim)
                    pp.YTickLabel{end} =[];
                    title(['Network bursts detected with default parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(pp)
                
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end

            %% new parameters
            nnetworkburstdisp = cell(1,length(M2));
            tt = subplot(2,1,2,'Parent',panel11);
            if networkburstttt.amount == 0
                cla(tt)
            else
                for i = 1:length(networkburstttt.starttime)
                    for j = 1:length(M2)
                        if isempty(burst6{j})
                            continue
                        else
                            temp = find(M2{j} > networkburstttt.starttime(i) &  M2{j} < networkburstttt.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(tt,'YTickLabel',correctylim)
                    tt.YTickLabel{end} =[];
                    title(['Network bursts detected with new parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(tt)
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end
            
        end
        
        linkaxes([pp tt],'xy');
        set(gcf,'doublebuffer','on');
        [tb,~] = axtoolbar(tt,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        [tb,~] = axtoolbar(pp,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        
    end

    function revertback(source,~)
        
        if maxinterval == 1 && logISI == 0
            burst6=burst6old;
            Exburst=Exburstold;
            networkburstttt=networkbursttttold;
            fs.burstdetectionmaxinterval.start=0.05;
            fs.burstdetectionmaxinterval.nspikes=4;
            fs.burstdetectionmaxinterval.IBI=0.1;
            fs.burstdetectionmaxinterval.intraBI=0.1;
            fs.burstdetectionmaxinterval.mindur=0.03;
            edit5.String = '0.03';
            edit4.String = '0.1';
            edit3.String = '0.1';
            edit2.String = '4';
            edit1.String = '0.05';
            fs.networkburstdetection.synchronizedtimewindow = 0.1; % time in seconds
            fs.networkburstdetection.minimumsynchronizedburstcount = 2; % in counts
            fs.networkburstdetection.minimumchannelparticipation = 0.25; % in percentage
            edit8.String = '0.1';
            edit9.String = '2';
            edit10.String = '0.25';
        elseif logISI == 1 && maxinterval == 0
            burst7=burst7old;
            logburst=logburstold;
            networkburstttt=networkbursttttold;
            fs.burstdetectionlogisi.void=0.7;
            fs.burstdetectionlogisi.nspikes=3;
            edit6.String ='3';
            edit7.String ='0.7';
            fs.networkburstdetection.synchronizedtimewindow = 0.1; % time in seconds
            fs.networkburstdetection.minimumsynchronizedburstcount = 2; % in counts
            fs.networkburstdetection.minimumchannelparticipation = 0.25; % in percentage
            edit8.String = '0.1';
            edit9.String = '2';
            edit10.String = '0.25';
        elseif logISI == 0 && maxinterval == 0 && overlapp == 1
            networkburstttt=networkbursttttold;
             fs.networkburstdetection.synchronizedtimewindow = 0.1; % time in seconds
            fs.networkburstdetection.minimumsynchronizedburstcount = 2; % in counts
            fs.networkburstdetection.minimumchannelparticipation = 0.25; % in percentage
            edit8.String = '0.1';
            edit9.String = '2';
            edit10.String = '0.25';
        end
    end

    function selectch(~,~)
        prompt = {'Enter Channel to compare the different burst detection methods in'};
        title = 'Comparison of burst detection methods';
        dims = [1 75];
        definput = {'1'};
        newname = inputdlg(prompt,title,dims,definput);
        if isempty(newname)
            return
        end
        Imax=find(strcmp(HITS,newname{1}));
        
        correctwell = ceil(Imax/electrodecount); %we found the correct well
        INDEX2 = ceil((((Imax/electrodecount) - (correctwell - 1))*electrodecount)-0.000001); %find correct index in 12 well
        change1 =  findobj('String',strjoin(['Channel', Totoro]));
        change1.String = strjoin(['Channel',newname]);
        Totoro = newname; % reset the name so it can searched again
        
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if contains(selecteddata,'Well')
                if isempty(regexp(selecteddata,checked))
                    continue
                else
                    oldname = sprintf('Well_%d',i);
                    selecteddata = strrep(selecteddata,oldname,'Well_1');
                end
            else
                selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
            end
        end % change the name to well 1
        
        selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',correctwell));
        load(selecteddata,'filteredData1')
        %we have to reload the old detected bursts otherwise it will take
        %the wrong bursts
        load(selecteddata,'burst6')
        load(selecteddata,'burst7')
        load(selecteddata,'Exburst')
        load(selecteddata,'RMS7');
        load(selecteddata,'M88');
        load(selecteddata,'burst6indx');
        load(selecteddata,'M2');
        load(selecteddata,'ISI58');
        load(selecteddata,'networkburstttt');
        load(selecteddata,'xpoints');
        Exburstold = Exburst;
        logburstold = logburst;
        burst6old = burst6;
        burst7old = burst7;
        networkbursttttold=networkburstttt;
%         filteredData1=hlp_deserialize(filteredData1);
        push45 = findobj('Tag','pushbutton45');
        if ~isempty(push45.UserData)
            rerunnnbursts
        else
            rerun
        end
    end

    function stats1(source,~)
        
        push45 = findobj('Tag','pushbutton45');
        % change the orientation of the fr_of_bursts
        if isempty(Exburst{INDEX2}.fr_of_bursts)
            warndlg('There are no bursts!','Warning');
            return
        end
        
        figure('units','normalized','outerposition',[0 0 1 1]);
        fig = gcf;
        set(gcf,'color','white')
        
        if size(Exburst{INDEX2}.fr_of_bursts,1) == 1
            Exburst{INDEX2}.fr_of_bursts = Exburst{INDEX2}.fr_of_bursts';
        end
        
        if size(logburst{INDEX2}.fr_of_bursts,1) == 1
            logburst{INDEX2}.fr_of_bursts = logburst{INDEX2}.fr_of_bursts';
        end
        
        
        
        if maxinterval == 1 && isempty(push45.UserData)
            
            if size(Exburstold{INDEX2}.fr_of_bursts,1) == 1
                Exburstold{INDEX2}.fr_of_bursts = Exburstold{INDEX2}.fr_of_bursts';
            end
            
            if length(Exburst{INDEX2}.IBI) == length(Exburst{INDEX2}.duration_of_bursts) % if the length are not equal add a nan value
            else
                Exburst{INDEX2}.IBI(end+1) = nan;
                
            end
            
            if length(Exburstold{INDEX2}.IBI) == length(Exburstold{INDEX2}.duration_of_bursts) % if the length are not equal add a nan value
            else
                Exburstold{INDEX2}.IBI(end+1) = nan;
            end
            
            if size(Exburst{INDEX2}.IBI,1) == 1
                Exburst{INDEX2}.IBI = Exburst{INDEX2}.IBI';
            end
            
            
            Table680=struct2table(Exburst{INDEX2});
            Table679=struct2table(Exburstold{INDEX2});
            table2 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/4 .05 1/4 .9], 'Data', Table679{:,:},'ColumnName',Table679.Properties.VariableNames,...
                'RowName',Table679.Properties.RowNames);
            text(0.24, 1.06,'Statistics of default max interval Bursts')
            table3 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/2 .05 1/4 .9], 'Data', Table680{:,:},'ColumnName',Table680.Properties.VariableNames,...
                'RowName',Table680.Properties.RowNames);
            text(0.57, 1.06,'Statistics of new max interval Bursts')
            
        elseif logISI == 1 && isempty(push45.UserData)
            
            if size(logburstold{INDEX2}.fr_of_bursts,1) == 1
                logburstold{INDEX2}.fr_of_bursts = logburstold{INDEX2}.fr_of_bursts';
            end
            
            Table680=struct2table(logburst{INDEX2});
            Table679=struct2table(logburstold{INDEX2});
            table2 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/4 .05 1/4 .9], 'Data', Table679{:,:},'ColumnName',Table679.Properties.VariableNames,...
                'RowName',Table679.Properties.RowNames);
            text(0.24, 1.06,'Statistics of default ISI Bursts')
            table3 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/2 .05 1/4 .9], 'Data', Table680{:,:},'ColumnName',Table680.Properties.VariableNames,...
                'RowName',Table680.Properties.RowNames);
            text(0.57, 1.06,'Statistics of new log ISI Bursts')
        elseif ~isempty(push45.UserData)
            networkbursttable = networkburstttt;
            networkbursttable.amount = 1:networkbursttable.amount;
            networkbursttable.networkburstnumber = networkbursttable.amount';
            networkbursttable  = rmfield(networkbursttable,'amount');
            networkbursttable  = rmfield(networkbursttable,'nburst_rate');
            networkbursttable  = rmfield(networkbursttable,'CVIBI');
            P = [7 1 2 3 4 5 6 ];
            networkbursttable = orderfields(networkbursttable,P);
            
            
            networkbursttableold = networkbursttttold;
            networkbursttableold.amount = 1:networkbursttableold.amount;
            networkbursttableold.networkburstnumber = networkbursttableold.amount';
            networkbursttableold  = rmfield(networkbursttableold,'amount');
            networkbursttableold  = rmfield(networkbursttableold,'nburst_rate');
            networkbursttableold  = rmfield(networkbursttableold,'CVIBI');
            P = [7 1 2 3 4 5 6 ];
            networkbursttableold = orderfields(networkbursttableold,P);
            
            if isempty(networkbursttable.networkburstnumber)
                networkbursttable.networkburstnumber = 0;
                networkbursttable.starttime = 0;
                networkbursttable.endtime = 0;
            end
            
            if isempty(networkbursttableold.networkburstnumber)
                networkbursttableold.networkburstnumber = 0;
                networkbursttableold.starttime = 0;
                networkbursttableold.endtime = 0;
            end
            
            
            networkbursttablenew=struct2table(networkbursttable);
            networkbursttablenold=struct2table(networkbursttableold);
            table2 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/4 .05 1/4 .9], 'Data',  networkbursttablenew{:,:},'ColumnName', networkbursttablenew.Properties.VariableNames,...
                'RowName', networkbursttablenew.Properties.RowNames);
            text(0.24, 1.06,'Statistics of new detected network bursts')
            table3 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/2 .05 1/4 .9], 'Data', networkbursttablenold{:,:},'ColumnName',networkbursttablenold.Properties.VariableNames,...
                'RowName',networkbursttablenold.Properties.RowNames);
            text(0.57, 1.06,'Statistics of old detected network bursts')
        end
        
        
        set(gca,'visible','off')
        
        %         c = uicontrol;
        %         c.Position = [1535,888,175,67];
        %         c.FontWeight = 'bold';
        %         c.ForegroundColor = [0.861,0.832,0.096,0.048];
        %         c.CData = imread('color_button.png');
        %         c.String = 'Save Table';
        %         c.Callback = @savetable;
        
        
        %% if the new burst detection results in no brusts detected remove the option for the user to select the statistics button
        
        if isempty(Exburst{INDEX2}.duration_of_bursts) % if the length are not equal add a nan value
            push4.Enable = 'off';
            
        else
            push4.Enable = 'on';
        end
        
    end

    function savetable(src,event)
        
        
        list = {'Save Table 1','Save Table 2','Save Table 3'};
        [indx23,~] = listdlg('PromptString','Select which table to save','SelectionMode','single','ListString',list);
        if isempty(indx23)
        else
            if indx23 == 1
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table139,uiputfile(filter),'WriteRowNames',true);
            elseif indx23 == 2
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table679,uiputfile(filter),'WriteRowNames',true);
                
            else
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table680,uiputfile(filter),'WriteRowNames',true);
            end
        end
        
    end

    function Chan(source,~)
        maxinterval = 0;
        push45 = findobj('Tag','pushbutton45');
        if ~isempty(push45.UserData) && cbox1.Value == 1
            edit8.Enable = 'on';
            edit9.Enable ='on';
            edit10.Enable ='on';
            maxinterval = 1;
            cbox2.Value = 0;
            cbox2.Enable ='off';
            cbox101.Value = 0;
            cbox101.Enable ='off';
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            push5.Visible ='on';
        elseif ~isempty(push45.UserData) && cbox1.Value == 0
            edit8.Enable = 'off';
            edit9.Enable ='off';
            edit10.Enable ='off';
            maxinterval = 0;
            
            cbox2.Enable ='on';
            cbox101.Enable = 'on';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            push5.Visible ='off';
        elseif source.Value == 1 && cbox1.Value == 1
            maxinterval = 1;
            %             text1.Enable = 'on';
            %             text2.Enable = 'on';
            %             text3.Enable = 'on';
            %             text4.Enable = 'on';
            %             text5.Enable = 'on';
            edit2.Enable = 'on';
            edit1.Enable = 'on';
            edit3.Enable = 'on';
            edit4.Enable = 'on';
            edit5.Enable = 'on';
            cbox2.Enable = 'off';
            cbox2.Value = 0;
              cbox101.Enable = 'off';
            cbox101.Value = 0;
            push1.Visible ='on';
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            
        elseif  source.Value == 0 && cbox1.Value == 0
            maxinterval = 0;
            %             text1.Enable = 'off';
            %             text2.Enable = 'off';
            %             text3.Enable = 'off';
            %             text4.Enable = 'off';
            %             text5.Enable = 'off';
            edit2.Enable = 'off';
            edit1.Enable = 'off';
            edit3.Enable = 'off';
            edit4.Enable = 'off';
            edit5.Enable = 'off';
            cbox2.Enable = 'on';
            cbox101.Enable = 'on';
            push1.Visible ='off';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            
            
            
        end
    end

    function Chan2(source,~)
        logISI = 0;
        push45 = findobj('Tag','pushbutton45');
        if ~isempty(push45.UserData) && cbox2.Value == 1
            edit8.Enable = 'on';
            edit9.Enable ='on';
            edit10.Enable ='on';
            logISI= 1;
            cbox1.Value = 0;
            cbox1.Enable ='off';
            cbox101.Value = 0;
            cbox101.Enable ='off';
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            push5.Visible ='on';
        elseif ~isempty(push45.UserData) && cbox2.Value == 0
            edit8.Enable = 'off';
            edit9.Enable ='off';
            edit10.Enable ='off';
            logISI = 0;
            cbox1.Enable ='on';
            cbox101.Enable = 'on';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            push5.Visible ='off';
        elseif source.Value == 1 && cbox2.Value == 1
            logISI = 1;
            %             text6.Enable = 'on';
            %             text7.Enable = 'on';
            edit6.Enable = 'on';
            edit7.Enable = 'on';
            cbox1.Enable = 'off';
            cbox1.Value = 0;
             cbox101.Enable = 'off';
            cbox101.Value = 0;
            push1.Visible ='on';
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            
        elseif source.Value == 0 && cbox2.Value == 0
            logISI = 0;
            %             text6.Enable = 'off';
            %             text7.Enable = 'off';
            edit6.Enable = 'off';
            edit7.Enable = 'off';
            cbox1.Enable = 'on';
            cbox101.Enable = 'on';
            push1.Visible ='off';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            
        end
    end

    function Chan3(source,~)
        overlapp = 0;
        push45 = findobj('Tag','pushbutton45');
        if ~isempty(push45.UserData) && cbox101.Value == 1
            overlapp = 1;
            edit8.Enable = 'on';
            edit9.Enable ='on';
            edit10.Enable ='on';
            
            cbox1.Value = 0;
            cbox1.Enable ='off';
            cbox2.Value = 0;
            cbox2.Enable ='off';
            
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            push5.Visible ='on';
        elseif ~isempty(push45.UserData) && cbox101.Value == 0
            edit8.Enable = 'off';
            edit9.Enable ='off';
            edit10.Enable ='off';
            logISI = 0;
            maxinterval = 0;
            cbox1.Enable ='on';
            cbox2.Enable ='on';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            push5.Visible ='off';
        elseif source.Value == 1 && cbox101.Value == 1
            overlapp = 1;
            %             text6.Enable = 'on';
            %             text7.Enable = 'on';
            edit6.Enable = 'on';
            edit7.Enable = 'on';
            cbox1.Enable = 'off';
            cbox1.Value = 0;
            cbox2.Enable = 'off';
            cbox2.Value = 0;
            push1.Visible ='on';
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            
        elseif source.Value == 0 && cbox101.Value == 0
            logISI = 0;
            maxinterval = 0;
            %             text6.Enable = 'off';
            %             text7.Enable = 'off';
            edit6.Enable = 'off';
            edit7.Enable = 'off';
            cbox1.Enable = 'on';
            cbox2.Enable = 'on';
            push1.Visible ='off';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            
        end
    end

    function editChan(~,~)
       
        if (str2double(edit1.String) > 0 && str2double(edit1.String) < 1)
                fs.burstdetectionmaxinterval.start = str2double(edit1.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 0.5 seconds','Burst Start Interval Error')
        end
        
        if (str2double(edit2.String) > 0 && str2double(edit2.String) < 1000)
                fs.burstdetectionmaxinterval.nspikes = str2double(edit2.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1000 spikes','Spike Number Error')
        end

        if (str2double(edit3.String) > 0 && str2double(edit3.String) < 1)
                fs.burstdetectionmaxinterval.IBI = str2double(edit3.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1 second','Inter Burst Interval Error')
        end
              
        if (str2double(edit4.String) > 0 && str2double(edit4.String) < 1)
                fs.burstdetectionmaxinterval.intraBI = str2double(edit4.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1 second','Intra Burst Interval Error')
        end
                
        if (str2double(edit5.String) > 0 && str2double(edit5.String) < 100)
                fs.burstdetectionmaxinterval.mindur = str2double(edit5.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 100 seconds','Minimum Burst Duration Error')
        end
               
        if (str2double(edit6.String) > 0 && str2double(edit6.String) < 1000)
                fs.burstdetectionlogisi.nspikes = str2double(edit6.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1000 spikes','Amount of Spikes Error')
        end
        
        if (str2double(edit7.String) > 0 && str2double(edit7.String) < 1)
                fs.burstdetectionlogisi.void = str2double(edit7.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1','Void Parameter Error')
        end
        
        if (str2double(edit8.String) > 0 && str2double(edit8.String) < 1)
            fs.networkburstdetection.synchronizedtimewindow = str2double(edit8.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1 seconds','Network Burst synchronized time window Error')
        end
        
        if (str2double(edit9.String) > 0 && str2double(edit9.String) < 10)
            fs.networkburstdetection.minimumsynchronizedburstcount = str2double(edit9.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 10','Network Burst minimum synchronzied bursts amount Error')
        end
        
        if (str2double(edit10.String) > 0 && str2double(edit10.String) < 1)
            fs.networkburstdetection.minimumchannelparticipation = str2double(edit10.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1 ','Network Burst minimum channel participation Error')
        end
    end
end

% ---
function uipanel11_CreateFcn(hObject, eventdata, handles)
global ax axes1 dx

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
ax=axes(hObject);
axes1=gca;
dx = 1;
% hObject.Position=[.009 .785 .806 .119];
hObject.Position=[.009 .302 .806 .603];
hObject.UserData = 1992;
% panel1 = hObject;
% panel2 = uipanel('Parent',panel1);
% set(panel1,'Position',[0 0.05 1 1]);
% set(panel2,'Position',[-1 0 1 2]);
end

function pushbutton42_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.String = 'Select Channel';
hObject.FontWeight = 'bold';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.92 0.89 0.655];
hObject.Position = [0.861 0.832 0.096 0.048 ];
end

% --- Select channel
function pushbutton42_Callback(hObject, eventdata, handles)
global HITS electrodecount Imax selecteddata h h1 h2 h3 correctchannel timesss overlap overlapburst networkburstttt INDEX2 Totoro ax dx tb filteredData1 X2 axes1 Xlim11 Ylim11 cbx109 cbx119 cbx129 cbx139 cbx98 cbx99 cbx159 cbx169

prompt = {'Enter Channel number'};
title = 'Comparison of burst detection methods';
dims = [1 35];
definput = {'1'};
Totoro = inputdlg(prompt,title,dims,definput);
if isempty(Totoro)
    return
end
Imax=find(strcmp(HITS,Totoro{1}));
electrodecount = 12;
correctwell = ceil(Imax/electrodecount); %we found the correct well
INDEX2 = ceil((((Imax/electrodecount) - (correctwell - 1))*electrodecount)-0.000001); % the -0.0000001 is for cases when the number is an whole number like 6.00 so it decreaseses the number for the ceil to work correctly

for i = 2:25
    checked =sprintf('Well_%d',i);
    if contains(selecteddata,'Well')
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    else
        selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
    end
end % change the name to well 1

selecteddata = replace(selecteddata,'Well_1',sprintf('Well_%d',correctwell));
load(selecteddata,'filteredData1')
load(selecteddata,'RMS7');
load(selecteddata,'M88');
load(selecteddata,'burst6');
load(selecteddata,'burst7');
load(selecteddata,'burst6indx');
load(selecteddata,'Exburst');
load(selecteddata,'logburst');
load(selecteddata,'burstsinfor');
load(selecteddata,'M2');
load(selecteddata,'ISI58');
load(selecteddata,'networkburstttt');
load(selecteddata,'xpoints');
% filteredData1=hlp_deserialize(filteredData1);

%clean the axes before plotting new one otherwise they will overlap
if isstruct(h)  % if it's a struct is means that the program has just started and there is nothing to delete
else
    delete(h)
end

if isstruct(h1)
else
    delete(h1)
end

if isstruct(h2)
else
    delete(h2)
end


if isstruct(h3)
else
    delete(h3)
end
%% display the channel in uipanel11
x=X2;
y=filteredData1(INDEX2,:);

if size(handles.uipanel11.Children,1) == 1
    delete(handles.uipanel11.Children(1));
end

if size(handles.uipanel11.Children,1) == 2
    delete(handles.uipanel11.Children(2));
    delete(handles.uipanel11.Children(1));
end

ax = axes(handles.uipanel11);
cla(ax)
plot(ax,x,y);
axes1=gca;
axes1.XLim =[0 timesss];
Xlim11=axes1.XLim;
Ylim11=axes1.YLim;


ylabel(ax,'Microvolts');
xlabel(ax,'Time(s)');
% xlabel('Time in seconds');
% title(['Channel ', HITS{Imax}]);
set(axes1,'Fontsize',10);

% Set appropriate axis limits and settings
set(gcf,'doublebuffer','on');
[tb,~] = axtoolbar(ax,{'pan','datacursor','zoomin','zoomout','restoreview'});
tb.Visible = 'on';
% This avoids flickering when updating the axis
set(axes1,'xlim',[0 dx]); % window
% find the values that is the largest for the axis and set the limit to the
% highest

if abs(min(y)) > max(y)
    set(axes1,'ylim',[min(y) abs(min(y))]);
else
    set(axes1,'ylim',[-max(y) max(y)]);
end

% Generate constants for use in uicontrol initialization
% pos=get(axes1,'position');
% Newpos=[pos(1) pos(2)-0.1 pos(3) 0.05];
% Newpos=[0.009 0.75 0.806 0.03];
Newpos=[.009 .272 .806 .03];

% This will create a slider which is just underneath the axis
%  but still leaves room for the axis labels above the slider
xmax=max(x);
% S=['set(axes1,''xlim'',get(gcbo,''value'')+[0 ' num2str(dx) '])'];

h=uicontrol('style','slider',...
    'units','normalized','position',Newpos,...
    'callback',@callbackfn,'min',0,'max',xmax-dx);

    function callbackfn(~,~)
        set(axes1,'xlim',get(gcbo,'value')+[0 dx]);
    end

h.Visible = 'off';
axes1.XLim = Xlim11;
axes1.YLim = Ylim11;

%% display the buttons in uipanel12

cbx109.Enable = 'on';
cbx119.Enable = 'on';
cbx129.Enable = 'on';
cbx139.Enable = 'on';
cbx98.Enable = 'off';
cbx99.Enable = 'off';
cbx159.Enable = 'off';
cbx169.Enable = 'on';

cbx109.Visible = 'on';
cbx119.Visible = 'on';
cbx129.Visible = 'on';
cbx139.Visible = 'on';
cbx98.Visible = 'on';
cbx99.Visible = 'on';
cbx159.Visible = 'on';
cbx169.Visible = 'on';


% uipanel13_ButtonDownFcn(handles.uipanel13, eventdata, handles)
% uipanel14_ButtonDownFcn(handles.uipanel14, eventdata, handles)
% text83_ButtonDownFcn(handles.text83,eventdata,handles)
% handles.text83.Visible = 'on';
set(handles.Pannel_25.Text,'String',['Channel ', Totoro{1}]);
% set(handles.Pannel_26.Text,'String',strjoin(['Bursts detected in channel', Totoro, 'with the Max interval Method']));
% set(handles.Pannel_27.Text,'String',strjoin(['Bursts detected in channel', Totoro, 'with the log ISI Method']));
% set(handles.Pannel_29.Text,'String',strjoin(['Bursts detected in channel', Totoro, 'with the BD Method']));
set(handles.pushbutton43,'Visible','on');
set(handles.pushbutton44,'Visible','on');
set(handles.pushbutton45,'Visible','on');
set(handles.pushbutton46,'Visible','off');
set(handles.pushbutton47,'Visible','on');
set(handles.pushbutton48,'Visible','on');

%% overlappping bursts
%The main goal is find overlapping bursts or bursts that are detected by
% both SCB detection methods.

overlap = {};
for iii = 1:length(burst6)
    for j =1:length(burst6{iii})
        if isempty(burst6{iii})
            continue
        else
            for k = 1:length(burst7{iii})
                temp1 = isequal(burst6{iii}(j),burst7{iii}(k));
                if temp1 == 1
                    overlap{iii}(j) = burst6{iii}(j); % if they are exactly the same put in new vector
                elseif temp1 == 0 % even if they not exactly the same we need to check if the values are not similar. if the values are within each other range of 100 ms the SCBs will still be counted as overlapping bursts
                    %
                    %                     check1 = find(burst7{i}{k} >= burst6{i}{j}(1) & burst7{i}{k} <= burst6{i}{j}(end));
                    %                     if ~isempty(check1)
                    %                         overlap{i}(j) = burst6{i}(j);
                    %                     end
                end
            end
        end
    end
end

overlap= overlap';

%remove empty cells
for iii =1:length(overlap)
    if isempty(overlap{iii})
        continue
    else
        overlap{iii}(cellfun('isempty',overlap{iii}))=[];
    end
end
%% stats of overlapping bursts

    overlapburst=cell(1,length(overlap))';
        for jj=1:length(overlap)
            overlapburst{jj}.number_of_bursts=1:length(overlap{jj,1});
            
            for i=1:length(overlap{jj,1})
                overlapburst{jj}.duration_of_bursts(i)=overlap{jj,1}{1,i}(end)-overlap{jj,1}{1,i}(1,1);
            end
            
            
            for i=1:length(overlap{jj,1})
                overlapburst{jj}.spikes_in_bursts(i)=length(overlap{jj,1}{1,i});
            end
        end
%         overlapburst=overlapburst';   %contains data about the bursts for the table
        
        for i=1:length(overlap)
            overlapburst{i,1}.number_of_bursts=overlapburst{i,1}.number_of_bursts'; %flip everything for the table
        end
        
        for i=1:length(overlap)
            if sum(strcmp(fieldnames(overlapburst{i,1}), 'spikes_in_bursts')) == 1
                overlapburst{i,1}.spikes_in_bursts=overlapburst{i,1}.spikes_in_bursts'; %flip everything for the table
            else
            end
        end
        
        for i=1:length(overlap)
            if sum(strcmp(fieldnames(overlapburst{i,1}), 'duration_of_bursts')) == 1
                overlapburst{i,1}.duration_of_bursts=overlapburst{i,1}.duration_of_bursts'; %flip everything for the table
            else
            end
        end
        
        clear mona
        
        %get the firing frequency (Hz) per burst per electrode
        
        fr_of_bursts = zeros(1,length(overlap))';
        for i = 1:length(overlap)
            if isempty(overlapburst{i}.number_of_bursts)
                overlapburst{i}.fr_of_bursts = [];
            else
                for j = 1:length(overlapburst{i}.spikes_in_bursts)
                    overlapburst{i}.fr_of_bursts(j) = overlapburst{i}.spikes_in_bursts(j)/ overlapburst{i}.duration_of_bursts(j);
                    overlapburst{i}.fr_of_bursts = overlapburst{i}.fr_of_bursts';
                end
            end
        end
        
        
        %get the mean ISI of the spikes inside of a burst
        %the timings are located in burst6 for max interval
        
        
        mISIbursts = cell(1,length(overlap));
        for i=1:length(overlap)
            if isempty(overlapburst{i}.number_of_bursts)
                mISIbursts{i} = 0;
            else
                mISIbursts{i} = cellfun(@diff,overlap{i},'UniformOutput',0);
            end
            
        end
        
        
        mISIbursts=cell(1,length(overlap))'; %contains the average ISI of the bursts in each electrode
        for i=1:length(overlap)
            mISIbursts{i}=zeros(1,length(overlap{i}));
            if isempty(overlapburst{i}.number_of_bursts)
                mISIbursts{i} = 0;
            else
                for j = 1:length(overlap{i})
                    mISIbursts{i}(j) = mean(diff(cell2mat(overlap{i}(j))));
                    overlapburst{i}.mean_ISI_bursts = mISIbursts{i}';
                end
            end
        end
        
        clear mISIbursts
        
        stdISIbursts=cell(1,length(overlap))'; %contains the std of the ISI of  bursts in each electrode
        for i=1:length(overlap)
            stdISIbursts{i}=zeros(1,length(overlap{i}));
            if isempty(overlapburst{i}.number_of_bursts)
                stdISIbursts{i} = 0;
            else
                for j = 1:length(overlap{i})
                    stdISIbursts{i}(j) = std(diff(cell2mat(overlap{i}(j))));
                    overlapburst{i}.std_ISI_bursts = stdISIbursts{i}';
                end
            end
        end
        
        clear stdISIbursts
        
        %calculate the IBI
        
        IBI2=[];
        for i =1:length(overlap)
            if isempty(overlap{i})
                continue
            else
                for j =1:length(overlap{i})-1
                    IBI = overlap{i}{j+1}(1) - overlap{i}{j}(end);
                    IBI2=[IBI2,IBI];
                end
            end
            overlapburst{i}.IBI = IBI2';  %this contains all the IBI's per electrode
            IBI2 =[];
        end
        

 clear IBI2



end

%Panel for buttons
function uipanel12_CreateFcn(hObject, eventdata, handles)
global Imax filteredData1 X2 correctchannel overlap INDEX2 channel963 M2 M88 burst6 cbx98  cbx99  cbx169  dx ax burst7 RMS7 cbx109 cbx119 cbx129 cbx139 cbx159

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.009 .009 .806 .224];
x=X2;
y=filteredData1(INDEX2,:);

%% the actual buttons
% Create a check box to diplay detected spikes
cbx109 = uicontrol(hObject,'Style','checkbox','Position',[10 207 200 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx109.String = 'Display Detected Spikes';
cbx109.FontSize = 8;
cbx109.BackgroundColor = [1 1 1];

% Create a check box to diplay thresholds
cbx119 = uicontrol(hObject,'Style','checkbox','Position',[10 187 200 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx119.String = 'Display Detected Thresholds';
cbx119.FontSize = 8;
cbx119.BackgroundColor = [1 1 1];

% Create a check box to diplay log ISI detected bursts
cbx129 = uicontrol(hObject,'Style','checkbox','Position',[10 167 300 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx129.String = 'Display Detected log ISI single channel bursts';
cbx129.FontSize = 8;
cbx129.BackgroundColor = [1 1 1];

% Create a check box to diplay max interval detected bursts
cbx139 = uicontrol(hObject,'Style','checkbox','Position',[10 147 300 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx139.String = 'Display Detected Max interval single channel bursts';
cbx139.FontSize = 8;
cbx139.BackgroundColor = [1 1 1];
%% network burst related buttons
% Create a check box to diplay single channel bursts in rasterplot:
cbx98 = uicontrol(hObject,'Style','checkbox','Position',[10 107 250 15],...
    'Callback',@(cbx,event) cBoxChanged1(cbx));
cbx98.String = 'Display Single Channel Bursts';
cbx98.BackgroundColor = [1 1 1];

% title('Rasterplot of all the Spike Activity and Array wide firing rate','Fontsize',30);

% Create a check box to diplay network bursts in rasterplot:
cbx99 = uicontrol(hObject,'Style','checkbox','Position',[10 87 250 15],...
    'Callback',@(cbx,event) cBoxChanged1(cbx));
cbx99.String = 'Display Network Spikes';
cbx99.BackgroundColor = [1 1 1];

cbx159 = uicontrol(hObject,'Style','checkbox','Position',[10 67 250 15],...
    'Callback',@(cbx,event) cBoxChanged1(cbx));
cbx159.String = 'Display Network Burst Detection';
cbx159.BackgroundColor = [1 1 1];


cbx169 = uicontrol(hObject,'Style','checkbox','Position',[10 127 250 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx169.String = 'Display Detected Overlapping Bursts';
cbx169.BackgroundColor = [1 1 1];
%%
cbx109.Visible = 'off';
cbx119.Visible = 'off';
cbx129.Visible = 'off';
cbx139.Visible = 'off';
cbx98.Visible = 'off';
cbx99.Visible = 'off';
cbx159.Visible = 'off';
cbx169.Visible = 'off';

slidec = uicontrol(hObject,'Style','edit','Position',[1000 107 50 25],...
    'Callback',@(cbx,event) Temp_call(cbx));
slidec.String = '1';
slidec.FontSize = 8;
slidec.BackgroundColor = [1 1 1];
slidec.Visible ='off';

%% callback functions for the buttons
    function Temp_call(src,~)
        str=get(src,'String');
        if isempty(str2double(str))
            set(src,'string','0');
            warndlg('Input must be numerical');
        else
            dx = str2double(src.String);
        end
    end

% will have to make a if statement for all possible combinations later

    function Changed1(source,~)
        
        
        x=X2;
        y=filteredData1(INDEX2,:);
        if source.Value == 1 && strcmp(source.String,'Display Detected Spikes')
            hold(ax,'on')
            if isempty(M88{INDEX2}) || length(M88{INDEX2}) < 10
            else
                plot(ax,M2{INDEX2},M88{INDEX2},'.','Color',[0 0 0]);
            end
        elseif cbx109.Value == 1 && cbx119.Value == 1 && cbx129.Value == 1 && cbx139.Value == 0
            cla(ax)
            plot(ax,x,y);
            hold(ax,'on')
            if isempty(M88{INDEX2}) || length(M88{INDEX2}) < 10
            else
                plot(ax,M2{INDEX2},M88{INDEX2},'.','Color',[0 0 0]);
            end
            hold(ax,'on')
            plot(ax,X2,RMS7(INDEX2,1)*ones(length(X2),1)','k');
            hold(ax,'on')
            plot(ax,X2,-RMS7(INDEX2,1)*ones(length(X2),1)','k');
            hold(ax,'on')
            channel963=filteredData1(INDEX2,:);
            for i=1:length(burst7{INDEX2,1})
                plot(ax,X2(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold(ax,'on')
            end
            
        elseif  cbx109.Value == 1 && cbx119.Value == 1 && cbx129.Value == 0 && cbx139.Value == 1
             cla(ax)
            plot(ax,x,y);
            hold(ax,'on')
            if isempty(M88{INDEX2}) || length(M88{INDEX2}) < 10
            else
                plot(ax,M2{INDEX2},M88{INDEX2},'.','Color',[0 0 0]);
            end
            hold(ax,'on')
            plot(ax,X2,RMS7(INDEX2,1)*ones(length(X2),1)','k');
            hold(ax,'on')
            plot(ax,X2,-RMS7(INDEX2,1)*ones(length(X2),1)','k');
            hold(ax,'on')
            channel963=filteredData1(INDEX2,:);
            for i=1:length(burst6{INDEX2,1})
                plot(ax,X2(find(X2 == burst6{INDEX2,1}{1,i}(1,1)): find(X2 == burst6{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst6{INDEX2,1}{1,i}(1,1)): find(X2 == burst6{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold(ax,'on')
            end
        elseif source.Value == 0 && strcmp(source.String,'Display Detected Spikes')
            cla(ax)
            hold(ax,'on')
            plot(ax,x,y);
        elseif source.Value == 1 && strcmp(source.String,'Display Detected Thresholds')
            hold(ax,'on')
            plot(ax,X2,RMS7(INDEX2,1)*ones(length(X2),1)','k');
            hold(ax,'on')
            plot(ax,X2,-RMS7(INDEX2,1)*ones(length(X2),1)','k');
        elseif source.Value == 0 && strcmp(source.String,'Display Detected Thresholds')
            cla(ax)
            hold(ax,'on')
            plot(ax,x,y);
        elseif source.Value == 1 && strcmp(source.String,'Display Detected Spikes') && cbx119.Value == 1 || source.Value == 1 && strcmp(source.String,'Display Detected Thresholds') && cbx109.Value == 1
            hold(ax,'on')
            plot(ax,M2{Imax},M88{INDEX2},'.','Color',[0 0 0]);
            hold(ax,'on')
            plot(ax,X2,RMS7(INDEX2,1)*ones(length(X2),1)','k');
            hold(ax,'on')
            plot(ax,X2,-RMS7(INDEX2,1)*ones(length(X2),1)','k');
        elseif source.Value == 0 && strcmp(source.String,'Display Detected Spikes') && cbx119.Value == 0 || source.Value == 0 && strcmp(source.String,'Display Detected Thresholds') && cbx119.Value == 0
            cla(ax)
            hold(ax,'on')
            plot(ax,x,y);
        elseif cbx109.Value == 1 && cbx119.Value == 0
            cla(ax)
            hold(ax,'on')
            plot(ax,x,y)
            hold(ax,'on')
            plot(ax,M2{INDEX2},M88{INDEX2},'.','Color',[0 0 0]);
        elseif cbx109.Value == 0 && cbx119.Value == 1
            cla(ax)
            hold(ax,'on')
            plot(ax,x,y)
            hold(ax,'on')
            plot(ax,X2,RMS7(INDEX2,1)*ones(length(X2),1)','k');
            hold(ax,'on')
            plot(ax,X2,-RMS7(INDEX2,1)*ones(length(X2),1)','k');
        elseif cbx129.Value == 1 && cbx139.Value == 0
            cla(ax)
            plot(ax,x,y);
            hold(ax,'on')
            channel963=filteredData1(INDEX2,:);
            for i=1:length(burst7{INDEX2,1})
                plot(ax,X2(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold(ax,'on')
            end
        elseif cbx139.Value == 1 && cbx129.Value == 0
            cla(ax)
            plot(ax,x,y);
            hold(ax,'on')
            channel963=filteredData1(INDEX2,:);
            for i=1:length(burst6{INDEX2,1})
                plot(ax,X2(find(X2 == burst6{INDEX2,1}{1,i}(1,1)): find(X2 == burst6{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst6{INDEX2,1}{1,i}(1,1)): find(X2 == burst6{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold(ax,'on')
            end
        elseif cbx139.Value == 0 && cbx129.Value == 0 && cbx169.Value == 0
            cla(ax)
            plot(ax,x,y);
        elseif cbx129.Value == 1 && cbx139.Value == 0
            hold(ax,'on')
            channel963=filteredData1(INDEX2,:);
            for i=1:length(burst7{INDEX2,1})
                plot(ax,X2(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),'Color',[0 1 0]);
                hold(ax,'on')
            end
            
        elseif cbx129.Value == 1 && cbx139.Value == 1
            cla(ax)
            plot(ax,x,y);
            hold(ax,'on')
            channel963=filteredData1(INDEX2,:);
            for i=1:length(burst6{INDEX2,1})
                plot(ax,X2(find(X2 == burst6{INDEX2,1}{1,i}(1,1)): find(X2 == burst6{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst6{INDEX2,1}{1,i}(1,1)): find(X2 == burst6{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold(ax,'on')
            end
            hold(ax,'on')
            channel963=filteredData1(INDEX2,:);
            for i=1:length(burst7{INDEX2,1})
                plot(ax,X2(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),channel963(find(X2 == burst7{INDEX2,1}{1,i}(1,1)): find(X2 == burst7{INDEX2,1}{1,i}(end))),'Color',[0 1 0]);
                hold(ax,'on')
            end
  
        elseif cbx169.Value == 1
       
            cla(ax)
            plot(ax,x,y);
            hold(ax,'on')
            channel963=filteredData1(INDEX2,:);
            
            for i=1:length(overlap{INDEX2,1})
                plot(ax,X2(find(X2 == overlap{INDEX2,1}{1,i}(1,1)): find(X2 == overlap{INDEX2,1}{1,i}(end))),channel963(find(X2 == overlap{INDEX2,1}{1,i}(1,1)): find(X2 == overlap{INDEX2,1}{1,i}(end))),'Color',[1 0 0]);
                hold(ax,'on')
            end
            
        elseif cbx169.Value == 0
            cla(ax)
            hold(ax,'on')
            plot(ax,x,y);
        end
    end

end

% --- Switch view button
function pushbutton43_Callback(hObject, eventdata, handles)
global cbx98 fs X2 filteredData1 cbx99 xpoints parts Imax Totoro dx INDEX2 ypoints xPoints yPoints ends2 h cbx169 starts2 tb cbx109 cbx119 cbx129 cbx139 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1 rrr ax cbx159
% after we selected the channel the correct well is loaded in 
if hObject.Value == 1 && isempty(hObject.UserData)
    %     cla(ax);
    %adapated from plotSPikeRaster by Jeffrey Chiou
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s =s/resolution; % to get the firing rate
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
    %Trim out the relevant portion of the spike density
    s = s(center:end-center-1);
%     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    t = (1:length(s))*resolution ;
    gg = subplot('position',[0.2 0.15 0.7 0.15],'Parent',handles.uipanel11);
    
    %     gg = subplot(ax,'position',[0.2 0.15 0.7 0.15]);
    %     hold(ax,'on');
    plot(gg,t,s,'k');
    xlim(gg,[0 timesss])
    ylim(gg,[0 max(s)])
    ylabel('AWFR (Hz)');
    xlabel('Time (s)','Fontsize',20);
    % set(gca,'XTick',[]);    % no x numbers
    correctxlim = get(gca,'XLim');
    [tb,~] = axtoolbar(gg,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    
    
    % calculate the rasterplot
    
    %     hold(ax,'on');
    yy = subplot('position',[0.2 0.35 0.7 0.6],'Parent',handles.uipanel11);
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        % Save points and update current index
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(yy,xPoints, yPoints, 'k')
    set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    title(['Well ',mat2str(ceil(Imax/12))])
    [tb,~] = axtoolbar(yy,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    
    %color the bursts in red for max interval method
    
    %allbursts contain all the indices of the bursts in a start followeed by
    %the end index of each burst
    % the xPoints vector are the time points of each spike sorted in a specific
    % manner each time point is represented double ending with a nan.
    %this means that one timepoint value of a spike corresponds with 3 spots
    %inteh xPoints vector
    burst6indx =burst6indx';
    
    % place them in the same configuration as the allbursts cell array
    
    maxbursts= [];
    
    max1bursts= cell(1,length(M2));
    for i = 1:length(burst6indx)
        for j= 1:length(burst6indx{i})
            maxbursts = [burst6indx{i}{j}(1),burst6indx{i}{j}(end)];
            max1bursts{i} = [max1bursts{i},maxbursts];
        end
        
    end
    max1bursts=max1bursts';
    
    max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
    % now lets make it easier to index in the xPoints vector by giving each
    % number the correct index so we can just index in the xPoints vector
    
    % the try and catch statements are only temp fix but need to take a
    % look att he code for max interval
    countold = 0;
    for i=1:length(max1bursts)
        try
            countnew = (length(M2{i})*3+countold);
            countold = countnew;
            if isempty(max1bursts{(i+1)})
            else
                for j = 1:length(max1bursts{(i+1)})
                    
                    max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                end
            end
        catch
        end
    end
    
    
    
    xlim(yy,[0 timesss]);
    xlim(gg,[0 timesss]);
    correctylim = ceil(Imax/12) * 12;
    correctylim = num2cell((correctylim - 12):2: correctylim+2);
    set(yy,'YTickLabel',correctylim)
    yy.YTickLabel{end} =[];
    linkaxes([gg yy],'x');
    ylabel('Channels','Fontsize',20);
    hObject.UserData = 1;
    
    h.Visible = 'off';
    cbx109.Enable = 'off';
    cbx119.Enable = 'off';
    cbx129.Enable = 'off';
    cbx139.Enable = 'off';
    cbx98.Enable = 'on';
    cbx99.Enable = 'off';
    cbx159.Enable = 'on';
    cbx169.Enable = 'off';
    hObject.String = 'Return View';
    handles.pushbutton45.Enable = 'off';
    handles.pushbutton44.Enable = 'off';
    handles.pushbutton42.Enable = 'off';
    handles.pushbutton47.Enable = 'off';
elseif hObject.Value == 1 && hObject.UserData == 1
    x=X2;
    y=filteredData1(INDEX2,:);
    
    
    
    delete(handles.uipanel11.Children(2));
    delete(handles.uipanel11.Children(1));
    ax = axes(handles.uipanel11);
    
    plot(ax,x,y);
    axes1 = gca;
    Xlim11=axes1.XLim;
    Ylim11=axes1.YLim;
    
    
    ylabel(ax,'Microvolts');
    xlabel(ax,'Time(s)');
    % xlabel('Time in seconds');
    % title(['Channel ', HITS{Imax}]);
    set(axes1,'Fontsize',10);
    
    % Set appropriate axis limits and settings
    set(gcf,'doublebuffer','on');
    [tb,~] = axtoolbar(ax,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    % This avoids flickering when updating the axis
    set(axes1,'xlim',[0 dx]); % window
    % find the values that is the largest for the axis and set the limit to the
    % highest
    
    if abs(min(y)) > max(y)
        set(axes1,'ylim',[min(y) abs(min(y))]);
    else
        set(axes1,'ylim',[-max(y) max(y)]);
    end
    axes1.XLim = Xlim11;
    axes1.YLim = Ylim11;
    
    %% display the buttons in uipanel12
    
    cbx109.Enable = 'on';
    cbx119.Enable = 'on';
    cbx129.Enable = 'on';
    cbx139.Enable = 'on';
    cbx98.Enable =  'off';
    cbx99.Enable =  'off';
    cbx159.Enable = 'off';
    cbx169.Enable = 'on';
    
    cbx109.Visible = 'on';
    cbx119.Visible = 'on';
    cbx129.Visible = 'on';
    cbx139.Visible = 'on';
    cbx98.Visible =  'on';
    cbx99.Visible =  'on';
    cbx159.Visible = 'on';
    cbx169.Visible = 'on';
    
    set(handles.Pannel_25.Text,'String',strjoin(['Channel', Totoro]));
    hObject.UserData = [];
    hObject.String = 'Switch View';
    handles.pushbutton45.Enable = 'on';
    handles.pushbutton44.Enable = 'on';
    handles.pushbutton42.Enable = 'on';
    handles.pushbutton47.Enable = 'on';
    %     uipanel11_CreateFcn(handles.uipanel11, eventdata, handles)
end

end

% --- 
function pushbutton43_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.755 0.096 0.048];
hObject.Visible = 'off';
hObject.String = 'Switch View';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.92 0.89 0.655];
hObject.FontWeight = 'bold';
end

% --- Rerun SCB detection
function pushbutton44_Callback(hObject, eventdata, handles)
global pushed ax pushed1 text2 text1 text3 text6 text7 text8 text9 text10 edit8 edit9 edit10 edit6 edit7 push1 push2 push3 push4 push5 text4 text5 edit1 edit2 edit3 edit4 edit5 filteredData1 X2 maxinterval INDEX2 dx logISI Imax cbox1 cbox2 Exburst Exburstold logburstold logburst burst6 burst6old burst7old burst7 cbx109 cbx119 cbx129 cbx139 cbx98 cbx99 cbx159 cbx169
% first we need to present a new screen that allows the user to choose what
% to rerun and what  kind of parameters the user can change
pushed = 1;
pushed1 = 1;
logISI = 0;
maxinterval =0;
burst6old=burst6;
burst7old=burst7;
logburstold=logburst;
Exburstold=Exburst;
push1.Visible ='off';
push2.Visible ='off';
push3.Visible ='off';
push4.Visible ='off';
push5.Visible ='off';
edit8.Visible ='off';
edit9.Visible ='off';
edit10.Visible ='off';
text8.Visible ='off';
text9.Visible ='off';
text10.Visible = 'off';
% run('parameters1')
if hObject.Value == 1 && isempty(hObject.UserData)
    hObject.String = 'Finish Burst Detection';
    %     gg = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    %     yy = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    gg = subplot('position',[0.2 0.15 0.7 0.15],'Parent',handles.uipanel11); hold on;
    yy = subplot('position',[0.2 0.35 0.7 0.6],'Parent',handles.uipanel11); hold on;
    set(cbx98,'Visible','off');
    cbx99.Visible = 'off';
    cbx109.Visible = 'off';
    cbx119.Visible = 'off';
    cbx129.Visible = 'off';
    cbx139.Visible = 'off';
    cbx159.Visible = 'off';
    cbx169.Visible = 'off';
    handles.uipanel12.Visible = 'off';
    handles.uipanel20.Visible = 'on';
    hObject.UserData = 2;
    handles.pushbutton45.Enable = 'off';
    handles.pushbutton43.Enable = 'off';
    handles.pushbutton42.Enable = 'off';
    handles.pushbutton47.Enable = 'off';
    handles.pushbutton48.Enable = 'off';
   
elseif hObject.Value == 1 && hObject.UserData == 2
    hObject.String = 'Rerun Burst Detection';
    %     uipanel11_ButtonDownFcn(handles.uipanel11, eventdata, handles)
    x=X2;
    y=filteredData1(INDEX2,:);
    
    delete(handles.uipanel11.Children(2));
    delete(handles.uipanel11.Children(1));
    ax = axes(handles.uipanel11);
    
    plot(ax,x,y);
    axes1 = gca;
    Xlim11=axes1.XLim;
    Ylim11=axes1.YLim;
    
    
    ylabel(ax,'Microvolts');
    xlabel(ax,'Time(s)');
    % xlabel('Time in seconds');
    % title(['Channel ', HITS{Imax}]);
    set(axes1,'Fontsize',10);
    
    % Set appropriate axis limits and settings
    set(gcf,'doublebuffer','on');
    [tb,~] = axtoolbar(ax,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    % This avoids flickering when updating the axis
    set(axes1,'xlim',[0 dx]); % window
    % find the values that is the largest for the axis and set the limit to the
    % highest
    
    if abs(min(y)) > max(y)
        set(axes1,'ylim',[min(y) abs(min(y))]);
    else
        set(axes1,'ylim',[-max(y) max(y)]);
    end
    axes1.XLim = Xlim11;
    axes1.YLim = Ylim11;
    
    cbx98.Visible = 'on';
    cbx99.Visible = 'on';
    cbx109.Visible = 'on';
    cbx119.Visible = 'on';
    cbx129.Visible = 'on';
    cbx139.Visible = 'on';
    cbx159.Visible = 'on';
    cbx169.Visible = 'on';
    
    cbx109.Enable = 'on';
    cbx119.Enable = 'on';
    cbx129.Enable = 'on';
    cbx139.Enable = 'on';
    cbx98.Enable =  'off';
    cbx99.Enable =  'off';
    cbx159.Enable = 'off';
    cbx169.Enable = 'on';
    
    handles.uipanel12.Visible = 'on';
    handles.uipanel20.Visible = 'off';
    hObject.UserData = [] ;
    handles.pushbutton45.Enable = 'on';
    handles.pushbutton43.Enable = 'on';
    handles.pushbutton42.Enable = 'on';
    handles.pushbutton47.Enable = 'on';
     handles.pushbutton48.Enable = 'on';

    % reset buttons to zero when finish burst detection is pressed
    if cbox1.Value == 1
        cbox1.Value = 0;
        cbox2.Enable = 'on';
        
       
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        edit6.Enable = 'off';
        edit7.Enable = 'off';
        
        
    end
    if cbox2.Value == 1
        cbox2.Value  = 0 ;
        cbox1.Enable = 'on';
       
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        edit6.Enable = 'off';
        edit7.Enable = 'off';
        
    end
end




end

% ---
function pushbutton44_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.678 0.096 0.048];
hObject.Visible = 'off';
hObject.String = 'Rerun Burst Detection';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.92 0.89 0.655];
hObject.FontWeight = 'bold';
end

% --- Rerun network burst detection
function pushbutton45_Callback(hObject, eventdata, handles)
% global axes1 axes2 axes3 axes4 timesss Xlim11 Ylim11
global pushed ax pushed1 text2 text1 text3 text6 text7 cbox101 edit8 edit9 edit10 text8 text9 text10 networkburstttt networkbursttttold push1 push5 edit6 edit7 text4 text5 edit1 edit2 edit3 edit4 edit5 filteredData1 X2 maxinterval INDEX2 dx logISI Imax cbox1 cbox2 Exburst Exburstold logburstold logburst burst6 burst6old burst7old burst7 cbx109 cbx119 cbx129 cbx139 cbx98 cbx99 cbx159 cbx169
pushed = 1;
pushed1 = 1;
logISI = 0;
maxinterval =0;
burst6old=burst6;
burst7old=burst7;
logburstold=logburst;
Exburstold=Exburst;
networkbursttttold = networkburstttt;
edit8.Visible ='on';
edit9.Visible ='on';
edit10.Visible ='on';
text8.Visible ='on';
text9.Visible ='on';
text10.Visible = 'on';
% run('parameters1')
if hObject.Value == 1 && isempty(hObject.UserData)
    hObject.String = 'Finish Network Burst Detection';
    %     gg = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    %     yy = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    gg = subplot('position',[0.2 0.15 0.7 0.15],'Parent',handles.uipanel11); hold on;
    yy = subplot('position',[0.2 0.35 0.7 0.6],'Parent',handles.uipanel11); hold on;
    set(cbx98,'Visible','off');
    push1.Visible = 'off';
    push5.Visible ='off';
    cbx99.Visible = 'off';
    cbx109.Visible = 'off';
    cbx119.Visible = 'off';
    cbx129.Visible = 'off';
    cbx139.Visible = 'off';
    cbx159.Visible = 'off';
    cbx169.Visible = 'off';
    handles.uipanel12.Visible = 'off';
    handles.uipanel20.Visible = 'on';
    hObject.UserData = 2;
    handles.pushbutton44.Enable = 'off';
    handles.pushbutton43.Enable = 'off';
    handles.pushbutton42.Enable = 'off';
    handles.pushbutton47.Enable = 'off';
    handles.pushbutton48.Enable = 'off';
    edit2.Visible = 'off';
    edit1.Visible = 'off';
    edit3.Visible = 'off';
    edit4.Visible = 'off';
    edit5.Visible = 'off';
    edit6.Visible = 'off';
    edit7.Visible = 'off';
    text1.Visible = 'off';
    text2.Visible = 'off';
    text3.Visible = 'off';
    text4.Visible = 'off';
    text5.Visible = 'off';
    text6.Visible = 'off';
    text7.Visible = 'off';
    cbox101.Visible = 'on';
elseif hObject.Value == 1 && hObject.UserData == 2
    hObject.String = 'Rerun Network Burst Detection';
    push1.Visible ='on';
    push5.Visible ='off';
    %     uipanel11_ButtonDownFcn(handles.uipanel11, eventdata, handles)
    x=X2;
    y=filteredData1(INDEX2,:);
    
    delete(handles.uipanel11.Children(2));
    delete(handles.uipanel11.Children(1));
    ax = axes(handles.uipanel11);
    
    plot(ax,x,y);
    axes1 = gca;
    Xlim11=axes1.XLim;
    Ylim11=axes1.YLim;
    
    
    ylabel(ax,'Microvolts');
    xlabel(ax,'Time(s)');
    % xlabel('Time in seconds');
    % title(['Channel ', HITS{Imax}]);
    set(axes1,'Fontsize',10);
    
    % Set appropriate axis limits and settings
    set(gcf,'doublebuffer','on');
    [tb,~] = axtoolbar(ax,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    % This avoids flickering when updating the axis
    set(axes1,'xlim',[0 dx]); % window
    % find the values that is the largest for the axis and set the limit to the
    % highest
    
    if abs(min(y)) > max(y)
        set(axes1,'ylim',[min(y) abs(min(y))]);
    else
        set(axes1,'ylim',[-max(y) max(y)]);
    end
    axes1.XLim = Xlim11;
    axes1.YLim = Ylim11;
    
    cbx98.Visible = 'on';
    cbx99.Visible = 'on';
    cbx109.Visible = 'on';
    cbx119.Visible = 'on';
    cbx129.Visible = 'on';
    cbx139.Visible = 'on';
    cbx159.Visible = 'on';
    cbx169.Visible = 'on';
    
    cbx109.Enable = 'on';
    cbx119.Enable = 'on';
    cbx129.Enable = 'on';
    cbx139.Enable = 'on';
    cbx98.Enable =  'off';
    cbx99.Enable =  'off';
    cbx159.Enable = 'off';
    cbx169.Enable = 'on';
    
    handles.uipanel12.Visible = 'on';
    handles.uipanel20.Visible = 'off';
    hObject.UserData = [] ;
    handles.pushbutton44.Enable = 'on';
    handles.pushbutton43.Enable = 'on';
    handles.pushbutton42.Enable = 'on';
    handles.pushbutton47.Enable = 'on';
    handles.pushbutton48.Enable = 'on';
    edit2.Visible = 'on';
    edit1.Visible = 'on';
    edit3.Visible = 'on';
    edit4.Visible = 'on';
    edit5.Visible = 'on';
    edit6.Visible = 'on';
    edit7.Visible = 'on';
    text1.Visible = 'on';
    text2.Visible = 'on';
    text3.Visible = 'on';
    text4.Visible = 'on';
    text5.Visible = 'on';
    text6.Visible = 'on';
    text7.Visible = 'on';
    cbox101.Visible= 'off';
    % reset buttons to zero when finish burst detection is pressed
    if cbox1.Value == 1
        cbox1.Value = 0;
        cbox2.Enable = 'on';
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        edit6.Enable = 'off';
        edit7.Enable = 'off';
    end
    if cbox2.Value == 1
        cbox2.Value  = 0 ;
        cbox1.Enable = 'on';
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        edit6.Enable = 'off';
        edit7.Enable = 'off';
    end
    
    if cbox101.Value == 1
        cbox1.Value = 0;
        cbox1.Enable = 'off';
        cbox2.Value = 0;
        cbox2.Enable = 'off';
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        edit6.Enable = 'off';
        edit7.Enable = 'off';
    end
    
end
% handles.uipanel11.Children.XLim = Xlim11;
% handles.uipanel11.Children.YLim = Ylim11;

end

% --- 
function pushbutton45_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.601 0.096 0.048];
hObject.Visible = 'off';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.92 0.89 0.655];
hObject.String = 'Rerun Network Burst Detection';
hObject.FontWeight = 'bold';
end

% --- Data cursor mode
function pushbutton46_Callback(hObject, eventdata, handles)

if hObject.Value == 1 && isempty(hObject.UserData)
    datacursormode on
    hObject.UserData = 1;
else
    datacursormode off
    hObject.UserData = [];
end

end

% --- 
function pushbutton46_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.524 0.096 0.048];
hObject.Visible = 'off';
hObject.String = 'Data Cursor Mode';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.92 0.89 0.655];
hObject.FontWeight = 'bold';
end

% --- Zoom in to specific bursts
function pushbutton47_Callback(hObject, eventdata, handles)
global yutp timesss axes1 axes2 axes3 burst6 burst7 X2 Imax axes4 INDEX2 filteredData1

prompt = {'Enter Burstnumber to zoom in     0 = Zoom Out','Select Burst method         1 = Max interval     2 = log ISI'};
title = 'Zoom in Bursts' ;
dims = [1 75];
definput = {'1','1'};
yutp = inputdlg(prompt,title,dims,definput);


if isempty(yutp)
    return
end

% check if there are any bursts

    if str2double(yutp{1}) == 0 && timesss > 100
        handles.uipanel11.Children.XLim = [0 timesss];
        handles.uipanel11.Children.YLim = [min(filteredData1(INDEX2,:))  max(filteredData1(INDEX2,:))];
        %     axes2.XLim = [0 300];
        %     axes2.YLim = [-300 300];
        %     axes3.XLim = [0 300];
        %     axes3.YLim = [-300 300];
        %     axes4.XLim = [0 300];
        %     axes4.YLim = [-300 300];
    elseif str2double(yutp{1}) == 0 && timesss < 100
        handles.uipanel11.Children.XLim = [0 timesss];
        handles.uipanel11.Children.YLim = [min(filteredData1(INDEX2,:))  max(filteredData1(INDEX2,:))];
        %     axes2.XLim = [0 60];
        %     axes2.YLim = [-300 300];
        %     axes3.XLim = [0 60];
        %     axes3.YLim = [-300 300];
        %     axes4.XLim = [0 60];
        %     axes4.YLim = [-300 300];
    elseif str2double(yutp{1}) >= 1 && str2double(yutp{2}) == 1
        % check if burst 7 has some bursts else switch to burst6
        if isempty(burst6{INDEX2})
            errordlg('There are no bursts found!','Error');
        else
            handles.uipanel11.Children.XLim=[(X2(find(X2 == burst6{INDEX2,1}{1,str2double(yutp{1})}(1,1)))-0.2) (X2(find(X2 == burst6{INDEX2,1}{1,str2double(yutp{1})}(end)))+0.2)];
        end
        
    elseif  str2double(yutp{1}) >= 1 && str2double(yutp{2}) == 2
        if isempty(burst7{INDEX2})
            errordlg('There are no bursts found!','Error');
        else
            handles.uipanel11.Children.XLim=[(X2(find(X2 == burst7{INDEX2,1}{1,str2double(yutp{1})}(1,1)))-0.2) (X2(find(X2 == burst7{INDEX2,1}{1,str2double(yutp{1})}(end)))+0.2)];
        end
        %     axes2.XLim=[(X2(find(X2 == burst6{Imax,1}{1,yutp}(1,1)))-0.2) (X2(find(X2 == burst6{Imax,1}{1,yutp}(end)))+0.2)];
        %     axes3.XLim=[(X2(find(X2 == burst6{Imax,1}{1,yutp}(1,1)))-0.2) (X2(find(X2 == burst6{Imax,1}{1,yutp}(end)))+0.2)];
        %     axes4.XLim=[(X2(find(X2 == burst6{Imax,1}{1,yutp}(1,1)))-0.2) (X2(find(X2 == burst6{Imax,1}{1,yutp}(end)))+0.2)];
        %
    end

end

% --- 
function pushbutton47_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.333 0.096 0.048];
hObject.Visible = 'off';
hObject.String = 'Zoom in Bursts';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.92 0.89 0.655];
hObject.FontWeight = 'bold';

end


% ---  statistics
function pushbutton48_Callback(hObject, eventdata, handles)
global burstsinfor Imax networkburstttt Exburst logburst overlapburst table1 Tablennbursts table4 table2 table5 table3 table681 Table680 Table139 Table679 Exburst1 INDEX2



%check if there are any bursts if not disp error

if isempty(Exburst{INDEX2}.fr_of_bursts)
    errordlg('There are no bursts found!','Error');
else
figure('units','normalized','outerposition',[0 0 1 1]);
fig = gcf;
set(gcf,'color','white')

% networkbursts
networkbursttable = networkburstttt;
networkbursttable.amount = 1:networkbursttable.amount;
networkbursttable.networkburstnumber = networkbursttable.amount';
networkbursttable  = rmfield(networkbursttable,'amount');
networkbursttable  = rmfield(networkbursttable,'nburst_rate');
networkbursttable  = rmfield(networkbursttable,'CVIBI');
P = [7 1 2 3 4 5 6 ];
networkbursttable = orderfields(networkbursttable,P);
% change the orientation of the fr_of_bursts

if size(Exburst{INDEX2}.fr_of_bursts,1) == 1
    Exburst{INDEX2}.fr_of_bursts = Exburst{INDEX2}.fr_of_bursts';
end

if size(logburst{INDEX2}.fr_of_bursts,1) == 1
    logburst{INDEX2}.fr_of_bursts = logburst{INDEX2}.fr_of_bursts';
end

if size(overlapburst{INDEX2}.fr_of_bursts,1) == 1
    overlapburst{INDEX2}.fr_of_bursts = overlapburst{INDEX2}.fr_of_bursts';
end


%remove the IBI field because its not the same lengh for now

Exburst1= rmfield(Exburst{INDEX2},'IBI');
overlapburst1= rmfield(overlapburst{INDEX2},'IBI');
Tablennbursts = struct2table(networkbursttable);
Table680=struct2table(logburst{INDEX2});
Table679=struct2table(Exburst1);
table681=struct2table(overlapburst1);
% Table139=struct2table(burstsinfor{INDEX2,1});

% % table1 = uitable('Parent', fig, 'Units', 'normal', 'Position', [0 .05 1/4 .9], 'Data', Table139{:,:},'ColumnName',Table139.Properties.VariableNames,...
%     'RowName',Table139.Properties.RowNames);
% text(-0.08, 1.06,'Statistics of BD Bursts')
table2 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/10 .05 1/5 .9], 'Data', Table679{:,:},'ColumnName',Table679.Properties.VariableNames,...
    'RowName',Table679.Properties.RowNames);
text(0.03, 1.06,'Statistics of Max Interval Bursts')
table3 = uitable('Parent', fig, 'Units', 'normal', 'Position', [3/10 .05 1/5 .9], 'Data', Table680{:,:},'ColumnName',Table680.Properties.VariableNames,...
    'RowName',Table680.Properties.RowNames);
text(0.28, 1.06,'Statistics of log ISI Bursts')
table5 = uitable('Parent', fig, 'Units', 'normal', 'Position', [5/10 .05 1/5 .9], 'Data', table681{:,:},'ColumnName',table681.Properties.VariableNames,...
    'RowName',table681.Properties.RowNames);
text(0.55, 1.06,'Statistics of Overlapping Bursts')
table4 = uitable('Parent', fig, 'Units', 'normal', 'Position', [7/10 .05 1/5 .9], 'Data', Tablennbursts{:,:},'ColumnName',Tablennbursts.Properties.VariableNames,...
    'RowName',Tablennbursts.Properties.RowNames);
text(0.8, 1.06,'Statistics of Network Bursts')


set(gca,'visible','off')
% 
% c = uicontrol;
% c.Position = [1535,888,175,67];
% c.FontWeight = 'bold';
% c.ForegroundColor = [0.861,0.832,0.096,0.048];
% c.CData = imread('color_button.png');
% c.String = 'Save Table';
% c.Callback = @savetable;
end

    function savetable(src,event)
        
        
        list = {'Save Table 1','Save Table 2','Save Table 3','Save Table 4'};
        [indx23,~] = listdlg('PromptString','Select which table to save','SelectionMode','single','ListString',list);
        if isempty(indx23)
            return
        else
            if indx23 == 4
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Tablennbursts,uiputfile(filter),'WriteRowNames',true);
            elseif indx23 == 1
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table679,uiputfile(filter),'WriteRowNames',true);
                
            elseif indx23 == 2
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table680,uiputfile(filter),'WriteRowNames',true);
            elseif indx23 == 3
                  filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(table681,uiputfile(filter),'WriteRowNames',true);
            end
        end
        
    end

end

% --- 
function pushbutton48_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.256 0.096 0.048];
hObject.Visible = 'off';
hObject.String = 'Statistics';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.92 0.89 0.655];
hObject.FontWeight = 'bold';

end

% --- 
function uipanel13_CreateFcn(hObject, eventdata, handles)
hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.009 .371 .806 .119];
end


% --- 
function uipanel14_CreateFcn(hObject, eventdata, handles)
hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.009 .164 .806 .119];
end
%% Spikes Panel


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% global wellsflag
if hObject.Value == 1
    GMM_loaddata_wells
else
    GMM_loaddata
end

end

% --- Executes during object creation, after setting all properties.
function checkbox4_CreateFcn(hObject, eventdata, handles)
hObject.BackgroundColor = [.97,.98,.98];
set(hObject,'Visible', 'off');
hObject.String = 'Display Wells';
hObject.Position = [0.871 0.471 0.06 0.027];
end

% --- Executes during object creation, after setting all properties.
function uipanel15_CreateFcn(hObject, eventdata, handles)
global handles1 parameters

%The code is from B. C. Souza,
% Brain Institute, Natal, Brazil,
% Adapted to fit inside the toolbox


% maximum number of gaussians to fit in one dimension.
parameters.maxGauss         = 8;

% maximum number of iterations of (exp maximization) EM algorithm
parameters.optgmfit.max_iter    = 10000;
parameters.optgmfit.conv_factor = 1e-6;

% number of models to calculate to check robustness
parameters.nof_replicates	= 10;

% maximum number of gaussians to overfit in multidim space. 12 for
% single-wire. 20 for tetrodes.
parameters.ngaussovfit      = 12;


hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position = [0.01 0.037 0.398 0.358];
handles1.Figures.Waveforms.main = handles;
handles1=[];
handles1.chid = 0;
handles1.data.waveforms = {};

handles1.Figures.Waveforms.main = hObject;

handles1.Figures.Waveforms.LoadData = ...
    uicontrol ('Style', 'pushbutton', 'String', 'Load','Units','normalized',...
    'Position', ...
    [0.861 0.832 0.096 0.048],...
    'Callback', @GMM_loaddata,...
    'BackgroundColor', [0.343 0.465 0.575],'ForegroundColor', [0.992 0.89 0.655],'Visible','off','FontWeight','bold');
set(handles1.Figures.Waveforms.LoadData,'FontName','Arial')
set(handles1.Figures.Waveforms.LoadData,'fontsize',14,'CData',imread('color_button.png'))


handles1.Figures.Waveforms.SaveData = ...
    uicontrol ('Style', 'pushbutton', 'String', 'Save','Units','normalized',...
    'Position', ...
    [0.861 0.755 0.096 0.048],...
    'Callback', @GMM_savedata,...
    'BackgroundColor', [0.343 0.465 0.575],'ForegroundColor', [0.992 0.89 0.655],...
    'FontName','Arial',...
    'fontsize',14,'Visible','off','FontWeight','bold','CData',imread('color_button.png'));


maintextbox = [0.138 .494 .204 .039];
handles1.Figures.Waveforms.maintext = ...
    uicontrol('Style','text','Units','normalized',...
    'Position',...
    maintextbox,...
    'String','Please load some data... ',...
    'BackgroundColor', [1 1 1]*.99,...
    'ForegroundColor', [1 1 1]*0,...
    'horizontalAlignment', 'left',...
    'fontsize',15,'Visible','off');

positionaux = [0.8 .93 .19 .04];
handles1.Figures.Waveforms.filename = ...
    uicontrol('Style','text','Units','normalized',...
    'Position',...
    positionaux,...
    'String',' No file loaded. ',...
    'BackgroundColor', [1 1 1]*.99,...
    'ForegroundColor', [1 1 1]*0,...
    'horizontalAlignment', 'right',...
    'fontsize',15,'Visible','off');

handles1.Figures.Waveforms.ch_id_txtbox  = uicontrol('Style', 'text',...
    'Units','normalized',...
    'String','Ch id: ',...
    'Position', [.017 .494 .085 .039],...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'horizontalAlignment', 'left',...
    'fontsize',14, 'Visible' ,'off');

handles1.Figures.Waveforms.ch_id= ...
    uicontrol('Style', 'popup',...
    'Units','normalized',...
    'String', '-',...
    'Position', [.017 .494 .035 .039],...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'Callback',@GMM_setCHid,...
    'horizontalAlignment', 'center',...
    'fontsize',14,'Visible', 'off');

handles1.Figures.Waveforms.runSorting = uicontrol ('Style', 'pushbutton', ...
    'String', 'Run Sorting',...
    'Units','normalized',...
    'Position', ...
    [0.861 0.678 0.096 0.048],...
    'Callback', @GMM_runSorting,...
    'BackgroundColor', [0.343 0.465 0.575],'ForegroundColor', [0.992 0.89 0.655],...
    'fontsize',14, 'Visible' ,'off','FontWeight','bold','CData',imread('color_button.png'));




handles1.Figures.Waveforms.resetSorting = uicontrol ('Style', 'pushbutton', ...
    'String', 'Reset',...
    'Units','normalized',...
    'Position', ...
    [0.861 .256 .096 .048],...
    'Callback', @GMM_resetSorting,...
    'BackgroundColor', [0.343 0.465 0.575],'ForegroundColor', [0.992 0.89 0.655],...
    'fontsize',14,'Visible','off','FontWeight','bold','CData',imread('color_button.png'));



positionaux = [0.0825 0.8875 0.08 0.04];
positionaux(1) = sum(positionaux([1,3]))+0.01;
handles1.Figures.Waveforms.DispClustersTOGGLE = ...
    uicontrol('Style', 'togglebutton',...
    'Units','normalized',...
    'Position', [0.861 0.333 0.096 0.048],...
    'String','Clusters',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_ClusterDisplayONOFF,...
    'fontsize',14, 'Visible' ,'off',...
    'horizontalAlignment', 'center','FontWeight','bold');


positionaux(1) = sum(positionaux([1,3]))+0.02;
handles1.Figures.Waveforms.RunSortingAllchs = ...
    uicontrol('Style', 'pushbutton',...
    'Units','normalized',...
    'Position', [0.861 0.601 0.096 0.048],...
    'String','Run ALL Chs',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_SSallCHs,...
    'fontsize',14, 'Visible' ,'off',...
    'horizontalAlignment', 'center','FontWeight','bold','CData',imread('color_button.png'));



positionaux(1) = sum(positionaux([1,3]))+0.01;
% positionaux = [0.245 0.8875 0.07 0.04];
handles1.Figures.Waveforms.EditUnsorted = ...
    uicontrol('Style', 'pushbutton',...
    'Units','normalized',...
    'Position', [0.861 0.179 0.096 0.048],...
    'String','Edit Unsorted',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_EditUnsorted,...
    'fontsize',14,...
    'horizontalAlignment', 'center','Visible','off','FontWeight','bold','CData',imread('color_button.png'));


positionaux(1) = sum(positionaux([1,3]))+0.01;
% positionaux = [0.245 0.8875 0.07 0.04];
handles1.Figures.Waveforms.DiscardUnsorted = ...
    uicontrol('Style', 'pushbutton',...
    'Units','normalized',...
    'Position', [0.861 0.029 0.096 0.048],...
    'String','Discard Unsorted',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_DiscardUnsorted,...
    'fontsize',14,...
    'horizontalAlignment', 'center','Visible','off','FontWeight','bold','CData',imread('color_button.png'));

positionaux(1) = sum(positionaux([1,3]))+0.01;
% positionaux = [0.105+class_i*0.25 .875 .02 .026];
% positionaux=positionaux-positionmod;
handles1.Config.Plot = 1;
handles1.Figures.Waveforms.PlotAllTOGGLE = ...
    uicontrol('Style', 'togglebutton',...
    'String','Plot all waveforms',...
    'Value',handles1.Config.Plot,...
    'Units','normalized',...
    'Position', [0.861 0.102 0.096 0.048],...
    'BackgroundColor', [1 1 1],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_ChangePlotAll,...
    'horizontalAlignment', 'center','Visible','off','FontWeight','bold','CData',imread('color_button.png'));



positionaux1 = [0.01 0.54 0.398 0.358];
handles1.Figures.Waveforms.UnsortedPanel = ...
    uipanel('Title','Unsorted Waveforms','FontSize',13,...
    'BackgroundColor',[1 1 1]*.97,...
    'bordertype','etchedout',...
    'ShadowColor',[1 1 1]*.8,...
    'highlightcolor',[1 1 1]*.5,...
    'Position',positionaux1,'Visible' ,'off');


% positionaux = [0.025 .5 .18 .325];
positionaux = [0.08 .08 .9 .9];
handles1.Figures.Waveforms.unsortedspikes = ...
    axes('Parent',handles1.Figures.Waveforms.UnsortedPanel,'Position',positionaux);
subplot('Position',positionaux);



for class_i = 1:6
    
    
    if class_i<4
        positionmod=[0.03 0.03 0 0];
        
        %         positionaux = [0.05+class_i*0.25 .5 .22 .375];
        positionaux = [0.08+(class_i-1)*0.35 .6 .22 .375];
        positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.cluster{class_i} = ...
            axes('Parent',hObject,'Position',positionaux,'Visible','off');
        
        %         positionaux = [0.055+class_i*0.15 .4 .025 .026];
        %         positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.clusterNUMB{class_i} = ...
            uicontrol('Style', 'edit',...
            'Units','normalized',...
            'String', '',...
            'Position', [0.015+(class_i-1)*0.135 .36 .025 .026],...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeClusterNumber,...
            'horizontalAlignment', 'center','Visible','off');
        set(handles1.Figures.Waveforms.clusterNUMB{class_i},'String',...
            num2str(class_i))
        
        %         positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.clusterPOPUP{class_i} = ...
            uicontrol('Style', 'popup',...
            'Units','normalized',...
            'String', ' ',...
            'Position', [0.015+(class_i-1)*0.135 .365 .025 .026],...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeDisplayedCluster,...
            'horizontalAlignment', 'center','Visible','off');
        %         set(handles1.Figures.Waveforms.clusterPOPUP{class_i},'Value',...
        %             class_i)
        
        positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.clusterTOGGLE{class_i} = ...
            uicontrol('Style', 'togglebutton',...
            'String','%',...
            'Units','normalized',...
            'Position', positionaux,...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeVisualization,...
            'horizontalAlignment', 'center','Visible','off');
        
        %         positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.delBUTTON{class_i} = ...
            uicontrol('Style', 'pushbutton',...
            'Units','normalized',...
            'Position', [0.045+(class_i-1)*0.135 .365 .025 .026],...
            'String','DEL',...
            'BackgroundColor', [1 .5 .5]*.8,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_deletecluster,...
            'horizontalAlignment', 'center','Visible','off');
        
        positionaux = [0.10+(class_i-1)*0.14 .40 .04 .02];
        positionaux=positionaux-positionmod;
        %         nspikes = sum(handles1.data.class_id{handles1.chid}==class_i);
        handles1.Figures.Waveforms.ch_id_txtbox(class_i) = ...
            uicontrol('Style', 'text',...
            'Units','normalized',...
            'String',' ',...
            'Position', positionaux,...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'horizontalAlignment', 'left',...
            'fontsize',8,'Visible','off');
        
    elseif class_i>=4 && class_i<8
        positionmod(2)=0.015;
        
        
        positionaux = [0.08+(class_i-4)*0.35 .06 .22 .375];
        positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.cluster{class_i} = ...
            axes('Parent',hObject,'Position',positionaux,'Visible','off');
        
        
        %         positionaux = [0.055+(class_i-4)*0.25 .2 .025 .026];
        %         positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.clusterNUMB{class_i} = ...
            uicontrol('Style', 'edit',...
            'Units','normalized',...
            'String', '',...
            'Position', [0.015+(class_i-4)*0.135 .18 .025 .026],...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeClusterNumber,...
            'horizontalAlignment', 'center','Visible','off');
        set(handles1.Figures.Waveforms.clusterNUMB{class_i},'String',...
            num2str(class_i))
        %
        %         positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.clusterPOPUP{class_i} = ...
            uicontrol('Style', 'popup',...
            'Units','normalized',...
            'String', ' ',...
            'Position', [0.015+(class_i-4)*0.135 .18 .025 .026],...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeDisplayedCluster,...
            'horizontalAlignment', 'center','Visible','off');
        
        positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.clusterTOGGLE{class_i} = ...
            uicontrol('Style', 'togglebutton',...
            'String','%',...
            'Units','normalized',...
            'Position', positionaux,...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeVisualization,...
            'horizontalAlignment', 'center','Visible','off');
        
        %         positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.delBUTTON{class_i} = ...
            uicontrol('Style', 'pushbutton',...
            'Units','normalized',...
            'Position', [0.045+(class_i-4)*0.135 .18 .025 .026],...
            'String','DEL',...
            'BackgroundColor', [1 .5 .5]*.8,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_deletecluster,...
            'horizontalAlignment', 'center','Visible','off');
        
        positionaux = [0.10+(class_i-4)*0.14 .19 .040 .02];
        positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.ch_id_txtbox(class_i) = ...
            uicontrol('Style', 'text',...
            'Units','normalized',...
            'String',' ',...
            'Position', positionaux,...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'horizontalAlignment', 'right',...
            'fontsize',8,'Visible','off');
        
    end
end


end


% --- Executes during object creation, after setting all properties.
function uipanel17_CreateFcn(hObject, eventdata, handles)
global plotforclusters handles1

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position = [0.418 0.54 0.398 0.358];
plotforclusters = axes('Parent',hObject);
end


% --- Executes during object creation, after setting all properties.
function uipanel18_CreateFcn(hObject, eventdata, handles)
global plotforclusterstability

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position = [0.418 0.037 0.398 0.358];
plotforclusterstability = axes('Parent',hObject);
end
%% display used parameters in home screen

% --- High pass filter (Butterworth)
function text43_CreateFcn(hObject, eventdata, handles)
global fs

hObject.FontWeight = 'bold';
hObject.String =  ['High Pass Butterworth filter Parameters used:',...
    newline 'Cuttoff Frequency : ',mat2str(fs.filtersettings.cut_off_frequency), ' Hz',...
    newline 'Order of fit : ',mat2str(fs.filtersettings.filter_order),...
    newline 'Sampling frequency : ',mat2str(fs.filtersettings.sampling_frequency), 'Hz',...
    newline ,...
    newline 'Baseline Noise Detection Parameters used:',...
    newline 'Window : ',mat2str(fs.baselinenoise.window),' (ms)',...
    newline 'Pure noise window : ',mat2str(fs.baselinenoise.purenoisewindow),' (s)',...
    newline 'Root Mean Square level : ',mat2str(fs.baselinenoise.RMS),...
    newline,...
    newline 'Spike Detection Parameters used:',...
    newline 'Min Peak Distance : ',mat2str(fs.unitdetection.minpeakdistance),' (ms)',...
    newline 'Min Peak Prominence : ',mat2str(fs.unitdetection.minpeakprominence),' (',char(181),'V)',...
    newline 'Minimum Fire frequency: ',mat2str(fs.standardsettings.minimum_activity_channel),' (Hz)'];
hObject.Position = [0.586 0.525 0.186 0.181];
hObject.BackgroundColor = [.97,.98,.98];
% hObject.ForegroundColor = [0.992 0.89 0.655];

end
