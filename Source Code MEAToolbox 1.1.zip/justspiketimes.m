%% to make it compatible with the toolbox
%globals
clear variables
clc
global selecteddata
global filteredData1
global X2
global timesss
global RMS7
global xpoints
global ypoints
global noiseall18
global noiseall2
global burstsinfor
global ypointsburst1
global Bap
global Bab
global Bak
global Bal
global T
global ISI58
global Spikeform3
global ends2
global starts2
global burst6
global burst7
global newHITS
global ans90
global ert48
global HITS
global fs
global burstview2
global burstview3
global channel963
global unitpersecond
global burstview19
global burstview20
global bincountssec
global binranges4567
global BI
global Imax
global imaxch imaxch2
global M2
global Exburst
global files
global newM2
global textstrings
global logburst
global layout
global M88
global BLog
global BNeuro
global BD
global M66
global M99
global M111
global M222
global Spikeform4
global looo12
global negunits
global posunits
global negunitsSEM
global posunitsSEM
global BLogSEM
global BNeuroSEM
global BDSEM
global HITSSEM
global Connections
global pushed
global INDEX1
global burst6indx
global burst7indx
global multiwell1 Multiwel2
global supa
global networkburstttt
global NetworkBurstStart
global M Tt OPP VORM OFFSET
global joost
global SCBflag
global electrodecount

correctfolder=uigetdir; %lets the user select  a folder for analysis
if correctfolder == 0
    return
else
    cd(correctfolder) ; %change the current folder to the user selected one
    files = dir('*.h5');
end

clear promptMessage totaldura button

%% Preparation phase
if pushed == 1
else
    joost =1;
    fs=[];
    fs.standardsettings.minimum_activity_channel = 0.1;
    fs.filtersettings.sampling_frequency=10000;
    fs.filtersettings.cut_off_frequency=200;
    fs.filtersettings.filter_order=2;
    fs.baselinenoise.window=50;
    fs.baselinenoise.purenoisewindow=2;
    fs.baselinenoise.RMS=5;
    fs.unitdetection.minpeakdistance=0;
    fs.unitdetection.minpeakprominence=0;
    fs.burstdetection.ISI=0.1;
    fs.burstdetection.nspikes=10;
    fs.burstdetectionmaxinterval.start=0.17;        %used in the paper 0.05  
    fs.burstdetectionmaxinterval.nspikes=10;        %used in the paper 4
    fs.burstdetectionmaxinterval.IBI=0.3;           %used in the paper 0.1
    fs.burstdetectionmaxinterval.intraBI=0.2;       %used in the paper 0.1
    fs.burstdetectionmaxinterval.mindur=0.01;       %used in the paper 0.03
    fs.burstdetectionlogisi.void=0.7;
    fs.burstdetectionlogisi.nspikes=3;
    fs.networkburstdetection.synchronizedtimewindow = 0.1; % time in seconds
    fs.networkburstdetection.minimumsynchronizedburstcount = 2; % in counts
    fs.networkburstdetection.minimumchannelparticipation = 0.5; % in percentage
    multiwell1 = 0;
    SCBflag = 1;
end
%% get the spike times from h5

tic
for pp = 1:length(files)
    selecteddata = files(pp).name;
    % selecteddata='Data2038.h5';
    
    hh=waitbar(0,'Reading the Raw Data');
    check1= 0;
    multiwell1 = 0;
    Data3=cell(1,60);
    for i=1:60
        A=i;
        A=num2str(A);
%                B='SegmentData_';
         B='Data_';
        A=strcat(B,A);
%               chr='/Data/Recording_0/SegmentStream/Stream_0/SegmentData_1';
         chr='/Data/Data_1';
%                newChr = strrep(chr,'SegmentData_1',A);
        newChr = strrep(chr,'Data_1',A);
        try
            Data3{i} = h5read(selecteddata,newChr)'; %contains all the spike waveforms
            Data3{i}= Data3{i}/16.7771; % conversion factor
        catch
            continue
        end
    end
    
    clear A B chr newChr i
    Data3=Data3';
    
    
    Data4=cell(1,60);
    for i=1:60
        A=i;
        A=num2str(A);
%          B='SegmentData_ts_';
          B='Data_ts_';
        A=strcat(B,A);
%         chr='/Data/Recording_0/SegmentStream/Stream_0/SegmentData_ts_1';
        chr='/Data/Data_ts_1';
%         newChr = strrep(chr,'SegmentData_ts_1',A);
          newChr = strrep(chr,'Data_ts_1',A);
        try
            Data4{i} = h5read(selecteddata,newChr)'; %contains all the timepoints of all the spikes
        catch
            continue
        end
    end
    
    clear A B chr newChr i
    Data4=Data4';  
    
%     totalduration=h5readatt(selecteddata,'/Data/Recording_0','Duration'); %this contains the total length of the recording
    totalduration=h5readatt(selecteddata,'/Data_info','Duration'); %this contains the total length of the recording
    totalsamples = totalduration/100;
    totalduration=totalduration/100 * fs.filtersettings.sampling_frequency;
    steps1=totalduration/totalsamples;
    
    X = 0:steps1:totalduration;  %This contains all the X data
    X = double(X(1:(end-1)));  %remove the last one to make it a nice round number just like the MCS datatools did
    timesss=length(X)/ fs.filtersettings.sampling_frequency;
    X2 = X/1000000; %convert to seconds
    filteredData1 = zeros(1,length(Data3))';
    yu2=[];
    ppp=cell(1,60);
    for j=1:length(Data3)
        if isempty(Data3{j})
            continue
        else
            for i=1:length(Data3{j}(1,:))
                yu=min(Data3{j}(:,i));
                yu2=[yu2,yu];
            end
            ppp{j}=yu2;
            yu2=[];
        end
    end
    ppp=ppp';
    
    yu2=[];
    ppp=cell(1,60);
    for j=1:length(Data3)
        if isempty(Data3{j})
            continue
        else
            for i=1:length(Data3{j}(1,:))
                yu=max(Data3{j}(:,i));
                yu2=[yu2,yu];
            end
            ppp{j}=yu2;
            yu2=[];
        end
    end
    ppp=ppp';
    
    clear bbb bbb2 ppp yu2 yu
    
    Truehits=zeros(1,60)';
    for i=1:length(Data3)
        if isempty(Data3{i})
            Truehits(i)=0;
        else
            Truehits(i)=length(Data3{i}(1,:));
        end
    end
    
    M489 =Truehits;
    waitbar(0 + 0.2,hh,'Loaded the Raw data');
    %% layout (creation of layout/HITS)
    HITS={};
    HITS{1,1}='C4';
    HITS{2,1}='C5';
    HITS{3,1}='C6';
    HITS{4,1}='C7';
    HITS{5,1}='C8';
    HITS{6,1}='C9';
    HITS{7,1}='D3';
    HITS{8,1}='D4';
    HITS{9,1}='D5';
    HITS{10,1}='D6';
    HITS{11,1}='D7';
    HITS{12,1}='D8';
    HITS{13,1}='D9';
    HITS{14,1}='D10';
    HITS{15,1}='E3';
    HITS{16,1}='E4';
    HITS{17,1}='E5';
    HITS{18,1}='E6';
    HITS{19,1}='E7';
    HITS{20,1}='E8';
    HITS{21,1}='E9';
    HITS{22,1}='E10';
    HITS{23,1}='F3';
    HITS{24,1}='F4';
    HITS{25,1}='F5';
    HITS{26,1}='F6';
    HITS{27,1}='F7';
    HITS{28,1}='F8';
    HITS{29,1}='F9';
    HITS{30,1}='F10';
    HITS{31,1}='G3';
    HITS{32,1}='G4';
    HITS{33,1}='G5';
    HITS{34,1}='G6';
    HITS{35,1}='G7';
    HITS{36,1}='G8';
    HITS{37,1}='G9';
    HITS{38,1}='G10';
    HITS{39,1}='H3';
    HITS{40,1}='H4';
    HITS{41,1}='H5';
    HITS{42,1}='H6';
    HITS{43,1}='H7';
    HITS{44,1}='H8';
    HITS{45,1}='H9';
    HITS{46,1}='H10';
    HITS{47,1}='J3';
    HITS{48,1}='J4';
    HITS{49,1}='J5';
    HITS{50,1}='J6';
    HITS{51,1}='J7';
    HITS{52,1}='J8';
    HITS{53,1}='J9';
    HITS{54,1}='J10';
    HITS{55,1}='K4';
    HITS{56,1}='K5';
    HITS{57,1}='K6';
    HITS{58,1}='K7';
    HITS{59,1}='K8';
    HITS{60,1}='K9';
    HITS{61,1}='D1';
    HITS{62,1}='E1';
    HITS{63,1}='F1';
    HITS{64,1}='G1';
    HITS{65,1}='H1';
    HITS{66,1}='J1';
    HITS{67,1}='C2';
    HITS{68,1}='D2';
    HITS{69,1}='E2';
    HITS{70,1}='F2';
    HITS{71,1}='G2';
    HITS{72,1}='H2';
    HITS{73,1}='J2';
    HITS{74,1}='K2';
    HITS{75,1}='B3';
    HITS{76,1}='C3';
    HITS{77,1}='K3';
    HITS{78,1}='L3';
    HITS{79,1}='A4';
    HITS{80,1}='B4';
    HITS{81,1}='L4';
    HITS{82,1}='M4';
    HITS{83,1}='A5';
    HITS{84,1}='B5';
    HITS{85,1}='L5';
    HITS{86,1}='M5';
    HITS{87,1}='A6';
    HITS{88,1}='B6';
    HITS{89,1}='L6';
    HITS{90,1}='M6';
    HITS{91,1}='A7';
    HITS{92,1}='B7';
    HITS{93,1}='L7';
    HITS{94,1}='M7';
    HITS{95,1}='A8';
    HITS{96,1}='B8';
    HITS{97,1}='L8';
    HITS{98,1}='M8';
    HITS{99,1}='A9';
    HITS{100,1}='B9';
    HITS{101,1}='L9';
    HITS{102,1}='M9';
    HITS{103,1}='B10';
    HITS{104,1}='C10';
    HITS{105,1}='K10';
    HITS{106,1}='L10';
    HITS{107,1}='C11';
    HITS{108,1}='D11';
    HITS{109,1}='E11';
    HITS{110,1}='F11';
    HITS{111,1}='G11';
    HITS{112,1}='H11';
    HITS{113,1}='J11';
    HITS{114,1}='K11';
    HITS{115,1}='D12';
    HITS{116,1}='E12';
    HITS{117,1}='F12';
    HITS{118,1}='G12';    %we will have to creat a new layout for the 60 channel MEA that fits within the 120 MEA
    HITS{119,1}='H12';
    HITS{120,1}='J12';
    
    channelIDs = HITS(:,1);
    
    HITS{1,2}=M489(1,1);
    HITS{2,2}=M489(2,1);
    HITS{3,2}=M489(3,1);
    HITS{4,2}=M489(4,1);
    HITS{5,2}=M489(5,1);
    HITS{6,2}=M489(6,1);
    HITS{7,2}=M489(7,1);
    HITS{8,2}=M489(8,1);
    HITS{9,2}=M489(9,1);
    HITS{10,2}=M489(10,1);
    HITS{11,2}=M489(11,1);
    HITS{12,2}=M489(12,1);
    HITS{13,2}=M489(13,1);
    HITS{14,2}=M489(14,1);
    HITS{15,2}=M489(15,1);
    HITS{16,2}=M489(16,1);
    HITS{17,2}=M489(17,1);
    HITS{18,2}=M489(18,1);
    HITS{19,2}=M489(19,1);
    HITS{20,2}=M489(20,1);
    HITS{21,2}=M489(21,1);
    HITS{22,2}=M489(22,1);
    HITS{23,2}=M489(23,1);
    HITS{24,2}=M489(24,1);
    HITS{25,2}=M489(25,1);
    HITS{26,2}=M489(26,1);
    HITS{27,2}=M489(27,1);
    HITS{28,2}=M489(28,1);
    HITS{29,2}=M489(29,1);
    HITS{30,2}=M489(30,1);
    HITS{31,2}=M489(31,1);
    HITS{32,2}=M489(32,1);
    HITS{33,2}=M489(33,1);
    HITS{34,2}=M489(34,1);
    HITS{35,2}=M489(35,1);
    HITS{36,2}=M489(36,1);
    HITS{37,2}=M489(37,1);
    HITS{38,2}=M489(38,1);
    HITS{39,2}=M489(39,1);
    HITS{40,2}=M489(40,1);
    HITS{41,2}=M489(41,1);
    HITS{42,2}=M489(42,1);
    HITS{43,2}=M489(43,1);
    HITS{44,2}=M489(44,1);
    HITS{45,2}=M489(45,1);
    HITS{46,2}=M489(46,1);
    HITS{47,2}=M489(47,1);
    HITS{48,2}=M489(48,1);
    HITS{49,2}=M489(49,1);
    HITS{50,2}=M489(50,1);
    HITS{51,2}=M489(51,1);
    HITS{52,2}=M489(52,1);
    HITS{53,2}=M489(53,1);
    HITS{54,2}=M489(54,1);
    HITS{55,2}=M489(55,1);
    HITS{56,2}=M489(56,1);
    HITS{57,2}=M489(57,1);
    HITS{58,2}=M489(58,1);
    HITS{59,2}=M489(59,1);
    HITS{60,2}=M489(60,1);
    
    layout= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS{7,2} HITS{15,2} HITS{23,2} HITS{31,2} HITS{39,2} HITS{47,2} nan nan nan; nan nan HITS{1,2} HITS{8,2} HITS{16,2} HITS{24,2} HITS{32,2} HITS{40,2} HITS{48,2} HITS{55,2} nan nan; nan nan HITS{2,2} HITS{9,2} HITS{17,2} HITS{25,2} HITS{33,2} HITS{41,2} HITS{49,2} HITS{56,2} nan nan; nan nan HITS{3,2} HITS{10,2} HITS{18,2} HITS{26,2} HITS{34,2} HITS{42,2} HITS{50,2} HITS{57,2} nan nan; nan nan HITS{4,2} HITS{11,2} HITS{19,2} HITS{27,2} HITS{35,2} HITS{43,2} HITS{51,2} HITS{58,2} nan nan; nan nan HITS{5,2} HITS{12,2} HITS{20,2} HITS{28,2} HITS{36,2} HITS{44,2} HITS{52,2} HITS{59,2} nan nan; nan nan HITS{6,2} HITS{13,2} HITS{21,2} HITS{29,2} HITS{37,2} HITS{45,2} HITS{53,2} HITS{60,2} nan nan;nan nan nan HITS{14,2} HITS{22,2} HITS{30,2} HITS{38,2} HITS{46,2} HITS{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
    
    ans90 = cellstr(('A':'H')')';
    ans90{9} = 'J';
    ans90{10} = 'K';
    ans90{11} ='L';
    ans90{12} = 'M';
    %% creation of xppoints and ypoints and M2
    
    
    % for the rasterplot
    pp2=[];
    for i=1:length(Data3)
        if isempty( Data3{i})
            continue
        else
            p=length(Data3{i}(1,:));
            pp= ones(1,p)*i;
            pp2=[pp2,pp];
        end
    end
    
    
    ypoints=pp2;
    
    clear pp2 pp p
    
    
    pp=[];
    for i=1:length(Data3)
        if isempty(Data4{i})
            continue
        else
            p=Data4{i};
            pp=[pp,p];
        end
    end
    
    xpoints=pp;
    xpoints=double(xpoints);
    clear p pp
    
    %
    xpoints=xpoints/1000000;  % time is now in seconds if the sampling frequency was 25Khz
    
    
    
    %create a cellarray similar to M2
    
    
    for i=1:length(Data4)
        Data4{i}=double(Data4{i})/1000000;  % converted all the timestamps into second range
    end
    
    M2=Data4;
    
    for i = 1:length(M2)
        if length(M2{i}) < 10
            M2{i} =[];
        end
    end
    
    
    
    
    %% Creation of Spikeform3 ( there is no spikeform4)
    
    Spikeform3 = Data3;
    %% Prepare the data for burst detection
    % Max interval method
    
    waitbar(0 + 0.55,hh,'Start Burst Detection');
    test2=cell(1,length(M2));
    for i=1:length(M2)
        test=diff(M2{i,1});
        test2{i}=test;
    end
    test2=test2'; %contain the ISI all of the channels
    
    for i =1:length(test2)
        test2{i}(2,:)=1:length(test2{i});    %add the index of the ISI in each cell
    end
    
    % remove any cell that has less than 3 spikes
    
    for i=1:length(test2)
        if size(test2{i},2) < 3
            test2{i}=[];
        end
    end
    %first part would be to detect the start of the bursts
    
    %maximum start of the burst is 170 ms between the first two spikes of a
    %burst
    
    burst6=cell(1,length(M2));
    for ii=1:length(M2)
        
        if isempty(test2{ii})
            burst6{ii} = [];
        else
            idx = find(test2{ii}(1,:) < fs.burstdetectionmaxinterval.start);
            maxbursts=round(length(test2{ii})/fs.burstdetectionmaxinterval.nspikes); %you have to have atleast 3 spikes per burst and therefore you have a max limit on the maount of bursts
            
            %check to see if the amount of bursts is normal if not remove it
            
            burst4=cell(1,length(idx));
            for j=1:length(idx)
                burst3=[];
                for i=idx(j):length(test2{ii})
                    if test2{ii}(1,i) < fs.burstdetectionmaxinterval.IBI     %max ISI of interburstspikes is 300 ms
                        burst = test2{ii}(2,i);    %get the indices of the spikes so its easier to work it
                        burst3{i} = burst;
                        %   burst4{j}(i)=burst;
                        
                    else
                        break;
                    end
                end
                
                if isempty(burst3)
                else
                    burst3 = vertcat(burst3{:});
                end
                
                burst4{j}=burst3;    %now we have our found our bursts that start with a ISI of 170 ms and have a ISI wihtin the bursts of max 300 ms
                
            end
            clear burst burst3
            
            for i=1:length(burst4)
                if length(burst4{1,i}) < fs.burstdetectionmaxinterval.nspikes   %removed any burst that had less than 3 spikes
                    burst4{1,i}=[];
                else
                    
                end
            end
            
            burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
            
            %merging/removal of duplicates
            
            NewVector = cellfun(@(x) x(end), burst4); % get all the last number of each detected burst
            
            
            for i = 1:length(NewVector)
                try
                    if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them (its based on the last number as in the duplicated bursts they are the same)
                        burst4{i+1} = [];
                    else
                        
                    end
                catch
                end
            end
            
            burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
            
            
            
            %now we need to get the real spike times for the other parameters
            
            %now we need to check if the time between the bursts is a minimal
            %of 200 ms otherwise merge
            
            burst5={};
            
            for i=1:length(burst4)-1
                j=i+1;
                if M2{ii,1}(burst4{1,j}(1,1))- M2{ii,1}(burst4{1,i}(end)) < fs.burstdetectionmaxinterval.intraBI   %if the distance between the last spike of the previous burst is not longer than 200 ms comapred to the first spike of the next bursts it will be merged into one bursts
                    burst5=vertcat(burst4{1,i},burst4{1,j});
                else
                    
                    burst5{i}=burst4{1,i};
                    burst5{j}=burst4{1,j};
                end
            end
            
            clear burst4
            %last check is to see if the total duration of the bursts is atleast 10 ms
            
            for i=1:length(burst5)
                if M2{ii,1}(burst5{1,i}(end)) - M2{ii,1}(burst5{1,i}(1,1)) < fs.burstdetectionmaxinterval.mindur
                    burst5{1,i}=[];
                else
                end
            end
            
            burst5=burst5(~cellfun('isempty',burst5)); %sort the correct amount of bursts
            
            burst6{ii}=burst5;
        end
    end
    
    clear burst5 test2 idx test maxbursts messsage1
    burst6=burst6';  %these are the indices of the spikes
    %we have to convert them to their actual spike timings
    burst6indx= burst6;
    
    for i=1:length(M2)
        for j=1:length(burst6{i,1})
            burst6{i,1}{1,j}=M2{i,1}(burst6{i,1}{1,j});  %now we have the correct spike timings!
        end
    end
    
    
    
    Exburst=cell(1,length(M2));
    for jj=1:length(M2)
        Exburst{jj}.number_of_bursts=1:length(burst6{jj,1});
        
        for i=1:length(burst6{jj,1})
            Exburst{jj}.duration_of_bursts(i)=burst6{jj,1}{1,i}(end)-burst6{jj,1}{1,i}(1,1);
        end
        
        
        for i=1:length(burst6{jj,1})
            Exburst{jj}.spikes_in_bursts(i)=length(burst6{jj,1}{1,i});
        end
    end
    Exburst=Exburst';   %contains data about the bursts for the table
    
    for i=1:length(M2)
        Exburst{i,1}.number_of_bursts=Exburst{i,1}.number_of_bursts'; %flip everything for the table
    end
    
    for i=1:length(M2)
        if sum(strcmp(fieldnames(Exburst{i,1}), 'spikes_in_bursts')) == 1
            Exburst{i,1}.spikes_in_bursts=Exburst{i,1}.spikes_in_bursts'; %flip everything for the table
        else
        end
    end
    
    for i=1:length(M2)
        if sum(strcmp(fieldnames(Exburst{i,1}), 'duration_of_bursts')) == 1
            Exburst{i,1}.duration_of_bursts=Exburst{i,1}.duration_of_bursts'; %flip everything for the table
        else
        end
    end
    
    clear mona
    
    %get the firing frequency (Hz) per burst per electrode
    
    fr_of_bursts = zeros(1,length(M2))';
    for i = 1:length(M2)
        if isempty(Exburst{i}.number_of_bursts)
            Exburst{i}.fr_of_bursts = [];
        else
            for j = 1:length(Exburst{i}.spikes_in_bursts)
                Exburst{i}.fr_of_bursts(j) = Exburst{i}.spikes_in_bursts(j)/ Exburst{i}.duration_of_bursts(j);
                Exburst{i}.fr_of_bursts = Exburst{i}.fr_of_bursts';
            end
        end
    end
    
    
    %get the mean ISI of the spikes inside of a burst
    %the timings are located in burst6 for max interval
    
    
    mISIbursts = cell(1,length(M2));
    for i=1:length(M2)
        if isempty(Exburst{i}.number_of_bursts)
            mISIbursts{i} = 0;
        else
            mISIbursts{i} = cellfun(@diff,burst6{i},'UniformOutput',0);
        end
        
    end
    
    
    mISIbursts=cell(1,length(burst6))'; %contains the average ISI of the bursts in each electrode
    for i=1:length(M2)
        mISIbursts{i}=zeros(1,length(burst6{i}));
        if isempty(Exburst{i}.number_of_bursts)
            mISIbursts{i} = 0;
        else
            for j = 1:length(burst6{i})
                mISIbursts{i}(j) = mean(diff(cell2mat(burst6{i}(j))));
                Exburst{i}.mean_ISI_bursts = mISIbursts{i}';
            end
        end
    end
    
    clear mISIbursts
    
    stdISIbursts=cell(1,length(burst6))'; %contains the std of the ISI of  bursts in each electrode
    for i=1:length(M2)
        stdISIbursts{i}=zeros(1,length(burst6{i}));
        if isempty(Exburst{i}.number_of_bursts)
            stdISIbursts{i} = 0;
        else
            for j = 1:length(burst6{i})
                stdISIbursts{i}(j) = std(diff(cell2mat(burst6{i}(j))));
                Exburst{i}.std_ISI_bursts = stdISIbursts{i}';
            end
        end
    end
    
    clear stdISIbursts
    
    %calculate the IBI
    
    IBI2=[];
    for i =1:length(burst6)
        if isempty(burst6{i})
            continue
        else
            for j =1:length(burst6{i})-1
                IBI = burst6{i}{j+1}(1) - burst6{i}{j}(end);
                IBI2=[IBI2,IBI];
            end
        end
        Exburst{i}.IBI = IBI2';  %this contains all the IBI's per electrode
        IBI2 =[];
    end
    
    
    % create a conditional to produce a error if burst6 and burst6indx
    % are not the same
    
    assert( length(find(~cellfun(@isempty,burst6))) == length(find(~cellfun(@isempty,burst6indx))));
    %% calculating ISI
    ISI58={}; %contains all the ISI for all channels
    for i=1:length(M2)
        ISI57= diff(M2{i,1});
        ISI58{i}=ISI57;
        ISI58=ISI58';
    end
    
    for i=1:length(M2)
        ISI58{i,1}=(ISI58{i,1}*1000); %x data in milliseconds
        
    end
    
    clear ISI57
    
    % burst detection according to log ISI method
    %% calulating the burst according to the logISI method from A self-adapting approach for the detection of bursts and network bursts in neuronal cultures (there seems to be a problem with overlapping bursts)
    %https://www.physiology.org/doi/full/10.1152/jn.00093.2016
    % LogISI method (Pasquale et al. 2010).
    
    %Bursts are detected using the histogram of the log-adjusted ISIs on a spike train.
    %The peaks of this histogram are found using a tailor-made peak finding algorithm outlined in Pasquale et al. (2010), and the largest peak corresponding to an ISI of ≤100 ms is set as the intraburst peak.
    %In the absence of such a peak, no bursts are found.
    %The minimum values between the intraburst peak and all subsequent peaks are found, and a void parameter, which represents how well the peaks are separated, is calculated for each minimum.
    %The ISI value corresponding to the first minimum at which the void parameter exceeds a threshold value of 0.7 is set as the cutoff value for burst detection, maxISI.
    %Bursts are then detected as any series of three or more spikes separated by ISIs smaller than maxISI.
    %If no cutoff is found, or if maxISI > 100 ms, bursts are found with a 100-ms cutoff, and then extended to include any spikes within maxISI of the edges of each burst.
    
    %all the ISI's are located in the ISI58
    
    
    
    %first thing we need to do is make the log ISI histograms
    logISI_hist = cell(1,length(M2));
    binsss= cell(1,length(M2));
    for i = 1:length(M2)
        if isempty(ISI58{i})
            logISI_hist{i} = [];
            continue
        else
            maxWin = ceil(log10(max(ISI58{i})));
            binss = logspace(0,maxWin,maxWin*10);           % equally spaced logarithmic bins using logspace
            ISIlog_hist = histc(ISI58{i},binss);                     % this is the actual log ISI histogram
            ISIlog_hist_area = sum(ISIlog_hist);
            ISIlog_hist_norm = ISIlog_hist./ISIlog_hist_area;    % normalization
            ISIlog_hist_norm = ISIlog_hist_norm(:);
            binss = binss(:);
        end
        logISI_hist{i} = ISIlog_hist_norm;
        binsss{i} = binss ;
    end
    clear binss ISIlog_hist_norm  ISIlog_hist maxWin
    logISI_hist = logISI_hist';
    binsss = binsss';  % remember this is in ms!
    
    
    %smooth the log ISI histograms
    smoothed_logISI = cell(1,length(M2));
    for i = 1:length(M2)
        if isempty(logISI_hist{i})
            smoothed_logISI{i} = [];
            continue
        else
            smoothed_logISI{i} = smooth(logISI_hist{i},5,'lowess') ;   % smooth the logISI histograms
        end
    end
    smoothed_logISI = smoothed_logISI';
    
    %now we need to find the peaks in the smoothed ISI log
    %histograms throw away channels that do not have a peak before
    %100 ms
    
    
    intraburstpeaks = cell(1,length(M2));
    logISIpeaks = cell(1,length(M2));
    logISIlocs = cell(1,length(M2));
    
    for i =1:length(M2)
        if isempty(smoothed_logISI{i})
            intraburstpeaks{i} =[];
            continue
        else
            [peaks,locs] = findpeaks(smoothed_logISI{i},'minpeakdistance',2); %2 points from 'A self-adapting approach for the detection of burstsand network bursts in neuronal cultures'
        end
        
        temp1 = binsss{i}(locs);
        %now we need to check if there is peak before 100 ms
        if numel(peaks) == 1
            intraburstpeaks{i} = [];
        elseif numel(find(temp1 < 100)) > 1 %if we have more than 1 peak then take the biggest value
            [~,I] = max(peaks(find(temp1 < 100)));
            intraburstpeaks{i} =  temp1(I);
            %                 elseif find(temp1 < 100) == 1   %there is one peak before 100 ms
            %                     intraburstpeaks{i} = temp1(find(temp1 < 100));
        elseif numel(find(temp1 < 100)) == 1
            [~,I] = find(temp1 < 100);
            intraburstpeaks{i} =  temp1(I);
            
        else % no peaks before 100 ms so we discontinue the burst analysis
            intraburstpeaks{i} = [];
        end
        
        if isempty(intraburstpeaks{i})
            logISIlocs{i} = [];
            logISIpeaks{i} =[];
        else
            logISIpeaks{i} = peaks;
            logISIlocs{i} = binsss{i}(locs);
        end
    end
    intraburstpeaks = intraburstpeaks'; % this cell contains all the intraburst peaks in ms!
    logISIpeaks =  logISIpeaks'; %y coordinates of the peaks in counts
    logISIlocs = logISIlocs'; %x coordinates of the peaks in ms
    clear locs peaks temp1 I
    
    %Now we need to find the correct interburst interval using the void parameter if that
    %fails than we set it at 100 ms
    % We do this by comparing the first peak or the intraburst peak with the
    % subsequent peaks
    
    
    interburstlogISI = cell(1,length(M2));
    
    for i = 1:length(M2)
        if isempty(logISIlocs{i})
            interburstlogISI{i} = [];
            continue
        else
            %lets find the min value between each peak pair
            % we can find the index in the locs cells
            maxiterations = numel(logISIlocs{i});
            index_intraburst = find(logISIlocs{i} == intraburstpeaks{i});
            for j = (index_intraburst+1):length(logISIlocs{i})
                
                temp1 = min(smoothed_logISI{i}(find(smoothed_logISI{i} == logISIpeaks{i}(index_intraburst)):find(smoothed_logISI{i} == logISIpeaks{i}(j))));
                %calculate how well the peaks are seperated
                void =  1 - (temp1 / sqrt(logISIpeaks{i}(index_intraburst) * logISIpeaks{i}(j)));
                if void > fs.burstdetectionlogisi.void
                    if temp1 == 0 %if the lowest number is equal to zero
                        temp2 = find(smoothed_logISI{i} == 0,find(find(smoothed_logISI{i} == 0) > find(smoothed_logISI{i} == logISIpeaks{i}(index_intraburst),1),1)) ;
                        temp2 = temp2(end);
                        interburstlogISI{i} = binsss{i}(temp2);
                    else
                        interburstlogISI{i} = binsss{i}(find(smoothed_logISI{i} == temp1,1)); %this is in ms
                        break
                    end
                else
                    interburstlogISI{i} = 100; %if the method cant find any peaks that are well seperated it will be put at 100 ms
                end
            end
        end
    end
    interburstlogISI =interburstlogISI';   %this contains all the interburst intervals in ms
    
    %combine both numbers in one cell
    
    ISIthh = cell(2,length(M2))';
    
    for i =1:length(M2)
        
        ISIthh{i,1} = interburstlogISI{i}/1000; %convert in seconds
        ISIthh{i,2} = intraburstpeaks{i}/1000;  %convert in seconds
        
    end
    
    % add a extra criteria because getting values of above 1s for
    % interburst intervals is too high
    
    
    for i = 1:length(M2)
        if isempty(ISIthh)
            continue
        else
            if ISIthh{i,1} > 1
                ISIthh{i,1} = 0.1;
            end
        end
    end
    
    
    
    %Added an extra control to esnure that both the intraburst
    %ISI's and interburst ISI are complete
    
    
    for i = 1:length(M2)
        if isempty(ISIthh{i,1})
            if isempty(ISIthh{i,2})
            else
                ISIthh{i,1} = 0.1;
            end
        else
        end
    end
    
    %the first column of ISIthh contains the interburst ISI thresholds and the
    %2nd column contains the intrasburst ISI thresholds (everything is in
    %seconds
    
    test2=cell(1,length(filteredData1(:,1)));
    for i=1:length(M2)
        test=diff(M2{i,1});
        test2{i}=test;
    end
    test2=test2'; %contain the ISI all of the channels % in seconds
    
    
    
    %first part would be to detect the start of the bursts
    
    %maximum start of the burst is the isi of the first peak found before
    %the found intraburst peak
    
    burst7=cell(1,length(M2));
    for ii=1:length(M2)
        
        if isempty(M2{ii}) || length(M2{ii}) < 3
            burst7{ii}={};
        elseif isempty(ISIthh{ii,2})
            burst7{ii}={};
        else
            test=test2{ii,1};
            test(2,:)=1:length(test);
            
            idx = find(test(1,:) < ISIthh{ii,2}(1));   % here we find the indexes of potential burst cores
            length(idx);
            
            maxbursts=round(length(test)/3); %you have to have atleast 3 spikes per burst and therefore you have a max limit on the maount of bursts
            
            %check to see if the amount of bursts is normal if not remove it
            
            burst4={};
            for j=1:length(idx)
                burst3=[];
                for i=idx(j):length(test(1,:))
                    if test(1,i) < ISIthh{ii,1}    %max ISI of interburstspikes is the found interburst interval with the void parameter if not than it is set at 100 ms
                        burst = test(2,i);    %get the indices of the spike so its easier to work it
                        burst3{i}=burst;
                        %         burst3{i}=burst;
                    else
                        break;
                    end
                end
                
                if isempty(burst3)
                else
                    burst3 = vertcat(burst3{:});
                end
                burst4{j}=burst3;    %now we have our found our bursts with a max intraburst ISI of the first peak of the logISI
                
            end
            clear burst burst3
            
            for i=1:length(burst4)
                if length(burst4{1,i}) < fs.burstdetectionlogisi.nspikes   %removed any burst that had less than 3 spikes
                    burst4{1,i}=[];
                else
                    
                end
            end
            
            burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
            
            %merging/removal of duplicates
            
            
            NewVector = cellfun(@(x) x(end), burst4); % get all the last number of each detected burst
            
            
            for i = 1:length(NewVector)
                try
                    if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them ( its based on the last number as in the duplicated bursts they are the same)
                        burst4{i+1} = [];
                    else
                        
                    end
                catch
                end
            end
            
            burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
            
            %now we need to check if the time between the found bursts is
            %not below the interbursts ISI thresholds if it is lower than
            %we will merge them
            
            
            burst5={};
            
            for i=1:length(burst4)-1
                j=i+1;
                if M2{ii,1}(burst4{1,j}(1,1))- M2{ii,1}(burst4{1,i}(end)) < ISIthh{ii,1}(1)   %if the distance between the last spike of the previous burst is not longer than the ISI threshold found of the interburst compared to the first spike of the next bursts it will be merged into one burst
                    burst5{i}=vertcat(burst4{1,i},burst4{1,j});
                else
                    
                    burst5{i}=burst4{1,i};
                    burst5{j}=burst4{1,j};
                end
            end
            
            clear burst4
            
            
            NewVector = cellfun(@(x) x(end), burst5); % get all the last number of each detected burst
            
            
            for i = 1:length(NewVector)
                try
                    if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them ( its based on the last number as in the duplicated bursts they are the same)
                        burst5{i+1} = [];
                    else
                        
                    end
                catch
                end
            end
            
            burst5=burst5(~cellfun('isempty',burst5)); %remove any empty cell
            %
            burst7{ii}=burst5;
        end
        
    end
    
    clear burst5 test2 idx test maxbursts ISIthh yy ii NewVector
    burst7=burst7'; %these contain the burst according to the log ISI method
    burst7indx=burst7;
    
    for i=1:length(M2)
        for j=1:length(burst7{i,1})
            burst7{i,1}{1,j}=M2{i,1}(burst7{i,1}{1,j});  %now we have the correct spike timings!
        end
    end
    
    logburst=cell(1,length(M2));
    for jj=1:length(M2)
        logburst{jj}.number_of_bursts=1:length(burst7{jj,1});
        
        for i=1:length(burst7{jj,1})
            logburst{jj}.duration_of_bursts(i)=burst7{jj,1}{1,i}(end)-burst7{jj,1}{1,i}(1,1);
        end
        
        
        for i=1:length(burst7{jj,1})
            logburst{jj}.spikes_in_bursts(i)=length(burst7{jj,1}{1,i});
        end
    end
    logburst=logburst';   %contains data about the bursts for the table
    
    for i=1:length(M2)
        logburst{i,1}.number_of_bursts=logburst{i,1}.number_of_bursts'; %flip everything for the table
    end
    
    for i=1:length(M2)
        if sum(strcmp(fieldnames(logburst{i,1}), 'spikes_in_bursts')) == 1
            logburst{i,1}.spikes_in_bursts=logburst{i,1}.spikes_in_bursts'; %flip everything for the table
        else
        end
    end
    
    for i=1:length(M2)
        if sum(strcmp(fieldnames(logburst{i,1}), 'duration_of_bursts')) == 1
            logburst{i,1}.duration_of_bursts=logburst{i,1}.duration_of_bursts'; %flip everything for the table
        else
        end
    end
    
    
    %get the firing frequency (Hz) per burst per electrode
    
    fr_of_bursts = zeros(1,length(M2))';
    for i = 1:length(M2)
        if isempty(logburst{i}.number_of_bursts)
            logburst{i}.fr_of_bursts = [];
        else
            for j = 1:length(logburst{i}.spikes_in_bursts)
                logburst{i}.fr_of_bursts(j) = logburst{i}.spikes_in_bursts(j)/ logburst{i}.duration_of_bursts(j);
                logburst{i}.fr_of_bursts = logburst{i}.fr_of_bursts';
            end
        end
    end
    
    
    %get the mean ISI of the spikes inside of a burst
    %the timings are located in burst6 for max interval
    
    
    mISIbursts = cell(1,length(M2));
    for i=1:length(M2)
        if isempty(logburst{i}.number_of_bursts)
            mISIbursts{i} = 0;
        else
            mISIbursts{i} = cellfun(@diff,burst7{i},'UniformOutput',0);
            %         mISIbursts{i} = diff(burst7{i})
        end
        
    end
    
    
    mISIbursts=cell(1,length(burst7))'; %contains the average ISI of the bursts in each electrode
    for i=1:length(M2)
        mISIbursts{i}=zeros(1,length(burst7{i}));
        if isempty(logburst{i}.number_of_bursts)
            mISIbursts{i} = 0;
        else
            for j = 1:length(burst7{i})
                mISIbursts{i}(j) = mean(diff(cell2mat(burst7{i}(j))));
                logburst{i}.mean_ISI_bursts = mISIbursts{i}';
            end
        end
    end
    
    clear mISIbursts
    
    stdISIbursts=cell(1,length(burst7))'; %contains the std of the ISI of  bursts in each electrode
    for i=1:length(M2)
        stdISIbursts{i}=zeros(1,length(burst7{i}));
        if isempty(logburst{i}.number_of_bursts)
            stdISIbursts{i} = 0;
        else
            for j = 1:length(burst7{i})
                stdISIbursts{i}(j) = std(diff(cell2mat(burst7{i}(j))));
                logburst{i}.std_ISI_bursts = stdISIbursts{i}';
            end
        end
    end
    
    clear stdISIbursts
    %% calculating  the IFR
    ifr2=cell(1,length(filteredData1(:,1)));
    
    for j=1:length(filteredData1(:,1))
        ifrl=[];
        for i=1:length(ISI58{j,1})
            ifr=1/(ISI58{j,1}(1,i));
            ifrl=[ifrl,ifr];
            ifr2{j}=ifrl;
        end
        %     ifr2{j}=ifrl; %IFR of all units per channel
    end
    ifr2=ifr2';
    
    %padding cell array
    
    ifr4=[];
    for i=1:length(M2)
        ifr3=mean(ifr2{i,1});
        ifr4=[ifr4, ifr3];
    end
    mean_ifr=ifr4';  %average IFR per channel
    
    clear ifr2 ifr ifrl ifr3 ifr4
    %% calculating CV
    %coefficient of variance according to file:///C:/Users/Michel/Desktop/Kros%20Ann%20of%20Neur%202015.pdf
    %Kros et al., 2014 Cerebellar Output Controls Generalized Spike-and-Wave Discharge Occurrence
    % this should say something about the regularity of firing throughout the
    % whole recording
    %CV of ISI is sigma/mean of the ISI
    %ISI58 contains all the ISI per channel
    
    meanISI={};
    for i=1:length(ISI58)
        men=mean(ISI58{i,1});
        meanISI{i}=men;
        meanISI=meanISI';
    end
    
    clear men
    
    stdISI={};
    for i=1:length(ISI58)
        stdisi=std(ISI58{i,1});
        stdISI{i}=stdisi;
        stdISI=stdISI';
    end
    
    clear stdisi
    
    CV=[];
    for i=1:length(ISI58)
        kgl=(stdISI{i,1})/(meanISI{i,1});
        CV=[CV kgl];
        
    end
    CV=CV';
    
    clear meanISI kgl
    %% calculating CV2
    %CV2 from the same paper as above
    %CV2= 2|ISIn+1-ISIn|/(ISIn+1+ISIn),
    CV21={};
    for i=1:length(ISI58)
        fyt1=[];
        for j=1:length(ISI58{i,1})-1
            fyt=ISI58{i,1}(1,(j+1)) - ISI58{i,1}(1,(j));
            fyt1=[fyt1 fyt];
            fyt1=abs(fyt1);
        end
        fyt1=fyt1*2;
        CV21{i}=fyt1;
        CV21=CV21';
    end
    
    CV22={};
    for i=1:length(ISI58)
        fyt1=[];
        for j=1:length(ISI58{i,1})-1
            fyt=ISI58{i,1}(1,(j+1)) + ISI58{i,1}(1,(j));
            fyt1=[fyt1 fyt];
        end
        CV22{i}=fyt1;
        CV22=CV22';
    end
    
    clear fyt1 fyt
    
    CV2={};
    for j=1:length(ISI58)
        CV24=[];
        for i=1:length(ISI58{j,1})-1
            CV23=(CV21{j,1}(1,i))/(CV22{j,1}(1,i));
            CV24=[CV24 CV23];
        end
        CV2{j}=CV24;
        CV2=CV2';
    end
    
    clear CV21 CV22 CV24 CV23
    
    meanCV2={};
    for i=1:length(ISI58)
        mCV2=mean(CV2{i,1});
        meanCV2{i}=mCV2;
        meanCV2=meanCV2';
    end
    meanCV2=cell2mat(meanCV2);
    %% preparation for table
    
    
    %for the max interval bursts
    number_of_burstsNeuroEx=[];
    for i=1:length(M2)
        noinb=length(burst6{i,1});
        number_of_burstsNeuroEx=[number_of_burstsNeuroEx;noinb];
    end
    clear noinb
    
    %for the logISI bursts
    number_of_burstslog=[];
    for i=1:length(M2)
        noinb=length(burst7{i,1});
        number_of_burstslog=[number_of_burstslog;noinb];
    end
    clear noinb
    
    if length(filteredData1(:,1)) > 121
        channelIDs =1:length(filteredData1(:,1));
        channelIDs=num2cell(channelIDs)';
        for i=1:length(filteredData1(:,1))
            channelIDs{i}=num2str(channelIDs{i});
        end
    else
    end
    
    % since we dont have any threshold values we create a vector of
    % zeros for now ( remove it later on)
    
    threshold_value=zeros(1,length(Data3))';
    Units_per_second = Truehits/timesss;  %firing frequency (hz)
    %         BD=sum(number_of_bursts1);
    %         BDSEM = std(number_of_bursts1)/sqrt(length(number_of_bursts1));
    BNeuro=sum(number_of_burstsNeuroEx);
    BNeuroSEM = std(number_of_burstsNeuroEx)/sqrt(length(number_of_burstsNeuroEx));
    BLog=sum(number_of_burstslog);
    BLogSEM = std(number_of_burstslog)/sqrt(length(number_of_burstslog));
    %         negunits=sum(negpksT);
    %         negunitsSEM = std(negpksT)/sqrt(length(negpksT));
    %         posunits=sum(pospeaksT);
    %         posunitsSEM = std(pospeaksT)/sqrt(length(pospeaksT));
    
    
    % calculate the ISI's and STD of ISI
    
    test2=cell(1,length(M2));
    for i=1:length(M2)
        test=diff(M2{i,1});
        test2{i}=test;
    end
    test2=test2'; %contain the ISI all of the channels
    
    meanISI=cell(1,length(M2));
    for i=1:length(M2)
        meanISI{i}=mean(test2{i});
    end
    meanISI=meanISI'; %contains all the meanISI's of each channel
    
    medianISI=cell(1,length(M2));
    for i=1:length(M2)
        medianISI{i}=median(test2{i});
    end
    medianISI=medianISI'; %contains all the meanISI's of each channel
    
    medianISI=cell2mat(medianISI);
    
    stdISI = cell(1,length(M2));
    for i=1:length(M2)
        stdISI{i}=std(test2{i});
    end
    stdISI=stdISI';
    %% Generation of Table
    
    % add a check for the rownames to check if there are duplicate
    % names if so change it
    
    if length(channelIDs) == length(Truehits)
    else
        channelIDs = zeros(1,length(Truehits));
        channelIDs = 1:length(channelIDs);
        
    end
    
    
    if length(unique(channelIDs)) == length(channelIDs)
    else
        channelIDs = zeros(1,length(Truehits));
        channelIDs = 1:length(channelIDs);
        
    end
  
    %Generate a table for general data
    
    %check if channelIDs is a cell array with strings
    
    if ~iscell(channelIDs)
        channelIDs = strsplit(num2str(channelIDs))';
    end
    
    T=table(Truehits,meanISI,medianISI,stdISI,number_of_burstsNeuroEx,number_of_burstslog,Units_per_second,mean_ifr,CV,meanCV2,threshold_value,'Rownames',channelIDs,'VariableNames',{'Spikes','mean_ISI','median_ISI','std_ISI','Bursts_max_interval','Bursts_log_ISI','Fire_rate','mean_ifr','mean_CV_ISI','mean_CV2_ISI','threshold_value'});
    
    
    
    clear pospeaksT threshold_value negpksT minamplitude_in_volt maxamplitude_in_volt Units_per_second mean_ifr meanCV2 number_of_bursts1 number_of_burstsNeuroEx number_of_burstslog meanISI stdISI
    
    
    if length(filteredData1(:,1)) > 121 % it seems the spikes or units from a multiwell are  different
        T.Spikes(T.Spikes < 10) =0;
    else
        T.Spikes(T.Spikes < 10) =0;  %remove any electrode that has 10 or less spikes
        clear ghy khy
    end
    
    
    
    
    newHITS=T.Spikes;
    T=sortrows(T,1,'descend');
    
    for i=0
        T(ismember(T.Spikes,i),:)=[];               %remove anything that is zero
    end
    
   
    HITSSEM=std(T.Spikes)/sqrt(length(T.Spikes));
    sum_Truehits=sum(T.Spikes)/(size(T,1)-1);
    sum_bursts1=sum(T.Bursts_max_interval)/(size(T,1)-1);
    sum_bursts2=sum(T.Bursts_log_ISI)/(size(T,1)-1);
    sum_meanFR=sum(T.Fire_rate/(size(T,1)-1)); % account for the sum row mean FR of whole arry for active electrodes
    sum_meanISI=sum(cell2mat(T.mean_ISI)/(size(T,1)-1)); %mean ISI for the whole array (active electrodes)
    sum_stdISI=sum(cell2mat(T.std_ISI)/(size(T,1)-1));
    sum_CV=sum((T.mean_CV_ISI)/(size(T,1)-1));
    
    if isempty(T.median_ISI)
        median_ISI = 0;
    else
        median_ISI=median(T.median_ISI);
    end
    
    sum12=zeros(1,size(T,2));
    sum12(1)=sum_Truehits;
    sum12(2)=sum_meanISI;
    sum12(3)=median_ISI;
    sum12(4)=sum_stdISI;
    sum12(5)=sum_bursts1;
    sum12(6)=sum_bursts2;
    sum12(7)=sum_meanFR;
    sum12(8) = sum(T.mean_ifr)/(size(T,1)-1);
    sum12(9)=sum_CV;
    sum12(10) = sum(T.mean_CV2_ISI)/(size(T,1)-1);
    sum12(11) = sum(T.threshold_value)/(size(T,1)-1);
    clear sum_negpks sum_pospks sum_Truehits sum_bursts sum_bursts1 sum_bursts2 sum_meanFR sum_meanISI sum_stdISI sum_CV median_ISI;
    
    
    sum12=table(sum12(1,1),sum12(1,2),sum12(1,3),sum12(1,4),sum12(1,5),sum12(1,6),sum12(1,7),sum12(1,8),sum12(1,9),sum12(1,10),sum12(1,11),'Rownames',{'Mean'},'VariableNames',{'Spikes','mean_ISI','median_ISI','std_ISI','Bursts_max_interval','Bursts_log_ISI','Fire_rate','mean_ifr','mean_CV_ISI','mean_CV2_ISI','threshold_value'});
    T=[T;sum12];
    
    clear sum12
    %% Heatmap generation
    % Data1 = McsHDF5.McsData(selecteddata);
    M489 =num2cell(newHITS);
    
    
    if length(channelIDs) == 60
        M489 =cell2mat(M489);
        HITS=cell(2,length(M2))';  % if there are only 60 channels create new cell array for the 60 channel MEA
        for i = 1:length(HITS)
            if isempty(HITS{i,2})
                HITS{i,2} = 0;
            end
        end
        HITS{1,2}=M489(1,1);
        HITS{2,2}=M489(2,1);
        HITS{3,2}=M489(3,1);
        HITS{4,2}=M489(4,1);
        HITS{5,2}=M489(5,1);
        HITS{6,2}=M489(6,1);
        HITS{7,2}=M489(7,1);
        HITS{8,2}=M489(8,1);
        HITS{9,2}=M489(9,1);
        HITS{10,2}=M489(10,1);
        HITS{11,2}=M489(11,1);
        HITS{12,2}=M489(12,1);
        HITS{13,2}=M489(13,1);
        HITS{14,2}=M489(14,1);
        HITS{15,2}=M489(15,1);
        HITS{16,2}=M489(16,1);
        HITS{17,2}=M489(17,1);
        HITS{18,2}=M489(18,1);
        HITS{19,2}=M489(19,1);
        HITS{20,2}=M489(20,1);
        HITS{21,2}=M489(21,1);
        HITS{22,2}=M489(22,1);
        HITS{23,2}=M489(23,1);
        HITS{24,2}=M489(24,1);
        HITS{25,2}=M489(25,1);
        HITS{26,2}=M489(26,1);
        HITS{27,2}=M489(27,1);
        HITS{28,2}=M489(28,1);
        HITS{29,2}=M489(29,1);
        HITS{30,2}=M489(30,1);
        HITS{31,2}=M489(31,1);
        HITS{32,2}=M489(32,1);
        HITS{33,2}=M489(33,1);
        HITS{34,2}=M489(34,1);
        HITS{35,2}=M489(35,1);
        HITS{36,2}=M489(36,1);
        HITS{37,2}=M489(37,1);
        HITS{38,2}=M489(38,1);
        HITS{39,2}=M489(39,1);
        HITS{40,2}=M489(40,1);
        HITS{41,2}=M489(41,1);
        HITS{42,2}=M489(42,1);
        HITS{43,2}=M489(43,1);
        HITS{44,2}=M489(44,1);
        HITS{45,2}=M489(45,1);
        HITS{46,2}=M489(46,1);
        HITS{47,2}=M489(47,1);
        HITS{48,2}=M489(48,1);
        HITS{49,2}=M489(49,1);
        HITS{50,2}=M489(50,1);
        HITS{51,2}=M489(51,1);
        HITS{52,2}=M489(52,1);
        HITS{53,2}=M489(53,1);
        HITS{54,2}=M489(54,1);
        HITS{55,2}=M489(55,1);
        HITS{56,2}=M489(56,1);
        HITS{57,2}=M489(57,1);
        HITS{58,2}=M489(58,1);
        HITS{59,2}=M489(59,1);
        HITS{60,2}=M489(60,1);
        
        HITS{1,1}='C4';
        HITS{2,1}='C5';
        HITS{3,1}='C6';
        HITS{4,1}='C7';
        HITS{5,1}='C8';
        HITS{6,1}='C9';
        HITS{7,1}='D3';
        HITS{8,1}='D4';
        HITS{9,1}='D5';
        HITS{10,1}='D6';
        HITS{11,1}='D7';
        HITS{12,1}='D8';
        HITS{13,1}='D9';
        HITS{14,1}='D10';
        HITS{15,1}='E3';
        HITS{16,1}='E4';
        HITS{17,1}='E5';
        HITS{18,1}='E6';
        HITS{19,1}='E7';
        HITS{20,1}='E8';
        HITS{21,1}='E9';
        HITS{22,1}='E10';
        HITS{23,1}='F3';
        HITS{24,1}='F4';
        HITS{25,1}='F5';
        HITS{26,1}='F6';
        HITS{27,1}='F7';
        HITS{28,1}='F8';
        HITS{29,1}='F9';
        HITS{30,1}='F10';
        HITS{31,1}='G3';
        HITS{32,1}='G4';
        HITS{33,1}='G5';
        HITS{34,1}='G6';
        HITS{35,1}='G7';
        HITS{36,1}='G8';
        HITS{37,1}='G9';
        HITS{38,1}='G10';
        HITS{39,1}='H3';
        HITS{40,1}='H4';
        HITS{41,1}='H5';
        HITS{42,1}='H6';
        HITS{43,1}='H7';
        HITS{44,1}='H8';
        HITS{45,1}='H9';
        HITS{46,1}='H10';
        HITS{47,1}='J3';
        HITS{48,1}='J4';
        HITS{49,1}='J5';
        HITS{50,1}='J6';
        HITS{51,1}='J7';
        HITS{52,1}='J8';
        HITS{53,1}='J9';
        HITS{54,1}='J10';
        HITS{55,1}='K4';
        HITS{56,1}='K5';
        HITS{57,1}='K6';
        HITS{58,1}='K7';
        HITS{59,1}='K8';
        HITS{60,1}='K9';
        HITS{61,1}='D1';
        HITS{62,1}='E1';
        HITS{63,1}='F1';
        HITS{64,1}='G1';
        HITS{65,1}='H1';
        HITS{66,1}='J1';
        HITS{67,1}='C2';
        HITS{68,1}='D2';
        HITS{69,1}='E2';
        HITS{70,1}='F2';
        HITS{71,1}='G2';
        HITS{72,1}='H2';
        HITS{73,1}='J2';
        HITS{74,1}='K2';
        HITS{75,1}='B3';
        HITS{76,1}='C3';
        HITS{77,1}='K3';
        HITS{78,1}='L3';
        HITS{79,1}='A4';
        HITS{80,1}='B4';
        HITS{81,1}='L4';
        HITS{82,1}='M4';
        HITS{83,1}='A5';
        HITS{84,1}='B5';
        HITS{85,1}='L5';
        HITS{86,1}='M5';
        HITS{87,1}='A6';
        HITS{88,1}='B6';
        HITS{89,1}='L6';
        HITS{90,1}='M6';
        HITS{91,1}='A7';
        HITS{92,1}='B7';
        HITS{93,1}='L7';
        HITS{94,1}='M7';
        HITS{95,1}='A8';
        HITS{96,1}='B8';
        HITS{97,1}='L8';
        HITS{98,1}='M8';
        HITS{99,1}='A9';
        HITS{100,1}='B9';
        HITS{101,1}='L9';
        HITS{102,1}='M9';
        HITS{103,1}='B10';
        HITS{104,1}='C10';
        HITS{105,1}='K10';
        HITS{106,1}='L10';
        HITS{107,1}='C11';
        HITS{108,1}='D11';
        HITS{109,1}='E11';
        HITS{110,1}='F11';
        HITS{111,1}='G11';
        HITS{112,1}='H11';
        HITS{113,1}='J11';
        HITS{114,1}='K11';
        HITS{115,1}='D12';
        HITS{116,1}='E12';
        HITS{117,1}='F12';
        HITS{118,1}='G12';    %we will have to creat a new layout for the 60 channel MEA that fits within the 120 MEA
        HITS{119,1}='H12';
        HITS{120,1}='J12';
        
        
        layout= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS{7,2} HITS{15,2} HITS{23,2} HITS{31,2} HITS{39,2} HITS{47,2} nan nan nan; nan nan HITS{1,2} HITS{8,2} HITS{16,2} HITS{24,2} HITS{32,2} HITS{40,2} HITS{48,2} HITS{55,2} nan nan; nan nan HITS{2,2} HITS{9,2} HITS{17,2} HITS{25,2} HITS{33,2} HITS{41,2} HITS{49,2} HITS{56,2} nan nan; nan nan HITS{3,2} HITS{10,2} HITS{18,2} HITS{26,2} HITS{34,2} HITS{42,2} HITS{50,2} HITS{57,2} nan nan; nan nan HITS{4,2} HITS{11,2} HITS{19,2} HITS{27,2} HITS{35,2} HITS{43,2} HITS{51,2} HITS{58,2} nan nan; nan nan HITS{5,2} HITS{12,2} HITS{20,2} HITS{28,2} HITS{36,2} HITS{44,2} HITS{52,2} HITS{59,2} nan nan; nan nan HITS{6,2} HITS{13,2} HITS{21,2} HITS{29,2} HITS{37,2} HITS{45,2} HITS{53,2} HITS{60,2} nan nan;nan nan nan HITS{14,2} HITS{22,2} HITS{30,2} HITS{38,2} HITS{46,2} HITS{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
        %     newHITS=HITS(:,2);
        %     newHITS=cell2mat(newHITS);
    elseif length(channelIDs) > 145 %multiwell 24
        HITS=[channelIDs M489];
        
        
        layout=[nan HITS{12,2} HITS{11,2} nan nan HITS{24,2} HITS{23,2} nan nan HITS{36,2} HITS{35,2} nan nan HITS{48,2} HITS{47,2} nan nan HITS{60,2} HITS{59,2} nan nan HITS{72,2} HITS{71,2} nan;HITS{10,2} HITS{9,2} HITS{8,2} HITS{7,2} HITS{22,2} HITS{21,2} HITS{20,2} HITS{19,2} HITS{34,2} HITS{33,2} HITS{32,2} HITS{31,2} HITS{46,2} HITS{45,2} HITS{44,2} HITS{43,2} HITS{58,2} HITS{57,2} HITS{56,2} HITS{55,2} HITS{70,2} HITS{69,2} HITS{68,2} HITS{67,2};HITS{6,2} HITS{5,2} HITS{4,2} HITS{3,2} HITS{18,2} HITS{17,2} HITS{16,2} HITS{15,2} HITS{30,2} HITS{29,2} HITS{28,2} HITS{27,2} HITS{42,2} HITS{41,2} HITS{40,2} HITS{39,2} HITS{54,2} HITS{53,2} HITS{52,2} HITS{51,2} HITS{66,2} HITS{65,2} HITS{64,2} HITS{63,2};nan HITS{2,2} HITS{1,2} nan nan HITS{14,2} HITS{13,2} nan nan HITS{26,2} HITS{25,2} nan nan HITS{38,2} HITS{37,2} nan nan HITS{50,2} HITS{49,2} nan nan HITS{62,2} HITS{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS{84,2} HITS{83,2} nan nan HITS{96,2} HITS{95,2} nan nan HITS{108,2} HITS{107,2} nan nan HITS{120,2} HITS{119,2} nan nan HITS{132,2} HITS{131,2} nan nan HITS{144,2} HITS{143,2} nan; HITS{82,2} HITS{81,2} HITS{80,2} HITS{79,2} HITS{94,2} HITS{93,2} HITS{92,2} HITS{91,2} HITS{106,2} HITS{105,2} HITS{104,2} HITS{103,2} HITS{118,2} HITS{117,2} HITS{116,2} HITS{115,2} HITS{130,2} HITS{129,2} HITS{128,2} HITS{127,2} HITS{142,2} HITS{141,2} HITS{140,2} HITS{139,2}; HITS{78,2} HITS{77,2} HITS{76,2} HITS{75,2} HITS{90,2} HITS{89,2} HITS{88,2} HITS{87,2} HITS{102,2} HITS{101,2} HITS{100,2} HITS{99,2} HITS{114,2} HITS{113,2} HITS{112,2} HITS{111,2} HITS{126,2} HITS{125,2} HITS{124,2} HITS{123,2} HITS{138,2} HITS{137,2} HITS{136,2} HITS{135,2}; nan HITS{74,2} HITS{73,2} nan nan HITS{86,2} HITS{85,2} nan nan HITS{98,2} HITS{97,2} nan nan HITS{110,2} HITS{109,2} nan nan HITS{122,2} HITS{121,2} nan nan HITS{134,2} HITS{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS{156,2} HITS{155,2} nan nan HITS{168,2} HITS{167,2} nan nan HITS{180,2} HITS{179,2} nan nan HITS{192,2} HITS{191,2} nan nan HITS{204,2} HITS{203,2} nan nan HITS{216,2} HITS{215,2} nan; HITS{154,2} HITS{153,2} HITS{152,2} HITS{151,2} HITS{166,2} HITS{165,2} HITS{164,2} HITS{163,2} HITS{178,2} HITS{177,2} HITS{176,2} HITS{175,2} HITS{190,2} HITS{189,2} HITS{188,2} HITS{187,2} HITS{202,2} HITS{201,2} HITS{200,2} HITS{199,2} HITS{214,2} HITS{213,2} HITS{212,2} HITS{211,2}; HITS{150,2} HITS{149,2} HITS{148,2} HITS{147,2} HITS{162,2} HITS{161,2} HITS{160,2} HITS{159,2} HITS{174,2} HITS{173,2} HITS{172,2} HITS{171,2} HITS{186,2} HITS{185,2} HITS{184,2} HITS{183,2} HITS{198,2} HITS{197,2} HITS{196,2} HITS{195,2} HITS{210,2} HITS{209,2} HITS{208,2} HITS{207,2}; nan HITS{146,2} HITS{145,2} nan nan HITS{158,2} HITS{157,2} nan nan HITS{170,2} HITS{169,2} nan nan HITS{182,2} HITS{181,2} nan nan HITS{194,2} HITS{193,2} nan nan HITS{206,2} HITS{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS{228,2} HITS{227,2} nan nan HITS{240,2} HITS{239,2} nan nan HITS{252,2} HITS{251,2} nan nan HITS{264,2} HITS{263,2} nan nan HITS{276,2} HITS{275,2} nan nan HITS{288,2} HITS{287,2} nan; HITS{226,2} HITS{225,2} HITS{224,2} HITS{223,2} HITS{238,2} HITS{237,2} HITS{236,2} HITS{235,2} HITS{250,2} HITS{249,2} HITS{248,2} HITS{247,2} HITS{262,2} HITS{261,2} HITS{260,2} HITS{259,2} HITS{274,2} HITS{273,2} HITS{272,2} HITS{271,2} HITS{286,2} HITS{285,2} HITS{284,2} HITS{283,2}; HITS{222,2} HITS{221,2} HITS{220,2} HITS{219,2} HITS{234,2} HITS{233,2} HITS{232,2} HITS{231,2} HITS{246,2} HITS{245,2} HITS{244,2} HITS{243,2} HITS{258,2} HITS{257,2} HITS{256,2} HITS{255,2} HITS{270,2} HITS{269,2} HITS{268,2} HITS{267,2} HITS{282,2} HITS{281,2} HITS{280,2} HITS{279,2}; nan HITS{218,2} HITS{217,2} nan nan HITS{230,2} HITS{229,2} nan nan HITS{242,2} HITS{241,2} nan nan HITS{254,2} HITS{253,2} nan nan HITS{266,2} HITS{265,2} nan nan HITS{278,2} HITS{277,2} nan];
        
    elseif length(channelIDs) == 144 %mutilwell 12
        HITS =[channelIDs M489];
        
        layout=[nan HITS{12,2} HITS{11,2} nan nan HITS{24,2} HITS{23,2} nan nan HITS{36,2} HITS{35,2} nan nan HITS{48,2} HITS{47,2} nan nan HITS{60,2} HITS{59,2} nan nan HITS{72,2} HITS{71,2} nan;HITS{10,2} HITS{9,2} HITS{8,2} HITS{7,2} HITS{22,2} HITS{21,2} HITS{20,2} HITS{19,2} HITS{34,2} HITS{33,2} HITS{32,2} HITS{31,2} HITS{46,2} HITS{45,2} HITS{44,2} HITS{43,2} HITS{58,2} HITS{57,2} HITS{56,2} HITS{55,2} HITS{70,2} HITS{69,2} HITS{68,2} HITS{67,2};HITS{6,2} HITS{5,2} HITS{4,2} HITS{3,2} HITS{18,2} HITS{17,2} HITS{16,2} HITS{15,2} HITS{30,2} HITS{29,2} HITS{28,2} HITS{27,2} HITS{42,2} HITS{41,2} HITS{40,2} HITS{39,2} HITS{54,2} HITS{53,2} HITS{52,2} HITS{51,2} HITS{66,2} HITS{65,2} HITS{64,2} HITS{63,2};nan HITS{2,2} HITS{1,2} nan nan HITS{14,2} HITS{13,2} nan nan HITS{26,2} HITS{25,2} nan nan HITS{38,2} HITS{37,2} nan nan HITS{50,2} HITS{49,2} nan nan HITS{62,2} HITS{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;...
            nan HITS{84,2} HITS{83,2} nan nan HITS{96,2} HITS{95,2} nan nan HITS{108,2} HITS{107,2} nan nan HITS{120,2} HITS{119,2} nan nan HITS{132,2} HITS{131,2} nan nan HITS{144,2} HITS{143,2} nan; HITS{82,2} HITS{81,2} HITS{80,2} HITS{79,2} HITS{94,2} HITS{93,2} HITS{92,2} HITS{91,2} HITS{106,2} HITS{105,2} HITS{104,2} HITS{103,2} HITS{118,2} HITS{117,2} HITS{116,2} HITS{115,2} HITS{130,2} HITS{129,2} HITS{128,2} HITS{127,2} HITS{142,2} HITS{141,2} HITS{140,2} HITS{139,2}; HITS{78,2} HITS{77,2} HITS{76,2} HITS{75,2} HITS{90,2} HITS{89,2} HITS{88,2} HITS{87,2} HITS{102,2} HITS{101,2} HITS{100,2} HITS{99,2} HITS{114,2} HITS{113,2} HITS{112,2} HITS{111,2} HITS{126,2} HITS{125,2} HITS{124,2} HITS{123,2} HITS{138,2} HITS{137,2} HITS{136,2} HITS{135,2}; nan HITS{74,2} HITS{73,2} nan nan HITS{86,2} HITS{85,2} nan nan HITS{98,2} HITS{97,2} nan nan HITS{110,2} HITS{109,2} nan nan HITS{122,2} HITS{121,2} nan nan HITS{134,2} HITS{133,2} nan];
        
    else
        HITS =[channelIDs M489];
        
        layout= [nan nan nan HITS{51,2} HITS{55,2} HITS{59,2} HITS{63,2} HITS{67,2} HITS{71,2} nan nan nan;nan nan HITS{47,2} HITS{50,2} HITS{54,2} HITS{58,2} HITS{64,2} HITS{68,2} HITS{72,2} HITS{75,2} nan nan;nan HITS{45,2} HITS{46,2} HITS{49,2} HITS{53,2} HITS{57,2} HITS{65,2} HITS{69,2} HITS{73,2} HITS{76,2} HITS{77,2} nan; HITS{41,2} HITS{42,2} HITS{43,2} HITS{44,2} HITS{52,2} HITS{56,2} HITS{66,2} HITS{70,2} HITS{74,2} HITS{79,2} HITS{80,2} HITS{81,2}; HITS{37,2} HITS{38,2} HITS{39,2} HITS{40,2} HITS{48,2} HITS{60,2} HITS{62,2} HITS{78,2} HITS{82,2} HITS{83,2} HITS{84,2} HITS{85,2}; HITS{33,2} HITS{34,2} HITS{35,2} HITS{36,2} HITS{32,2} HITS{31,2} HITS{61,2} HITS{90,2} HITS{86,2} HITS{87,2} HITS{88,2} HITS{89,2}; HITS{29,2} HITS{28,2} HITS{27,2} HITS{26,2} HITS{30,2} HITS{1,2} HITS{91,2} HITS{92,2} HITS{96,2} HITS{95,2} HITS{94,2} HITS{93,2}; HITS{25,2} HITS{24,2} HITS{23,2} HITS{22,2} HITS{18,2} HITS{2,2} HITS{120,2} HITS{108,2} HITS{100,2} HITS{99,2} HITS{98,2} HITS{97,2}; HITS{21,2} HITS{20,2} HITS{19,2} HITS{14,2} HITS{10,2} HITS{6,2} HITS{116,2} HITS{112,2} HITS{104,2} HITS{103,2} HITS{102,2} HITS{101,2};nan HITS{17,2} HITS{16,2} HITS{13,2} HITS{9,2} HITS{5,2} HITS{117,2} HITS{113,2} HITS{109,2} HITS{106,2} HITS{105,2} nan;nan nan HITS{15,2} HITS{12,2} HITS{8,2} HITS{4,2} HITS{118,2} HITS{114,2} HITS{110,2} HITS{107,2} nan nan;nan nan nan HITS{11,2} HITS{7,2} HITS{3,2} HITS{119,2} HITS{115,2} HITS{111,2} nan nan nan];
        
    end
    
    if length(channelIDs) > 121
        ans90 = 1:length(layout(:,1));
        ans90=num2cell(ans90);
        for i=1:length(layout(:,1))
            ans90{i}=num2str(ans90{i});
        end
        
    else
        ans90 = cellstr(('A':'H')')';
        ans90{9} = 'J';
        ans90{10} = 'K';
        ans90{11} ='L';
        ans90{12} = 'M';
    end
    clear Data1 M489
    %% calculating firing rate/active electrodes/inactive
    %Calculate Firing rate
    %The SPYCODE paper  bologna et al., 2010 stated that they calculated the fire rate and instaneous fire rate over the whole culture
    %They stated that they calculate the FR as the hits per channel averaged over all the active electrodes
    %The IFR is calculatd by
    %Total duration of one signal is 60.2 s
    %M4 contains all the units per channel
    FireR = Truehits/timesss; %per second%--> total amount of units of all channels
    silentelec= find(newHITS < 1); %silent electrodes
    silentelecamount = length(silentelec);
    silentelecnames = channelIDs(silentelec); % which electrode is inactive
    activeelec = find(newHITS >= 1);   %active electrodes
    activeelecamount = length(activeelec);
    activeelecnames = channelIDs(activeelec); %which electrodes were active
    
    
    Bab=table(silentelecamount);
    Bap=table(silentelecnames);
    Bak=table(activeelecamount);
    Bal=table(activeelecnames);
    
    
    clear silentelecamount silentelecnames activeelecamount activeelecnames channelIDs
    %% calculating burstiness index
    %burstiness index from Daniel wagenaar neurosci et al.,2005
    % Instead, we used the following method: divide a 5 min recording into 300 1-sec-long
    % time bins and count the number of spikes (total
    % across all electrodes) in each bin. Compute the
    % fraction of the total number of spikes accounted
    % for by the 15% of bins with the largest counts. If
    % the firing rate is tonic, this number, f15, will be
    % close to 0.15. Conversely, if a recording is so
    % bursty that most of the spikes are contained in
    % bursts, f15 will be close to 1, because even at the
    % highest burst rates observed during these experiments, bursts did not occupy 45 1-seclong bins (15%) in a 5 min recording. We then
    % defined a burstiness index (BI), normalized between 0 (no bursts) and 1 (burst dominated) as
    % BI = ( f15 - 0.15)/0.85.
    
    
    bincounts2={};
    binranges=linspace(0,floor(timesss),floor(timesss)*30); %the 30 represents the fps
    binranges4567=binranges;
    for i=1:length(M2)
        if isempty(M2{i})
            bincounts = zeros(1,floor(timesss)*30);
        else
            bincounts=histc(M2{i,1},binranges);
        end
        bincounts2=[bincounts2 bincounts];
    end
    bincounts2=bincounts2';
    bincounts2=vertcat(bincounts2{:});
    bincountssec=bincounts2;
    
    clear bincounts2 binranges bincounts
    
    bincounts21={};
    binranges21=0:timesss;
    for i=1:length(M2)
        if isempty(M2{i})
            bincounts20 = zeros(1,length(binranges21));
        else
            bincounts20=histc(M2{i,1},binranges21);
        end
        bincounts21=[bincounts21 bincounts20];
    end
    bincounts21=bincounts21';
    unitpersecond=bincounts21;
    bincounts21=vertcat(bincounts21{:});
    
    M3=[];
    for i = 1:length(M2)
        M3 = [M3 M2{i}];
    end
    M3 =sort(M3,'ascend');
    binned = histc(M3,0:floor(timesss));
    top15 = floor(length(binned)*0.15);
    
    BI = sum(maxk(binned,top15))/length(M3);
    
  
    BI=table(BI);
    
    
    clear bincounts21 binranges21 bincounts20 top9 lengthop BIp Truehits M3 binned top15 bincounts21
    %% top active channels
    [~,Imax]=max(newHITS);  %determines the channel with the highest units and sets this as the referenec channel
    
    [maxch,imaxch]=maxk(newHITS,10);  %only in matlab 2017 and up
    imaxch2=imaxch(6:10);
    
    clear val maxch olds indolds correctindxolds
    %% for the Connectivity maps
    
    for i=1:length(M2) %remove anything below 10 spikes
        if length(M2{i,1}) < 10
            M2{i,1} =[];
        else
        end
    end
    
    
    if length(filteredData1(:,1)) == 60
        newM2={};
        newM2{1}=nan;
        newM2{2}=nan;
        newM2{3}=nan;
        newM2{4}=nan;
        newM2{5}=nan;
        newM2{6}=nan;
        newM2{7}=nan;
        newM2{8}=nan;
        newM2{9}=nan;
        newM2{10}=nan;
        newM2{11}=nan;
        newM2{12}=nan;
        newM2{13}=nan;
        newM2{14}=nan;
        newM2{15}=nan;
        newM2{16}=nan;
        newM2{17}=nan;
        newM2{18}=nan;
        newM2{19}=nan;
        newM2{20}=nan;
        newM2{21}=nan;
        newM2{22}=nan;
        newM2{23}=nan;
        newM2{24}=nan;
        
        newM2{25}=nan;
        newM2{26}=nan;
        newM2{27}=nan;
        newM2{28}=M2{1};
        newM2{29}=M2{2};
        newM2{30}=M2{3};
        newM2{31}=M2{4};
        newM2{32}=M2{5};
        newM2{33}=M2{6};
        newM2{34}=nan;
        newM2{35}=nan;
        newM2{36}=nan;
        
        newM2{37}=nan;
        newM2{38}=nan;
        newM2{39}=M2{7};
        newM2{40}=M2{8};
        newM2{41}=M2{9};
        newM2{42}=M2{10};
        newM2{43}=M2{11};
        newM2{44}=M2{12};
        newM2{45}=M2{13};
        newM2{46}=M2{14};
        newM2{47}=nan;
        newM2{48}=nan;
        
        newM2{49}=nan;
        newM2{50}=nan;
        newM2{51}=M2{15};
        newM2{52}=M2{16};
        newM2{53}=M2{17};
        newM2{54}=M2{18};
        newM2{55}=M2{19};
        newM2{56}=M2{20};
        newM2{57}=M2{21};
        newM2{58}=M2{22};
        newM2{59}=nan;
        newM2{60}=nan;
        
        newM2{61}=nan;
        newM2{62}=nan;
        newM2{63}=M2{23};
        newM2{64}=M2{24};
        newM2{65}=M2{25};
        newM2{66}=M2{26};
        newM2{67}=M2{27};
        newM2{68}=M2{28};
        newM2{69}=M2{29};
        newM2{70}=M2{30};
        newM2{71}=nan;
        newM2{72}=nan;
        
        newM2{73}=nan;
        newM2{74}=nan;
        newM2{75}=M2{31};
        newM2{76}=M2{32};
        newM2{77}=M2{33};
        newM2{78}=M2{34};
        newM2{79}=M2{35};
        newM2{80}=M2{36};
        newM2{81}=M2{37};
        newM2{82}=M2{38};
        newM2{83}=nan;
        newM2{84}=nan;
        
        newM2{85}=nan;
        newM2{86}=nan;
        newM2{87}=M2{39};
        newM2{88}=M2{40};
        newM2{89}=M2{41};
        newM2{90}=M2{42};
        newM2{91}=M2{43};
        newM2{92}=M2{44};
        newM2{93}=M2{45};
        newM2{94}=M2{46};
        newM2{95}=nan;
        newM2{96}=nan;
        
        newM2{97}=nan;
        newM2{98}=nan;
        newM2{99}=M2{47};
        newM2{100}=M2{48};
        newM2{101}=M2{49};
        newM2{102}=M2{50};
        newM2{103}=M2{51};
        newM2{104}=M2{52};
        newM2{105}=M2{53};
        newM2{106}=M2{54};
        newM2{107}=nan;
        newM2{108}=nan;
        
        newM2{109}=nan;
        newM2{110}=nan;
        newM2{111}=nan;
        newM2{112}=M2{55};
        newM2{113}=M2{56};
        newM2{114}=M2{57};
        newM2{115}=M2{58};
        newM2{116}=M2{59};
        newM2{117}=M2{60};
        newM2{118}=nan;
        newM2{119}=nan;
        newM2{120}=nan;
        
        newM2{121}=nan;
        newM2{122}=nan;
        newM2{123}=nan;
        newM2{124}=nan;
        newM2{125}=nan;
        newM2{126}=nan;
        newM2{127}=nan;
        newM2{128}=nan;
        newM2{129}=nan;
        newM2{130}=nan;
        newM2{131}=nan;
        newM2{132}=nan;
        newM2{133}=nan;
        newM2{134}=nan;
        newM2{135}=nan;
        newM2{136}=nan;
        newM2{137}=nan;
        newM2{138}=nan;
        newM2{139}=nan;
        newM2{140}=nan;
        newM2{141}=nan;
        newM2{142}=nan;
        newM2{143}=nan;
        newM2{144}=nan;
        newM2=newM2';
        
    elseif length(filteredData1(:,1)) > 145
        newM2={};
        newM2{1}=nan;
        newM2{2}=M2{10};
        newM2{3}=M2{6};
        newM2{4}=nan;
        newM2{5}=nan;
        newM2{6}=nan;
        newM2{7}=M2{82};
        newM2{8}=M2{78};
        newM2{9}=nan;
        newM2{10}=nan;
        newM2{11}=nan;
        newM2{12}=M2{154};
        newM2{13}=M2{150};
        newM2{14}=nan;
        newM2{15}=nan;
        newM2{16}=nan;
        newM2{17}=M2{226};
        newM2{18}=M2{222};
        newM2{19}=nan;
        
        newM2{20}=M2{12};
        newM2{21}=M2{9};
        newM2{22}=M2{5};
        newM2{23}=M2{2};
        newM2{24}=nan;
        newM2{25}=M2{84};
        newM2{26}=M2{81};
        newM2{27}=M2{77};
        newM2{28}=M2{74};
        newM2{29}=nan;
        newM2{30}=M2{156};
        newM2{31}=M2{153};
        newM2{32}=M2{149};
        newM2{33}=M2{146};
        newM2{34}=nan;
        newM2{35}=M2{228};
        newM2{36}=M2{225};
        newM2{37}=M2{221};
        newM2{38}=M2{218};
        
        newM2{39}=M2{11};
        newM2{40}=M2{8};
        newM2{41}=M2{4};
        newM2{42}=M2{1};
        newM2{43}=nan;
        newM2{44}=M2{83};
        newM2{45}=M2{80};
        newM2{46}=M2{76};
        newM2{47}=M2{73};
        newM2{48}=nan;
        newM2{49}=M2{155};
        newM2{50}=M2{152};
        newM2{51}=M2{148};
        newM2{52}=M2{145};
        newM2{53}=nan;
        newM2{54}=M2{227};
        newM2{55}=M2{224};
        newM2{56}=M2{220};
        newM2{57}=M2{217};
        
        newM2{58}=nan;
        newM2{59}=M2{7};
        newM2{60}=M2{3};
        newM2{61}=nan;
        newM2{62}=nan;
        newM2{63}=nan;
        newM2{64}=M2{79};
        newM2{65}=M2{75};
        newM2{66}=nan;
        newM2{67}=nan;
        newM2{68}=nan;
        newM2{69}=M2{151};
        newM2{70}=M2{147};
        newM2{71}=nan;
        newM2{72}=nan;
        newM2{73}=nan;
        newM2{74}=M2{223};
        newM2{75}=M2{219};
        newM2{76}=nan;
        
        newM2{77}=nan;
        newM2{78}=M2{22};
        newM2{79}=M2{18};
        newM2{80}=nan;
        newM2{81}=nan;
        newM2{82}=nan;
        newM2{83}=M2{94};
        newM2{84}=M2{90};
        newM2{85}=nan;
        newM2{86}=nan;
        newM2{87}=nan;
        newM2{88}=M2{166};
        newM2{89}=M2{162};
        newM2{90}=nan;
        newM2{91}=nan;
        newM2{92}=nan;
        newM2{93}=M2{238};
        newM2{94}=M2{234};
        newM2{95}=nan;
        
        newM2{96}=M2{24};
        newM2{97}=M2{21};
        newM2{98}=M2{17};
        newM2{99}=M2{14};
        newM2{100}=nan;
        newM2{101}=M2{96};
        newM2{102}=M2{93};
        newM2{103}=M2{89};
        newM2{104}=M2{86};
        newM2{105}=nan;
        newM2{106}=M2{168};
        newM2{107}=M2{165};
        newM2{108}=M2{161};
        newM2{109}=M2{158};
        newM2{110}=nan;
        newM2{111}=M2{240};
        newM2{112}=M2{237};
        newM2{113}=M2{233};
        newM2{114}=M2{230};
        
        newM2{115}=M2{23};
        newM2{116}=M2{20};
        newM2{117}=M2{16};
        newM2{118}=M2{13};
        newM2{119}=nan;
        newM2{120}=M2{95};
        newM2{121}=M2{92};
        newM2{122}=M2{88};
        newM2{123}=M2{85};
        newM2{124}=nan;
        newM2{125}=M2{167};
        newM2{126}=M2{164};
        newM2{127}=M2{160};
        newM2{128}=M2{157};
        newM2{129}=nan;
        newM2{130}=M2{239};
        newM2{131}=M2{236};
        newM2{132}=M2{232};
        newM2{133}=M2{229};
        
        newM2{134}=nan;
        newM2{135}=M2{19};
        newM2{136}=M2{15};
        newM2{137}=nan;
        newM2{138}=nan;
        newM2{139}=nan;
        newM2{140}=M2{91};
        newM2{141}=M2{87};
        newM2{142}=nan;
        newM2{143}=nan;
        newM2{144}=nan;
        newM2{145}=M2{163};
        newM2{146}=M2{159};
        newM2{147}=nan;
        newM2{148}=nan;
        newM2{149}=nan;
        newM2{150}=M2{235};
        newM2{151}=M2{231};
        newM2{152}=nan;
        
        newM2{153}=nan;
        newM2{154}=M2{34};
        newM2{155}=M2{30};
        newM2{156}=nan;
        newM2{157}=nan;
        newM2{158}=nan;
        newM2{159}=M2{106};
        newM2{160}=M2{102};
        newM2{161}=nan;
        newM2{162}=nan;
        newM2{163}=nan;
        newM2{164}=M2{178};
        newM2{165}=M2{174};
        newM2{166}=nan;
        newM2{167}=nan;
        newM2{168}=nan;
        newM2{169}=M2{250};
        newM2{170}=M2{246};
        newM2{171}=nan;
        
        newM2{172}=M2{36};
        newM2{173}=M2{33};
        newM2{174}=M2{29};
        newM2{175}=M2{26};
        newM2{176}=nan;
        newM2{177}=M2{108};
        newM2{178}=M2{105};
        newM2{179}=M2{101};
        newM2{180}=M2{98};
        newM2{181}=nan;
        newM2{182}=M2{180};
        newM2{183}=M2{177};
        newM2{184}=M2{173};
        newM2{185}=M2{170};
        newM2{186}=nan;
        newM2{187}=M2{252};
        newM2{188}=M2{249};
        newM2{189}=M2{245};
        newM2{190}=M2{242};
        
        newM2{191}=M2{35};
        newM2{192}=M2{32};
        newM2{193}=M2{28};
        newM2{194}=M2{25};
        newM2{195}=nan;
        newM2{196}=M2{107};
        newM2{197}=M2{104};
        newM2{198}=M2{100};
        newM2{199}=M2{97};
        newM2{200}=nan;
        newM2{201}=M2{179};
        newM2{202}=M2{176};
        newM2{203}=M2{172};
        newM2{204}=M2{169};
        newM2{205}=nan;
        newM2{206}=M2{251};
        newM2{207}=M2{248};
        newM2{208}=M2{244};
        newM2{209}=M2{241};
        
        newM2{210}=nan;
        newM2{211}=M2{31};
        newM2{212}=M2{27};
        newM2{213}=nan;
        newM2{214}=nan;
        newM2{215}=nan;
        newM2{216}=M2{103};
        newM2{217}=M2{99};
        newM2{218}=nan;
        newM2{219}=nan;
        newM2{220}=nan;
        newM2{221}=M2{175};
        newM2{222}=M2{171};
        newM2{223}=nan;
        newM2{224}=nan;
        newM2{225}=nan;
        newM2{226}=M2{247};
        newM2{227}=M2{243};
        newM2{228}=nan;
        
        newM2{229}=nan;
        newM2{230}=M2{46};
        newM2{231}=M2{42};
        newM2{232}=nan;
        newM2{233}=nan;
        newM2{234}=nan;
        newM2{235}=M2{118};
        newM2{236}=M2{114};
        newM2{237}=nan;
        newM2{238}=nan;
        newM2{239}=nan;
        newM2{240}=M2{190};
        newM2{241}=M2{186};
        newM2{242}=nan;
        newM2{243}=nan;
        newM2{244}=nan;
        newM2{245}=M2{262};
        newM2{246}=M2{258};
        newM2{247}=nan;
        
        newM2{248}=M2{48};
        newM2{249}=M2{45};
        newM2{250}=M2{41};
        newM2{251}=M2{38};
        newM2{252}=nan;
        newM2{253}=M2{120};
        newM2{254}=M2{117};
        newM2{255}=M2{113};
        newM2{256}=M2{110};
        newM2{257}=nan;
        newM2{258}=M2{192};
        newM2{259}=M2{189};
        newM2{260}=M2{185};
        newM2{261}=M2{182};
        newM2{262}=nan;
        newM2{263}=M2{264};
        newM2{264}=M2{261};
        newM2{265}=M2{257};
        newM2{266}=M2{254};
        
        newM2{267}=M2{47};
        newM2{268}=M2{44};
        newM2{269}=M2{40};
        newM2{270}=M2{37};
        newM2{271}=nan;
        newM2{272}=M2{119};
        newM2{273}=M2{116};
        newM2{274}=M2{112};
        newM2{275}=M2{109};
        newM2{276}=nan;
        newM2{277}=M2{191};
        newM2{278}=M2{188};
        newM2{279}=M2{184};
        newM2{280}=M2{181};
        newM2{281}=nan;
        newM2{282}=M2{263};
        newM2{283}=M2{250};
        newM2{284}=M2{256};
        newM2{285}=M2{253};
        
        newM2{286}=nan;
        newM2{287}=M2{43};
        newM2{288}=M2{39};
        newM2{289}=nan;
        newM2{290}=nan;
        newM2{291}=nan;
        newM2{292}=M2{115};
        newM2{293}=M2{111};
        newM2{294}=nan;
        newM2{295}=nan;
        newM2{296}=nan;
        newM2{297}=M2{187};
        newM2{298}=M2{183};
        newM2{299}=nan;
        newM2{300}=nan;
        newM2{301}=nan;
        newM2{302}=M2{259};
        newM2{303}=M2{255};
        newM2{304}=nan;
        
        newM2{305}=nan;
        newM2{306}=M2{58};
        newM2{307}=M2{54};
        newM2{308}=nan;
        newM2{309}=nan;
        newM2{310}=nan;
        newM2{311}=M2{130};
        newM2{312}=M2{126};
        newM2{313}=nan;
        newM2{314}=nan;
        newM2{315}=nan;
        newM2{316}=M2{202};
        newM2{317}=M2{198};
        newM2{318}=nan;
        newM2{319}=nan;
        newM2{320}=nan;
        newM2{321}=M2{274};
        newM2{322}=M2{270};
        newM2{323}=nan;
        
        newM2{324}=M2{60};
        newM2{325}=M2{57};
        newM2{326}=M2{53};
        newM2{327}=M2{50};
        newM2{328}=nan;
        newM2{329}=M2{132};
        newM2{330}=M2{129};
        newM2{331}=M2{125};
        newM2{332}=M2{122};
        newM2{333}=nan;
        newM2{334}=M2{204};
        newM2{335}=M2{201};
        newM2{336}=M2{197};
        newM2{337}=M2{194};
        newM2{338}=nan;
        newM2{339}=M2{276};
        newM2{340}=M2{273};
        newM2{341}=M2{269};
        newM2{342}=M2{266};
        
        newM2{343}=M2{59};
        newM2{344}=M2{56};
        newM2{345}=M2{52};
        newM2{346}=M2{49};
        newM2{347}=nan;
        newM2{348}=M2{131};
        newM2{349}=M2{128};
        newM2{350}=M2{124};
        newM2{351}=M2{121};
        newM2{352}=nan;
        newM2{353}=M2{203};
        newM2{354}=M2{200};
        newM2{355}=M2{196};
        newM2{356}=M2{193};
        newM2{357}=nan;
        newM2{358}=M2{275};
        newM2{359}=M2{272};
        newM2{360}=M2{268};
        newM2{361}=M2{265};
        
        newM2{362}=nan;
        newM2{363}=M2{55};
        newM2{364}=M2{51};
        newM2{365}=nan;
        newM2{366}=nan;
        newM2{367}=nan;
        newM2{368}=M2{127};
        newM2{369}=M2{123};
        newM2{370}=nan;
        newM2{371}=nan;
        newM2{372}=nan;
        newM2{373}=M2{199};
        newM2{374}=M2{195};
        newM2{375}=nan;
        newM2{376}=nan;
        newM2{377}=nan;
        newM2{378}=M2{271};
        newM2{379}=M2{267};
        newM2{380}=nan;
        
        newM2{381}=nan;
        newM2{382}=M2{70};
        newM2{383}=M2{66};
        newM2{384}=nan;
        newM2{385}=nan;
        newM2{386}=nan;
        newM2{387}=M2{142};
        newM2{388}=M2{138};
        newM2{389}=nan;
        newM2{390}=nan;
        newM2{391}=nan;
        newM2{392}=M2{214};
        newM2{393}=M2{210};
        newM2{394}=nan;
        newM2{395}=nan;
        newM2{396}=nan;
        newM2{397}=M2{286};
        newM2{398}=M2{282};
        newM2{399}=nan;
        
        newM2{400}=M2{72};
        newM2{401}=M2{69};
        newM2{402}=M2{65};
        newM2{403}=M2{62};
        newM2{404}=nan;
        newM2{405}=M2{144};
        newM2{406}=M2{141};
        newM2{407}=M2{137};
        newM2{408}=M2{134};
        newM2{409}=nan;
        newM2{410}=M2{216};
        newM2{411}=M2{213};
        newM2{412}=M2{209};
        newM2{413}=M2{206};
        newM2{414}=nan;
        newM2{415}=M2{288};
        newM2{416}=M2{285};
        newM2{417}=M2{281};
        newM2{418}=M2{278};
        
        newM2{419}=M2{71};
        newM2{420}=M2{68};
        newM2{421}=M2{64};
        newM2{422}=M2{61};
        newM2{423}=nan;
        newM2{424}=M2{143};
        newM2{425}=M2{140};
        newM2{426}=M2{136};
        newM2{427}=M2{133};
        newM2{428}=nan;
        newM2{429}=M2{215};
        newM2{430}=M2{212};
        newM2{431}=M2{208};
        newM2{432}=M2{205};
        newM2{433}=nan;
        newM2{434}=M2{287};
        newM2{435}=M2{284};
        newM2{436}=M2{280};
        newM2{437}=M2{277};
        
        newM2{438}=nan;
        newM2{439}=M2{67};
        newM2{440}=M2{63};
        newM2{441}=nan;
        newM2{442}=nan;
        newM2{443}=nan;
        newM2{444}=M2{139};
        newM2{445}=M2{135};
        newM2{446}=nan;
        newM2{447}=nan;
        newM2{448}=nan;
        newM2{449}=M2{211};
        newM2{450}=M2{207};
        newM2{451}=nan;
        newM2{452}=nan;
        newM2{453}=nan;
        newM2{454}=M2{283};
        newM2{455}=M2{279};
        newM2{456}=nan;
        newM2=newM2';
    elseif length(filteredData1(:,1)) == 144
        newM2={};
        newM2{1}=nan;
        newM2{2}=M2{10};
        newM2{3}=M2{6};
        newM2{4}=nan;
        newM2{5}=nan;
        newM2{6}=nan;
        newM2{7}=M2{82};
        newM2{8}=M2{78};
        newM2{9}=nan;
        newM2{10}=nan;
        newM2{11}=nan;
        newM2{12}=M2{154};
        newM2{13}=M2{150};
        newM2{14}=nan;
        newM2{15}=nan;
        newM2{16}=nan;
        newM2{17}=M2{226};
        newM2{18}=M2{222};
        newM2{19}=nan;
        
        newM2{20}=M2{12};
        newM2{21}=M2{9};
        newM2{22}=M2{5};
        newM2{23}=M2{2};
        newM2{24}=nan;
        newM2{25}=M2{84};
        newM2{26}=M2{81};
        newM2{27}=M2{77};
        newM2{28}=M2{74};
        newM2{29}=nan;
        newM2{30}=M2{156};
        newM2{31}=M2{153};
        newM2{32}=M2{149};
        newM2{33}=M2{146};
        newM2{34}=nan;
        newM2{35}=M2{228};
        newM2{36}=M2{225};
        newM2{37}=M2{221};
        newM2{38}=M2{218};
        
        newM2{39}=M2{11};
        newM2{40}=M2{8};
        newM2{41}=M2{4};
        newM2{42}=M2{1};
        newM2{43}=nan;
        newM2{44}=M2{83};
        newM2{45}=M2{80};
        newM2{46}=M2{76};
        newM2{47}=M2{73};
        newM2{48}=nan;
        newM2{49}=M2{155};
        newM2{50}=M2{152};
        newM2{51}=M2{148};
        newM2{52}=M2{145};
        newM2{53}=nan;
        newM2{54}=M2{227};
        newM2{55}=M2{224};
        newM2{56}=M2{220};
        newM2{57}=M2{217};
        
        newM2{58}=nan;
        newM2{59}=M2{7};
        newM2{60}=M2{3};
        newM2{61}=nan;
        newM2{62}=nan;
        newM2{63}=nan;
        newM2{64}=M2{79};
        newM2{65}=M2{75};
        newM2{66}=nan;
        newM2{67}=nan;
        newM2{68}=nan;
        newM2{69}=M2{151};
        newM2{70}=M2{147};
        newM2{71}=nan;
        newM2{72}=nan;
        newM2{73}=nan;
        newM2{74}=M2{223};
        newM2{75}=M2{219};
        newM2{76}=nan;
        
        newM2{77}=nan;
        newM2{78}=M2{22};
        newM2{79}=M2{18};
        newM2{80}=nan;
        newM2{81}=nan;
        newM2{82}=nan;
        newM2{83}=M2{94};
        newM2{84}=M2{90};
        newM2{85}=nan;
        newM2{86}=nan;
        newM2{87}=nan;
        newM2{88}=M2{166};
        newM2{89}=M2{162};
        newM2{90}=nan;
        newM2{91}=nan;
        newM2{92}=nan;
        newM2{93}=M2{238};
        newM2{94}=M2{234};
        newM2{95}=nan;
        
        newM2{96}=M2{24};
        newM2{97}=M2{21};
        newM2{98}=M2{17};
        newM2{99}=M2{14};
        newM2{100}=nan;
        newM2{101}=M2{96};
        newM2{102}=M2{93};
        newM2{103}=M2{89};
        newM2{104}=M2{86};
        newM2{105}=nan;
        newM2{106}=M2{168};
        newM2{107}=M2{165};
        newM2{108}=M2{161};
        newM2{109}=M2{158};
        newM2{110}=nan;
        newM2{111}=M2{240};
        newM2{112}=M2{237};
        newM2{113}=M2{233};
        newM2{114}=M2{230};
        
        newM2{115}=M2{23};
        newM2{116}=M2{20};
        newM2{117}=M2{16};
        newM2{118}=M2{13};
        newM2{119}=nan;
        newM2{120}=M2{95};
        newM2{121}=M2{92};
        newM2{122}=M2{88};
        newM2{123}=M2{85};
        newM2{124}=nan;
        newM2{125}=M2{167};
        newM2{126}=M2{164};
        newM2{127}=M2{160};
        newM2{128}=M2{157};
        newM2{129}=nan;
        newM2{130}=M2{239};
        newM2{131}=M2{236};
        newM2{132}=M2{232};
        newM2{133}=M2{229};
        
        newM2{134}=nan;
        newM2{135}=M2{19};
        newM2{136}=M2{15};
        newM2{137}=nan;
        newM2{138}=nan;
        newM2{139}=nan;
        newM2{140}=M2{91};
        newM2{141}=M2{87};
        newM2{142}=nan;
        newM2{143}=nan;
        newM2{144}=nan;
        newM2{145}=M2{163};
        newM2{146}=M2{159};
        newM2{147}=nan;
        newM2{148}=nan;
        newM2{149}=nan;
        newM2{150}=M2{235};
        newM2{151}=M2{231};
        newM2{152}=nan;
        
        newM2{153}=nan;
        newM2{154}=M2{34};
        newM2{155}=M2{30};
        newM2{156}=nan;
        newM2{157}=nan;
        newM2{158}=nan;
        newM2{159}=M2{106};
        newM2{160}=M2{102};
        newM2{161}=nan;
        newM2{162}=nan;
        newM2{163}=nan;
        newM2{164}=M2{178};
        newM2{165}=M2{174};
        newM2{166}=nan;
        newM2{167}=nan;
        newM2{168}=nan;
        newM2{169}=M2{250};
        newM2{170}=M2{246};
        newM2{171}=nan;
        
        newM2{172}=M2{36};
        newM2{173}=M2{33};
        newM2{174}=M2{29};
        newM2{175}=M2{26};
        newM2{176}=nan;
        newM2{177}=M2{108};
        newM2{178}=M2{105};
        newM2{179}=M2{101};
        newM2{180}=M2{98};
        newM2{181}=nan;
        newM2{182}=M2{180};
        newM2{183}=M2{177};
        newM2{184}=M2{173};
        newM2{185}=M2{170};
        newM2{186}=nan;
        newM2{187}=M2{252};
        newM2{188}=M2{249};
        newM2{189}=M2{245};
        newM2{190}=M2{242};
        
        newM2{191}=M2{35};
        newM2{192}=M2{32};
        newM2{193}=M2{28};
        newM2{194}=M2{25};
        newM2{195}=nan;
        newM2{196}=M2{107};
        newM2{197}=M2{104};
        newM2{198}=M2{100};
        newM2{199}=M2{97};
        newM2{200}=nan;
        newM2{201}=M2{179};
        newM2{202}=M2{176};
        newM2{203}=M2{172};
        newM2{204}=M2{169};
        newM2{205}=nan;
        newM2{206}=M2{251};
        newM2{207}=M2{248};
        newM2{208}=M2{244};
        newM2{209}=M2{241};
        
        newM2{210}=nan;
        newM2{211}=M2{31};
        newM2{212}=M2{27};
        newM2{213}=nan;
        newM2{214}=nan;
        newM2{215}=nan;
        newM2{216}=M2{103};
        newM2{217}=M2{99};
        newM2{218}=nan;
        newM2{219}=nan;
        newM2{220}=nan;
        newM2{221}=M2{175};
        newM2{222}=M2{171};
        newM2{223}=nan;
        newM2{224}=nan;
        newM2{225}=nan;
        newM2{226}=M2{247};
        newM2{227}=M2{243};
        newM2{228}=nan;
        
        newM2{229}=nan;
        newM2{230}=M2{46};
        newM2{231}=M2{42};
        newM2{232}=nan;
        newM2{233}=nan;
        newM2{234}=nan;
        newM2{235}=M2{118};
        newM2{236}=M2{114};
        newM2{237}=nan;
        newM2{238}=nan;
        newM2{239}=nan;
        newM2{240}=M2{190};
        newM2{241}=M2{186};
        newM2{242}=nan;
        newM2{243}=nan;
        newM2{244}=nan;
        newM2{245}=M2{262};
        newM2{246}=M2{258};
        newM2{247}=nan;
        
        newM2{248}=M2{48};
        newM2{249}=M2{45};
        newM2{250}=M2{41};
        newM2{251}=M2{38};
        newM2{252}=nan;
        newM2{253}=M2{120};
        newM2{254}=M2{117};
        newM2{255}=M2{113};
        newM2{256}=M2{110};
        newM2{257}=nan;
        newM2{258}=M2{192};
        newM2{259}=M2{189};
        newM2{260}=M2{185};
        newM2{261}=M2{182};
        newM2{262}=nan;
        newM2{263}=M2{264};
        newM2{264}=M2{261};
        newM2{265}=M2{257};
        newM2{266}=M2{254};
        
        newM2{267}=M2{47};
        newM2{268}=M2{44};
        newM2{269}=M2{40};
        newM2{270}=M2{37};
        newM2{271}=nan;
        newM2{272}=M2{119};
        newM2{273}=M2{116};
        newM2{274}=M2{112};
        newM2{275}=M2{109};
        newM2{276}=nan;
        newM2{277}=M2{191};
        newM2{278}=M2{188};
        newM2{279}=M2{184};
        newM2{280}=M2{181};
        newM2{281}=nan;
        newM2{282}=M2{263};
        newM2{283}=M2{250};
        newM2{284}=M2{256};
        newM2{285}=M2{253};
        
        newM2{286}=nan;
        newM2{287}=M2{43};
        newM2{288}=M2{39};
        newM2{289}=nan;
        newM2{290}=nan;
        newM2{291}=nan;
        newM2{292}=M2{115};
        newM2{293}=M2{111};
        newM2{294}=nan;
        newM2{295}=nan;
        newM2{296}=nan;
        newM2{297}=M2{187};
        newM2{298}=M2{183};
        newM2{299}=nan;
        newM2{300}=nan;
        newM2{301}=nan;
        newM2{302}=M2{259};
        newM2{303}=M2{255};
        newM2{304}=nan;
        
        newM2{305}=nan;
        newM2{306}=M2{58};
        newM2{307}=M2{54};
        newM2{308}=nan;
        newM2{309}=nan;
        newM2{310}=nan;
        newM2{311}=M2{130};
        newM2{312}=M2{126};
        newM2{313}=nan;
        newM2{314}=nan;
        newM2{315}=nan;
        newM2{316}=M2{202};
        newM2{317}=M2{198};
        newM2{318}=nan;
        newM2{319}=nan;
        newM2{320}=nan;
        newM2{321}=M2{274};
        newM2{322}=M2{270};
        newM2{323}=nan;
        
        newM2{324}=M2{60};
        newM2{325}=M2{57};
        newM2{326}=M2{53};
        newM2{327}=M2{50};
        newM2{328}=nan;
        newM2{329}=M2{132};
        newM2{330}=M2{129};
        newM2{331}=M2{125};
        newM2{332}=M2{122};
        newM2{333}=nan;
        newM2{334}=M2{204};
        newM2{335}=M2{201};
        newM2{336}=M2{197};
        newM2{337}=M2{194};
        newM2{338}=nan;
        newM2{339}=M2{276};
        newM2{340}=M2{273};
        newM2{341}=M2{269};
        newM2{342}=M2{266};
        
        newM2{343}=M2{59};
        newM2{344}=M2{56};
        newM2{345}=M2{52};
        newM2{346}=M2{49};
        newM2{347}=nan;
        newM2{348}=M2{131};
        newM2{349}=M2{128};
        newM2{350}=M2{124};
        newM2{351}=M2{121};
        newM2{352}=nan;
        newM2{353}=M2{203};
        newM2{354}=M2{200};
        newM2{355}=M2{196};
        newM2{356}=M2{193};
        newM2{357}=nan;
        newM2{358}=M2{275};
        newM2{359}=M2{272};
        newM2{360}=M2{268};
        newM2{361}=M2{265};
        
        newM2{362}=nan;
        newM2{363}=M2{55};
        newM2{364}=M2{51};
        newM2{365}=nan;
        newM2{366}=nan;
        newM2{367}=nan;
        newM2{368}=M2{127};
        newM2{369}=M2{123};
        newM2{370}=nan;
        newM2{371}=nan;
        newM2{372}=nan;
        newM2{373}=M2{199};
        newM2{374}=M2{195};
        newM2{375}=nan;
        newM2{376}=nan;
        newM2{377}=nan;
        newM2{378}=M2{271};
        newM2{379}=M2{267};
        newM2{380}=nan;
        
        newM2{381}=nan;
        newM2{382}=M2{70};
        newM2{383}=M2{66};
        newM2{384}=nan;
        newM2{385}=nan;
        newM2{386}=nan;
        newM2{387}=M2{142};
        newM2{388}=M2{138};
        newM2{389}=nan;
        newM2{390}=nan;
        newM2{391}=nan;
        newM2{392}=M2{214};
        newM2{393}=M2{210};
        newM2{394}=nan;
        newM2{395}=nan;
        newM2{396}=nan;
        newM2{397}=M2{286};
        newM2{398}=M2{282};
        newM2{399}=nan;
        
        newM2{400}=M2{72};
        newM2{401}=M2{69};
        newM2{402}=M2{65};
        newM2{403}=M2{62};
        newM2{404}=nan;
        newM2{405}=M2{144};
        newM2{406}=M2{141};
        newM2{407}=M2{137};
        newM2{408}=M2{134};
        newM2{409}=nan;
        newM2{410}=M2{216};
        newM2{411}=M2{213};
        newM2{412}=M2{209};
        newM2{413}=M2{206};
        newM2{414}=nan;
        newM2{415}=M2{288};
        newM2{416}=M2{285};
        newM2{417}=M2{281};
        newM2{418}=M2{278};
        
        newM2{419}=M2{71};
        newM2{420}=M2{68};
        newM2{421}=M2{64};
        newM2{422}=M2{61};
        newM2{423}=nan;
        newM2{424}=M2{143};
        newM2{425}=M2{140};
        newM2{426}=M2{136};
        newM2{427}=M2{133};
        newM2{428}=nan;
        newM2{429}=M2{215};
        newM2{430}=M2{212};
        newM2{431}=M2{208};
        newM2{432}=M2{205};
        newM2{433}=nan;
        newM2{434}=M2{287};
        newM2{435}=M2{284};
        newM2{436}=M2{280};
        newM2{437}=M2{277};
        
        newM2{438}=nan;
        newM2{439}=M2{67};
        newM2{440}=M2{63};
        newM2{441}=nan;
        newM2{442}=nan;
        newM2{443}=nan;
        newM2{444}=M2{139};
        newM2{445}=M2{135};
        newM2{446}=nan;
        newM2{447}=nan;
        newM2{448}=nan;
        newM2{449}=M2{211};
        newM2{450}=M2{207};
        newM2{451}=nan;
        newM2{452}=nan;
        newM2{453}=nan;
        newM2{454}=M2{283};
        newM2{455}=M2{279};
        newM2{456}=nan;
        newM2=newM2';
        
        
    else
        newM2={};
        newM2{1}=nan;
        newM2{2}=nan;
        newM2{3}=nan;
        newM2{4}=M2{41};
        newM2{5}=M2{37};
        newM2{6}=M2{33};
        newM2{7}=M2{29};
        newM2{8}=M2{25};
        newM2{9}=M2{21};
        newM2{10}=nan;
        newM2{11}=nan;
        newM2{12}=nan;
        newM2{13}=nan;
        newM2{14}=nan;
        newM2{15}=M2{45};
        newM2{16}=M2{42};
        newM2{17}=M2{38};
        newM2{18}=M2{34};
        newM2{19}=M2{28};
        newM2{20}=M2{24};
        newM2{21}=M2{20};
        newM2{22}=M2{17};
        newM2{23}=nan;
        newM2{24}=nan;
        newM2{25}=nan;
        newM2{26}=M2{47};
        newM2{27}=M2{46};
        newM2{28}=M2{43};
        newM2{29}=M2{39};
        newM2{30}=M2{35};
        newM2{31}=M2{27};
        newM2{32}=M2{23};
        newM2{33}=M2{19};
        newM2{34}=M2{16};
        newM2{35}=M2{15};
        newM2{36}=nan;
        newM2{37}=M2{51};
        newM2{38}=M2{50};
        newM2{39}=M2{49};
        newM2{40}=M2{44};
        newM2{41}=M2{40};
        newM2{42}=M2{36};
        newM2{43}=M2{26};
        newM2{44}=M2{22};
        newM2{45}=M2{14};
        newM2{46}=M2{13};
        newM2{47}=M2{12};
        newM2{48}=M2{11};
        newM2{49}=M2{55};
        newM2{50}=M2{54};
        newM2{51}=M2{53};
        newM2{52}=M2{52};
        newM2{53}=M2{48};
        newM2{54}=M2{32};
        newM2{55}=M2{30};
        newM2{56}=M2{18};
        newM2{57}=M2{10};
        newM2{58}=M2{9};
        newM2{59}=M2{8};
        newM2{60}=M2{7};
        newM2{61}=M2{59};
        newM2{62}=M2{58};
        newM2{63}=M2{57};
        newM2{64}=M2{56};
        newM2{65}=M2{60};
        newM2{66}=M2{31};
        newM2{67}=M2{1};
        newM2{68}=M2{2};
        newM2{69}=M2{6};
        newM2{70}=M2{5};
        newM2{71}=M2{4};
        newM2{72}=M2{3};
        newM2{73}=M2{63};
        newM2{74}=M2{64};
        newM2{75}=M2{65};
        newM2{76}=M2{66};
        newM2{77}=M2{62};
        newM2{78}=M2{61};
        newM2{79}=M2{91};
        newM2{80}=M2{120};
        newM2{81}=M2{116};
        newM2{82}=M2{117};
        newM2{83}=M2{118};
        newM2{84}=M2{119};
        newM2{85}=M2{67};
        newM2{86}=M2{68};
        newM2{87}=M2{69};
        newM2{88}=M2{70};
        newM2{89}=M2{78};
        newM2{90}=M2{90};
        newM2{91}=M2{92};
        newM2{92}=M2{108};
        newM2{93}=M2{112};
        newM2{94}=M2{113};
        newM2{95}=M2{114};
        newM2{96}=M2{115};
        newM2{97}=M2{71};
        newM2{98}=M2{72};
        newM2{99}=M2{73};
        newM2{100}=M2{74};
        newM2{101}=M2{82};
        newM2{102}=M2{86};
        newM2{103}=M2{96};
        newM2{104}=M2{100};
        newM2{105}=M2{104};
        newM2{106}=M2{109};
        newM2{107}=M2{110};
        newM2{108}=M2{111};
        newM2{109}=nan;
        newM2{110}=M2{75};
        newM2{111}=M2{76};
        newM2{112}=M2{79};
        newM2{113}=M2{83};
        newM2{114}=M2{87};
        newM2{115}=M2{95};
        newM2{116}=M2{99};
        newM2{117}=M2{103};
        newM2{118}=M2{106};
        newM2{119}=M2{107};
        newM2{120}=nan;
        newM2{121}=nan;
        newM2{122}=nan;
        newM2{123}=M2{77};
        newM2{124}=M2{80};
        newM2{125}=M2{84};
        newM2{126}=M2{88};
        newM2{127}=M2{94};
        newM2{128}=M2{98};
        newM2{129}=M2{102};
        newM2{130}=M2{105};
        newM2{131}=nan;
        newM2{132}=nan;
        newM2{133}=nan;
        newM2{134}=nan;
        newM2{135}=nan;
        newM2{136}=M2{81};
        newM2{137}=M2{85};
        newM2{138}=M2{89};
        newM2{139}=M2{93};
        newM2{140}=M2{97};
        newM2{141}=M2{101};
        newM2{142}=nan;
        newM2{143}=nan;
        newM2{144}=nan;
        newM2=newM2';
    end
    
    if length(filteredData1(:,1)) > 121
        textstrings={[] '10' '6' [] [] [] '82' '78' [] [] [] '154' '150' [] [] [] '226' '222' [] '12' '9' '5' '2' [] '84' '81' '77' '74' [] '156' '153' '149' '146' [] '228' '225' '221' '218' '11' '8' '4' '1' [] '83' '80' '76' '73' [] '155' '152' '148' '145' [] '227' '224' '220' '217' [] '7' '3' [] [] [] '79' '75' [] [] [] '151' '147' [] [] [] '223' '219' [] [] '22' '18' [] [] [] '94' '90' [] [] [] '166' '162' [] [] [] '238' '234' [] '24' '21' '17' '14' [] '96' '93' '89' '86' [] '168' '165' '161' '158' [] '240' '237' '233' '230' '23' '20' '16' '13' [] '95' '92' '88' '85' [] '167' '164' '160' '157' [] '239' '236' '232' '229' [] '19' '15' [] [] [] '91' '87' [] [] [] '163' '159' [] [] [] '235' '231' [] [] '34' '30' [] [] [] '106' '102' [] [] [] '178' '174' [] [] [] '250' '246' [] '36' '33' '29' '26' [] '108' '105' '101' '98' [] '180' '177' '173' '170' [] '252' '249' '245' '242' '35' '32' '28' '25' [] '107' '104' '100' '97' [] '179' '176' '172' '169' [] '251' '248' '244' '241' [] '31' '27' [] [] [] '103' '99' [] [] [] '175' '171' [] [] [] '247' '243' [] [] '46' '42' [] [] [] '118' '114' [] [] [] '190' '186' [] [] [] '262' '258' [] '48' '45' '41' '38' [] '120' '117' '113' '110' [] '192' '189' '185' '182' [] '264' '261' '257' '254' '47' '44' '40' '37' [] '119' '116' '112' '109' [] '191' '188' '184' '181' [] '263' '260' '256' '253' [] '43' '39' [] [] [] '115' '111' [] [] [] '187' '183' [] [] [] '259' '255' [] [] '58' '54' [] [] [] '130' '126' [] [] [] '202' '198' [] [] [] '274' '270' [] '60' '57' '53' '50' [] '132' '129' '125' '122' [] '204' '201' '197' '194' [] '276' '273' '269' '266' '59' '56' '52' '49' [] '131' '128' '124' '121' [] '203' '200' '196' '193' [] '275' '272' '268' '265' [] '55' '51' [] [] [] '127' '123' [] [] [] '199' '195' [] [] [] '271' '267' [] [] '70' '66' [] [] [] '142' '138' [] [] [] '214' '210' [] [] [] '286' '282' [] '72' '69' '65' '62' [] '144' '141' '137' '134' [] '216' '213' '209' '206' [] '288' '285' '281' '278' '71' '68' '64' '61' [] '143' '140' '136' '133' [] '215' '212' '208' '205' [] '287' '284' '280' '277' [] '67' '63' [] [] [] '139' '135' [] [] [] '211' '207' [] [] [] '283' '279' []}';
        
    elseif length(filteredData1(:,1)) == 60
        textstrings= {[] [] [] [] [] [] [] [] []  [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] 'C4' 'C5' 'C6' 'C7' 'C8' 'C9' [] [] [] [] [] 'D3' 'D4' 'D5' 'D6' 'D7' 'D8' 'D9' 'D10' [] [] [] [] 'E3' 'E4' 'E5' 'E6' 'E7' 'E8' 'E9' 'E10' [] [] [] [] 'F3' 'F4' 'F5' 'F6' 'F7' 'F8' 'F9' 'F10' [] [] [] [] 'G3' 'G4' 'G5' 'G6' 'G7' 'G8' 'G9' 'G10' [] [] [] [] 'H3' 'H4' 'H5' 'H6' 'H7' 'H8' 'H9' 'H10' [] [] [] [] 'J3' 'J4' 'J5' 'J6' 'J7' 'J8' 'J9' 'J10' [] [] [] [] [] 'K4' 'K5' 'K6' 'K7' 'K8' 'K9' [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] [] []}';
    else
        textstrings= {[] [] [] 'A4' 'A5' 'A6' 'A7' 'A8' 'A9' [] [] [] [] [] 'B3' 'B4' 'B5' 'B6' 'B7' 'B8' 'B9' 'B10' [] [] [] 'C2' 'C3' 'C4' 'C5' 'C6' 'C7' 'C8' 'C9' 'C10' 'C11' [] 'D1' 'D2' 'D3' 'D4' 'D5' 'D6' 'D7' 'D8' 'D9' 'D10' 'D11' 'D12' 'E1' 'E2' 'E3' 'E4' 'E5' 'E6' 'E7' 'E8' 'E9' 'E10' 'E11' 'E12' 'F1' 'F2' 'F3' 'F4' 'F5' 'F6' 'F7' 'F8' 'F9' 'F10' 'F11' 'F12' 'G1' 'G2' 'G3' 'G4' 'G5' 'G6' 'G7' 'G8' 'G9' 'G10' 'G11' 'G12' 'H1' 'H2' 'H3' 'H4' 'H5' 'H6' 'H7' 'H8' 'H9' 'H10' 'H11' 'H12' 'J1' 'J2' 'J3' 'J4' 'J5' 'J6' 'J7' 'J8' 'J9' 'J10' 'J11' 'J12' [] 'K2' 'K3' 'K4' 'K5' 'K6' 'K7' 'K8' 'K9' 'K10' 'K11' [] [] [] 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' [] [] [] [] [] 'M4' 'M5' 'M6' 'M7' 'M8' 'M9' [] [] []}';
        
    end
    %% Network bursts
    waitbar(0 + 0.80,hh,'Performing Post Processing analyses');
    
    % this method is based on first detecting the single channel bursts
    % based on the max interval method.
    
    if SCBflag == 1
        %Step 1 we need to find the a minimum of two synchronized bursts
        
        starttimesbursts2 = [];
        for i = 1:length(burst6)
            for j = 1:length(burst6{i})
                starttimesbursts = burst6{i}{j}(1);
                starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
            end
        end
        
        uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes
        
        %now we need to put all the times in a giant matrix so we can
        %search in this matrix with the unique burst start times
        
        %convert all the cells into vectors
        % all the vectors are made equal in length by adding in nans
        temp = cell(1,length(burst6))';
        for i = 1:length(burst6)
            temp{i} = cell2mat(burst6{i});
        end
        
        newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
        newc=cell2mat(newc);
        
        
        % now we need to find if there are multiple channels that start
        % bursting at the same time
        channelnumbernnbursts =cell(1,length(burst6))';
        timeofnnbursts =cell(1,length(burst6))';
        for i = 1:length(uniquestarttimesbursts)
            [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) - fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) + fs.networkburstdetection.synchronizedtimewindow );
        end
        
        
        
        
        
        % check for duplicate channelnumbers if so remove them
        for i =1:length(channelnumbernnbursts)
            if isempty(channelnumbernnbursts{i})
            else
                if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                    channelnumbernnbursts{i} = [];
                    timeofnnbursts{i}=[];
                else
                    
                end
            end
        end
        
        
        % now that we the channels that are synchronzied in their bursting
        % we need to remove the channels that do not fullfull our
        % requirements of have atleast 2 synchronized channels and atleast
        % 50% of the otal amount of channels should participate in the
        % nnburst or else it gets removed
        
        
        for i = 1:length(channelnumbernnbursts)
            if length(channelnumbernnbursts{i}) <  fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                channelnumbernnbursts{i} = [];
                timeofnnbursts{i} = [];
                uniquestarttimesbursts(i) = nan;
            end
        end
        
        %clean up by removing empty cells and nan values
        uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
        channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
        timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
        
        % now we need to find the bursts that are part of the synchronized
        % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
        % synchronzied bursts in other channels and then we can see how
        % many channels are participating
        
        
        burst6length =burst6; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
        for i = 1:length(burst6)
            for j = 1:length(burst6{i})
                burst6length{i}{j} = length(burst6{i}{j});
            end
        end
        
        for i = 1:length(burst6) % convert the cell arrays in vectors
            burst6length{i} = cell2mat(burst6length{i});
        end
        
        
        potentialnnbursts = cell(1,length(channelnumbernnbursts))';
        burstsindexcount=[];
        for i = 1:length(potentialnnbursts)
            for j = 1:length(channelnumbernnbursts{i})
                for k = 1:cellfun(@length,(burst6(channelnumbernnbursts{i}(j))))
                    %figure out which bursts the indexes belong to
                    
                    %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
                    %                      burstsindexcount = cumsum( burstsindexcount); % old version
                    burstsindexcount = cumsum( burst6length{channelnumbernnbursts{i}(j)});
                    if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                        correctburst = k;
                        potentialnnbursts{i}{j} = burst6{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                        break
                    end
                end
            end
        end
        
        
        % we have to check if the times of the bursts are within acceptable
        
        
        % create variable that is the exact same varible as potentialnnbursts
        % but intead each cell contains the mean + std of that channel to
        % improve the speed
        
        potentialnnburstsmean = potentialnnbursts;
        for i =1 :length(potentialnnbursts)
            potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 2.5*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
        end
        
        for i = 1:length(potentialnnbursts)
            for j = 1:length(potentialnnbursts{i})
                %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                    potentialnnbursts{i}{j} = [];
                end
            end
        end
        
        % now we need to use the synscho bursts to find if there are bursts that
        % fall within the same duration as the synchronized bursts. if they do then
        % they are part of the  potential network bursts
        % we loop through both synchronized bursts just to extra certain we do not
        % miss anything because the starttimes might be the same but the ending
        % time might not be.
        
        mergeburstchannel = cell(1,length(potentialnnbursts))';
        mergeburstnumber  = cell(1,length(potentialnnbursts))';
        tobemergedbursts  = cell(1,length(potentialnnbursts))';
        
        % create vaiable of potneialnnbursts that have all the cells converted into
        % vectors to improve the performance
        potentialnnburstsvector = potentialnnbursts;
        potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
        
        for i = 1:length(potentialnnburstsvector)
            potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
            potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
        end
        
        for i =1:length(potentialnnbursts)
            for k = 1:length(burst6)
                for l = 1:length(burst6{k})
                    if ~isempty(find(burst6{k}{l} > potentialnnburstsvector{i,2}(1) & burst6{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                        tobemergedbursts{i}{k} =cell2mat(burst6{k}(l)) ;
                        mergeburstchannel{i}{k} = k;
                        mergeburstnumber{i}{k} = l;
                    end
                end
            end
        end
        
        
        % clean up the empty  cells
        
        for i =1:length(tobemergedbursts)
            tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
            mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
            mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
        end
        
        %now we need remove the nnbursts that have less than 50% of the whole wwell
        %participating in the nnbursts
        
        % find the number of active channels
        amountactivechannels = length(find(~cellfun(@isempty,M2)));
        mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
        tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
        mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
        % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
        % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
        % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
        
        %the last step is to find duplicates and merge them together
        findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
        
        for i = 1:length(tobemergedbursts)
            findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
        end
        
        
        
        for i = 1:length(tobemergedbursts)
            if isempty(findoverlappingnnbursts{i})
                continue
            else
                for k = 2:length(tobemergedbursts)
                    if isempty(findoverlappingnnbursts{k}) || k == i
                        continue
                    else
                        if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                            % if this is true than there is overlap. so we need to find out
                            % which one is longer and that will be the one remaining.
                            if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                findoverlappingnnbursts{k} = [];
                            else
                                findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                findoverlappingnnbursts{k} = [];
                            end
                        else
                            
                            
                        end
                    end
                end
            end
        end
        
        %lets use logical indezing to get rid of the overlapping nnbursts and
        %finally get our actual nnbursts
        
        tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
        mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
        mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
        findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
        
        % now that we have our nnbursts we can extract the ifnroamtion about the
        % nnbursts
        
        %struct for networkbursts
        networkburstttt =[];
        for i = 1:length(mergeburstnumber)
            
            networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
            networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
            networkburstttt.amount = length(mergeburstnumber);
            networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
            networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
            networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
            networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
        end
        
        for i = 1:length(mergeburstnumber)
            if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                networkburstttt.IBI(i,1) = 0;
                continue
            else
                networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
            end
        end
        
        % added the CV of IBI of nnbursts
        if isempty(networkburstttt)
            networkburstttt.starttime = 0;
            networkburstttt.endtime = 0;
            networkburstttt.amount = 0;
            networkburstttt.duration = 0;
            networkburstttt.spikesfr_in_nbursts = 0;
            networkburstttt.nburst_rate = 0;
            networkburstttt.ISI = 0;
            networkburstttt.IBI = 0;
            networkburstttt.CVIBI= 0;
        else
            networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
            
        end
        
    elseif SCBflag == 0
        
        starttimesbursts2 = [];
        for i = 1:length(burst7)
            for j = 1:length(burst7{i})
                starttimesbursts = burst7{i}{j}(1);
                starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
            end
        end
        
        uniquestarttimesbursts = unique(starttimesbursts2); %these are the unique starttimes
        
        %now we need to put all the times in a giant matrix so we can
        %search in this matrix with the unique burst start times
        
        %convert all the cells into vectors
        % all the vectors are made equal in length by adding in nans
        temp = cell(1,length(burst7))';
        for i = 1:length(burst7)
            temp{i} = cell2mat(burst7{i});
        end
        
        newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
        newc=cell2mat(newc);
        
        
        % now we need to find if there are multiple channels that start
        % bursting at the same time
        channelnumbernnbursts =cell(1,length(burst7))';
        timeofnnbursts =cell(1,length(burst7))';
        for i = 1:length(uniquestarttimesbursts)
            [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) -  fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) +  fs.networkburstdetection.synchronizedtimewindow );
        end
        
        % check for duplicate channelnumbers if so remove them
        for i =1:length(channelnumbernnbursts)
            if isempty(channelnumbernnbursts{i})
            else
                if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                    channelnumbernnbursts{i} = [];
                    timeofnnbursts{i}=[];
                else
                    
                end
            end
        end
        
        % now that we the channels that are synchronzied in their bursting
        % we need to remove the channels that do not fullfull our
        % requirements of have atleast 2 synchronized channels and atleast
        % 50% of the otal amount of channels should participate in the
        % nnburst or else it gets removed
        
        
        for i = 1:length(channelnumbernnbursts)
            if length(channelnumbernnbursts{i}) < fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                channelnumbernnbursts{i} = [];
                timeofnnbursts{i} = [];
                uniquestarttimesbursts(i) = nan;
            end
        end
        
        %clean up by removing empty cells and nan values
        uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
        channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
        timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
        
        % now we need to find the bursts that are part of the synchronized
        % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
        % synchronzied bursts in other channels and then we can see how
        % many channels are participating
        
        burst7length =burst7; % create a cell array that is equal to burst7 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
        for i = 1:length(burst7)
            for j = 1:length(burst7{i})
                burst7length{i}{j} = length(burst7{i}{j});
            end
        end
        
        for i = 1:length(burst7) % convert the cell arrays in vectors
            burst7length{i} = cell2mat(burst7length{i});
        end
        
        
        potentialnnbursts = cell(1,length(channelnumbernnbursts))';
        burstsindexcount=[];
        for i = 1:length(potentialnnbursts)
            for j = 1:length(channelnumbernnbursts{i})
                for k = 1:cellfun(@length,(burst7(channelnumbernnbursts{i}(j))))
                    %figure out which bursts the indexes belong to
                    
                    %                      burstsindexcount = cellfun(@length,burst7{channelnumbernnbursts{i}(j)}); % old version that was slower
                    %                      burstsindexcount = cumsum( burstsindexcount); % old version
                    burstsindexcount = cumsum( burst7length{channelnumbernnbursts{i}(j)});
                    if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                        correctburst = k;
                        potentialnnbursts{i}{j} = burst7{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                        break
                    end
                end
            end
        end
        
        % we have to check if the times of the bursts are within acceptable
        % ( check for nana values
        
        % create variable that is the exact same varible as potentialnnbursts
        % but intead each cell contains the mean + std of that channel to
        % improve the speed
        
        potentialnnburstsmean = potentialnnbursts;
        for i =1 :length(potentialnnbursts)
            potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 2.5*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
        end
        
        for i = 1:length(potentialnnbursts)
            for j = 1:length(potentialnnbursts{i})
                %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                    potentialnnbursts{i}{j} = [];
                end
            end
        end
        
        % now we need to use the synscho bursts to find if there are bursts that
        % fall within the same duration as the synchronized bursts. if they do then
        % they are part of the  potential network bursts
        % we loop through both synchronized bursts just to extra certain we do not
        % miss anything because the starttimes might be the same but the ending
        % time might not be.
        
        mergeburstchannel = cell(1,length(potentialnnbursts))';
        mergeburstnumber  = cell(1,length(potentialnnbursts))';
        tobemergedbursts  = cell(1,length(potentialnnbursts))';
        
        
        % create vaiable of potneialnnbursts that have all the cells converted into
        % vectors to improve the performance
        potentialnnburstsvector = potentialnnbursts;
        potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
        
        
        for i = 1:length(potentialnnburstsvector)
            potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
            potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
        end
        
        for i =1:length(potentialnnbursts)
            for k = 1:length(burst7)
                for l = 1:length(burst7{k})
                    if ~isempty(find(burst7{k}{l} > potentialnnburstsvector{i,2}(1) & burst7{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                        tobemergedbursts{i}{k} =cell2mat(burst7{k}(l)) ;
                        mergeburstchannel{i}{k} = k;
                        mergeburstnumber{i}{k} = l;
                    end
                end
            end
        end
        
        % clean up the empty  cells
        
        for i =1:length(tobemergedbursts)
            tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
            mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
            mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
        end
        
        %now we need remove the nnbursts that have less than 50% of the whole wwell
        %participating in the nnbursts
        
        % find the number of active channels
        amountactivechannels = length(find(~cellfun(@isempty,M2)));
        
        mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
        tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
        mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
        % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
        % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
        % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
        
        %the last step is to find duplicates and merge them together
        findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
        
        for i = 1:length(tobemergedbursts)
            findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
        end
        
        
        
        for i = 1:length(tobemergedbursts)
            if isempty(findoverlappingnnbursts{i})
                continue
            else
                for k = 2:length(tobemergedbursts)
                    if isempty(findoverlappingnnbursts{k}) || k == i
                        continue
                    else
                        if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  0.1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+0.1)))
                            % if this is true than there is overlap. so we need to find out
                            % which one is longer and that will be the one remaining.
                            if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                findoverlappingnnbursts{k} = [];
                            else
                                findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                findoverlappingnnbursts{k} = [];
                            end
                        else
                            
                            
                        end
                    end
                end
            end
        end
        
        %lets use logical indezing to get rid of the overlapping nnbursts and
        %finally get our actual nnbursts
        
        tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
        mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
        mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
        findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
        
        % now that we have our nnbursts we can extract the ifnroamtion about the
        % nnbursts
        
        if isempty(findoverlappingnnbursts)
            networkburstttt.amount = 0;
            networkburstttt.duration = 0;
            networkburstttt.spikesfr_in_nbursts = 0;
            networkburstttt.nburst_rate = 0;
            networkburstttt.ISI = 0 ;
            networkburstttt.IBI = 0;
            networkburstttt.CVIBI = 0;
        else
            %struct for networkbursts
            networkburstttt =[];
            for i = 1:length(mergeburstnumber)
                
                networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
                networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
                networkburstttt.amount = length(mergeburstnumber);
                networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
                networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
                networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
                networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
            end
            
            for i = 1:length(mergeburstnumber)
                if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                    networkburstttt.IBI(i,1) = 0;
                    networkburstttt.CVIBI = 0;
                    continue
                else
                    networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
                end
            end
            
            if isempty(networkburstttt)
            else
                networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
            end
        end
    end
         
    %% For connectivity maps (Conditonal firing probabilities)
    
    spikestimes = [M2{:}]; % this contains all the spikes times
    spikeslocations = zeros(1,length(spikestimes));
    correctcounter = 0;
    
    for i = 1:length(M2)
        if i == 1
        else
            correctcounter = correctcounter + length(M2{i-1});
        end
        for j = 1:length(M2{i})
            if i == 1
                spikeslocations(j) = i;
            else
                spikeslocations(j+correctcounter) = i;
            end
        end
    end
    
    [sortedspikestimes, Indexes] = sort(spikestimes);
    sortedspikeslocations = spikeslocations(Indexes);
    
    % for easier writing
    Ts = sortedspikestimes;
    Cs = sortedspikeslocations;
    
   if Ts < 2^15 
       Connections = 0;
   else
    %Now we need to divide the data in chunks of 2^15 spikes (32768)
    
    minchunk = floor(length(Cs)/2^15);
    leftover = length(Cs)-minchunk*2^15;
    divdata = cell(1,minchunk);   %contains channellocations
    divdataTs = cell(1,minchunk); %contains spiketimes
    
    for i =1:minchunk
        if i == 1
            divdata{i}(1,:) = Cs(1:2^15);
            divdataTs{i}(1,:) = Ts(1:2^15);
        else
            m = i * 2^15;
            k = ((i-1) * 2^15) + 1;
            divdata{i}(1,:) = Cs(k:m);
            divdataTs{i}(1,:) = Ts(k:m);
        end
    end
    
    
    %%reorganize the data for each chunk to make it easeir to process it
    
    sortchunks = cell(1,minchunk);
    
    for i =1:length(sortchunks)
        for j = 1:length(M2) % total amount of channels 
            sortchunks{i}{j} = divdataTs{i}(divdata{i} == j);
        end
    end
    
    for i =1:length(sortchunks)
        sortchunks{i} =sortchunks{i}';
    end
    
    % now the spikes in each chunk is sorted to which channel it belongs too
    
    %now we need to calculate the CFP curves
    
    max_t = 0.5; % the max window in which the correlation is calculated over in seconds (500ms)
    binsize = 0.005 ; % 5 ms resolution is used by the paper lefeber et al., 2007
    xbin_centers = 0-binsize:binsize:max_t+binsize; %unwanted bins will be removed
    cc = zeros(size(xbin_centers));
    correctlen = length(cc)-2;
    
    supa=cell(1,length(sortchunks{1})); % change to length(M2)
    CFP = cell(1,length(sortchunks));
    for aa = 1:length(sortchunks) % iteration through the chunks
        for i=1:length(sortchunks{aa}) % iteration throuch channel '1' one side
            if isempty(sortchunks{aa}{i,1})
                supa{i}=[];
                continue
            end
            finalssss=zeros(length(sortchunks{aa}(:,1)),correctlen);
            for j=1:length(sortchunks{aa}) % iteration throuch channel '2' other side
                if isempty(sortchunks{aa}{j,1})
                    supa{i}=[];
                    continue
                else
                    spk_t1 = sortchunks{aa}{j} ; %contains spike train timings in seconds of train 1
                    spk_t2 = sortchunks{aa}{i} ; %contains spike train timings in seconds of train 2
                    if length(spk_t1) < 250 || length(spk_t2) <250 % skip the channels that have less than 250 spikes
                        continue
                    else
                        for iSpk = 1:length(spk_t1) % iteration through all the spikes in spiketrain 1
                            relative_spk_t = spk_t2 - spk_t1(iSpk);
                            cc = cc + hist(relative_spk_t,xbin_centers); % note that histc puts all spikes outside the bin centers in the first and last bins! delete later.
                        end
                        cc = cc(2:end-1); % remove 2 unwanted bins
                        cc = cc./(length(spk_t1)); % normalize by number of spikes of first input like the conditional firing probability of Lefeber et al ., (2007)
                        finalssss(j,:) = cc;
                        finalssss(i,:)=zeros(1,correctlen);  % remove the autocorrelation
                        cc = zeros(size(xbin_centers)); % make it empty again for the next iteration
                    end
                end
            end
            supa{i}=finalssss;
        end
        CFP{aa} = supa';
    end
    
    delay = 0:5:500;
    bingrootte = 0.005;
    % Fs = FileInfo.samplefrequency;
    M=zeros(length(M2),length(M2)); Tt=zeros(length(M2),length(M2)); OFFSET=zeros(length(M2),length(M2)); VORM=zeros(length(M2),length(M2));
    OPP=zeros(length(M2),length(M2)); % in deze matrices gaat het model
    % i is het eerst vurende neuron, j het dan vurende neuron
    allM = cell(1,length(CFP));
    allTt = cell(1,length(CFP));
    allOFFSET = cell(1,length(CFP));
    allVORM = cell(1,length(CFP));
    allOPP = cell(1,length(CFP));
    
    mapping = 1:length(M2);
    AantSpikes = cellfun(@length,sortchunks{2});
    actiefdrempel=250; %threshold for active electrodes
    a=find(AantSpikes>=actiefdrempel); % bekijk alleen kanalen met minstens 250 spikes
    tekenen = 0;
    
    % Here the active channels are selected.  "actiefdrempel" sets the
    % threshold number of spikes recorded in an active channel
    % a is an array that contains the numbers of all active electrodes (1-60)
    % you can set i and j to the indices of a that refer to the channels that
    % you're interested in.
    
    for aa = 1:length(CFP)
        supa = CFP{aa};
        for i=1:length(a)
            for j=1:length(a)
                AA = (supa{a(i)}(a(j),:));
                if tekenen==1
                    plot(delay,AA);
                    grid on;
                end
                if i~=j
                    if tekenen==1
                        hold on; V=axis; misfit=0; axis normal;
                    end
                    
                    test=find(AA==max(AA))*(bingrootte/10);
                    Po=[max(AA) 10 test(1) 0]; % eerste gok
                    options=optimset('MaxFunEvals',1e9,'TolFun',1e-20);
                    P=Po;
                    P=fminsearch(@(P) errorfun(delay,AA,P),Po,options);
                    Mtekst=''; tctekst='';
                    if P(3)<1; P(3)=0; end
                    if P(1)<P(4) % M<offset
                        Mtekst='/ aangepast.      SNR te laag';
                        tctekst=['/ niet van belang; M=0'];
                        P(1)=0; P(4)=mean(AA); misfit=1;
                    end
                    if ((P(2)<2) | (P(2)>250)) % v moet liggen tussen 10 en 250 msec
                        misfit=1; P(1)=0; P(4)=mean(AA);
                        Mtekst='/ aangepast.   v buiten grenzen.';
                    end
                    if (P(3)>250)  % tau-c > 250
                        misfit=1;  P(1)=0; P(4)=mean(AA);
                        Mtekst='/ aangepast.   tc > 250.';
                    end
                    M(a(i),a(j))=P(1); VORM(a(i),a(j))=P(2);
                    Tt(a(i),a(j))=P(3); OFFSET(a(i),a(j))=P(4);
                    OPP(a(i),a(j))=sum((Amsdatafitfun(delay,P)-P(4))*(bingrootte/10));
                    if tekenen==1 % om de fit te tekenen: 1 invullen.
                        if misfit axis square; end
                        plot(delay,Amsdatafitfun(delay,P),'r');
                        text(400,0.7*V(4),['OPP: ' num2str(OPP(a(i),a(j)))]);
                        text(400,.95*V(4),['M = ' num2str(P(1)) Mtekst]);
                        text(400,.9*V(4),['tc = ' num2str(P(3)) tctekst]);
                        text(400,.85*V(4),['offset = ' num2str(P(4))]);
                        text(400,.8*V(4),['v = ' num2str(P(2))]);
                        hold off
                    end
                end
                if tekenen==1
                    xlabel('Delay [msec]');
                    ylabel(['CFP electr.' num2str(mapping(a(j))) ' (' num2str(AantSpikes(a(j))) ' sp) | electr.' num2str(mapping(a(i))) ' (' num2str(AantSpikes(a(i))) 'sp)']);
                    %             ylabel(['CFP electr.' num2str((a(j))) ' (' num2str(AantSpikes(a(j))) ' sp) | electr.' num2str((a(i))) ' (' num2str(AantSpikes(a(i))) 'sp)']);
                    title(['Conditional firing probability (' datafile ')']);pause
                end
            end
        end
        allM{aa} = M;
        allT{aa} = Tt;
        allVORM{aa} = VORM;
        allOFFSET{aa} = OFFSET;
        allOPP{aa} = OPP;
    end
    
    clear A AA Cy V tekenen a i j test DT Mtekst tctekst TotalChance options
    clear AlBekeken Po P V C Xm Xn b h k m n nn status tc x3 misfit
   
     for i =1:length(sortchunks)
        if i ==1
            M = allM{i};
        else
            M = M + allM{i};
        end
    end
    
    M = M/length(sortchunks);
    
    
    meanconnect = length(find((M>0)));
    Connections = meanconnect;
    clear meanconnect
   end
    %% serialize the biggest data
    %https://nl.mathworks.com/matlabcentral/fileexchange/34564-fast-serialize-deserialize
    %these useful files make saving big variables faster
    %By Christian Kothe
    
    filteredData1 =Data3;

%     filteredData1=hlp_serialize(filteredData1);
    waitbar(0 + 1,hh,'Finished Analysis');
    close(hh)
    %% save variables
    joost =1;
    %add .mat to the selecteddata
%     selecteddata = [selecteddata,'.mat'];
    mkdir Analyzedfiles
%     movefile(selecteddata,'Analyzedfiles')
    cd Analyzedfiles;
    clearvars -except joost M Tt VORM OFFSET OPP multiwell1 NetworkBurstStart networkburstttt burst6indx supa burst7indx correctfolder BNeuroSEM BLogSEM INDEX1 Connections BDSEM posunitsSEM negunitsSEM HITSSEM negunits posunits files M66 M99 M111 looo12 Spikeform4 M222 logburst BD BLog BNeuro burst7 M88 textstrings newM2 Exburst fs HITS timesss X2 filteredData1 RMS7 noiseall18 noiseall2  burstsinfor ISI58 Spikeform3 burstview2 burstview3 unitpersecond burstview19 burstview20 xpoints ypoints ends2 starts2 ypointsburst1 Bap Bal Bab Bak T selecteddata layout ans90 BI Imax M2 imaxch imaxch2 burst6 bincountssec binranges4567
    save([selecteddata, '.mat'],'multiwell1','joost','M','Tt','VORM','OFFSET','OPP','NetworkBurstStart','networkburstttt','supa','burst6indx','burst7indx','BNeuroSEM','BLogSEM','INDEX1','Connections','BDSEM','posunitsSEM','negunitsSEM','HITSSEM','logburst','posunits','negunits','looo12','Spikeform4','M66','M99','M111','M222','BD','BLog','BNeuro','M88','burst7','textstrings','newM2','Exburst','fs','HITS','timesss','X2','filteredData1','RMS7','noiseall18','noiseall2','burstsinfor','ISI58','Spikeform3','burstview2','burstview3','unitpersecond','burstview19','burstview20','xpoints','ypoints','ends2','starts2','ypointsburst1','Bap','Bal','Bab','Bak','T','selecteddata','layout','ans90','BI','Imax','M2','imaxch','imaxch2','burst6','bincountssec','binranges4567','-v7.3');
    cd(correctfolder);
    toc
    %% clear variables
    clear networkburstttt
end

clear totaldura
if multiwell1 == 0
%     filteredData1=hlp_deserialize(filteredData1);
    
    
    MEA_Data_Plots2
elseif multiwell1 == 1
    
    %     filteredData1=hlp_deserialize(filteredData1);
    %
    %
    %     multiwell
    msgbox(sprintf('Succesfully completed the analysis of a multiwell'))
    
end
toc















