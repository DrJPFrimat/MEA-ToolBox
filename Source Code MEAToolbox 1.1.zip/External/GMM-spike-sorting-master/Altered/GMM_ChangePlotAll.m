function GMM_ChangePlotAll(A,B)
    global handles1
    if handles1.Config.Plot == 1
        handles1.Config.Plot = 0;
        set(handles1.Figures.Waveforms.PlotAllTOGGLE,'String','Plot <1000');
    else
        handles1.Config.Plot = 1;
        set(handles1.Figures.Waveforms.PlotAllTOGGLE,'String','Plot all waveforms');
    end
    GMM_plotwaveforms
    if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
        GMM_showclusters
    end
end