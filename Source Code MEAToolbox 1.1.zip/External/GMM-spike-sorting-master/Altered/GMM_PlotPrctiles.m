
function [ ] = GMM_PlotPrctiles( class_i )

global handles1

auxplot = handles1.data.waveforms{handles1.chid}';
auxplot = auxplot(:,handles1.data.class_id{handles1.chid}==class_i);

auxplotprc = prctile(auxplot',[5,25,50,75,95]);
vecwidth = [1 2 4 2 1];

for i = 1:size(auxplotprc,1)
    hold on
    plot(auxplotprc(i,:),'color',...
        handles1.dataaux.class_colors(class_i,:),'linewidth',...
        vecwidth(i))
    
end
hold off
axis tight
ylim(handles1.Figures.Waveforms.ylim)
box off

end
