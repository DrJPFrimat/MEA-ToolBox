function GMM_savedata(A,B)

global handles1

data = handles1.data;

if handles1.dataaux.nelectrodes>1
    nelec=handles1.dataaux.nelectrodes;
    for ch_i = 1:handles1.dataaux.nchannels
        data.waveforms{ch_i} = reshape(data.waveforms{ch_i},size(data.waveforms{ch_i},1),[],nelec);
    end
end

[~, fname, ext]=fileparts(handles1.filename);

uisave('data',[fname '_sorting' ext])

end