
for i=1:length(Spikeform3)
    if length(Spikeform3{i}) == 1
        Spikeform3{i}=[];
    end
        
end


Spikeform3=Spikeform3';

M2=M2';




for i=1:60
    if isempty(data1.times{1,i})
        continue
    else
        data1.times{1,i}=data1.times{1,i}';
    end
end

for i=1:60
    if isempty(data1.waveforms{1,i})
        continue
    else
        data1.waveforms{1,i}=data1.waveforms{1,i}';
    end
end

data1.waveforms=data1.waveforms(~cellfun('isempty',data1.waveforms));
data1.spiketimes=data1.spiketimes(~cellfun('isempty',data1.spiketimes));