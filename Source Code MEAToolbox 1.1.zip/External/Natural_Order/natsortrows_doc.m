%% NATSORTROWS Examples
% The function <https://www.mathworks.com/matlabcentral/fileexchange/47433
% |NATSORTROWS|> sorts the rows of a cell array of strings (1xN char), taking
% into account any number values within the strings. This is known as a
% _natural order sort_ or an _alphanumeric sort_. Note that MATLAB's inbuilt
% <https://www.mathworks.com/help/matlab/ref/sortrows.html |SORTROWS|>
% function sorts only by character order.
%
% For sorting filenames or filepaths use
% <https://www.mathworks.com/matlabcentral/fileexchange/47434 |NATSORTFILES|>.
%
% For sorting a cell array of strings use
% <https://www.mathworks.com/matlabcentral/fileexchange/34464 |NATSORT|>.
%
%% Basic Usage:
% By default |NATSORTROWS| interprets consecutive digits as being part of
% a single integer:
A = {'A2','X';'A10','Y';'A10','X';'A1','X'};
sortrows(A) % Wrong numeric order
natsortrows(A)
%% Output 2: Sort Index
% The second output argument is a numeric array of the sort indices |ndx|,
% such that |Y = X(ndx,:)| where  for |Y = natsortrows(X)|:
[~,ndx] = natsortrows(A)
%% Output 3: Debugging Array
% The third output is a cell vector of cell arrays, where the cell arrays
% correspond to the columns of the input cell array |X|.
% The cell arrays contain all matched numbers (after converting to
% numeric using the specified |SSCANF| format) and all split character
% substrings. These cell arrays are useful for confirming that the
% numbers are being correctly identified by the regular expression.
% Note that the even columns contain any matched number values,
% while the odd columns contain any split substrings:
[~,~,dbg] = natsortrows(A);
dbg{:}
%% Input 2: Regular Expression
% The optional second input argument is a regular expression which
% specifies the number matching:
B = {'1.3','X';'1.10','X';'1.2','X'};
natsortrows(B)   % by default match integers
natsortrows(B, '\d+\.?\d*') % match decimal fractions
%% Input 3+: |SORTROWS| Column Argument
% |SORTROWS| |col| input is supported, where a positive integer will sort
% the corresponding column in ascending order, and a negative integer will
% sort the corresponding column in descending order. In this example the
% second column is sorted descending, and the first ascending:
sortrows(A,[-2,1]) % wrong numeric order
natsortrows(A,[],[-2,1]) % correct numeric order:
%% Inputs 3+: Optional Arguments
% Further inputs are passed directly to |NATSORT|, thus giving control over
% the case sensitivity, sort direction, and other options. See the
% |NATSORT| help for explanations and examples of the supported options:
C = {'B','X';'10','X';'1','X';'A','X';'2','X'};
natsortrows(C, [], 'descend')
natsortrows(C, [], 'char<num')
%% Regular Expression: Decimal Fractions, E-notation, +/- Sign.
% |NATSORTROWS| number matching can be customized to detect numbers with
% a decimal fraction, E-notation, a +/- sign, binary/hexadecimal, or other
% required features. The number matching is specified using an
% appropriate regular expression: see |NATSORT| for details and examples.
D = {'v10.2','b'; 'v2.5','b'; 'v2.40','a'; 'v1.9','b'};
natsortrows(D) % integers, e.g. version numbers
natsortrows(D,'\d+\.?\d*') % decimal fractions
%% Bonus: Interactive Regular Expression Tool
% Regular expressions are powerful and compact, but getting them right is
% not always easy. One assistance is to download my interactive tool
% <https://www.mathworks.com/matlabcentral/fileexchange/48930 |IREGEXP|>,
% which lets you quickly try different regular expressions and see all of
% <https://www.mathworks.com/help/matlab/ref/regexp.html |REGEXP|>'s
% outputs displayed and updated as you type.