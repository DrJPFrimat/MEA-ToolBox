function varargout = Main_Menu_Toolbox(varargin)
% MAIN_MENU_TOOLBOX MATLAB code for Main_Menu_Toolbox.fig
%      MAIN_MENU_TOOLBOX, by itself, creates a new MAIN_MENU_TOOLBOX or raises the existing
%      singleton*.
%
%      H = MAIN_MENU_TOOLBOX returns the handle to a new MAIN_MENU_TOOLBOX or the handle to
%      the existing singleton*.
%
%      MAIN_MENU_TOOLBOX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN_MENU_TOOLBOX.M with the given input arguments.
%
%      MAIN_MENU_TOOLBOX('Property','Value',...) creates a new MAIN_MENU_TOOLBOX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Main_Menu_Toolbox_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Main_Menu_Toolbox_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Main_Menu_Toolbox

% Last Modified by GUIDE v2.5 10-May-2021 13:53:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Main_Menu_Toolbox_OpeningFcn, ...
                   'gui_OutputFcn',  @Main_Menu_Toolbox_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

% --- Executes just before Main_Menu_Toolbox is made visible.
function Main_Menu_Toolbox_OpeningFcn(hObject, eventdata, handles, varargin)

% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Main_Menu_Toolbox (see VARARGIN)
global changeflag 
set(gcf,'units','normalized','position',[0 0 1 1])
set(gcf,'WindowState','fullscreen')
ha = axes('units','normalized', ...
            'position',[0 0 1 1]);

   




% I=imread('Good_One.tif');
% I=I(:,:,(1:3));
% 
% imagesc(I);


% Turn the handlevisibility off so that we don't inadvertently plot into the axes again
% Also, make the axes invisible
set(ha,'handlevisibility','off', ...
            'visible','off')
% % % Move the background axes to the bottom
uistack(ha,'bottom');

% Choose default command line output for Main_Menu_Toolbox
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Main_Menu_Toolbox wait for user response (see UIRESUME)
% uiwait(handles.figure1);
end

% --- Outputs from this function are returned to the command line.
function varargout = Main_Menu_Toolbox_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This animation was created by Tom Morris @ https://palerlotus.tumblr.com/
% Permission was asked to use his animation for the start-up screen and he
% granted it by mail.

% 
% Video1 = VideoReader('Start Screen.avi');
% frame_video =read(Video1,1);

while ~isempty(findobj('Name','Main_Menu_Toolbox'))
    for i = 1:20
        if isempty(findobj('Name','Main_Menu_Toolbox'))
            return
        else
%                    frame_video =read(Video1,i);
%                   imshow(frame_video);
            imshow(['Frame',num2str(i),'-min.jpg'])
            set(gcf,'MenuBar','none')
            set(gca,'DataAspectRatioMode','auto')
            set(gca,'Position',[0 0 1 1])
            
            pause(0.03);
        end
    end
    
end



% Get default command line output from handles structure
varargout{1} = handles.output;
end

%% analyze files button
% --- Executes during object creation, after setting all properties.
function pushbutton1_CreateFcn(hObject, eventdata, handles)

hObject.Enable ='off';


end


function pushbutton1_Callback(hObject, eventdata, handles)
global pushed flag 

current=pwd;
addpath(current);

if flag == 1
    run('justspiketimes')
elseif flag == 0
    run('MEAToolboxV3.m')
end

end
%% load files button
% --- Executes during object creation, after setting all properties.
function pushbutton3_CreateFcn(hObject, eventdata, handles)

hObject.Enable ='off';

end

% --- Executes on button press in load files
function pushbutton3_Callback(hObject, eventdata, handles)
global selecteddata filteredData1 burst6 multiwell1 clustertag
   clustertag = 0;
    clear variables
    % clear global
    [selecteddata,folder]=uigetfile('data.mat');
    if folder == 0
        return
    else
        
        f = waitbar(0,'Loading File...');
        addpath(folder);
        waitbar(.5,f,'Loading your data');
        selecteddata144 = selecteddata;
        load(selecteddata);
        selecteddata = selecteddata144;
%         if floor(filteredData1)==ceil(filteredData1)
%             filteredData1=hlp_deserialize(filteredData1);
%         end
        
        close(f)
        close('Main_Menu_Toolbox')
        % run('MEA_Data_Plots2.m');
%          waitbar(1,f,'Loading Complete');
        
        if  multiwell1 == 1
%             filteredData1=hlp_deserialize(filteredData1);
           run('multiwell.m')
        else
%             filteredData1=hlp_deserialize(filteredData1);
            MEA_Data_Plots2
        end
        
%          close(f)
    end

end
%% change parameters button
% --- Executes on button press in change parameters
function pushbutton4_Callback(hObject, eventdata, handles)
global pushed
pushed=1;
run('parameters')

end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
web('https://github.com/mhyhu/Toolbox');
end

% --- Executes during object creation, after setting all properties.
function pushbutton5_CreateFcn(hObject, eventdata, handles)
hObject.String ='Help';
hObject.FontSize =16;
hObject.FontWeight ='Bold';
end
