% Create the function for the ValueChangedFcn callback:
function cBoxChanged(cbx,~)
global supa BurstCount MeanData networkburstttt multiwell1 Connextions InterBurstInterval CVTt IBI CVISI InterISI MaxAmplitude ratioISI BurstDur AllData PercentageSpikes SpikeCount BurstRate ArrayFiringRate flag cbx99 timesss Exburst cbx32 CVIBITt total13 connectionst networkburstt burstNt maxamp meanISI medianISI total31 MAD synchronicity IBIT IBITt burstdurT burstdurTt M2 total17 perspikesburstTt files spikeT spikeTt burstTt total16 burstT fireT cbx16 cbx17 arrayfiringrate divdate cbx cbx28 cbx30 cbx31 cbx29 cbx26 cbx27 cbx24 cbx25 cbx22 cbx23 cbx18 cbx19  cbx1 cbx2 cbx3 cbx4 cbx5 cbx6 cbx7 cbx8 cbx9 cbx10 cbx11 cbx12 cbx13 cbx14 cbx20 cbx15 cbx21

flag = 0;
 hh=waitbar(0,'Calculating the Endpoints');
%%     Groups or Series
%%     for creating graphs out of the endpoints (useful perhaps for the future)
% if cbx99.Value == 1
%     flag = 1;
%     cbx32.Enable = 'on';
% elseif cbx99.Value == 0
%     cbx32.Enable = 'off';
%     flag = 0;
% end
% 
% %% fire rate
% if cbx.Value == 1
%     cbx16.Visible = 'on';
%     cbx17.Visible = 'on';
%     
% else
%     cbx16.Visible = 'off';
%     cbx17.Visible = 'off';
% end
% 
% if cbx16.Value == 1
%     cbx17.Visible = 'off';
% end
% 
% if cbx17.Value == 1
%     cbx16.Visible = 'off';
% end
% 
% if cbx16.Value == 1 && cbx.Value == 1
%     
%     %make a new matrix appropriate for table later
%     fireT = [];
%     fireT(1,:) = divdate ;
%     
%     if iscell(arrayfiringrate)
%         arrayfiringrate = cell2mat(arrayfiringrate);
%     end
%     
%     fireT(2,:) = arrayfiringrate ;
%     fireT=table(fireT);
%     fireT.Properties.RowNames{1} = 'Groups';
%     fireT.Properties.RowNames{2} = 'Data';
%     
%     %plot the mean firing rate
%     meanfiringrate = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanfiringrate(i) = mean(arrayfiringrate(divdate == temp(i)));
%     end
%     
%     semfiringrate = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semfiringrate(i) = std(arrayfiringrate(divdate == temp(i)))/sqrt(length(arrayfiringrate(divdate == temp(i))));
%     end
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(meanfiringrate);
%     
%     for k1 = 1:size(meanfiringrate,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semfiringrate,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Firing Rate (Hz)')
%     title('Mean Firing Rate (Hz)')
%     
%     
%     jjj = figure(2);
%     uitable('Data',fireT{:,:},'ColumnName',fireT.Properties.VariableNames,...
%         'RowName',fireT.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif cbx.Value == 1 && cbx17.Value == 1
%     
%     %make a new matrix appropriate for table later
%     fireT = [];
%     fireT(1,:) = divdate ;
%     
%     if iscell(arrayfiringrate)
%         arrayfiringrate = cell2mat(arrayfiringrate);
%     end
%     
%     fireT(2,:) = arrayfiringrate ;
%     fireT=table(fireT);
%     fireT.Properties.RowNames{1} = 'Groups';
%     fireT.Properties.RowNames{2} = 'Data';
%     
%     %plot the median firing rate
%     
%     medianfiringrate = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         medianfiringrate(i) = median(arrayfiringrate(divdate == temp(i)));
%     end
%     
%     semmedianfiringrate = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semmedianfiringrate(i) = 1.253*(std(arrayfiringrate(divdate == temp(i)))/sqrt(length(arrayfiringrate(divdate == temp(i)))));
%     end
%     
%     jj = figure(1);
%     clf
%     movegui(jj,'west');
%     pp = bar(medianfiringrate);
%     
%     for k1 = 1:size(medianfiringrate,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semmedianfiringrate,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Firing Rate (Hz)')
%     title('Median Firing Rate (Hz)')
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',fireT{:,:},'ColumnName',fireT.Properties.VariableNames,...
%         'RowName',fireT.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
% elseif flag == 1 && cbx.Value == 1
%     if cbx.Value == 1
%         cbx16.Visible = 'off';
%         cbx17.Visible = 'off';
%         
%     else
%         cbx16.Visible = 'off';
%         cbx17.Visible = 'off';
%     end
%     
%     if cbx16.Value == 1
%         cbx17.Visible = 'off';
%     end
%     
%     if cbx17.Value == 1
%         cbx16.Visible = 'off';
%     end
%     
%     %make a new matrix appropriate for table later
%     
%     
%     fireT = cell(1,length(files))';
%     for i =1:length(files)
%         fireT{i} = arrayfiringrate(i);
%     end
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     ArrayFiringRate = [];
%     ArrayFiringRate.FileName = filenames;
%     ArrayFiringRate.ArrayFiringRate = fireT;
%     ArrayFiringRate =struct2table(ArrayFiringRate);
%     
%     
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(arrayfiringrate);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Firing Rate (Hz)')
%     title('Mean Firing Rate (Hz)')
%     
%     
%     jjj = figure(2);
%     uitable('Data',ArrayFiringRate{:,:},'ColumnName',ArrayFiringRate.Properties.VariableNames,...
%         'RowName',ArrayFiringRate.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
% end
% 
% 
% %% Burst rate
% 
% 
% if cbx1.Value == 1
%     cbx18.Visible = 'on';
%     cbx19.Visible = 'on';
% else
%     cbx18.Visible = 'off';
%     cbx19.Visible = 'off';
% end
% 
% if cbx18.Value == 1
%     cbx19.Visible = 'off';
% end
% 
% if cbx19.Value == 1
%     cbx18.Visible = 'off';
% end
% 
% if cbx1.Value == 1 && cbx18.Value == 1
%     %plot the mean burst rate
%     %make a new matrix appropriate for table later
%     burstT = [];
%     burstT(1,:) = divdate ;
%     
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             burstT(2,i) = 0 ;
%         else
%             burstT(2,i) = cell2mat(total16{i}(4)) ;
%         end
%     end
%     
%     
%     %plot the mean firing rate
%     meanburstrate = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanburstrate(i) = mean(burstT(2,divdate == temp(i)));
%     end
%     
%     semburstrate = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semburstrate(i) = std(burstT(2,divdate == temp(i)))/sqrt(length(burstT(divdate == temp(i))));
%     end
%     
%     jj = figure(1);
%     clf
%     movegui(jj,'east');
%     pp = bar(meanburstrate);
%     
%     for k1 = 1:size(meanburstrate,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semburstrate,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Burst Rate (Hz)')
%     title('Mean Burst Rate (Hz)')
%     
%     burstTt=table(burstT);
%     burstTt.Properties.RowNames{1} = 'Groups';
%     burstTt.Properties.RowNames{2} = 'Data';
%     
%     jjj = figure(2);
%     movegui(jjj,'west');
%     uitable('Data',burstTt{:,:},'ColumnName',burstTt.Properties.VariableNames,...
%         'RowName',burstTt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
% elseif  cbx19.Value == 1 && cbx1.Value == 1
%     %plot the median burst rate
%     
%     
%     medianburstrate = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         medianburstrate(i) = median(burstT(2,divdate == temp(i)));
%     end
%     
%     semmedianburstrate = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semmedianburstrate(i) = 1.253*(std(burstT(2,divdate == temp(i)))/sqrt(length(burstT(2,divdate == temp(i)))));
%     end
%     
%     jj = figure(1)
%     clf
%     pp = bar(medianburstrate);
%     movegui(jj,'east');
%     for k1 = 1:size(medianburstrate,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semmedianburstrate,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Firing Rate (Hz)')
%     title('Median burst Rate (Hz)')
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'west');
%     uitable('Data',burstTt{:,:},'ColumnName',burstTt.Properties.VariableNames,...
%         'RowName',burstTt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif flag == 1 && cbx1.Value == 1
%     
%     if cbx1.Value == 1
%         cbx18.Visible = 'off';
%         cbx19.Visible = 'off';
%     else
%         cbx18.Visible = 'off';
%         cbx19.Visible = 'off';
%     end
%     
%     if cbx18.Value == 1
%         cbx19.Visible = 'off';
%     end
%     
%     if cbx19.Value == 1
%         cbx18.Visible = 'off';
%     end
%     
%     %make a new matrix appropriate for table later
%     burstT = cell(1,length(files))';
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             burstT{i} = 0 ;
%         else
%             burstT{i} = cell2mat(total16{i}(4));
%         end
%     end
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     BurstRate = [];
%     BurstRate.FileName = filenames;
%     BurstRate.BurstRate = burstT;
%     BurstRate =struct2table(BurstRate);
%     
%     burstT = cell2mat(burstT);
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(burstT);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Burst Rate (Burst per second)')
%     title('Burst Rate (Hz)')
%     
%     
%     jjj = figure(2);
%     uitable('Data',BurstRate{:,:},'ColumnName',BurstRate.Properties.VariableNames,...
%         'RowName',BurstRate.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
% end
% 
% 
% %% amount of spikes in burst
% 
% 
% if cbx2.Value == 1
%     cbx20.Visible = 'on';
%     cbx21.Visible = 'on';
% else
%     cbx20.Visible = 'off';
%     cbx21.Visible = 'off';
% end
% 
% if cbx20.Value == 1
%     cbx21.Visible = 'off';
% end
% 
% if cbx21.Value == 1
%     cbx20.Visible = 'off';
% end
% 
% 
% if cbx2.Value == 1 && cbx20.Value == 1
%     %plot the mean amount of spikes in burst
%     
%     %make a new matrix appropriate for table later
%     spikeT = [];
%     spikeT(1,:) = divdate ;
%     
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             spikeT(2,i) = 0 ;
%         else
%             spikeT(2,i) = cell2mat(total16{i}(3)) ;
%         end
%     end
%     
%     
%     %plot the mean firing rate
%     meanspikeburst= zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanspikeburst(i) = mean(spikeT(2,divdate == temp(i)));
%     end
%     
%     semspikeburst = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semspikeburst(i) = std(spikeT(2,divdate == temp(i)))/sqrt(length(spikeT(divdate == temp(i))));
%     end
%     
%     jj = figure(1)
%     clf
%     pp = bar(meanspikeburst);
%     movegui(jj,'west');
%     for k1 = 1:size(meanspikeburst,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semspikeburst,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Spikes (n)')
%     title('Mean amount of spikes in bursts (n)')
%     
%     spikeTt=table(spikeT);
%     spikeTt.Properties.RowNames{1} = 'Groups';
%     spikeTt.Properties.RowNames{2} = 'Data';
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',spikeTt{:,:},'ColumnName',spikeTt.Properties.VariableNames,...
%         'RowName',spikeTt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif cbx2.Value == 1 && cbx21.Value == 1
%     %plot the median amount of spikes in burst
%     
%     
%     medianspikeburst = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         medianspikeburst(i) = median(spikeT(2,divdate == temp(i)));
%     end
%     
%     semmedianspikeburst = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semmedianspikeburst(i) = 1.253*(std(spikeT(2,divdate == temp(i)))/sqrt(length(spikeT(2,divdate == temp(i)))));
%     end
%     
%     jj = figure(1)
%     clf
%     pp = bar(medianspikeburst);
%     movegui(jj,'west');
%     for k1 = 1:size(medianspikeburst,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semmedianspikeburst,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Spikes (n)')
%     title('Median amount of spikes in bursts (n)')
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',spikeTt{:,:},'ColumnName',spikeTt.Properties.VariableNames,...
%         'RowName',spikeTt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif flag == 1 && cbx2.Value == 1
%     
%     if cbx2.Value == 1
%         cbx20.Visible = 'off';
%         cbx21.Visible = 'off';
%     else
%         cbx20.Visible = 'off';
%         cbx21.Visible = 'off';
%     end
%     
%     if cbx20.Value == 1
%         cbx21.Visible = 'off';
%     end
%     
%     if cbx21.Value == 1
%         cbx20.Visible = 'off';
%     end
%     
%     
%     %make a new matrix appropriate for table later
%     spikeT = cell(1,length(files))';
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             spikeT{i} = 0 ;
%         else
%             spikeT{i} = cell2mat(total16{i}(3));
%         end
%     end
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     SpikeCount = [];
%     SpikeCount.FileName = filenames;
%     SpikeCount.SpikeCount = spikeT;
%     SpikeCount =struct2table(SpikeCount);
%     
%     spikeT = cell2mat(spikeT);
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(spikeT);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Spike Count (n)')
%     title('Amount of spikes in bursts (n)')
%     
%     
%     jjj = figure(2);
%     uitable('Data',SpikeCount{:,:},'ColumnName',SpikeCount.Properties.VariableNames,...
%         'RowName',SpikeCount.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
% end
% 
% 
% %% percentage spikes in burst
% 
% if cbx3.Value == 1 && flag == 0
%     %plot the mean percentage spikes in burst
%     
%     total18= cell(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         total18{i}=load(selecteddata1,'Exburst');
%     end
%     total18=total18';
%     
%     perspikesburst2=cell(1,length(total17));
%     perspikesbursts=zeros(1,length(M2));
%     for k = 1:length(total17)
%         for i=1:length(M2)
%             if isempty(total18{k}.Exburst{i}.number_of_bursts)
%                 perspikesbursts(i) = 0;
%             else
%                 perspikesbursts(i) = ((sum(total18{k}.Exburst{i}.spikes_in_bursts))/size(total17{k}.M2{i},2))*100';   % the cell array contains the amount of spikes that are part of a burst per channel
%                 perspikesbursts(perspikesbursts == 0)=[];    %remove all zeros
%                 if length(perspikesbursts) == 1 %if there is only one values it means that tehre is only one hcannel with bursts so don't do anything
%                 else
%                     perspikesbursts = mean(perspikesbursts);
%                 end
%                 
%                 perspikesburst2{k} = perspikesbursts; % contains the 'raw' data
%             end
%         end
%     end
%     
%     for i = 1:length(perspikesburst2)
%         if isempty(perspikesburst2{i})
%             perspikesburst2{i} = 0;
%         end
%     end
%     %perspikesburst2(cellfun('isempty',perspikesburst2))=[]; %remove empty cells
%     perspikesburst2 = cell2mat(perspikesburst2);
%     %average it over all channels
%     meanper= zeros(1,length(unique(divdate)));
%     for i=1:length(unique(divdate))
%         temp = unique(divdate);
%         meanper(i)=mean(perspikesburst2(divdate == temp(i)));
%     end
%     
%     semper= zeros(1,length(unique(divdate)));
%     for i=1:length(unique(divdate))
%         temp = unique(divdate);
%         semper(i)=std(perspikesburst2(divdate == temp(i)))/sqrt(length(perspikesburst2(divdate == temp(i))));
%     end
%     
%     
%     
%     jj = figure(1)
%     clf
%     pp = bar(meanper);
%     movegui(jj,'west');
%     for k1 = 1:size(meanper,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semper,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Percentage (%)')
%     title('Percentage of spikes participating in bursts')
%     
%     perspikesburst2(2,:) = perspikesburst2;
%     perspikesburst2(1,:) = divdate ;
%     perspikesburstTt=table(perspikesburst2);
%     perspikesburstTt.Properties.RowNames{1} = 'Groups';
%     perspikesburstTt.Properties.RowNames{2} = 'Data';
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',perspikesburstTt{:,:},'ColumnName',perspikesburstTt.Properties.VariableNames,...
%         'RowName',perspikesburstTt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif flag == 1 && cbx3.Value == 1
%     
%     
%     %make a new matrix appropriate for table later
%     
%     
%     total18= cell(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         total18{i}=load(selecteddata1,'Exburst');
%     end
%     total18=total18';
%     
%     perspikesburst2=cell(1,length(total17));
%     perspikesbursts=zeros(1,length(M2));
%     for k = 1:length(total17)
%         for i=1:length(M2)
%             if isempty(total18{k}.Exburst{i}.number_of_bursts)
%                 perspikesbursts(i) = 0;
%             else
%                 perspikesbursts(i) = ((sum(total18{k}.Exburst{i}.spikes_in_bursts))/size(total17{k}.M2{i},2))*100';   % the cell array contains the amount of spikes that are part of a burst per channel
%                 perspikesbursts(perspikesbursts == 0)=[];    %remove all zeros
%                 if length(perspikesbursts) == 1 %if there is only one values it means that tehre is only one hcannel with bursts so don't do anything
%                 else
%                     perspikesbursts = mean(perspikesbursts);
%                 end
%                 
%                 perspikesburst2{k} = perspikesbursts; % contains the 'raw' data
%             end
%         end
%     end
%     
%     for i = 1:length(perspikesburst2)
%         if isempty(perspikesburst2{i})
%             perspikesburst2{i} = 0;
%         end
%     end
%     
%     
%     perspikesburst2 = perspikesburst2';
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     PercentageSpikes = [];
%     PercentageSpikes.FileName = filenames;
%     PercentageSpikes.PercentageSpikes = perspikesburst2;
%     PercentageSpikes =struct2table( PercentageSpikes);
%     
%     spikeT = cell2mat(perspikesburst2);
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(spikeT);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Spike Count (%)')
%     title('Spike participating in bursts (%)')
%     
%     
%     jjj = figure(2);
%     uitable('Data',PercentageSpikes{:,:},'ColumnName',PercentageSpikes.Properties.VariableNames,...
%         'RowName',PercentageSpikes.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% end
% 
% 
% 
% 
% %% CV of ISIs
% 
% 
% if cbx4.Value == 1 && flag == 0
%     %plot the mean CV of ISIs
%     
%     
%     total19= cell(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         total19{i}=load(selecteddata1,'T');
%         if total19{i}.T.Units_per_second(end) == inf
%             total19{i} = total19{i}.T.CV(1);
%         else
%             total19{i} = total19{i}.T.CV(end);   % contaisn the 'raw' data
%         end
%     end
%     
%     total19=cell2mat(total19);
%     
%     meanCV= zeros(1,length(unique(divdate)));
%     for i=1:length(unique(divdate))
%         temp = unique(divdate);
%         meanCV(i)=mean(total19(divdate == temp(i)));
%     end
%     
%     semCV= zeros(1,length(unique(divdate)));
%     for i=1:length(unique(divdate))
%         temp = unique(divdate);
%         semCV(i)=std(total19(divdate == temp(i)))/sqrt(length(total19(divdate == temp(i))));
%     end
%     
%     jj = figure(1);
%     clf
%     pp = bar(meanCV);
%     movegui(jj,'west');
%     for k1 = 1:size(meanCV,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semCV,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('-')
%     title('Coefficient of variation of ISIs')
%     
%     total19(2,:) = total19;
%     total19(1,:) = divdate ;
%     CVTt=table(total19);
%     CVTt.Properties.RowNames{1} = 'Groups';
%     CVTt.Properties.RowNames{2} = 'Data';
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',CVTt{:,:},'ColumnName',CVTt.Properties.VariableNames,...
%         'RowName',CVTt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif flag == 1 && cbx4.Value == 1
%     
%     
%     %make a new matrix appropriate for table later
%     
%     total19= cell(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         total19{i}=load(selecteddata1,'T');
%         if total19{i}.T.Units_per_second(end) == inf
%             total19{i} = total19{i}.T.CV(1);
%         else
%             total19{i} = total19{i}.T.CV(end);   % contaisn the 'raw' data
%         end
%     end
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     CVISI = [];
%     CVISI.FileName = filenames;
%     CVISI.CV_ISI = total19';
%     CVISI =struct2table(CVISI);
%     
%     CV_ISI = cell2mat(total19)';
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(CV_ISI);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Coefficient')
%     title('Coefficient of Variation of ISIs')
%     
%     
%     jjj = figure(2);
%     uitable('Data',CVISI{:,:},'ColumnName',CVISI.Properties.VariableNames,...
%         'RowName',CVISI.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% end
% 
% 
% 
% 
% 
% %% Burst Duration
% 
% if cbx5.Value == 1
%     cbx22.Visible = 'on';
%     cbx23.Visible = 'on';
% else
%     cbx22.Visible = 'off';
%     cbx23.Visible = 'off';
% end
% 
% if cbx22.Value == 1
%     cbx23.Visible = 'off';
% end
% 
% if cbx23.Value == 1
%     cbx22.Visible = 'off';
% end
% 
% 
% if cbx5.Value == 1 && cbx22.Value == 1
%     %plot the mean burst duration
%     
%     %make a new matrix appropriate for table later
%     burstdurT = [];
%     burstdurT(1,:) = divdate ;
%     
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             burstdurT(2,i) = 0 ;
%         else
%             burstdurT(2,i) = cell2mat(total16{i}(2)) ;
%         end
%     end
%     
%     
%     %plot the mean firing rate
%     meandurburst= zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meandurburst(i) = mean(burstdurT(2,divdate == temp(i)));
%     end
%     
%     semdurburst = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semdurburst(i) = std(burstdurT(2,divdate == temp(i)))/sqrt(length(burstdurT(divdate == temp(i))));
%     end
%     
%     jj = figure(1)
%     clf
%     pp = bar(meandurburst);
%     movegui(jj,'west');
%     for k1 = 1:size(meandurburst,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semdurburst,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Time (s)')
%     title('Mean Burst duration (s)')
%     
%     burstdurTt=table(burstdurT);
%     burstdurTt.Properties.RowNames{1} = 'Groups';
%     burstdurTt.Properties.RowNames{2} = 'Data';
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',burstdurTt{:,:},'ColumnName',burstdurTt.Properties.VariableNames,...
%         'RowName',burstdurTt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif cbx5.Value == 1 && cbx23.Value == 1
%     %plot the median burst duration
%     
%     
%     medianburstdur = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         medianburstdur(i) = median(burstdurT(2,divdate == temp(i)));
%     end
%     
%     semmedianburstdur = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semmedianburstdur(i) = 1.253*(std(burstdurT(2,divdate == temp(i)))/sqrt(length(burstdurT(2,divdate == temp(i)))));
%     end
%     
%     jj = figure(1)
%     clf
%     pp = bar(medianburstdur);
%     movegui(jj,'west');
%     for k1 = 1:size(medianburstdur,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semmedianburstdur,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Time (s)')
%     title('Median burst duration (s)')
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',burstdurTt{:,:},'ColumnName',burstdurTt.Properties.VariableNames,...
%         'RowName',burstdurTt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif flag == 1 && cbx5.Value == 1
%     
%     
%     if cbx5.Value == 1
%         cbx22.Visible = 'off';
%         cbx23.Visible = 'off';
%     else
%         cbx22.Visible = 'off';
%         cbx23.Visible = 'off';
%     end
%     
%     if cbx22.Value == 1
%         cbx23.Visible = 'off';
%     end
%     
%     if cbx23.Value == 1
%         cbx22.Visible = 'off';
%     end
%     
%     
%     
%     
%     
%     %make a new matrix appropriate for table later
%     
%     burstdurT = cell(1,length(files))';
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             burstdurT{i} = 0 ;
%         else
%             burstdurT{i} = cell2mat(total16{i}(2)) ;
%         end
%     end
%     
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     BurstDur = [];
%     BurstDur.FileName = filenames;
%     BurstDur.BurstDur = burstdurT;
%     BurstDur =struct2table(BurstDur);
%     
%     burstdurTt = cell2mat(burstdurT)';
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(burstdurTt);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Time (s)')
%     title('Burst Duration')
%     
%     
%     jjj = figure(2);
%     uitable('Data',BurstDur{:,:},'ColumnName',BurstDur.Properties.VariableNames,...
%         'RowName',BurstDur.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
% end
% 
% %% IBI
% 
% 
% if cbx6.Value == 1
%     cbx24.Visible = 'on';
%     cbx25.Visible = 'on';
% else
%     cbx24.Visible = 'off';
%     cbx25.Visible = 'off';
% end
% 
% if cbx24.Value == 1
%     cbx25.Visible = 'off';
% end
% 
% if cbx25.Value == 1
%     cbx24.Visible = 'off';
% end
% 
% 
% if cbx6.Value == 1 && cbx24.Value == 1
%     %plot the mean IBI
%     
%     %make a new matrix appropriate for table later
%     IBIT = [];
%     IBIT(1,:) = divdate ;
%     
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             IBIT(2,i) = 0 ;
%         else
%             IBIT(2,i) = cell2mat(total16{i}(7)) ;
%         end
%     end
%     
%     
%     %plot the mean firing rate
%     meanIBI= zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanIBI(i) = mean(IBIT(2,divdate == temp(i)));
%     end
%     
%     semIBI = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semIBI(i) = std(IBIT(2,divdate == temp(i)))/sqrt(length(IBIT(divdate == temp(i))));
%     end
%     
%     jj = figure(1);
%     clf
%     pp = bar(meanIBI);
%     movegui(jj,'west');
%     for k1 = 1:size(meanIBI,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semIBI,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Time (s)')
%     title('Mean IBI (s)')
%     
%     IBITt=table(IBIT);
%     IBITt.Properties.RowNames{1} = 'Groups';
%     IBITt.Properties.RowNames{2} = 'Data';
%     
%     jj = figure(2);
%     movegui(jj,'east');
%     uitable('Data',IBITt{:,:},'ColumnName',IBITt.Properties.VariableNames,...
%         'RowName',IBITt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
% elseif cbx6.Value == 1 && cbx25.Value == 1
%     %plot the median IBI
%     
%     
%     medianIBI = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         medianIBI(i) = median(IBIT(2,divdate == temp(i)));
%     end
%     
%     semmedianIBI = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semmedianIBI(i) = 1.253*(std(IBIT(2,divdate == temp(i)))/sqrt(length(IBIT(2,divdate == temp(i)))));
%     end
%     
%     jj = figure(1);
%     clf
%     pp = bar(medianIBI);
%     movegui(jj,'west');
%     for k1 = 1:size(medianIBI,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semmedianIBI,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Time (s)')
%     title('Median IBI (n)')
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',IBITt{:,:},'ColumnName',IBITt.Properties.VariableNames,...
%         'RowName',IBITt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif flag == 1 && cbx6.Value == 1
%     
%     if cbx6.Value == 1
%         cbx24.Visible = 'off';
%         cbx25.Visible = 'off';
%     else
%         cbx24.Visible = 'off';
%         cbx25.Visible = 'off';
%     end
%     
%     if cbx24.Value == 1
%         cbx25.Visible = 'off';
%     end
%     
%     if cbx25.Value == 1
%         cbx24.Visible = 'off';
%     end
%     
%     
%     
%     
%     %make a new matrix appropriate for table later
%     
%     IBIT = cell(1,length(files))';
%     
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             IBIT{i} = 0 ;
%         else
%             IBIT{i} = cell2mat(total16{i}(7)) ;
%         end
%     end
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     IBI = [];
%     IBI.FileName = filenames;
%     IBI.IBI = IBIT;
%     IBI =struct2table(IBI);
%     
%     IBITt = cell2mat(IBIT)';
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(IBITt);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Time (s)')
%     title('Inter Burst Interval')
%     
%     
%     jjj = figure(2);
%     uitable('Data',IBI{:,:},'ColumnName',IBI.Properties.VariableNames,...
%         'RowName',IBI.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
% end
% 
% 
% %% Synchrony
% 
% if cbx7.Value == 1
%     %plot the mean synchrony
%     
%     synchronicity = zeros(1,length(files));
%     h = waitbar(0,'Calculating Synchrony');
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         waitbar(i/length(files))
%         load(selecteddata1,'supa');
%         %
%         
%         
%         %use fwhm to calculate the full width at half height of the peaks
%         
%         xv=1:301;
%         synccc = cell(1,length(M2));
%         syncc1 = [];
%         for iii = 1:length(M2)
%             if isempty(supa{iii})
%                 continue
%             else
%                 for j = 1:length(M2)
%                     if max(supa{iii}(j,:)) < 0.7
%                         syncc = 0;
%                     else
%                         syncc = fwhm(xv,supa{iii}(j,:));
%                     end
%                     syncc1 = [syncc1,syncc];
%                 end
%                 synccc{iii} = syncc1;
%                 syncc1 = [];
%             end
%         end
%         
%         
%         %remove all the zeros
%         
%         for iiii =1:length(M2)
%             if isempty(synccc{iiii})
%                 continue
%             else
%                 synccc{iiii}(synccc{iiii} == 0) =[];
%             end
%         end
%         
%         synccc = synccc(~cellfun('isempty',synccc));
%         
%         
%         clear syncc1 syncc
%         %now we get the average
%         
%         
%         for p =1:length(synccc)
%             synccc{p} = mean(synccc{p});
%         end
%         synccc= synccc';
%         synccc=cell2mat(synccc);
%         %array wide mean
%         synccc = mean(synccc);
%         if isnan(synccc) || synccc == 0
%             synchronicity(i) = 0;
%         else
%             synchronicity(i) = synccc;
%         end
%     end
%     close(h)
%     %average over the div days
%     %     meansync=[];
%     %     for i = 1:length(unique(divdate))
%     %         temp = unique(divdate);
%     %         meansync(i) = mean(synchronicity(divdate == temp(i)));
%     %
%     %     end
%     %
%     %
%     %     for i = 1:length(unique(divdate))
%     %         temp = unique(divdate);
%     %         semsync(i) = std(synchronicity(divdate == temp(i)))/sqrt(length(synchronicity(divdate == temp(i))));
%     %     end
%     
%     clear temp
%     
%     jj = figure(1);
%     clf
%     movegui(jj,'west');
%     pp = bar(synchronicity);
%     %
%     %     for k1 = 1:size(meansync,1)
%     %         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%     %         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     %     end
%     %
%     clear temp
%     %     hold on
%     %     errorbar(ctr,ydt,semsync,'.r')
%     %     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Time (s)')
%     title('Mean synchrony (s)')
%     
%     
%     
%     synchronicity=table(synchronicity);
%     %     synchronicity.Properties.RowNames{1} = 'Groups';
%     %     synchronicity.Properties.RowNames{2} = 'Data';
%     %
%     %
%     %     jjj = figure(2);
%     %     movegui(jjj,'east');
%     %     uitable('Data',synchronicity{:,:},'ColumnName',synchronicity.Properties.VariableNames,...
%     %         'RowName',synchronicity.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     %
%     %
%     %     screen = get(0,'Screensize');
%     %     c = uicontrol;
%     %     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     %     c.FontWeight = 'bold';
%     %     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     %     c.CData = imread('color_button.png');
%     %     c.String = 'Save Table';
%     %     c.Callback = @savetable;
%     
% end
% 
% 
% %% MAD
% if cbx8.Value == 1
%     %plot the normalized MAD burst spike number
%     
%     
%     
%     %get the mean of spikes in burst
%     meanyy = zeros(1,length(total16));
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             meanyy(i) = 0 ;
%         else
%             meanyy(i) = total16{i}{3};
%         end
%     end
%     
%     
%     %now we mean according to the groups
%     meanMAD = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanMAD(i) = mean(meanyy(divdate == temp(i)));  %now we have the mean values of each group
%     end
%     
%     MAD = cell(1,length(total16));
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             continue
%         else
%             MAD{i}= abs(total16{i}{3} - meanMAD(divdate(i)));
%         end
%     end
%     MAD=MAD';   % contains all the 'raw' data
%     
%     
%     for i = 1:length(MAD)
%         if isempty(MAD{i})
%             MAD{i} = 0;
%         end
%     end
%     
%     MAD = cell2mat(MAD);
%     meanMAD=[];
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanMAD(i) = mean(MAD(divdate == temp(i)));
%         
%     end
%     
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semMAD(i) = std(MAD(divdate == temp(i)))/sqrt(length(MAD(divdate == temp(i))));
%         
%     end
%     clear temp
%     
%     jj = figure(1);
%     clf
%     movegui(jj,'west');
%     pp = bar(meanMAD);
%     
%     for k1 = 1:size(meanMAD,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semMAD,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('-')
%     title('Mean MAD')
%     
%     
%     
%     MAD = MAD';
%     MAD(2,:) = MAD;
%     MAD(1,:) = divdate;
%     MAD=table(MAD);
%     MAD.Properties.RowNames{1} = 'Groups';
%     MAD.Properties.RowNames{2} = 'Data';
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',MAD{:,:},'ColumnName',MAD.Properties.VariableNames,...
%         'RowName',MAD.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
%     
% end
% 
% %% Median ISI /Mean ISI
% if cbx9.Value == 1 && flag == 0
%     %plot the ratio of Median ISI over Mean ISI
%     total30 = cell(1,length(files));
%     total31 = cell(1,length(files));
%     for i = 1:length(files)
%         selecteddata1=files(i).name;
%         total30{i} = load(selecteddata1,'T');
%         if cell2mat(total30{i}.T.meanISI(end)) == inf
%             total30{i} = total30{i}.T.meanISI(1);
%         else
%             total30{i} = total30{i}.T.meanISI(end);  %meanISI
%         end
%     end
%     
%     for i = 1:length(files)
%         selecteddata1=files(i).name;
%         total31{i} = load(selecteddata1,'T');
%         if total31{i}.T.medianISI(end) == inf
%             total31{i} = total31{i}.T.medianISI(1);
%         else
%             total31{i} = total31{i}.T.medianISI(end);   %medianISI
%         end
%     end
%     
%     for i = 1:length(total30)
%         total30{i} = total30{i}{1};
%     end
%     
%     total30 = cell2mat(total30);
%     total31 = cell2mat(total31);
%     
%     %now we get the ratio between the mdian and mean ISI
%     
%     for i = 1:length(total30)
%         if total31(i) == 0
%             continue
%         else
%             total31(i) = total31(i)/total30(i); %now we have the ratio
%         end
%     end
%     
%     
%     
%     
%     meanRISI=[];
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanRISI(i) = mean(total31(divdate == temp(i)));
%         
%     end
%     
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semRISI(i) = std(total31(divdate == temp(i)))/sqrt(length(total31(divdate == temp(i))));
%         
%     end
%     clear temp
%     
%     jj = figure(1) ;
%     clf
%     movegui(jj,'west');
%     pp = bar(meanRISI);
%     
%     for k1 = 1:size(meanRISI,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semRISI,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('-')
%     title('Mean Median ISI/Mean ISI')
%     
%     
%     
%     
%     total31(2,:) = total31;
%     total31(1,:) = divdate;
%     total31=table(total31);
%     total31.Properties.RowNames{1} = 'Groups';
%     total31.Properties.RowNames{2} = 'Data';
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',total31{:,:},'ColumnName',total31.Properties.VariableNames,...
%         'RowName',total31.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif flag == 1 && cbx9.Value == 1
%     
%     %make a new matrix appropriate for table later
%     
%     
%     
%     total30 = cell(1,length(files));
%     total31 = cell(1,length(files));
%     for i = 1:length(files)
%         selecteddata1=files(i).name;
%         total30{i} = load(selecteddata1,'T');
%         if cell2mat(total30{i}.T.meanISI(end)) == inf
%             total30{i} = total30{i}.T.meanISI(1);
%         else
%             total30{i} = total30{i}.T.meanISI(end);  %meanISI
%         end
%     end
%     
%     for i = 1:length(files)
%         selecteddata1=files(i).name;
%         total31{i} = load(selecteddata1,'T');
%         if total31{i}.T.medianISI(end) == inf
%             total31{i} = total31{i}.T.medianISI(1);
%         else
%             total31{i} = total31{i}.T.medianISI(end);   %medianISI
%         end
%     end
%     
%     for i = 1:length(total30)
%         total30{i} = total30{i}{1};
%     end
%     
%     total30 = cell2mat(total30);
%     total31 = cell2mat(total31);
%     
%     %now we get the ratio between the mdian and mean ISI
%     
%     for i = 1:length(total30)
%         if total31(i) == 0
%             continue
%         else
%             total31(i) = total31(i)/total30(i); %now we have the ratio
%         end
%     end
%     
%     total31 = total31';
%     
%     RatioISI = cell(1,length(files))';
%     for i = 1:length(files)
%         RatioISI{i} = total31(i);
%     end
%     
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     ratioISI = [];
%     ratioISI.FileName = filenames;
%     ratioISI.ratioISI = RatioISI;
%     ratioISI =struct2table(ratioISI);
%     
%     
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(total31);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('')
%     title('Ratio of Median ISI over Mean ISI')
%     
%     
%     jjj = figure(2);
%     uitable('Data',ratioISI{:,:},'ColumnName',ratioISI.Properties.VariableNames,...
%         'RowName',ratioISI.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
% end
% 
% %% ISI
% 
% if cbx10.Value == 1
%     cbx26.Visible = 'on';
%     cbx27.Visible = 'on';
% else
%     cbx26.Visible = 'off';
%     cbx27.Visible = 'off';
% end
% 
% if cbx26.Value == 1
%     cbx27.Visible = 'off';
% end
% 
% if cbx27.Value == 1
%     cbx26.Visible = 'off';
% end
% 
% 
% if cbx10.Value == 1 && cbx26.Value == 1
%     %plot the mean ISI
%     
%     meanISI = cell(1,length(files));
%     
%     for i = 1:length(files)
%         selecteddata1=files(i).name;
%         meanISI{i} = load(selecteddata1,'T');
%         if cell2mat(meanISI{i}.T.meanISI(end)) == inf
%             meanISI{i} = meanISI{i}.T.meanISI(1);
%         else
%             meanISI{i} = meanISI{i}.T.meanISI(end);  %meanISI
%         end
%     end
%     
%     
%     
%     for i = 1:length(meanISI)
%         meanISI{i} = meanISI{i}{1};
%     end
%     
%     meanISI = cell2mat(meanISI);
%     
%     
%     
%     
%     
%     meanISI1=[];
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanISI1(i) = mean(meanISI(divdate == temp(i)));
%         
%     end
%     
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semISI(i) = std(meanISI(divdate == temp(i)))/sqrt(length(meanISI(divdate == temp(i))));
%         
%     end
%     clear temp
%     
%     jj = figure(1);
%     clf
%     movegui(jj,'west');
%     pp = bar(meanISI1);
%     
%     for k1 = 1:size(meanISI1,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semISI,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Time (s)')
%     title('Mean ISI')
%     
%     
%     
%     
%     meanISI(2,:) = meanISI;
%     meanISI(1,:) = divdate;
%     meanISI = table(meanISI);
%     meanISI.Properties.RowNames{1} = 'Groups';
%     meanISI.Properties.RowNames{2} = 'Data';
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',meanISI{:,:},'ColumnName',meanISI.Properties.VariableNames,...
%         'RowName',meanISI.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
%     
%     
% elseif cbx10.Value == 1 && cbx27.Value == 1
%     %plot the median ISI
%     
%     medianISI = cell(1,length(files));
%     for i = 1:length(files)
%         selecteddata1=files(i).name;
%         medianISI{i} = load(selecteddata1,'T');
%         if medianISI{i}.T.medianISI(end) == inf
%             medianISI{i} = medianISI{i}.T.medianISI(1);
%         else
%             medianISI{i} = medianISI{i}.T.medianISI(end);   %medianISI
%         end
%     end
%     
%     medianISI = cell2mat(medianISI);
%     
%     
%     
%     
%     medianISI1=[];
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         medianISI1(i) = median(medianISI(divdate == temp(i)));
%         
%     end
%     
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semmedianISI(i) = 1.253*(std(medianISI(divdate == temp(i)))/sqrt(length(medianISI(divdate == temp(i)))));
%         
%     end
%     clear temp
%     
%     jj = figure(1);
%     clf
%     movegui(jj,'west');
%     pp = bar(medianISI1);
%     
%     for k1 = 1:size(medianISI1,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semmedianISI,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Time (s)')
%     title('Median ISI')
%     
%     
%     
%     
%     medianISI(2,:) = medianISI;
%     medianISI(1,:) = divdate;
%     medianISI = table(medianISI);
%     medianISI.Properties.RowNames{1} = 'Groups';
%     medianISI.Properties.RowNames{2} = 'Data';
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',medianISI{:,:},'ColumnName',medianISI.Properties.VariableNames,...
%         'RowName',medianISI.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
% elseif flag == 1 && cbx10.Value == 1
%     
%     if cbx10.Value == 1
%         cbx26.Visible = 'off';
%         cbx27.Visible = 'off';
%     else
%         cbx26.Visible = 'off';
%         cbx27.Visible = 'off';
%     end
%     
%     if cbx26.Value == 1
%         cbx27.Visible = 'off';
%     end
%     
%     if cbx27.Value == 1
%         cbx26.Visible = 'off';
%     end
%     
%     %make a new matrix appropriate for table later
%     
%     
%     meanISI = cell(1,length(files));
%     
%     for i = 1:length(files)
%         selecteddata1=files(i).name;
%         meanISI{i} = load(selecteddata1,'T');
%         if cell2mat(meanISI{i}.T.meanISI(end)) == inf
%             meanISI{i} = meanISI{i}.T.meanISI(1);
%         else
%             meanISI{i} = meanISI{i}.T.meanISI(end);  %meanISI
%         end
%     end
%     
%     
%     
%     for i = 1:length(meanISI)
%         meanISI{i} = meanISI{i}{1};
%     end
%     
%     meanISI = cell2mat(meanISI);
%     
%     meanISI = meanISI';
%     
%     
%     InterSI = cell(1,length(files))';
%     for i = 1:length(files)
%         InterSI{i} = meanISI(i);
%     end
%     
%     
%     
%     
%     
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     InterISI = [];
%     InterISI.FileName = filenames;
%     InterISI.ISI = InterSI;
%     InterISI =struct2table(InterISI);
%     
%     
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(meanISI);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Time (s)')
%     title('InterSpike Interval (ISI)')
%     
%     
%     jjj = figure(2);
%     uitable('Data', InterISI{:,:},'ColumnName', InterISI.Properties.VariableNames,...
%         'RowName', InterISI.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
%     
%     
%     
%     
% end
% 
% 
% %% maximum amplitude of spikes
% 
% if cbx11.Value == 1
%     cbx28.Visible = 'on';
%     cbx29.Visible = 'on';
% else
%     cbx28.Visible = 'off';
%     cbx29.Visible = 'off';
% end
% 
% if cbx28.Value == 1
%     cbx29.Visible = 'off';
% end
% 
% if cbx28.Value == 1
%     cbx29.Visible = 'off';
% end
% 
% 
% if cbx11.Value == 1 && cbx28.Value == 1
%     %plot the mean maxmium amplitude of spikes
%     
%     
%     maxamp = cell(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         maxamp{i} = load(selecteddata1,'T');
%         if maxamp{i}.T.Units_per_second(end) == inf
%             maxamp{i} = maxamp{i}.T.Units_per_second(1);
%         else
%             maxamp{i} = mean(maxamp{i}.T.maxamplitude_in_volt(1:end-1)); %contains the 'raw' data
%         end
%     end
%     
%     %change nan values into zero's
%     for i = 1:length(maxamp)
%         if isnan(maxamp{i})
%             maxamp{i} = 0 ;
%         end
%     end
%     
%     maxamp = cell2mat(maxamp);
%     
%     
%     
%     meanmaxamp=[];
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanmaxamp(i) = mean(maxamp(divdate == temp(i)));
%         
%     end
%     
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semmaxamp(i) = std(maxamp(divdate == temp(i)))/sqrt(length(maxamp(divdate == temp(i))));
%         
%     end
%     clear temp
%     
%     jj = figure(1);
%     clf
%     movegui(jj,'west');
%     pp = bar(meanmaxamp);
%     
%     for k1 = 1:size(meanmaxamp,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semmaxamp,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Voltage (Microvolt)')
%     title('Mean Max amplitude of spikes')
%     
%     
%     
%     
%     maxamp(2,:) = maxamp;
%     maxamp(1,:) = divdate;
%     maxamp = table(maxamp);
%     maxamp.Properties.RowNames{1} = 'Groups';
%     maxamp.Properties.RowNames{2} = 'Data';
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',maxamp{:,:},'ColumnName',maxamp.Properties.VariableNames,...
%         'RowName',maxamp.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
%     
% elseif cbx11.Value == 1 && cbx29.Value == 1
%     %plot the median maximum amplitude of spikes
%     
%     
%     maxamp = cell(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         maxamp{i} = load(selecteddata1,'T');
%         if maxamp{i}.T.Units_per_second(end) == inf
%             maxamp{i} = maxamp{i}.T.Units_per_second(1);
%         else
%             maxamp{i} = mean(maxamp{i}.T.maxamplitude_in_volt(1:end-1)); %contains the 'raw' data
%         end
%     end
%     
%     %change nan values into zero's
%     for i = 1:length(maxamp)
%         if isnan(maxamp{i})
%             maxamp{i} = 0 ;
%         end
%     end
%     
%     maxamp = cell2mat(maxamp);
%     
%     
%     
%     medianmaxamp=[];
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         medianmaxamp(i) = median(maxamp(divdate == temp(i)));
%         
%     end
%     
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semmedianmaxamp(i) = 1.253*(std(maxamp(divdate == temp(i)))/sqrt(length(maxamp(divdate == temp(i)))));
%         
%     end
%     clear temp
%     
%     jj = figure(1);
%     clf
%     movegui(jj,'west');
%     pp = bar(medianmaxamp);
%     
%     for k1 = 1:size(medianmaxamp,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semmedianmaxamp,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Time (s)')
%     title('Median max amplitude of spikes')
%     
%     
%     
%     
%     maxamp(2,:) = maxamp;
%     maxamp(1,:) = divdate;
%     maxamp = table(maxamp);
%     maxamp.Properties.RowNames{1} = 'Groups';
%     maxamp.Properties.RowNames{2} = 'Data';
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',maxamp{:,:},'ColumnName',maxamp.Properties.VariableNames,...
%         'RowName',maxamp.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif flag == 1 && cbx11.Value == 1
%     
%     
%     if cbx11.Value == 1
%         cbx28.Visible = 'off';
%         cbx29.Visible = 'off';
%     else
%         cbx28.Visible = 'off';
%         cbx29.Visible = 'off';
%     end
%     
%     if cbx28.Value == 1
%         cbx29.Visible = 'off';
%     end
%     
%     if cbx28.Value == 1
%         cbx29.Visible = 'off';
%     end
%     
%     %make a new matrix appropriate for table later
%     
%     
%     
%     maxamp = cell(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         maxamp{i} = load(selecteddata1,'T');
%         if maxamp{i}.T.Units_per_second(end) == inf
%             maxamp{i} = maxamp{i}.T.Units_per_second(1);
%         else
%             maxamp{i} = mean(maxamp{i}.T.maxamplitude_in_volt(1:end-1)); %contains the 'raw' data
%         end
%     end
%     
%     %change nan values into zero's
%     for i = 1:length(maxamp)
%         if isnan(maxamp{i})
%             maxamp{i} = 0 ;
%         end
%     end
%     
%     maxamp = cell2mat(maxamp);
%     
%     maxamp = maxamp';
%     
%     
%     
%     
%     MaxAmp = cell(1,length(files))';
%     for i = 1:length(files)
%         MaxAmp{i} = maxamp(i);
%     end
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     MaxAmplitude = [];
%     MaxAmplitude.FileName = filenames;
%     MaxAmplitude.MaxAmplitude = MaxAmp;
%     MaxAmplitude =struct2table(MaxAmplitude);
%     
%     
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(maxamp);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Voltage (microVolt')
%     title('Max Amplitude of Spikes')
%     
%     
%     jjj = figure(2);
%     uitable('Data', MaxAmplitude{:,:},'ColumnName', MaxAmplitude.Properties.VariableNames,...
%         'RowName', MaxAmplitude.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
%     
% end
% 
% %% amount of bursts
% 
% if cbx12.Value == 1
%     cbx30.Visible = 'on';
%     cbx31.Visible = 'on';
% else
%     cbx30.Visible = 'off';
%     cbx31.Visible = 'off';
% end
% 
% if cbx30.Value == 1
%     cbx31.Visible = 'off';
% end
% 
% if cbx31.Value == 1
%     cbx30.Visible = 'off';
% end
% 
% 
% if cbx12.Value == 1 && cbx30.Value == 1
%     %plot the mean amount of bursts
%     
%     %make a new matrix appropriate for table later
%     burstN = [];
%     burstN(1,:) = divdate ;
%     
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             burstN(2,i) = 0 ;
%         else
%             burstN(2,i) = cell2mat(total16{i}(1)) ;
%         end
%     end
%     
%     
%     %plot the mean firing rate
%     meanburstN = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanburstN(i) = mean(burstN(2,divdate == temp(i)));
%     end
%     
%     semburstN = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semburstN(i) = std(burstN(2,divdate == temp(i)))/sqrt(length(burstN(divdate == temp(i))));
%     end
%     
%     jj = figure(1);
%     clf
%     pp = bar(meanburstN);
%     movegui(jj,'west');
%     for k1 = 1:size(meanburstN,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semburstN,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Burst Count (n)')
%     title('Mean Burst Amount ')
%     
%     burstNt=table(burstN);
%     burstNt.Properties.RowNames{1} = 'Groups';
%     burstNt.Properties.RowNames{2} = 'Data';
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',burstNt{:,:},'ColumnName',burstNt.Properties.VariableNames,...
%         'RowName',burstNt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
%     
% elseif cbx12.Value == 1 && cbx31.Value == 1
%     %plot the median amount of bursts
%     
%     %make a new matrix appropriate for table later
%     burstN = [];
%     burstN(1,:) = divdate ;
%     
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             burstN(2,i) = 0 ;
%         else
%             burstN(2,i) = cell2mat(total16{i}(1)) ;
%         end
%     end
%     
%     
%     %plot the mean firing rate
%     medianburstN = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         medianburstN(i) = median(burstN(2,divdate == temp(i)));
%     end
%     
%     semmedianburstN = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semmedianburstN(i) = 1.253*(std(burstN(2,divdate == temp(i)))/sqrt(length(burstN(divdate == temp(i)))));
%     end
%     
%     jj = figure(1);
%     clf
%     pp = bar(medianburstN);
%     movegui(jj,'west');
%     for k1 = 1:size(medianburstN,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semmedianburstN,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Burst Count (n)')
%     title('Median Burst Amount ')
%     
%     burstNt=table(burstN);
%     burstNt.Properties.RowNames{1} = 'Groups';
%     burstNt.Properties.RowNames{2} = 'Data';
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',burstNt{:,:},'ColumnName',burstNt.Properties.VariableNames,...
%         'RowName',burstNt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
% elseif flag == 1 && cbx12.Value == 1
%     
%     
%     if cbx12.Value == 1
%         cbx30.Visible = 'off';
%         cbx31.Visible = 'off';
%     else
%         cbx30.Visible = 'off';
%         cbx31.Visible = 'off';
%     end
%     
%     if cbx30.Value == 1
%         cbx31.Visible = 'off';
%     end
%     
%     if cbx31.Value == 1
%         cbx30.Visible = 'off';
%     end
%     
%     
%     %make a new matrix appropriate for table later
%     
%     burstN = cell(1,length(files))';
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             burstN{i} = 0 ;
%         else
%             burstN{i} = cell2mat(total16{i}(1)) ;
%         end
%     end
%     
%     
%     
%     
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     BurstCount = [];
%     BurstCount.FileName = filenames;
%     BurstCount.BurstCount = burstN;
%     BurstCount =struct2table(BurstCount);
%     
%     BurstCC = cell2mat(burstN);
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(BurstCC);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Burst Count (n)')
%     title('Burst Count')
%     
%     
%     jjj = figure(2);
%     uitable('Data', BurstCount{:,:},'ColumnName', BurstCount.Properties.VariableNames,...
%         'RowName', BurstCount.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
% end
% 
% 
% %% amount of network bursts
% 
% if cbx13.Value == 1
%     %plot the mean amount of network bursts
%     
%     % calculate network bursts
%     %two criteria's 80% of active channels have to be particiapting
%     %the bursts in the different channels have to occur within 100 ms
%     %lets just take the max interval detetced bursts
%     
%     networkburstt = zeros(1,length(files));
%     for pp=1:length(files)
%         selecteddata1=files(pp).name;
%         load(selecteddata1,'M2');
%         load(selecteddata1,'burst6');
%         
%         nn= 0 ;
%         for ll = 1:length(M2)
%             if isempty(M2{ll})
%                 nn = nn +1;
%             else
%             end
%         end
%         
%         activeelec = length(M2) - nn ;
%         %20% of active electrodes
%         
%         if activeelec < 10
%             reqactive = 120; % if the amount of active channle is lower than 10 channels than there can't be any network burst becasue there hould be atleast 2 elctrodes that contribute to it
%         else
%             reqactive = round(0.8*activeelec) ;
%         end
%         
%         %based on the max interval method
%         test=cell(1,length(burst6));
%         for oo =1:length(M2)
%             if isempty(burst6{oo})
%                 continue
%             else
%                 for j =1:length(burst6{oo})
%                     
%                     test{oo}(j) = burst6{oo}{j}(1) ;
%                 end
%             end
%         end
%         
%         test=test';
%         
%         %R = max value ,I is index of max value
%         [~,I]=max(cell2mat((cellfun(@length,test,'UniformOutput',0))));
%         
%         nn = 1;
%         networkburst = cell(1,length(burst6));
%         % fulll = cell(1,length(burst6));
%         %for m = 1:length(test)
%         for k = 1:length(test{I})
%             for jj = 1:length(test)
%                 if isempty(test{jj})
%                     continue
%                 else
%                     for i = 1:length(test{jj})
%                         if abs(test{I}(k) - test{jj}(i)) < 0.1
%                             
%                             networkburst{I}(k) = nn;
%                             networkburst{jj}(i) = nn;
%                         else
%                         end
%                     end
%                     
%                 end
%                 
%             end
%             nn = nn + 1;
%         end   %shortcut?
%         % fulll{m}=networkburst;
%         % networkburst = [];
%         % nn = 1;
%         % end
%         
%         % fulll = fulll'; % this cell contains all the checks for every channel with every hcannel to determine if there are network bursts with numbers assigned to them
%         
%         %now we need to combine all the network bursts that belong to each other
%         %check how many network bursts are present
%         
%         
%         nbursts = zeros(1,length(networkburst));
%         for ig= 1:length(networkburst)
%             if isempty(networkburst{ig})
%                 nbursts(ig) = 0;
%             else
%                 nbursts(ig) = max(networkburst{ig});
%             end
%         end
%         networkbursts = max(nbursts); % this the maximum amount of network bursts
%         
%         %now we need to check if the found networkbursts pass the 20% active
%         %electrodes requirement
%         %     networkburst = networkburst(~cellfun(@isempty,networkburst)); %remove all empty cells
%         %
%         %    for i =1:length(networkburst)
%         %        networkburst{i}(networkburst{i} == 0) = [];
%         %    end
%         %
%         testnetworkb = zeros(2,networkbursts);
%         for ie = 1 : networkbursts
%             nr_in_cell = cellfun(@(x) find(x==ie), networkburst, 'Uni',0);                 % Find OccurrencesIn Each Cell
%             total_occurrences = numel([nr_in_cell{:}]);                                 % Output Total Occurrences In All Cells
%             
%             testnetworkb(1,ie) = ie;
%             testnetworkb(2,ie) = total_occurrences;
%         end
%         % the networkburst has to have more than 20 occurences otherwise it is
%         % not valid this number is from spycode
%         for ill = 1:networkbursts
%             if testnetworkb(2,ill) < reqactive
%                 testnetworkb(:,ill) = 0;
%             end
%         end
%         
%         % remove all zeros
%         testnetworkb(testnetworkb == 0) =[];
%         
%         
%         %testnetworkb contains the amount of networkbursts !
%         networkburstt(pp) = size(testnetworkb,2);  % this contains the 'raw' data
%     end
%     
%     % now we need to average them according to the div days and calcaualte
%     % the SEM
%     
%     meannetworkburst=[];
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meannetworkburst(i) = mean(networkburstt(divdate == temp(i)));
%         
%     end
%     
%     semnetworkburst =[];
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semnetworkburst(i) = std(networkburstt(divdate == temp(i)))/sqrt(length(networkburstt(divdate == temp(i))));
%         
%     end
%     clear temp
%     
%     jj = figure(1);
%     clf
%     movegui(jj,'west');
%     pp = bar(meannetworkburst);
%     
%     for k1 = 1:size(meannetworkburst,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semnetworkburst,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('Amount of network bursts (n)')
%     title('Mean amount of network bursts')
%     
%     
%     
%     
%     networkburstt(2,:) = networkburstt;
%     
%     networkburstt(1,:) = divdate;
%     networkburstt = table(networkburstt);
%     networkburstt.Properties.RowNames{1} = 'Groups';
%     networkburstt.Properties.RowNames{2} = 'Data';
%     
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',networkburstt{:,:},'ColumnName',networkburstt.Properties.VariableNames,...
%         'RowName',networkburstt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
% end
% 
% %% Connections
% 
% if cbx14.Value == 1 && flag == 0
%     %plot the mean amount of connections
%     
%     %total13 contains the amount of connections
%     total13=cell(1,length(files));
%     
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         total13{i}=load(selecteddata1,'Connections');
%         total13{i}=total13{i}.Connections;
%     end
%     
%     
%     total13 = cell2mat(total13);
%     
%     
%     %plot the mean firing rate
%     meanconnections = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         meanconnections(i) = mean(total13(divdate == temp(i)));
%     end
%     
%     semconnections = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semconnections(i) = std(total13(divdate == temp(i)))/sqrt(length(total13(divdate == temp(i))));
%     end
%     
%     jj = figure(1);
%     clf
%     pp = bar(meanconnections);
%     movegui(jj,'west');
%     for k1 = 1:size(meanconnections,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semconnections,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('AMount of Connections(n)')
%     title('Mean Connections Amount ')
%     
%     connectionst = [];
%     connectionst(2,:) = total13;
%     connectionst(1,:) = divdate;
%     connectionst=table(connectionst);
%     connectionst.Properties.RowNames{1} = 'Groups';
%     connectionst.Properties.RowNames{2} = 'Data';
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',connectionst{:,:},'ColumnName',connectionst.Properties.VariableNames,...
%         'RowName',connectionst.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
% elseif flag == 1 && cbx14.Value == 1
%     
%     
%     
%     
%     %make a new matrix appropriate for table later
%     
%     total13=cell(1,length(files))';
%     
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         total13{i}=load(selecteddata1,'Connections');
%         total13{i}=total13{i}.Connections;
%     end
%     
%     
%     
%     Connections1 = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         Connections1{i} = cell2mat(total13(i));
%         
%     end
%     
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     Connextions = [];
%     Connextions.FileName = filenames;
%     Connextions.BurstCount = Connections1;
%     Connextions =struct2table(Connextions);
%     
%     
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(cell2mat(total13));
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Count (n)')
%     title('Functional Connections')
%     
%     
%     jjj = figure(2);
%     uitable('Data', Connextions{:,:},'ColumnName', Connextions.Properties.VariableNames,...
%         'RowName', Connextions.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
%     
%     
% end
% 
% %% CV of IBIs
% 
% if cbx15.Value == 1 && flag == 0
%     
%     %make a new matrix appropriate for table later
%     IBIT = [];
%     IBIT(1,:) = divdate ;
%     
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             IBIT(2,i) = 0 ;
%         else
%             IBIT(2,i) = cell2mat(total16{i}(7)) ;
%         end
%     end
%     
%     IBIT = cell(1,length(files));
%     for i =1:length(files)
%         selecteddata1=files(i).name;
%         IBIT{i} = load(selecteddata1,'Exburst');
%     end
%     
%     %first remove any empty structs
%     for j=1:length(IBIT)
%         for i =1:length(Exburst)
%             if isempty(IBIT{j}.Exburst{i}.number_of_bursts)
%                 IBIT{j}.Exburst{i} = [];
%             end
%         end
%     end
%     
%     %remove any empty cells
%     for i = 1:length(IBIT)
%         IBIT{i}.Exburst=IBIT{i}.Exburst(~cellfun('isempty',IBIT{i}.Exburst));
%     end
%     
%     for i=1:length(IBIT)
%         IBIT{i} = IBIT{i}.Exburst; % this contains the amount of channels that contain bursts per file
%     end
%     IBIT=IBIT';
%     
%     
%     
%     for i =1:length(IBIT)
%         for j=1:length(IBIT{i})
%             if isempty(IBIT{i})
%                 IBIT{i} = 0;
%             else
%                 IBIT{i}{j}=struct2cell(IBIT{i}{j});
%             end
%             
%         end
%     end
%     
%     %check to see if every if aligned in the same dimensions
%     for i =1:length(IBIT)
%         if isempty(IBIT{i})
%         else
%             for j =1:length(IBIT{i})
%                 if size(IBIT{i}{j}{4},1) == 1
%                     IBIT{i}{j}{4} = IBIT{i}{j}{4}';
%                 end
%             end
%         end
%     end
%     
%     % concatenated all the bursts together per file
%     for i =1:length(IBIT)
%         if isempty(IBIT{i})
%         elseif size(IBIT{i},1) == 1
%             IBIT{i} = IBIT{i}{1};
%         else
%             IBIT{i} = cellfun(@vertcat, IBIT{i}{:}, 'UniformOutput',false);
%         end
%     end
%     
%     % the 7th cell contains all the IBI's per file!
%     
%     for i =1:length(IBIT)
%         if isempty(IBIT{i})
%             continue
%         else
%             IBIT{i} = IBIT{i}{7};  %now we have all the IBIs!
%         end
%         
%     end
%     
%     %calculate the CV of IBIs by dividing the standard deviation of IBIs by
%     %the mean IBIs
%     
%     for i =1:length(IBIT)
%         if isempty(IBIT{i})
%             continue
%         else
%             IBIT{i} = std(IBIT{i}) / mean(IBIT{i}); % contains of the CV of IBIs! 'raw' data
%         end
%     end
%     
%     for i = 1:length(IBIT)
%         if isempty(IBIT{i})
%             IBIT{i} = 0;
%         end
%     end
%     
%     IBIT = cell2mat(IBIT);
%     
%     CVIBI = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         CVIBI(i) = mean(IBIT(divdate == temp(i)));  % mean
%     end
%     
%     
%     
%     semCVIBI = zeros(1,length(unique(divdate)));
%     
%     for i = 1:length(unique(divdate))
%         temp = unique(divdate);
%         semCVIBI(i) = std(IBIT(divdate == temp(i)))/sqrt(length(IBIT(divdate == temp(i))));
%     end
%     
%     jj = figure(1);
%     clf
%     pp = bar(CVIBI);
%     movegui(jj,'west');
%     for k1 = 1:size(CVIBI,1)
%         ctr(k1,:) = bsxfun(@plus, pp(1).XData, pp(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
%         ydt(k1,:) = pp(k1).YData;                                     % Individual Bar Heights
%     end
%     
%     clear temp
%     hold on
%     errorbar(ctr,ydt,semCVIBI,'.r')
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Groups');
%     ylabel('-')
%     title('Coefficient of IBIs')
%     
%     IBIT = IBIT';
%     CVIBITt = [];
%     CVIBITt(2,:) = IBIT;
%     CVIBITt(1,:) = divdate;
%     CVIBITt=table(CVIBITt);
%     CVIBITt.Properties.RowNames{1} = 'Groups';
%     CVIBITt.Properties.RowNames{2} = 'Data';
%     
%     jjj = figure(2);
%     movegui(jjj,'east');
%     uitable('Data',CVIBITt{:,:},'ColumnName',CVIBITt.Properties.VariableNames,...
%         'RowName',CVIBITt.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
% elseif flag == 1 && cbx15.Value == 1
%     
%     
%     
%     
%     %make a new matrix appropriate for table later
%     
%     IBIT = [];
%     
%     
%     for i = 1:length(total16)
%         if isempty(total16{i})
%             IBIT(2,i) = 0 ;
%         else
%             IBIT(2,i) = cell2mat(total16{i}(7)) ;
%         end
%     end
%     
%     IBIT = cell(1,length(files));
%     for i =1:length(files)
%         selecteddata1=files(i).name;
%         IBIT{i} = load(selecteddata1,'Exburst');
%     end
%     
%     %first remove any empty structs
%     for j=1:length(IBIT)
%         for i =1:length(Exburst)
%             if isempty(IBIT{j}.Exburst{i}.number_of_bursts)
%                 IBIT{j}.Exburst{i} = [];
%             end
%         end
%     end
%     
%     %remove any empty cells
%     for i = 1:length(IBIT)
%         IBIT{i}.Exburst=IBIT{i}.Exburst(~cellfun('isempty',IBIT{i}.Exburst));
%     end
%     
%     for i=1:length(IBIT)
%         IBIT{i} = IBIT{i}.Exburst; % this contains the amount of channels that contain bursts per file
%     end
%     IBIT=IBIT';
%     
%     
%     
%     for i =1:length(IBIT)
%         for j=1:length(IBIT{i})
%             if isempty(IBIT{i})
%                 IBIT{i} = 0;
%             else
%                 IBIT{i}{j}=struct2cell(IBIT{i}{j});
%             end
%             
%         end
%     end
%     
%     %check to see if every if aligned in the same dimensions
%     for i =1:length(IBIT)
%         if isempty(IBIT{i})
%         else
%             for j =1:length(IBIT{i})
%                 if size(IBIT{i}{j}{4},1) == 1
%                     IBIT{i}{j}{4} = IBIT{i}{j}{4}';
%                 end
%             end
%         end
%     end
%     
%     % concatenated all the bursts together per file
%     for i =1:length(IBIT)
%         if isempty(IBIT{i})
%         elseif size(IBIT{i},1) == 1
%             IBIT{i} = IBIT{i}{1};
%         else
%             IBIT{i} = cellfun(@vertcat, IBIT{i}{:}, 'UniformOutput',false);
%         end
%     end
%     
%     % the 7th cell contains all the IBI's per file!
%     
%     for i =1:length(IBIT)
%         if isempty(IBIT{i})
%             continue
%         else
%             IBIT{i} = IBIT{i}{7};  %now we have all the IBIs!
%         end
%         
%     end
%     
%     %calculate the CV of IBIs by dividing the standard deviation of IBIs by
%     %the mean IBIs
%     
%     for i =1:length(IBIT)
%         if isempty(IBIT{i})
%             continue
%         else
%             IBIT{i} = std(IBIT{i}) / mean(IBIT{i}); % contains of the CV of IBIs! 'raw' data
%         end
%     end
%     
%     for i = 1:length(IBIT)
%         if isempty(IBIT{i})
%             IBIT{i} = 0;
%         end
%     end
%     
%     IBITTT = cell2mat(IBIT);
%     
%     
%     
%     filenames = cell(1,length(files))';
%     
%     for i = 1:length(files)
%         
%         filenames{i} = files(i).name;
%     end
%     
%     InterBurstInterval = [];
%     InterBurstInterval.FileName = filenames;
%     InterBurstInterval.IBI = IBIT;
%     InterBurstInterval =struct2table(InterBurstInterval);
%     
%     
%     
%     jj = figure(1);
%     movegui(jj,'west');
%     clf
%     pp = bar(IBITTT);
%     pp.FaceColor = 'k';
%     set(gcf,'Color','white')
%     xlabel('Files');
%     ylabel('Time (s)')
%     title('CV of Inter Burst Intervals')
%     
%     
%     jjj = figure(2);
%     uitable('Data',InterBurstInterval{:,:},'ColumnName', InterBurstInterval.Properties.VariableNames,...
%         'RowName',InterBurstInterval.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
%     movegui(jjj,'east');
%     screen = get(0,'Screensize');
%     c = uicontrol;
%     c.Position = [(screen(3)*0.1),(screen(3)*0.45),175,67];
%     c.FontWeight = 'bold';
%     c.ForegroundColor = [0.861,0.832,0.096,0.048];
%     c.CData = imread('color_button.png');
%     c.String = 'Save Table';
%     c.Callback = @savetable;
%     
%     
%     
% end
%%     Get all Data
% if cbx32.Value == 1
    %get all the data in an excel file
    
    %test with fire rate and burst rate
    %files names are located in files.name
    MeanFiringRate= [];
    
    %get the filenames
    filenames = cell(1,length(files))';
    
    for i = 1:length(files)
        
        filenames{i} = files(i).name;
    end
    
    MeanFiringRate.FileName = filenames; 
   waitbar(0 + 0.15,hh,'Calculating the Endpoints');
%%    %Next Column
    
    ActiveElec = cell(1,length(files))';
    for i = 1:length(files)
        selecteddata1 = files(i).name;
        hehe{i} = load(selecteddata1,'M2');
        ActiveElec{i} =  length(find(~cellfun('isempty',hehe{i}.M2)));
    end
    
    MeanFiringRate.Active_Electrodes = ActiveElec;
    
    
    %now we add the second column which is the mean firing rate for each file
    MEANFIRINGRATE = cell(1,length(files));
    
    for i =1:length(files)
        MEANFIRINGRATE{i} = arrayfiringrate(i);
    end
    MEANFIRINGRATE = MEANFIRINGRATE';
    
    MeanFiringRate.Mean_FiringRate = MEANFIRINGRATE;  
    waitbar(0 + 0.20,hh,'Calculating the Endpoints');
%%    %Next column is std of the mean firing rate % (Maybe useful later?)
%     arrayfiringrate1 = cell(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         arrayfiringrate1{i} = load(selecteddata1,'T');
%         if arrayfiringrate1{i}.T.Fire_rate(end) == inf
%             arrayfiringrate1{i} = arrayfiringrate1{i}.T.Fire_rate(1);
%         else
%             arrayfiringrate1{i} = arrayfiringrate1{i}.T.Fire_rate(:);
%         end
%     end
%     
%     %remove the last number
%     
%     for i =1:length(arrayfiringrate1)
%         arrayfiringrate1{i}(end) = [];
%         arrayfiringrate1{i} = std(arrayfiringrate1{i});
%     end
%     
%     arrayfiringrate1 = arrayfiringrate1';
%     
%     
%     
%     MeanFiringRate.Std_FiringRate = arrayfiringrate1
%%    %Next Column is the Ratio between the Median ISI and the Mean ISI
    
    total30 = cell(1,length(files));
    total31 = cell(1,length(files));
    for i = 1:length(files)
        selecteddata1=files(i).name;
        total30{i} = load(selecteddata1,'T');
        if iscell(total30{i}.T.mean_ISI(end))
            if cell2mat(total30{i}.T.mean_ISI(end)) == inf
                total30{i} = total30{i}.T.mean_ISI(1);
            else
                total30{i} = total30{i}.T.mean_ISI(end);  %meanISI
            end
        else
             if total30{i}.T.mean_ISI(end) == inf
                total30{i} = total30{i}.T.mean_ISI(1);
            else
                total30{i} = total30{i}.T.mean_ISI(end);  %meanISI
            end
        end
    end
    
    for i = 1:length(files)
        selecteddata1=files(i).name;
        total31{i} = load(selecteddata1,'T');
        if total31{i}.T.median_ISI(end) == inf
            total31{i} = total31{i}.T.median_ISI(1);
        else
            total31{i} = total31{i}.T.median_ISI(end);   %medianISI
        end
    end
    
    
    
    
    for i = 1:length(total30)
        if iscell(total30{i})
            total30{i} = total30{i}{1};
        end
    end
    
    total30 = cell2mat(total30);
    total31 = cell2mat(total31);
    
    %now we get the ratio between the median and mean ISI
    
    for i = 1:length(total30)
        if total31(i) == 0
            continue
        else
            total31(i) = total31(i)/total30(i); %now we have the ratio
        end
    end
    total31 = total31';
    
    
    total311 = cell(1,length(files));
    
    for i =1:length(files)
        total311{i} = total31(i);
    end
    total311=total311';
    
    MeanFiringRate.Ratio_of_Median_ISI_over_Mean_ISI = total311;
    waitbar(0 + 0.25,hh,'Calculating the Endpoints');
%%    %Next Column is the Mean ISI
    
    meanISI = cell(1,length(files));
    
    for i = 1:length(files)
        selecteddata1=files(i).name;
        meanISI{i} = load(selecteddata1,'T');
        if iscell(meanISI{i}.T.mean_ISI(end))
            if cell2mat(meanISI{i}.T.mean_ISI(end)) == inf
                meanISI{i} = meanISI{i}.T.mean_ISI(1);
            else
                meanISI{i} = meanISI{i}.T.mean_ISI(end);  %meanISI
            end
        else
            if meanISI{i}.T.mean_ISI(end) == inf
                meanISI{i} = meanISI{i}.T.mean_ISI(1);
            else
                meanISI{i} = meanISI{i}.T.mean_ISI(end);  %meanISI
            end
        end
    end
    
    
    
    for i = 1:length(meanISI)
        if iscell(meanISI{i})
            meanISI{i} = meanISI{i}{1};
        end
    end
    
    meanISI = cell2mat(meanISI);
    
    
    meanISI = meanISI';
    
    meanISI1 = cell(1,length(files));
    for i = 1:length(files)
        
        meanISI1{i} = meanISI(i);
        
    end
    meanISI1 = meanISI1';
    
    MeanFiringRate.MeanISI = meanISI1;
    waitbar(0 + 0.3,hh,'Calculating the Endpoints');
%%    %Next column is the std of the ISI per well (maybe useful later)
    
    
%     stdISI = cell(1,length(files));
%     
%     for i = 1:length(files)
%         selecteddata1=files(i).name;
%         stdISI{i} = load(selecteddata1,'T');
%         if iscell(stdISI{i}.T.std_ISI(end))
%             if cell2mat(stdISI{i}.T.std_ISI(end)) == inf
%                 stdISI{i} = stdISI{i}.T.std_ISI(1);
%             else
%                 stdISI{i} = stdISI{i}.T.std_ISI(end);  %meanISI
%             end
%         else
%             if stdISI{i}.T.std_ISI(end) == inf
%                 stdISI{i} = stdISI{i}.T.std_ISI(1);
%             else
%                 stdISI{i} = stdISI{i}.T.std_ISI(end);  %meanISI
%             end
%         end
%     end
%     
%     
%     
%     for i = 1:length(stdISI)
%         if iscell(stdISI{i})
%             stdISI{i} = stdISI{i}{1};
%         end
%     end
%     
%     stdISI = cell2mat(stdISI);
%     
%     
%     stdISI = stdISI';
%     
%     stdISI1 = cell(1,length(files));
%     for i = 1:length(files)
%         
%         stdISI1{i} = stdISI(i);
%         
%     end
%     stdISI1 = stdISI1';
%     
%     MeanFiringRate.StdISI = stdISI1;
%%    %Next Column is the CV of ISIs
    
    
    total19= cell(1,length(files));
    for i=1:length(files)
        selecteddata1=files(i).name;
        total19{i}=load(selecteddata1,'T');
        if total19{i}.T.Fire_rate(end) == inf
            total19{i} = total19{i}.T.mean_CV_ISI(1);
        else
            total19{i} = total19{i}.T.mean_CV_ISI(end);   % contains the 'raw' data
        end
    end
    
    
    total19 = total19';
    
    MeanFiringRate.MeanCoefficientOfVariation_of_ISI = total19;
    waitbar(0 + 0.35,hh,'Calculating the Endpoints');
%%    %Next column is the maximum aplitude of spikes(maybe useful later?) 
    %( not useful since we detect spikes on both sides and sometimes you only have negative
    %spikes and a zero might give a worng impression
    
%     
%     maxamp = cell(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         maxamp{i} = load(selecteddata1,'T');
%         if maxamp{i}.T.Units_per_second(end) == inf
%             maxamp{i} = maxamp{i}.T.Units_per_second(1);
%         else
%             maxamp{i} = mean(maxamp{i}.T.maxamplitude_in_volt(1:end-1)); %contains the 'raw' data
%         end
%     end
%     
%     %change nan values into zero's
%     for i = 1:length(maxamp)
%         if isnan(maxamp{i})
%             maxamp{i} = 0 ;
%         end
%     end
%     
%     
%     maxamp=maxamp';
%     MeanFiringRate.Mean_Max_Amplitude_Spikes = maxamp;
    
    
    % Next column is the burstiness index ( Not useful anymore sicne we actualy do burst detection)
%     
%     Burstiness1 = cell(1,length(files))';
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         Burstiness{i} = load(selecteddata1,'BI');
%         Burstiness1{i} = Burstiness{i}.BI{:,:};
%     end
%     
%     
%         MeanFiringRate.Burstiness_Index = Burstiness1;
%%    %Next column is the burst rate(bursts/min) per file

    Burst_Count= cell(1,length(files));
    
    
    for i =1:length(files)
        if isempty(total16{i})
            Burst_Count{i} = 0;
        else
            Burst_Count{i} = cell2mat(total16{i}(1));
        end
    end
    % timesss is in seconds
    timesssminutes = timesss/60; 
    
    Burst_Count=Burst_Count';
    Burst_Count = cell2mat(Burst_Count)/timesssminutes;
    Burst_Count = num2cell(Burst_Count);
    
    MeanFiringRate.MeanBurstRate = Burst_Count;
    waitbar(0 + 0.40,hh,'Calculating the Endpoints');
%%    %Next Column is the mean spike frequency in bursts /std
    
    %we have to get the  from the original struct that
    %contains the detected bursts which is exburst
    
    meanspikefreqbursts = cell(1,length(files))';
    stdspikefreqbursts = cell(1,length(files))';
    for jj = 1:length(files)
        selecteddata1=files(jj).name;
        load(selecteddata1,'Exburst');
        %first we need to get rid of the empty structs
        meanspikefreqb = cell(1,length(Exburst))';
        for i = 1:length(Exburst)
            if isempty(Exburst{i}.number_of_bursts)
                meanspikefreqb{i} = [];
            else
                meanspikefreqb{i} = Exburst{i}.fr_of_bursts;
                
            end
            
        end
        
        meanspikefreqbursts{jj} = (meanspikefreqb(~cellfun('isempty',meanspikefreqb))); % this vector contains the std of the burst durations of the whole well
%         stdspikefreqbursts{jj} = (meanspikefreqb(~cellfun('isempty',meanspikefreqb)));
        %check if the vectors inside are in the same dimensions
        for ii = 1:length(meanspikefreqbursts{jj})
            if size(meanspikefreqbursts{jj}{ii},2) == 1
            else
                meanspikefreqbursts{jj}{ii} = meanspikefreqbursts{jj}{ii}';
%                 stdspikefreqbursts{jj}{ii} = stdspikefreqbursts{jj}{ii}';
            end
        end
        meanspikefreqbursts{jj} = mean(cell2mat(meanspikefreqbursts{jj}));
%         stdspikefreqbursts{jj} = std(cell2mat(stdspikefreqbursts{jj})); % this vector contains the std of the burst durations of the whole well
        
    end
    
    MeanFiringRate.Mean_Spike_Freq_in_Bursts = meanspikefreqbursts;
    waitbar(0 + 0.45,hh,'Calculating the Endpoints');
%     MeanFiringRate.Std_Spike_Freq_in_Bursts = stdspikefreqbursts;
%%    %Next Column is the MAD or the mean asbolute deviation of the spikes
    % in the burst
    
    % MAD = sum of abs(data values - mean)/ number of values
    
    MADnum = cell(1,length(files));
    for i =1:length(files)
        selecteddata1 = files(i).name;
        MADnum{i} = load(selecteddata1,'Exburst');
    end
    MADnum = MADnum';
    
    MAD = cell(1,length(files))';
    for i = 1:length(files)
        MAD{i} = cell(1,length(Exburst))';
    end

    for i = 1:length(files)
        for j = 1:length(MADnum{i}.Exburst)
            if isempty(MADnum{i}.Exburst{j}.number_of_bursts)
                continue
            else
                MAD{i}{j} = MADnum{i}.Exburst{j}.spikes_in_bursts; %first column that contains the data values
                %                  MAD{i}{j}(j,2) = mean(MAD{i}{j}); % first number in column two contains the mean
                MAD{i}{j} = abs(MAD{i}{j} - mean(MAD{i}{j}));
                MAD{i}{j} = sum(MAD{i}{j}) / length(MAD{i}{j}); % contains the MAD number of spikes in bursts per channel
          
            end
        end
    end
    
    
    MAD1 = cell(1,length(files))';
    for i = 1:length(files)
        MAD1{i} = mean(cell2mat(MAD{i}));
    end
    
     MeanFiringRate.MAD_Spikes_in_Bursts = MAD1;
     waitbar(0 + 0.5,hh,'Calculating the Endpoints');
%%    %Next Column is the Percentage of Spikes that are not part of Bursts
    
    
    total18= cell(1,length(files));
    for i=1:length(files)
        selecteddata1=files(i).name;
        total18{i}=load(selecteddata1,'Exburst');
    end
    total18=total18';
    
%     try total18.Exburst
%     catch error1
%         if isempty(error1)
%         else
%             total18=total18{1};
%         end
%     end
    
    
    
    perspikesburst2=cell(1,length(total17));
    perspikesbursts=zeros(1,length(M2));
    for k = 1:length(total18)
        for i=1:length(total18{k}.Exburst)
            if isempty(total18{k}.Exburst{i}.number_of_bursts)
                perspikesbursts(i) = 0;
            else
                perspikesbursts(i) = ((sum(total18{k}.Exburst{i}.spikes_in_bursts))/size(total17{k}.M2{i},2))*100';   % the cell array contains the amount of spikes that are part of a burst per channel
                perspikesbursts(perspikesbursts == 0)=[];    %remove all zeros
                if length(perspikesbursts) == 1 %if there is only one values it means that there is only one hcannel with bursts so don't do anything
                else
                    perspikesbursts = mean(perspikesbursts);
                end
                
                perspikesburst2{k} = perspikesbursts; % contains the 'raw' data
            end
        end
    end
    
    for i = 1:length(perspikesburst2)
        if isempty(perspikesburst2{i})
            perspikesburst2{i} = 0;
        end
    end
    
    
    perspikesburst2 = perspikesburst2';
    
    for i = 1:length(perspikesburst2)
        perspikesburst2{i} = 100 - perspikesburst2{i};
    end
    
    
    MeanFiringRate.Mean_Isolated_Spikes = perspikesburst2;
    waitbar(0 + 0.55,hh,'Calculating the Endpoints');
%%    %Next Column is the Burst Duration
    
    
    BurstDuration= cell(1,length(files));
    
    
    for i =1:length(files)
        if isempty(total16{i})
            BurstDuration{i} = 0;
        else
            BurstDuration{i} = cell2mat(total16{i}(2));
        end
    end
    
    BurstDuration = BurstDuration';
    
    MeanFiringRate.MeanBurstDuration = BurstDuration;
    
    
    
%     
%     %Next column is the std of the burst duration
%     %we have to get the burst durations from the original struct that
%     %contains the detected bursts which is exburst
%     
%     stdburstdur = cell(1,length(files))';
%     for jj = 1:length(files)
%         selecteddata1=files(jj).name;
%         load(selecteddata1,'Exburst');
%         %first we need to get rid of the empty structs
%         STDburstdur = cell(1,length(Exburst))';
%         for i = 1:length(Exburst)
%             if isempty(Exburst{i}.number_of_bursts)
%                 STDburstdur{i} = [];
%             else
%                 STDburstdur{i} = Exburst{i}.duration_of_bursts;
%                 
%             end
%             
%         end
%         
%         stdburstdur{jj} = std(cell2mat(STDburstdur(~cellfun('isempty',STDburstdur)))); % this vector contains the std of the burst durations of the whole well
%         
%         
%         
%     end
%     
%     MeanFiringRate.StdBurstDuration = stdburstdur;
waitbar(0 + 0.6,hh,'Calculating the Endpoints');
%%    %Next Column is the interBurst Interval
    
    
    
    InterBurst_Interval= cell(1,length(files));
    
    
    for i =1:length(files)
        if isempty(total16{i})
            InterBurst_Interval{i} = 0;
        else
            InterBurst_Interval{i} = cell2mat(total16{i}(7));
        end
    end
    
    InterBurst_Interval=InterBurst_Interval';
    
    MeanFiringRate.MeanInterBurst_Interval = InterBurst_Interval;
    waitbar(0 + 0.65,hh,'Calculating the Endpoints');
%%    %Next Column is the CV of IBIs
    
    IBIT = [];
    
    
    
    for i = 1:length(total16)
        if isempty(total16{i})
            IBIT(2,i) = 0 ;
        else
            IBIT(2,i) = cell2mat(total16{i}(7)) ;
        end
    end
    
    IBIT = cell(1,length(files));
    for i =1:length(files)
        selecteddata1=files(i).name;
        IBIT{i} = load(selecteddata1,'Exburst');
    end
    
    %first remove any empty structs
    for j=1:length(IBIT)
        for i =1:length(IBIT{j}.Exburst)
            if isempty(IBIT{j}.Exburst{i}.number_of_bursts)
                if isempty(IBIT{j}.Exburst{i})
                else
                    IBIT{j}.Exburst{i} = [];
                end
            end
        end
    end
    
    %remove any empty cells
    for i = 1:length(IBIT)
        IBIT{i}.Exburst=IBIT{i}.Exburst(~cellfun('isempty',IBIT{i}.Exburst));
    end
    
    for i=1:length(IBIT)
        IBIT{i} = IBIT{i}.Exburst; % this contains the amount of channels that contain bursts per file
    end
    IBIT=IBIT';
    
    
    
    for i =1:length(IBIT)
        for j=1:length(IBIT{i})
            if isempty(IBIT{i})
                IBIT{i} = 0;
            else
                IBIT{i}{j}=struct2cell(IBIT{i}{j});
            end
            
        end
    end
    
    %check to see if every if aligned in the same dimensions
    for i =1:length(IBIT)
        if isempty(IBIT{i})
        else
            for j =1:length(IBIT{i})
                if size(IBIT{i}{j}{4},1) == 1
                    IBIT{i}{j}{4} = IBIT{i}{j}{4}';
                end
            end
        end
    end
    
    % concatenated all the bursts together per file
    for i =1:length(IBIT)
        if isempty(IBIT{i})
        elseif size(IBIT{i},1) == 1
            IBIT{i} = IBIT{i}{1};
        else
            IBIT{i} = cellfun(@vertcat, IBIT{i}{:}, 'UniformOutput',false);
        end
    end
    
    % the 7th cell contains all the IBI's per file!
    
    for i =1:length(IBIT)
        if isempty(IBIT{i})
            continue
        else
            IBIT{i} = IBIT{i}{7};  %now we have all the IBIs!
        end
        
    end
    
    %calculate the CV of IBIs by dividing the standard deviation of IBIs by
    %the mean IBIs
    
    for i =1:length(IBIT)
        if isempty(IBIT{i})
            continue
        else
            IBIT{i} = std(IBIT{i}) / mean(IBIT{i}); % contains of the CV of IBIs! 'raw' data
        end
    end
    
    for i = 1:length(IBIT)
        if isempty(IBIT{i})
            IBIT{i} = 0;
        end
    end

    MeanFiringRate.Mean_CoefficientOfVariation_InterBurst_Interval = IBIT;
    
    waitbar(0 + 0.70,hh,'Calculating the Endpoints');
%%    %Next column is the amount of network bursts
    
    
    networkburstttttt = cell(1,length(files))';
    for pp=1:length(files)
        selecteddata1=files(pp).name;
        load(selecteddata1,'networkburstttt');
        
        %find the correct indexes
     
        networkburstttttt{pp} = networkburstttt.amount;
        
    end
    
    MeanFiringRate.Mean_NetworkBursts= networkburstttttt;
    waitbar(0 + 0.75,hh,'Calculating the Endpoints');
%%    %next Column is the amount of networkburstsrate (maybe useful later?)
        
%     networkburstrate = cell(1,length(files))';
%     for i = 1:length(files)
%         
%         selecteddata1 = files(i).name;
%         load(selecteddata1,'networkburstttt');
%         networkburstrate{i} = networkburstttt.nburst_rate;
%     end
%     
%     MeanFiringRate.Mean_NetworkBursts_Duration= networkburstrate;
%%    %next Column is the amount of networkburstsduration
    

    networkburstduration = cell(1,length(files))';
    for i = 1:length(files)
        
        selecteddata1 = files(i).name;
        load(selecteddata1,'networkburstttt');
        networkburstduration{i} = mean(networkburstttt.duration);
    end
    
    MeanFiringRate.Mean_NetworkBursts_Duration= networkburstduration;   
    waitbar(0 + 0.8,hh,'Calculating the Endpoints');
%%    %next Column is the amount of networkburstsfirerate
        
    networkburstfirerate = cell(1,length(files))';
    for i = 1:length(files)
        
        selecteddata1 = files(i).name;
        load(selecteddata1,'networkburstttt');
        networkburstfirerate{i} = mean(networkburstttt.spikesfr_in_nbursts);
    end
    
    MeanFiringRate.Mean_NetworkBursts_Fire_Rate_Spikes= networkburstfirerate;     
%%    %next Column is the amount of networkburstsISI
        
    networkburstISI = cell(1,length(files))';
    for i = 1:length(files)
        
        selecteddata1 = files(i).name;
        load(selecteddata1,'networkburstttt');
        networkburstISI{i} = mean(networkburstttt.ISI);
    end
    
    MeanFiringRate.Mean_NetworkBursts_ISI= networkburstISI;   
%%    %next Column is the amount of networkburstsIBI
        
    networkburstIBI = cell(1,length(files))';
    for i = 1:length(files)
        
        selecteddata1 = files(i).name;
        load(selecteddata1,'networkburstttt');
        networkburstIBI{i} = mean(networkburstttt.IBI);
    end
    
    MeanFiringRate.Mean_NetworkBursts_IBI= networkburstIBI;       
%%    %next is CV of IBI nnbursts
        networkburstCVIBI = cell(1,length(files))';
    for i = 1:length(files)
        
        selecteddata1 = files(i).name;
        load(selecteddata1,'networkburstttt');
        networkburstCVIBI{i} = mean(networkburstttt.CVIBI);
    end
    
    MeanFiringRate.Mean_NetworkBursts_CVIBI= networkburstCVIBI;       
%%    %fourteenth column is the amount of functional connections
    
    
    
    total13=cell(1,length(files));
    
    for i=1:length(files)
        selecteddata1=files(i).name;
        total13{i}=load(selecteddata1,'Connections');
        total13{i}=total13{i}.Connections;
    end
    
    
    %     total13 = cell2mat(total13);
    total13 = total13';
    
    MeanFiringRate.Mean_Amount_of_Connections = total13;   
    waitbar(0 + 0.85,hh,'Calculating the Endpoints');
%%    %Next Column is synchronicity
    synchronicity = zeros(1,length(files));
%     for i=1:length(files)
%         selecteddata1=files(i).name;
%         
%         load(selecteddata1,'supa');
%         %
%         supa1 = supa; 
% 
%         for p=1:length(supa1)
%             if isempty(supa1{p})
%                 continue
%             end
%             M = max(supa1{p}(:));          %depict the cross correaltion in percentages
%             supa1{p}=supa1{p}/M;
%         end
%         
%         
%       
%         %use fwhm to calculate the full width at half height of the peaks
%         
%         xv=1:301;
%         synccc = cell(1,length(supa1));
%         syncc1 = [];
%         for iii = 1:length(supa1)
%             if isempty(supa1{iii})
%                 continue
%             else
%                 for j = 1:length(supa1)
%                     if max(supa1{iii}(j,:)) < 0.7
%                         syncc = 0;
%                     else
%                         try
%                             syncc = fwhm(xv,supa1{iii}(j,:));
%                         catch ME
%                             if exist('ME','var')
%                                 syncc = 0;
%                                 clear ME
%                             end
%                         end
%                     end
%                     syncc1 = [syncc1,syncc];
%                 end
%                 synccc{iii} = syncc1;
%                 syncc1 = [];
%             end
%         end
%         
%         
%         %remove all the zeros
%         
%         for iiii =1:length(supa1)
%             if isempty(synccc{iiii})
%                 continue
%             else
%                 synccc{iiii}(synccc{iiii} == 0) =[];
%             end
%         end
%         
%         synccc = synccc(~cellfun('isempty',synccc));
%         
%         
%         clear syncc1 syncc
%         %now we get the average
%         
%         
%         for p =1:length(synccc)
%             synccc{p} = mean(synccc{p});
%         end
%         synccc= synccc';
%         synccc=cell2mat(synccc);
%         %array wide mean
%         synccc = mean(synccc);
%         if isnan(synccc) || synccc == 0
%             synchronicity(i) = 0;
%         else
%             synchronicity(i) = synccc;
%         end
%     end
    %Refer to Kreuz et al papers or cyspike (The lower the number the more
    %synchronous it is
    
    for i=1:length(files)
        selecteddata1=files(i).name;
        load(selecteddata1,'M2');
        load(selecteddata1,'timesss');
        M3=M2';
        M3=M3(~cellfun('isempty',M3)); %remove empty cells
        if length(M3) == 1
            synchronicity(i) = 0;
            continue
            
        end
        STS = SpikeTrainSet(M3,0,timesss);
        synchronicity(i) = STS.AdaptiveISIdistance();
    end

    syncha = cell(1,length(files))';
    for i = 1:length(files)
        syncha{i} = synchronicity(i);
    end
    
    
    MeanFiringRate.Synchronicity = syncha;
    clear M2 M3   
%%    %implement checks to determine if the variables are not in cell format!
    
    if iscell(MeanFiringRate.Mean_FiringRate)
        for i = 1:length(arrayfiringrate)
            MeanFiringRate.Mean_FiringRate{i} = cell2mat(MeanFiringRate.Mean_FiringRate{i});
            
            
        end
        
    end
%%    we need to sort the order of the files in the natural order
    [~,dnx,~]= natsort(MeanFiringRate.FileName);
    
    fields=fieldnames(MeanFiringRate);
    for categoryidx=1:length(fields)
        categoryname=fields{categoryidx};
        MeanFiringRate.(categoryname)=MeanFiringRate.(categoryname)(dnx);
    end
    waitbar(0 + 0.9,hh,'Calculating the Endpoints');
    close(hh)
    %%    Take the average of each endpoints based on the files that belong to each other (multiwell)
    
    if multiwell1 == 1
        
        message1=sprintf('Multiwell Data Detected. Do you want to group wells together and calculate the Mean + SEM values of these groups?');
        button = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');
        if isempty(button)
            return
        end
        
        if strcmpi(button, 'Continue')
            
            message1=sprintf('Warning! The groups will be made under the assumption that each group has the same amount of wells (Example: There are 4 groups in a 24 multiwell. Then the wells will be grouped as such, wells (1-6)(7-12)(13-18)(19-24))');
            button2 = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');
            if strcmpi(button2,'Continue')
                
                prompt = {'How many groups are there?'};
                title = 'Grouping Wells together';
                dims = [1 50];
                definput = {'1'};
                groups = inputdlg(prompt,title,dims,definput);  % we will have to ask the user how many groups there are with the assumption that each group has to the same wells
                groups= str2double(cell2mat(groups));
                
                if isnan(groups)
                    return
                end
                
           
                correctgroup1 = multiwell_grouping(groups);
                
                for i = 1:length(correctgroup1)
                    correctgroup1{i} = str2num(correctgroup1{i});
                end
                
                %check all the characters before the _Well_ was added by
                %the analysis.
                %the date so we will average all the files that are taken on the same
                %date (will have to implement a option to turn this off later)
                % so first we need to find how many files there are.
                strings1 = cell(1,length(MeanFiringRate.FileName))';
                for i = 1:length(MeanFiringRate.FileName)
                    strings1{i} = MeanFiringRate.FileName{i}(1:(strfind(MeanFiringRate.FileName{1},'_Well_')-1));
                end
                
                filenumber = unique(strings1,'rows');
                
                % now we have how many files there are we need to find the indices which wells
                % belong to each other
                % these are the groups
                
                for i = 1:length(filenumber)
                    wellcount(i) = sum(contains(MeanFiringRate.FileName,filenumber{i})); % now we have the total well amount for each file
                end
                
                
                % we will have to ask the user how many wells belong to the same group
              % we will assume that alle the files in the folder have the
              % same orginatizon when it comes to which wells belong to
              % which group
                
                correctgroup1 =correctgroup1';
                
                for i = 1:length(filenumber)
                    correctgroups{i} = correctgroup1;
                end
                
                
              % the correctgroups now has the correct indices for naming
              % the files however it does not have the correct indices for
              % getting the data from MeanFiringrate
            
                correctnames = {};
                
                for i = 1:length(filenumber)
                    for j = 1:groups
                        correctnames{i}{j} = MeanFiringRate.FileName(i*wellcount(i));
                        correctnames{i}{j} = strrep(correctnames{i}{j},['_Well_',mat2str(wellcount(i)),'.'],['_Wells_',mat2str(cell2mat(correctgroups{1}(j))),'.']);
                        
                    end
                end
                
                
                
                % now we get the correct indices for extarting the data
                % from MeanFiringRate
                
                correctgroups ={};
                
                for i = 1:length(filenumber)
                    wells= wellcount(i)/groups ; % each groups contains this amount of wells
                    for j = 1:groups
                        if i == 1
                            correctgroups{i}{j} = (j*wells-wells+1):(j*wells);
                        else
                            correctgroups{i}{j} = ((j*wells-wells+1):(j*wells)) + (i-1)*wellcount(i); % now we have the correct well numbers that belong to each group
                        end
                    end
                end
                
                
                
                
                
                
                % new struct to store the new mean values and SEM values
                
                averageddata= [];
                
                for i = 1:length(filenumber)
                    for j = 1:groups
                        averageddata.FileName{i} = correctnames{i};
                        averageddata.Active_Electrodes{i}{j} = MeanFiringRate.Active_Electrodes(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_FiringRate{i}{j} = MeanFiringRate.Mean_FiringRate(cell2mat(correctgroups{i}(j)));
                        averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j} = MeanFiringRate.Ratio_of_Median_ISI_over_Mean_ISI(cell2mat(correctgroups{i}(j)));
                        averageddata.MeanISI{i}{j} = MeanFiringRate.MeanISI(cell2mat(correctgroups{i}(j)));
                        averageddata.MeanCoefficientOfVariation_of_ISI{i}{j} = MeanFiringRate.MeanCoefficientOfVariation_of_ISI(cell2mat(correctgroups{i}(j)));
                        averageddata.MeanBurstRate{i}{j} = MeanFiringRate.MeanBurstRate(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_Spike_Freq_in_Bursts{i}{j} = MeanFiringRate.Mean_Spike_Freq_in_Bursts(cell2mat(correctgroups{i}(j)));
                        averageddata.MAD_Spikes_in_Bursts{i}{j} = MeanFiringRate.MAD_Spikes_in_Bursts(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_Isolated_Spikes{i}{j} = MeanFiringRate.Mean_Isolated_Spikes(cell2mat(correctgroups{i}(j)));
                        averageddata.MeanBurstDuration{i}{j} = MeanFiringRate.MeanBurstDuration(cell2mat(correctgroups{i}(j)));
                        averageddata.MeanInterBurst_Interval{i}{j} = MeanFiringRate.MeanInterBurst_Interval(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j} = MeanFiringRate.Mean_CoefficientOfVariation_InterBurst_Interval(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_NetworkBursts{i}{j} = MeanFiringRate.Mean_NetworkBursts(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_NetworkBursts_Duration{i}{j} = MeanFiringRate.Mean_NetworkBursts_Duration(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j} = MeanFiringRate.Mean_NetworkBursts_Fire_Rate_Spikes(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_NetworkBursts_ISI{i}{j} = MeanFiringRate.Mean_NetworkBursts_ISI(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_NetworkBursts_IBI{i}{j} = MeanFiringRate.Mean_NetworkBursts_IBI(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_NetworkBursts_CVIBI{i}{j} = MeanFiringRate.Mean_NetworkBursts_CVIBI(cell2mat(correctgroups{i}(j)));
                        averageddata.Mean_Amount_of_Connections{i}{j} = MeanFiringRate.Mean_Amount_of_Connections(cell2mat(correctgroups{i}(j)));
                        averageddata.Synchronicity{i}{j} = MeanFiringRate.Synchronicity(cell2mat(correctgroups{i}(j)));
                    end
                end
                % now we have all the correct files together with the correct values
                % the next step is to remove all the wells that were not active
                indices ={};
                for i = 1:length(filenumber)
                    for j = 1:groups
                        indices{i}{j} = find(cell2mat(averageddata.Active_Electrodes{i}{j})== 0); % now we have the indices that we have to remove and fater we can calculate the mean and SEM values
                    end
                end
                
                %now we remove the inactive wells
                for i = 1:length(filenumber)
                    for j = 1:groups
                        if isempty(indices{i}{j})
                            continue
                        else
                            averageddata.Active_Electrodes{i}{j}(indices{i}{j}) = [];
                            averageddata.Mean_FiringRate{i}{j}(indices{i}{j}) = [];
                            averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j}(indices{i}{j}) = [];
                            averageddata.MeanISI{i}{j}(indices{i}{j}) = [];
                            averageddata.MeanCoefficientOfVariation_of_ISI{i}{j}(indices{i}{j})= [];
                            averageddata.MeanBurstRate{i}{j}(indices{i}{j}) =[];
                            averageddata.Mean_Spike_Freq_in_Bursts{i}{j}(indices{i}{j}) = [];
                            averageddata.MAD_Spikes_in_Bursts{i}{j}(indices{i}{j}) =[];
                            averageddata.Mean_Isolated_Spikes{i}{j}(indices{i}{j}) = [];
                            averageddata.MeanBurstDuration{i}{j}(indices{i}{j}) = [];
                            averageddata.MeanInterBurst_Interval{i}{j}(indices{i}{j}) = [];
                            averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j}(indices{i}{j}) = [];
                            averageddata.Mean_NetworkBursts{i}{j}(indices{i}{j}) = [];
                            averageddata.Mean_NetworkBursts_Duration{i}{j}(indices{i}{j}) = [];
                            averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j}(indices{i}{j}) = [];
                            averageddata.Mean_NetworkBursts_ISI{i}{j}(indices{i}{j}) = [];
                            averageddata.Mean_NetworkBursts_IBI{i}{j}(indices{i}{j}) = [];
                            averageddata.Mean_NetworkBursts_CVIBI{i}{j}(indices{i}{j}) = [];
                            averageddata.Mean_Amount_of_Connections{i}{j}(indices{i}{j}) = [];
                            averageddata.Synchronicity{i}{j}(indices{i}{j}) = [];
                        end
                        
                    end
                end
                
                
                % the next step is to average and calculate the SEM values of each endpoint
                % and organize it correctly
                for i = 1:length(filenumber)
                    for j= 1:groups
                        tempmean = nanmean(cell2mat(averageddata.Active_Electrodes{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Active_Electrodes{i}{j}))/sqrt(length(cell2mat(averageddata.Active_Electrodes{i}{j})));
                        tempN = length(cell2mat(averageddata.Active_Electrodes{i}{j}));
                        averageddata.Active_Electrodes{i}{j} = [];
                        averageddata.Active_Electrodes{i}{j}{1} = tempmean;
                        averageddata.Active_Electrodes{i}{j}{2,1} = tempsem;
                        averageddata.Active_Electrodes{i}{j}{3,1} = tempN;
                        
                        averageddata.FileName{i}{j}{1} = strrep(averageddata.FileName{i}{j}{1},'.mat','(Mean)');
                        averageddata.FileName{i}{j}{2,1} = averageddata.FileName{i}{j}{1};
                        averageddata.FileName{i}{j}{2,1} = strrep(averageddata.FileName{i}{j}{2,1},'(Mean)','(SEM)');
                        averageddata.FileName{i}{j}{3,1} = 'N';
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_FiringRate{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_FiringRate{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_FiringRate{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_FiringRate{i}{j}));
                        averageddata.Mean_FiringRate{i}{j} = [];
                        averageddata.Mean_FiringRate{i}{j}{1} = tempmean;
                        averageddata.Mean_FiringRate{i}{j}{2,1} = tempsem;
                        averageddata.Mean_FiringRate{i}{j}{3,1} = tempN;
                        
                        
                        tempmean = nanmean(cell2mat(averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j}))/sqrt(length(cell2mat(averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j})));
                        tempN = length(cell2mat(averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j}));
                        averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j} = [];
                        averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j}{1} = tempmean;
                        averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j}{2,1} = tempsem;
                        averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.MeanISI{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.MeanISI{i}{j}))/sqrt(length(cell2mat(averageddata.MeanISI{i}{j})));
                        tempN = length(cell2mat(averageddata.MeanISI{i}{j}));
                        averageddata.MeanISI{i}{j} = [];
                        averageddata.MeanISI{i}{j}{1} = tempmean;
                        averageddata.MeanISI{i}{j}{2,1} = tempsem;
                        averageddata.MeanISI{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.MeanCoefficientOfVariation_of_ISI{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.MeanCoefficientOfVariation_of_ISI{i}{j}))/sqrt(length(cell2mat(averageddata.MeanCoefficientOfVariation_of_ISI{i}{j})));
                        tempN = length(cell2mat(averageddata.MeanCoefficientOfVariation_of_ISI{i}{j}));
                        averageddata.MeanCoefficientOfVariation_of_ISI{i}{j} = [];
                        averageddata.MeanCoefficientOfVariation_of_ISI{i}{j}{1} = tempmean;
                        averageddata.MeanCoefficientOfVariation_of_ISI{i}{j}{2,1} = tempsem;
                        averageddata.MeanCoefficientOfVariation_of_ISI{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.MeanBurstRate{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.MeanBurstRate{i}{j}))/sqrt(length(cell2mat(averageddata.MeanBurstRate{i}{j})));
                        tempN = length(cell2mat(averageddata.MeanBurstRate{i}{j}));
                        averageddata.MeanBurstRate{i}{j} = [];
                        averageddata.MeanBurstRate{i}{j}{1} = tempmean;
                        averageddata.MeanBurstRate{i}{j}{2,1} = tempsem;
                        averageddata.MeanBurstRate{i}{j}{3,1} = tempN;
                        
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_Spike_Freq_in_Bursts{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_Spike_Freq_in_Bursts{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_Spike_Freq_in_Bursts{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_Spike_Freq_in_Bursts{i}{j}));
                        averageddata.Mean_Spike_Freq_in_Bursts{i}{j} = [];
                        averageddata.Mean_Spike_Freq_in_Bursts{i}{j}{1} = tempmean;
                        averageddata.Mean_Spike_Freq_in_Bursts{i}{j}{2,1} = tempsem;
                        averageddata.Mean_Spike_Freq_in_Bursts{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.MAD_Spikes_in_Bursts{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.MAD_Spikes_in_Bursts{i}{j}))/sqrt(length(cell2mat(averageddata.MAD_Spikes_in_Bursts{i}{j})));
                        tempN = length(cell2mat(averageddata.MAD_Spikes_in_Bursts{i}{j}));
                        averageddata.MAD_Spikes_in_Bursts{i}{j} = [];
                        averageddata.MAD_Spikes_in_Bursts{i}{j}{1} = tempmean;
                        averageddata.MAD_Spikes_in_Bursts{i}{j}{2,1} = tempsem;
                        averageddata.MAD_Spikes_in_Bursts{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_Isolated_Spikes{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_Isolated_Spikes{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_Isolated_Spikes{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_Isolated_Spikes{i}{j}));
                        averageddata.Mean_Isolated_Spikes{i}{j} = [];
                        averageddata.Mean_Isolated_Spikes{i}{j}{1} = tempmean;
                        averageddata.Mean_Isolated_Spikes{i}{j}{2,1} = tempsem;
                        averageddata.Mean_Isolated_Spikes{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.MeanBurstDuration{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.MeanBurstDuration{i}{j}))/sqrt(length(cell2mat(averageddata.MeanBurstDuration{i}{j})));
                        tempN = length(cell2mat(averageddata.MeanBurstDuration{i}{j}));
                        averageddata.MeanBurstDuration{i}{j} = [];
                        averageddata.MeanBurstDuration{i}{j}{1} = tempmean;
                        averageddata.MeanBurstDuration{i}{j}{2,1} = tempsem;
                        averageddata.MeanBurstDuration{i}{j}{3,1} = tempN;
                        
                        
                        tempmean = nanmean(cell2mat(averageddata.MeanInterBurst_Interval{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.MeanInterBurst_Interval{i}{j}))/sqrt(length(cell2mat(averageddata.MeanInterBurst_Interval{i}{j})));
                        tempN = length(cell2mat(averageddata.MeanInterBurst_Interval{i}{j}));
                        averageddata.MeanInterBurst_Interval{i}{j} = [];
                        averageddata.MeanInterBurst_Interval{i}{j}{1} = tempmean;
                        averageddata.MeanInterBurst_Interval{i}{j}{2,1} = tempsem;
                        averageddata.MeanInterBurst_Interval{i}{j}{3,1} = tempN;
                        
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j}));
                        averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j} = [];
                        averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j}{1} = tempmean;
                        averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j}{2,1} = tempsem;
                        averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_NetworkBursts{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_NetworkBursts{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_NetworkBursts{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_NetworkBursts{i}{j}));
                        averageddata.Mean_NetworkBursts{i}{j} = [];
                        averageddata.Mean_NetworkBursts{i}{j}{1} = tempmean;
                        averageddata.Mean_NetworkBursts{i}{j}{2,1} = tempsem;
                        averageddata.Mean_NetworkBursts{i}{j}{3,1} = tempN;
                        
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_NetworkBursts_Duration{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_NetworkBursts_Duration{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_NetworkBursts_Duration{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_NetworkBursts_Duration{i}{j}));
                        averageddata.Mean_NetworkBursts_Duration{i}{j} = [];
                        averageddata.Mean_NetworkBursts_Duration{i}{j}{1} = tempmean;
                        averageddata.Mean_NetworkBursts_Duration{i}{j}{2,1} = tempsem;
                        averageddata.Mean_NetworkBursts_Duration{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j}));
                        averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j} = [];
                        averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j}{1} = tempmean;
                        averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j}{2,1} = tempsem;
                        averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_NetworkBursts_ISI{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_NetworkBursts_ISI{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_NetworkBursts_ISI{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_NetworkBursts_ISI{i}{j}));
                        averageddata.Mean_NetworkBursts_ISI{i}{j} = [];
                        averageddata.Mean_NetworkBursts_ISI{i}{j}{1} = tempmean;
                        averageddata.Mean_NetworkBursts_ISI{i}{j}{2,1} = tempsem;
                        averageddata.Mean_NetworkBursts_ISI{i}{j}{3,1} = tempN;
                        
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_NetworkBursts_IBI{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_NetworkBursts_IBI{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_NetworkBursts_IBI{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_NetworkBursts_IBI{i}{j}));
                        averageddata.Mean_NetworkBursts_IBI{i}{j} = [];
                        averageddata.Mean_NetworkBursts_IBI{i}{j}{1} = tempmean;
                        averageddata.Mean_NetworkBursts_IBI{i}{j}{2,1} = tempsem;
                        averageddata.Mean_NetworkBursts_IBI{i}{j}{3,1} = tempN;
                        
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_NetworkBursts_CVIBI{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_NetworkBursts_CVIBI{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_NetworkBursts_CVIBI{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_NetworkBursts_CVIBI{i}{j}));
                        averageddata.Mean_NetworkBursts_CVIBI{i}{j} = [];
                        averageddata.Mean_NetworkBursts_CVIBI{i}{j}{1} = tempmean;
                        averageddata.Mean_NetworkBursts_CVIBI{i}{j}{2,1} = tempsem;
                        averageddata.Mean_NetworkBursts_CVIBI{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.Mean_Amount_of_Connections{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Mean_Amount_of_Connections{i}{j}))/sqrt(length(cell2mat(averageddata.Mean_Amount_of_Connections{i}{j})));
                        tempN = length(cell2mat(averageddata.Mean_Amount_of_Connections{i}{j}));
                        averageddata.Mean_Amount_of_Connections{i}{j} = [];
                        averageddata.Mean_Amount_of_Connections{i}{j}{1} = tempmean;
                        averageddata.Mean_Amount_of_Connections{i}{j}{2,1} = tempsem;
                        averageddata.Mean_Amount_of_Connections{i}{j}{3,1} = tempN;
                        
                        tempmean = nanmean(cell2mat(averageddata.Synchronicity{i}{j}));
                        tempsem = nanstd(cell2mat(averageddata.Synchronicity{i}{j}))/sqrt(length(cell2mat(averageddata.Synchronicity{i}{j})));
                        tempN = length(cell2mat(averageddata.Synchronicity{i}{j}));
                        averageddata.Synchronicity{i}{j} = [];
                        averageddata.Synchronicity{i}{j}{1} = tempmean;
                        averageddata.Synchronicity{i}{j}{2,1} = tempsem;
                        averageddata.Synchronicity{i}{j}{3,1} = tempN;
                        
                    end
                    averageddata.Active_Electrodes{i} = vertcat(averageddata.Active_Electrodes{i}{:});
                    averageddata.FileName{i} = vertcat(averageddata.FileName{i}{:});
                    averageddata.Mean_FiringRate{i} = vertcat(averageddata.Mean_FiringRate{i}{:});
                    averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i} = vertcat(averageddata.Ratio_of_Median_ISI_over_Mean_ISI{i}{:});
                    averageddata.MeanISI{i} = vertcat(averageddata.MeanISI{i}{:});
                    averageddata.MeanCoefficientOfVariation_of_ISI{i} = vertcat(averageddata.MeanCoefficientOfVariation_of_ISI{i}{:});
                    averageddata.MeanBurstRate{i} = vertcat(averageddata.MeanBurstRate{i}{:});
                    averageddata.Mean_Spike_Freq_in_Bursts{i} = vertcat(averageddata.Mean_Spike_Freq_in_Bursts{i}{:});
                    averageddata.MAD_Spikes_in_Bursts{i} = vertcat(averageddata.MAD_Spikes_in_Bursts{i}{:});
                    averageddata.Mean_Isolated_Spikes{i} = vertcat(averageddata.Mean_Isolated_Spikes{i}{:});
                    averageddata.MeanBurstDuration{i} = vertcat(averageddata.MeanBurstDuration{i}{:});
                    averageddata.MeanInterBurst_Interval{i} = vertcat(averageddata.MeanInterBurst_Interval{i}{:});
                    averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i} = vertcat(averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{i}{:});
                    averageddata.Mean_NetworkBursts{i} = vertcat(averageddata.Mean_NetworkBursts{i}{:});
                    averageddata.Mean_NetworkBursts_Duration{i} = vertcat(averageddata.Mean_NetworkBursts_Duration{i}{:});
                    averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i} = vertcat(averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{i}{:});
                    averageddata.Mean_NetworkBursts_ISI{i} = vertcat(averageddata.Mean_NetworkBursts_ISI{i}{:});
                    averageddata.Mean_NetworkBursts_IBI{i} = vertcat(averageddata.Mean_NetworkBursts_IBI{i}{:});
                    averageddata.Mean_NetworkBursts_CVIBI{i} = vertcat(averageddata.Mean_NetworkBursts_CVIBI{i}{:});
                    averageddata.Mean_Amount_of_Connections{i} = vertcat(averageddata.Mean_Amount_of_Connections{i}{:});
                    averageddata.Synchronicity{i} = vertcat(averageddata.Synchronicity{i}{:});
                end
                
                
                
                % now we combine it into one so we can convert it into a table
                
                averageddata.Active_Electrodes = vertcat(averageddata.Active_Electrodes{:});
                averageddata.FileName = vertcat(averageddata.FileName{:});
                averageddata.Mean_FiringRate = vertcat(averageddata.Mean_FiringRate{:});
                averageddata.Ratio_of_Median_ISI_over_Mean_ISI = vertcat(averageddata.Ratio_of_Median_ISI_over_Mean_ISI{:});
                averageddata.MeanISI = vertcat(averageddata.MeanISI{:});
                averageddata.MeanCoefficientOfVariation_of_ISI = vertcat(averageddata.MeanCoefficientOfVariation_of_ISI{:});
                averageddata.MeanBurstRate = vertcat(averageddata.MeanBurstRate{:});
                averageddata.Mean_Spike_Freq_in_Bursts = vertcat(averageddata.Mean_Spike_Freq_in_Bursts{:});
                averageddata.MAD_Spikes_in_Bursts = vertcat(averageddata.MAD_Spikes_in_Bursts{:});
                averageddata.Mean_Isolated_Spikes = vertcat(averageddata.Mean_Isolated_Spikes{:});
                averageddata.MeanBurstDuration = vertcat(averageddata.MeanBurstDuration{:});
                averageddata.MeanInterBurst_Interval = vertcat(averageddata.MeanInterBurst_Interval{:});
                averageddata.Mean_CoefficientOfVariation_InterBurst_Interval = vertcat(averageddata.Mean_CoefficientOfVariation_InterBurst_Interval{:});
                averageddata.Mean_NetworkBursts = vertcat(averageddata.Mean_NetworkBursts{:});
                averageddata.Mean_NetworkBursts_Duration = vertcat(averageddata.Mean_NetworkBursts_Duration{:});
                averageddata.Mean_NetworkBursts_Fire_Rate_Spikes = vertcat(averageddata.Mean_NetworkBursts_Fire_Rate_Spikes{:});
                averageddata.Mean_NetworkBursts_ISI = vertcat(averageddata.Mean_NetworkBursts_ISI{:});
                averageddata.Mean_NetworkBursts_IBI = vertcat(averageddata.Mean_NetworkBursts_IBI{:});
                averageddata.Mean_NetworkBursts_CVIBI = vertcat(averageddata.Mean_NetworkBursts_CVIBI{:});
                averageddata.Mean_Amount_of_Connections = vertcat(averageddata.Mean_Amount_of_Connections{:});
                averageddata.Synchronicity = vertcat(averageddata.Synchronicity{:});
                
                MeanData = struct2table(averageddata);
                writetable(MeanData,uiputfile('*.xlsx','Saving Output File'),'WriteRowNames',true);
%                 writetable(MeanData,'Neuronal Endpoints(Mean + SEM).xlsx','WriteRowNames',true);
                AllData = struct2table(MeanFiringRate);
                
                % remove empty wells
                
                indexi = find(cell2mat(AllData.Active_Electrodes) == 0);
                AllData(indexi,:) = [];
                writetable(AllData,uiputfile('*.xlsx','Saving Output File'),'WriteRowNames',true);
%                 writetable(AllData,'Neuronal Endpoints(All Data).xlsx','WriteRowNames',true);
          
                msgbox('Finished calculating the Neuro Endpoints (All + Grouped Values)')
            elseif strcmpi(button2, 'Terminate')
                AllData = struct2table(MeanFiringRate);
                
                % remove empty wells
                
                indexi = find(cell2mat(AllData.Active_Electrodes) == 0);
                AllData(indexi,:) = [];
                
                  writetable(AllData,uiputfile('*.xlsx','Saving Output File'),'WriteRowNames',true);
          
                msgbox('Finished calculating the Neuro Endpoints (All Values)')
            end
        elseif strcmpi(button, 'Terminate')
            AllData = struct2table(MeanFiringRate);
            
            % remove empty wells
            
            indexi = find(cell2mat(AllData.Active_Electrodes) == 0);
            AllData(indexi,:) = [];
            
             writetable(AllData,uiputfile('*.xlsx','Saving Output File'),'WriteRowNames',true);
           
            msgbox('Finished calculating the Neuro Endpoints (All Values)')
        end
        
    end
  
    
    
    %%
    if multiwell1 == 1
    else
        
        AllData = struct2table(MeanFiringRate);
        
        % remove empty wells
        
%         indexi = find(cell2mat(AllData.Active_Electrodes) == 0);
%         AllData(indexi,:) = [];
        
       writetable(AllData,uiputfile('*.xlsx','Saving Output File'),'WriteRowNames',true);
        
        msgbox('Finished calculating the Neuro Endpoints (All Values)')
    end
    
end



