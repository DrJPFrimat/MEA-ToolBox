
%% CSV file as input file for the MEA Toolbox
global multiwell1 parts SCBflag electrodecount Multiwell2
%% go through multiple CSV files ( these files will be treated as a single well data format because we miss the voltage data so there is enough memory)
multiwell1 = 1;
parts = 24; % this is based on the 24 multweill from axion biosystems with 16 electrodes in each well for a total of 384 electrodes
for iiii = 1:parts
    %     selecteddata = files(pp).name;
    hh=waitbar(0,'Reading the Raw Data(CSV)');
    alldata = readtable(selecteddata);
    
    % Data4 contains all the spiketimes in seconds
    % Data3 contains all the spike waveforms in uV
    % find the index of a column that contains time in it (the assumption is
    % that this column contains all the spike times)
    Indextime = find(contains(alldata.Properties.VariableNames,'Time'));
    Data4 = alldata(:,Indextime); % add the option to ask what the name is of the clumn that contains all the spike times?
    Data4= table2array(Data4);
    Indexwaveform = find(contains(alldata.Properties.VariableNames,'Waveform'));
    Data3 = alldata(:,Indexwaveform); % this is for the spikewaveforms
    Data3= table2array(Data3);
    timesss = max(Data4); % total duration of the recording (last detected spike)
    
    
    %allocate the spikes to their appropriate channels
    Indexelectrodes = find(contains(alldata.Properties.VariableNames,'Electrode'));
    Electrodes = alldata(:,Indexelectrodes);
    totalelectrodes =unique(Electrodes); % total electrodes with activity
    alldata = sortrows(alldata,'Electrode','ascend'); %sorted based on the electrodenames
    
    sortedspikes = cell(1,length(table2array(totalelectrodes)))'; % amount of electrodes poer well times the wells (change later)
    for i = 1:length(table2array(totalelectrodes))
        indices = find(contains(table2array(alldata(:,Indexelectrodes)),table2array(totalelectrodes(i,1))));
        sortedspikes{i} = table2array(alldata(indices,Indextime)); % sortedspikes contains all the spikes sorted to each channel
    end
    
    
    waitbar(0 + 0.2,hh,'Loaded the Raw data(CSV)');
    
    %% layout (creation of layout/HITS)
    
    % this layout is based on the axion biosystems 24 well maestro pro (the csv file
    % is from meaRtools github page)
    
    
    HITS= cell(1,384)'; %24 wells * 16 electrodes
    electrodelabels = [11 12 13 14 21 22 23 24 31 32 33 34 41 42 43 44]; % these are the suffixes for the electrodes
    electrodelabels2 = [2 3 4 5 6 7];
    electrodelabels3 = ['B' 'C' 'D' 'E'];
    electrodename = 'B2_11';
    k=1;
    l=1;
    m=1;
    for i =1:length(HITS)
        electrodename = sprintf('%s%d_%d',electrodelabels3(k),electrodelabels2(l),electrodelabels(m));
        HITS{i,1} = electrodename;
        m=m+1;
        if m == 17
            m=1;
            l=l+1;
            if l== 7
                l=1;
                k=k+1;
                if k == 5
                    k=1;
                end
            end
        end
    end
    clear electrodename electrodelabels electrodelabels2 electrodelabels3 k l m
    channelIDs = HITS(:,1); %contains all the channelnames in chronological order
    
    %now we need to match the correct spikes with the correct channel in the
    %variable HITS (the correct channelnames is in totalelectrodes and they
    %need to be put correctly in HITS)
    
    sortedspikes2 = cell(1,16*24)';
    for i = 1:length(table2array(totalelectrodes))
        correctindex = find(contains(HITS(:,1),char(table2array(totalelectrodes(i,1)))));
        if i == correctindex
            sortedspikes2{i}=sortedspikes{correctindex};
        else
            sortedspikes2{correctindex} =  sortedspikes{i};
        end
    end
    
    sortedspikes= sortedspikes2;
    clear sortedspikes2
    
    
    
    Truehits=zeros(1,length(sortedspikes))';
    for i=1:length(sortedspikes)
        if isempty(sortedspikes{i})
            Truehits(i)=0;
        else
            Truehits(i)=length(sortedspikes{i}(:,1));
        end
    end
    
    M489 =Truehits;
    clear Indextime Indexwaveform Indexelectrodes indices
    
    HITS(:,2) = num2cell(Truehits);
    
    % for i = 1:length(M489)
    %     correctindex = find(contains(HITS(:,1),char(table2array(totalelectrodes(i,1)))));
    %     if i == correctindex
    %         HITS{i,2}=M489(correctindex);
    %     else
    %         HITS{correctindex,2} =  M489(i);
    %     end
    % end
    
    for i =1:length(HITS(:,1))
        if isempty(HITS{i,2})
            HITS{i,2} = 0;
        end
    end
    
    
    
    
    %layout
    %the layout is probably 4x4 for one well (cant verify because dont have
    %access to software from axion biosystems)
    
    layout= [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan HITS{1,2}   HITS{2,2}   HITS{3,2}   HITS{4,2}   nan nan HITS{17,2}  HITS{18,2}  HITS{19,2}  HITS{20,2}  nan nan HITS{33,2}  HITS{34,2}  HITS{35,2}  HITS{36,2}  nan nan HITS{49,2}  HITS{50,2}  HITS{51,2}  HITS{52,2}  nan nan HITS{65,2}  HITS{66,2}  HITS{67,2}  HITS{68,2}  nan nan HITS{81,2}  HITS{82,2}  HITS{83,2}  HITS{84,2}  nan nan;
        nan nan HITS{5,2}   HITS{6,2}   HITS{7,2}   HITS{8,2}   nan nan HITS{21,2}  HITS{22,2}  HITS{23,2}  HITS{24,2}  nan nan HITS{37,2}  HITS{38,2}  HITS{39,2}  HITS{40,2}  nan nan HITS{53,2}  HITS{54,2}  HITS{55,2}  HITS{56,2}  nan nan HITS{69,2}  HITS{70,2}  HITS{71,2}  HITS{72,2}  nan nan HITS{85,2}  HITS{86,2}  HITS{87,2}  HITS{88,2}  nan nan;
        nan nan HITS{9,2}   HITS{10,2}  HITS{11,2}  HITS{12,2}  nan nan HITS{25,2}  HITS{26,2}  HITS{27,2}  HITS{28,2}  nan nan HITS{41,2}  HITS{42,2}  HITS{43,2}  HITS{44,2}  nan nan HITS{57,2}  HITS{58,2}  HITS{59,2}  HITS{60,2}  nan nan HITS{73,2}  HITS{74,2}  HITS{75,2}  HITS{76,2}  nan nan HITS{89,2}  HITS{90,2}  HITS{91,2}  HITS{92,2}  nan nan;
        nan nan HITS{13,2}  HITS{14,2}  HITS{15,2}  HITS{16,2}  nan nan HITS{29,2}  HITS{30,2}  HITS{31,2}  HITS{32,2}  nan nan HITS{45,2}  HITS{46,2}  HITS{47,2}  HITS{48,2}  nan nan HITS{61,2}  HITS{62,2}  HITS{63,2}  HITS{64,2}  nan nan HITS{77,2}  HITS{78,2}  HITS{79,2}  HITS{80,2}  nan nan HITS{93,2}  HITS{94,2}  HITS{95,2}  HITS{96,2}  nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan HITS{97,2}  HITS{98,2}  HITS{99,2}  HITS{100,2} nan nan HITS{113,2} HITS{114,2} HITS{115,2} HITS{116,2} nan nan HITS{129,2} HITS{130,2} HITS{131,2} HITS{132,2} nan nan HITS{145,2} HITS{146,2} HITS{147,2} HITS{148,2} nan nan HITS{161,2} HITS{162,2} HITS{163,2} HITS{164,2} nan nan HITS{177,2} HITS{178,2} HITS{179,2} HITS{180,2} nan nan;
        nan nan HITS{101,2} HITS{102,2} HITS{103,2} HITS{104,2} nan nan HITS{117,2} HITS{118,2} HITS{119,2} HITS{120,2} nan nan HITS{133,2} HITS{134,2} HITS{135,2} HITS{136,2} nan nan HITS{149,2} HITS{150,2} HITS{151,2} HITS{152,2} nan nan HITS{165,2} HITS{166,2} HITS{167,2} HITS{168,2} nan nan HITS{181,2} HITS{182,2} HITS{183,2} HITS{184,2} nan nan;
        nan nan HITS{105,2} HITS{106,2} HITS{107,2} HITS{108,2} nan nan HITS{121,2} HITS{122,2} HITS{123,2} HITS{124,2} nan nan HITS{137,2} HITS{138,2} HITS{139,2} HITS{140,2} nan nan HITS{153,2} HITS{154,2} HITS{155,2} HITS{156,2} nan nan HITS{169,2} HITS{170,2} HITS{171,2} HITS{172,2} nan nan HITS{185,2} HITS{186,2} HITS{187,2} HITS{188,2} nan nan;
        nan nan HITS{109,2} HITS{110,2} HITS{111,2} HITS{112,2} nan nan HITS{125,2} HITS{126,2} HITS{127,2} HITS{128,2} nan nan HITS{141,2} HITS{142,2} HITS{143,2} HITS{144,2} nan nan HITS{157,2} HITS{158,2} HITS{159,2} HITS{160,2} nan nan HITS{173,2} HITS{174,2} HITS{175,2} HITS{176,2} nan nan HITS{189,2} HITS{190,2} HITS{191,2} HITS{192,2} nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan HITS{193,2} HITS{194,2} HITS{195,2} HITS{196,2} nan nan HITS{209,2} HITS{210,2} HITS{211,2} HITS{212,2} nan nan HITS{225,2} HITS{226,2} HITS{227,2} HITS{228,2} nan nan HITS{241,2} HITS{242,2} HITS{243,2} HITS{244,2} nan nan HITS{257,2} HITS{258,2} HITS{259,2} HITS{260,2} nan nan HITS{273,2} HITS{274,2} HITS{275,2} HITS{276,2} nan nan;
        nan nan HITS{197,2} HITS{198,2} HITS{199,2} HITS{200,2} nan nan HITS{213,2} HITS{214,2} HITS{215,2} HITS{216,2} nan nan HITS{229,2} HITS{230,2} HITS{231,2} HITS{232,2} nan nan HITS{245,2} HITS{246,2} HITS{247,2} HITS{248,2} nan nan HITS{261,2} HITS{262,2} HITS{263,2} HITS{264,2} nan nan HITS{277,2} HITS{278,2} HITS{279,2} HITS{280,2} nan nan;
        nan nan HITS{201,2} HITS{202,2} HITS{203,2} HITS{204,2} nan nan HITS{217,2} HITS{218,2} HITS{219,2} HITS{220,2} nan nan HITS{233,2} HITS{234,2} HITS{235,2} HITS{236,2} nan nan HITS{249,2} HITS{250,2} HITS{251,2} HITS{252,2} nan nan HITS{265,2} HITS{266,2} HITS{267,2} HITS{268,2} nan nan HITS{281,2} HITS{282,2} HITS{283,2} HITS{284,2} nan nan;
        nan nan HITS{205,2} HITS{206,2} HITS{207,2} HITS{208,2} nan nan HITS{221,2} HITS{222,2} HITS{223,2} HITS{224,2} nan nan HITS{237,2} HITS{238,2} HITS{239,2} HITS{240,2} nan nan HITS{253,2} HITS{254,2} HITS{255,2} HITS{256,2} nan nan HITS{269,2} HITS{270,2} HITS{271,2} HITS{272,2} nan nan HITS{285,2} HITS{286,2} HITS{287,2} HITS{288,2} nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan HITS{289,2} HITS{290,2} HITS{291,2} HITS{292,2} nan nan HITS{305,2} HITS{306,2} HITS{307,2} HITS{308,2} nan nan HITS{321,2} HITS{322,2} HITS{323,2} HITS{324,2} nan nan HITS{337,2} HITS{338,2} HITS{339,2} HITS{340,2} nan nan HITS{353,2} HITS{354,2} HITS{355,2} HITS{356,2} nan nan HITS{369,2} HITS{370,2} HITS{371,2} HITS{372,2} nan nan;
        nan nan HITS{293,2} HITS{294,2} HITS{295,2} HITS{296,2} nan nan HITS{309,2} HITS{310,2} HITS{311,2} HITS{312,2} nan nan HITS{325,2} HITS{326,2} HITS{327,2} HITS{328,2} nan nan HITS{341,2} HITS{342,2} HITS{343,2} HITS{344,2} nan nan HITS{357,2} HITS{358,2} HITS{359,2} HITS{360,2} nan nan HITS{373,2} HITS{374,2} HITS{375,2} HITS{376,2} nan nan;
        nan nan HITS{297,2} HITS{298,2} HITS{299,2} HITS{300,2} nan nan HITS{313,2} HITS{314,2} HITS{315,2} HITS{316,2} nan nan HITS{329,2} HITS{330,2} HITS{331,2} HITS{332,2} nan nan HITS{345,2} HITS{346,2} HITS{347,2} HITS{348,2} nan nan HITS{361,2} HITS{362,2} HITS{363,2} HITS{364,2} nan nan HITS{377,2} HITS{378,2} HITS{379,2} HITS{380,2} nan nan;
        nan nan HITS{301,2} HITS{302,2} HITS{303,2} HITS{304,2} nan nan HITS{317,2} HITS{318,2} HITS{319,2} HITS{320,2} nan nan HITS{333,2} HITS{334,2} HITS{335,2} HITS{336,2} nan nan HITS{349,2} HITS{350,2} HITS{351,2} HITS{352,2} nan nan HITS{365,2} HITS{366,2} HITS{367,2} HITS{368,2} nan nan HITS{381,2} HITS{382,2} HITS{383,2} HITS{384,2} nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;
        nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan];
    %% split the data in mutliple parts each corresponding to a well
    wells = cell(1,24);
    for i = 1:length(wells)
        wells{i} = (((i-1)*16)+1:(i*16));
    end
    
    temp = HITS(wells{iiii})';
    temp(:,2) = HITS(wells{iiii},2);
    HITS = temp;
    
    sortedspikes = sortedspikes(wells{iiii});
    filteredData1 = zeros(1,length(sortedspikes))';
    Truehits = Truehits(wells{iiii});
    channelIDs = channelIDs(wells{iiii});
    
    %% creation of xpoints and ypoints and M2
    
    % for the rasterplot
    pp2=[];
    for i=1:length(sortedspikes)
        if isempty(sortedspikes{i})
            continue
        else
            p=length(sortedspikes{i}(:,1));
            pp= ones(1,p)*i;
            pp2=[pp2,pp];
        end
    end
    
    ypoints=pp2;
    
    clear pp2 pp p
    
    
    
    pp=[];
    for i=1:length(sortedspikes)
        if isempty(sortedspikes{i})
            continue
        else
            p=sortedspikes{i}';
            pp=[pp,p];
        end
    end
    
    
    xpoints=pp;
    clear p pp
    
    M2 = cell(1,length(sortedspikes))';
    for i = 1:length(sortedspikes) % this is done to switch the orientation to make it work with the other code
        M2{i} = sortedspikes{i}';
    end
    
    waitbar(0 + 0.55,hh,'Start Burst Detection');
    % we need to ignore all calculations that involve the spike waveforms
    if isempty(Data3)
        
        %% Prepare the data for single channel burst detection  (SCBs)
        
        waitbar(0 + 0.55,hh,'Start Burst Detection');
        
        
        test2=cell(1,length(M2));
        for i=1:length(M2)
            test=diff(M2{i,1});
            test2{i}=test;
        end
        test2=test2'; %contain the ISI all of the channels
        
        for i =1:length(test2)
            test2{i}(2,:)=1:length(test2{i});    %add the index of the ISI in each cell
        end
        
        % remove any cell that has less than 3 spikes
        
        for i=1:length(test2)
            if size(test2{i},2) < 3
                test2{i}=[];
            end
        end
        
        %first part would be to detect the start of the bursts
        
        %maximum start of the burst is 170 ms between the first two spikes of a
        %burst
        
        burst6=cell(1,length(M2));
        for ii=1:length(M2)
            
            if isempty(test2{ii})
                burst6{ii} = [];
            else
                idx = find(test2{ii}(1,:) < fs.burstdetectionmaxinterval.start);
                maxbursts=round(length(test2{ii})/fs.burstdetectionmaxinterval.nspikes); %you have to have atleast 3 spikes per burst and therefore you have a max limit on the maount of bursts
                
                %check to see if the amount of bursts is normal if not remove it
                
                burst4=cell(1,length(idx));
                for j=1:length(idx)
                    burst3=[];
                    for i=idx(j):length(test2{ii})
                        if test2{ii}(1,i) < fs.burstdetectionmaxinterval.IBI     %max ISI of interburstspikes is 300 ms
                            burst = test2{ii}(2,i);    %get the indices of the spikes so its easier to work it
                            burst3{i} = burst;
                            %   burst4{j}(i)=burst;
                            
                        else
                            break;
                        end
                    end
                    
                    if isempty(burst3)
                    else
                        burst3 = vertcat(burst3{:});
                    end
                    
                    burst4{j}=burst3;    %now we have our found our bursts that start with a ISI of 170 ms and have a ISI wihtin the bursts of max 300 ms
                    
                end
                clear burst burst3
                
                for i=1:length(burst4)
                    if length(burst4{1,i}) < fs.burstdetectionmaxinterval.nspikes   %removed any burst that had less than 3 spikes
                        burst4{1,i}=[];
                    else
                        
                    end
                end
                
                burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                
                %merging/removal of duplicates
                
                NewVector = cellfun(@(x) x(end), burst4); % get all the last number of each detected burst
                
                
                for i = 1:length(NewVector)
                    try
                        if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them (its based on the last number as in the duplicated bursts they are the same)
                            burst4{i+1} = [];
                        else
                            
                        end
                    catch
                    end
                end
                
                burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                
                
                
                %now we need to get the real spike times for the other parameters
                
                %now we need to check if the time between the bursts is a minimal
                %of 200 ms otherwise merge
                
                burst5={};
                
                for i=1:length(burst4)-1
                    j=i+1;
                    if M2{ii,1}(burst4{1,j}(1,1))- M2{ii,1}(burst4{1,i}(end)) < fs.burstdetectionmaxinterval.intraBI   %if the distance between the last spike of the previous burst is not longer than 200 ms comapred to the first spike of the next bursts it will be merged into one bursts
                        burst5=vertcat(burst4{1,i},burst4{1,j});
                    else
                        
                        burst5{i}=burst4{1,i};
                        burst5{j}=burst4{1,j};
                    end
                end
                
                clear burst4
                %last check is to see if the total duration of the bursts is atleast 10 ms
                
                for i=1:length(burst5)
                    if M2{ii,1}(burst5{1,i}(end)) - M2{ii,1}(burst5{1,i}(1,1)) < fs.burstdetectionmaxinterval.mindur
                        burst5{1,i}=[];
                    else
                    end
                end
                
                burst5=burst5(~cellfun('isempty',burst5)); %sort the correct amount of bursts
                
                burst6{ii}=burst5;
            end
        end
        
        clear burst5 test2 idx test maxbursts messsage1
        burst6=burst6';  %these are the indices of the spikes
        %we have to convert them to their actual spike timings
        burst6indx= burst6;
        
        for i=1:length(M2)
            for j=1:length(burst6{i,1})
                burst6{i,1}{1,j}=M2{i,1}(burst6{i,1}{1,j});  %now we have the correct spike timings!
            end
        end
        
        
        
        Exburst=cell(1,length(M2));
        for jj=1:length(M2)
            Exburst{jj}.number_of_bursts=1:length(burst6{jj,1});
            
            for i=1:length(burst6{jj,1})
                Exburst{jj}.duration_of_bursts(i)=burst6{jj,1}{1,i}(end)-burst6{jj,1}{1,i}(1,1);
            end
            
            
            for i=1:length(burst6{jj,1})
                Exburst{jj}.spikes_in_bursts(i)=length(burst6{jj,1}{1,i});
            end
        end
        Exburst=Exburst';   %contains data about the bursts for the table
        
        for i=1:length(M2)
            Exburst{i,1}.number_of_bursts=Exburst{i,1}.number_of_bursts'; %flip everything for the table
        end
        
        for i=1:length(M2)
            if sum(strcmp(fieldnames(Exburst{i,1}), 'spikes_in_bursts')) == 1
                Exburst{i,1}.spikes_in_bursts=Exburst{i,1}.spikes_in_bursts'; %flip everything for the table
            else
            end
        end
        
        for i=1:length(M2)
            if sum(strcmp(fieldnames(Exburst{i,1}), 'duration_of_bursts')) == 1
                Exburst{i,1}.duration_of_bursts=Exburst{i,1}.duration_of_bursts'; %flip everything for the table
            else
            end
        end
        
        clear mona
        
        %get the firing frequency (Hz) per burst per electrode
        
        fr_of_bursts = zeros(1,length(M2))';
        for i = 1:length(M2)
            if isempty(Exburst{i}.number_of_bursts)
                Exburst{i}.fr_of_bursts = [];
            else
                for j = 1:length(Exburst{i}.spikes_in_bursts)
                    Exburst{i}.fr_of_bursts(j) = Exburst{i}.spikes_in_bursts(j)/ Exburst{i}.duration_of_bursts(j);
                    Exburst{i}.fr_of_bursts = Exburst{i}.fr_of_bursts';
                end
            end
        end
        
        
        %get the mean ISI of the spikes inside of a burst
        %the timings are located in burst6 for max interval
        
        
        mISIbursts = cell(1,length(M2));
        for i=1:length(M2)
            if isempty(Exburst{i}.number_of_bursts)
                mISIbursts{i} = 0;
            else
                mISIbursts{i} = cellfun(@diff,burst6{i},'UniformOutput',0);
            end
            
        end
        
        
        mISIbursts=cell(1,length(burst6))'; %contains the average ISI of the bursts in each electrode
        for i=1:length(M2)
            mISIbursts{i}=zeros(1,length(burst6{i}));
            if isempty(Exburst{i}.number_of_bursts)
                mISIbursts{i} = 0;
            else
                for j = 1:length(burst6{i})
                    mISIbursts{i}(j) = mean(diff(cell2mat(burst6{i}(j))));
                    Exburst{i}.mean_ISI_bursts = mISIbursts{i}';
                end
            end
        end
        
        clear mISIbursts
        
        stdISIbursts=cell(1,length(burst6))'; %contains the std of the ISI of  bursts in each electrode
        for i=1:length(M2)
            stdISIbursts{i}=zeros(1,length(burst6{i}));
            if isempty(Exburst{i}.number_of_bursts)
                stdISIbursts{i} = 0;
            else
                for j = 1:length(burst6{i})
                    stdISIbursts{i}(j) = std(diff(cell2mat(burst6{i}(j))));
                    Exburst{i}.std_ISI_bursts = stdISIbursts{i}';
                end
            end
        end
        
        clear stdISIbursts
        
        %calculate the IBI
        
        IBI2=[];
        for i =1:length(burst6)
            if isempty(burst6{i})
                continue
            else
                for j =1:length(burst6{i})-1
                    IBI = burst6{i}{j+1}(1) - burst6{i}{j}(end);
                    IBI2=[IBI2,IBI];
                end
            end
            Exburst{i}.IBI = IBI2';  %this contains all the IBI's per electrode
            IBI2 =[];
        end
        
        
        % create a conditional to produce a error if burst6 and burst6indx
        % are not the same
        
        assert( length(find(~cellfun(@isempty,burst6))) == length(find(~cellfun(@isempty,burst6indx))));
        
        %% calculating ISI
        ISI58={}; %contains all the ISI for all channels
        for i=1:length(M2)
            ISI57= diff(M2{i,1});
            ISI58{i}=ISI57;
            %         ISI58=ISI58';
        end
        ISI58=ISI58';
        
        
        for i=1:length(M2)
            ISI58{i,1}=(ISI58{i,1}*1000); %x data in milliseconds
            
        end
        
        clear ISI57
        
        %% calulating the burst according to the logISI method from A self-adapting approach for the detection of bursts and network bursts in neuronal cultures (there seems to be a problem with overlapping bursts)
        %https://www.physiology.org/doi/full/10.1152/jn.00093.2016
        % LogISI method (Pasquale et al. 2010).
        
        %Bursts are detected using the histogram of the log-adjusted ISIs on a spike train.
        %The peaks of this histogram are found using a tailor-made peak finding algorithm outlined in Pasquale et al. (2010), and the largest peak corresponding to an ISI of ≤100 ms is set as the intraburst peak.
        %In the absence of such a peak, no bursts are found.
        %The minimum values between the intraburst peak and all subsequent peaks are found, and a void parameter, which represents how well the peaks are separated, is calculated for each minimum.
        %The ISI value corresponding to the first minimum at which the void parameter exceeds a threshold value of 0.7 is set as the cutoff value for burst detection, maxISI.
        %Bursts are then detected as any series of three or more spikes separated by ISIs smaller than maxISI.
        %If no cutoff is found, or if maxISI > 100 ms, bursts are found with a 100-ms cutoff, and then extended to include any spikes within maxISI of the edges of each burst.
        
        %all the ISI's are located in the ISI58
        
        
        
        %first thing we need to do is make the log ISI histograms
        logISI_hist = cell(1,length(M2));
        binsss= cell(1,length(M2));
        for i = 1:length(M2)
            if isempty(ISI58{i})
                logISI_hist{i} = [];
                continue
            else
                maxWin = ceil(log10(max(ISI58{i})));
                binss = logspace(0,maxWin,maxWin*10);           % equally spaced logarithmic bins using logspace
                ISIlog_hist = histc(ISI58{i},binss);                     % this is the actual log ISI histogram
                ISIlog_hist_area = sum(ISIlog_hist);
                ISIlog_hist_norm = ISIlog_hist./ISIlog_hist_area;    % normalization
                ISIlog_hist_norm = ISIlog_hist_norm(:);
                binss = binss(:);
            end
            logISI_hist{i} = ISIlog_hist_norm;
            binsss{i} = binss ;
        end
        clear binss ISIlog_hist_norm  ISIlog_hist maxWin
        logISI_hist = logISI_hist';
        binsss = binsss';  % remember this is in ms!
        
        
        %smooth the log ISI histograms
        smoothed_logISI = cell(1,length(M2));
        for i = 1:length(M2)
            if isempty(logISI_hist{i})
                smoothed_logISI{i} = [];
                continue
            else
                smoothed_logISI{i} = smooth(logISI_hist{i},5,'lowess') ;   % smooth the logISI histograms
            end
        end
        smoothed_logISI = smoothed_logISI';
        
        %now we need to find the peaks in the smoothed ISI log
        %histograms throw away channels that do not have a peak before
        %100 ms
        
        
        intraburstpeaks = cell(1,length(M2));
        logISIpeaks = cell(1,length(M2));
        logISIlocs = cell(1,length(M2));
        
        for i =1:length(M2)
            if isempty(smoothed_logISI{i})
                intraburstpeaks{i} =[];
                continue
            else
                [peaks,locs] = findpeaks(smoothed_logISI{i},'minpeakdistance',2); %2 points from 'A self-adapting approach for the detection of burstsand network bursts in neuronal cultures'
            end
            
            temp1 = binsss{i}(locs);
            %now we need to check if there is peak before 100 ms
            if numel(peaks) == 1
                intraburstpeaks{i} = [];
            elseif numel(find(temp1 < 100)) > 1 %if we have more than 1 peak then take the biggest value
                [~,I] = max(peaks(find(temp1 < 100)));
                intraburstpeaks{i} =  temp1(I);
                %                 elseif find(temp1 < 100) == 1   %there is one peak before 100 ms
                %                     intraburstpeaks{i} = temp1(find(temp1 < 100));
            elseif numel(find(temp1 < 100)) == 1
                [~,I] = find(temp1 < 100);
                intraburstpeaks{i} =  temp1(I);
                
            else % no peaks before 100 ms so we discontinue the burst analysis
                intraburstpeaks{i} = [];
            end
            
            if isempty(intraburstpeaks{i})
                logISIlocs{i} = [];
                logISIpeaks{i} =[];
            else
                logISIpeaks{i} = peaks;
                logISIlocs{i} = binsss{i}(locs);
            end
        end
        intraburstpeaks = intraburstpeaks'; % this cell contains all the intraburst peaks in ms!
        logISIpeaks =  logISIpeaks'; %y coordinates of the peaks in counts
        logISIlocs = logISIlocs'; %x coordinates of the peaks in ms
        clear locs peaks temp1 I
        
        %Now we need to find the correct interburst interval using the void parameter if that
        %fails than we set it at 100 ms
        % We do this by comparing the first peak or the intraburst peak with the
        % subsequent peaks
        
        
        interburstlogISI = cell(1,length(M2));
        
        for i = 1:length(M2)
            if isempty(logISIlocs{i})
                interburstlogISI{i} = [];
                continue
            else
                %lets find the min value between each peak pair
                % we can find the index in the locs cells
                maxiterations = numel(logISIlocs{i});
                index_intraburst = find(logISIlocs{i} == intraburstpeaks{i});
                for j = (index_intraburst+1):length(logISIlocs{i})
                    
                    temp1 = min(smoothed_logISI{i}(find(smoothed_logISI{i} == logISIpeaks{i}(index_intraburst)):find(smoothed_logISI{i} == logISIpeaks{i}(j))));
                    %calculate how well the peaks are seperated
                    void =  1 - (temp1 / sqrt(logISIpeaks{i}(index_intraburst) * logISIpeaks{i}(j)));
                    if void > fs.burstdetectionlogisi.void
                        if temp1 == 0 %if the lowest number is equal to zero
                            temp2 = find(smoothed_logISI{i} == 0,find(find(smoothed_logISI{i} == 0) > find(smoothed_logISI{i} == logISIpeaks{i}(index_intraburst),1),1)) ;
                            temp2 = temp2(end);
                            interburstlogISI{i} = binsss{i}(temp2);
                        else
                            interburstlogISI{i} = binsss{i}(find(smoothed_logISI{i} == temp1,1)); %this is in ms
                            break
                        end
                    else
                        interburstlogISI{i} = 100; %if the method cant find any peaks that are well seperated it will be put at 100 ms
                    end
                end
            end
        end
        interburstlogISI =interburstlogISI';   %this contains all the interburst intervals in ms
        
        %combine both numbers in one cell
        
        ISIthh = cell(2,length(M2))';
        
        for i =1:length(M2)
            
            ISIthh{i,1} = interburstlogISI{i}/1000; %convert in seconds
            ISIthh{i,2} = intraburstpeaks{i}/1000;  %convert in seconds
            
        end
        
        % add a extra criteria because getting values of above 1s for
        % interburst intervals is too high
        
        
        for i = 1:length(M2)
            if isempty(ISIthh)
                continue
            else
                if ISIthh{i,1} > 1
                    ISIthh{i,1} = 0.1;
                end
            end
        end
        
        
        
        %Added an extra control to esnure that both the intraburst
        %ISI's and interburst ISI are complete
        
        
        for i = 1:length(M2)
            if isempty(ISIthh{i,1})
                if isempty(ISIthh{i,2})
                else
                    ISIthh{i,1} = 0.1;
                end
            else
            end
        end
        
        %the first column of ISIthh contains the interburst ISI thresholds and the
        %2nd column contains the intrasburst ISI thresholds (everything is in
        %seconds
        
        test2=cell(1,length(filteredData1(:,1)));
        for i=1:length(M2)
            test=diff(M2{i,1});
            test2{i}=test;
        end
        test2=test2'; %contain the ISI all of the channels % in seconds
        
        
        
        %first part would be to detect the start of the bursts
        
        %maximum start of the burst is the isi of the first peak found before
        %the found intraburst peak
        
        burst7=cell(1,length(M2));
        for ii=1:length(M2)
            
            if isempty(M2{ii}) || length(M2{ii}) < 3
                burst7{ii}={};
            elseif isempty(ISIthh{ii,2})
                burst7{ii}={};
            else
                test=test2{ii,1};
                test(2,:)=1:length(test);
                
                idx = find(test(1,:) < ISIthh{ii,2}(1));   % here we find the indexes of potential burst cores
                length(idx);
                
                maxbursts=round(length(test)/3); %you have to have atleast 3 spikes per burst and therefore you have a max limit on the maount of bursts
                
                %check to see if the amount of bursts is normal if not remove it
                
                burst4={};
                for j=1:length(idx)
                    burst3=[];
                    for i=idx(j):length(test(1,:))
                        if test(1,i) < ISIthh{ii,1}    %max ISI of interburstspikes is the found interburst interval with the void parameter if not than it is set at 100 ms
                            burst = test(2,i);    %get the indices of the spike so its easier to work it
                            burst3{i}=burst;
                            %         burst3{i}=burst;
                        else
                            break;
                        end
                    end
                    
                    if isempty(burst3)
                    else
                        burst3 = vertcat(burst3{:});
                    end
                    burst4{j}=burst3;    %now we have our found our bursts with a max intraburst ISI of the first peak of the logISI
                    
                end
                clear burst burst3
                
                for i=1:length(burst4)
                    if length(burst4{1,i}) < fs.burstdetectionlogisi.nspikes   %removed any burst that had less than 3 spikes
                        burst4{1,i}=[];
                    else
                        
                    end
                end
                
                burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                
                %merging/removal of duplicates
                
                
                NewVector = cellfun(@(x) x(end), burst4); % get all the last number of each detected burst
                
                
                for i = 1:length(NewVector)
                    try
                        if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them ( its based on the last number as in the duplicated bursts they are the same)
                            burst4{i+1} = [];
                        else
                            
                        end
                    catch
                    end
                end
                
                burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                
                %now we need to check if the time between the found bursts is
                %not below the interbursts ISI thresholds if it is lower than
                %we will merge them
                
                
                burst5={};
                
                for i=1:length(burst4)-1
                    j=i+1;
                    if M2{ii,1}(burst4{1,j}(1,1))- M2{ii,1}(burst4{1,i}(end)) < ISIthh{ii,1}(1)   %if the distance between the last spike of the previous burst is not longer than the ISI threshold found of the interburst compared to the first spike of the next bursts it will be merged into one burst
                        burst5{i}=vertcat(burst4{1,i},burst4{1,j});
                    else
                        
                        burst5{i}=burst4{1,i};
                        burst5{j}=burst4{1,j};
                    end
                end
                
                clear burst4
                
                
                NewVector = cellfun(@(x) x(end), burst5); % get all the last number of each detected burst
                
                
                for i = 1:length(NewVector)
                    try
                        if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them ( its based on the last number as in the duplicated bursts they are the same)
                            burst5{i+1} = [];
                        else
                            
                        end
                    catch
                    end
                end
                
                burst5=burst5(~cellfun('isempty',burst5)); %remove any empty cell
                %
                burst7{ii}=burst5;
            end
            
        end
        
        clear burst5 test2 idx test maxbursts ISIthh yy ii NewVector
        burst7=burst7'; %these contain the burst according to the log ISI method
        burst7indx=burst7;
        
        for i=1:length(M2)
            for j=1:length(burst7{i,1})
                burst7{i,1}{1,j}=M2{i,1}(burst7{i,1}{1,j});  %now we have the correct spike timings!
            end
        end
        
        logburst=cell(1,length(M2));
        for jj=1:length(M2)
            logburst{jj}.number_of_bursts=1:length(burst7{jj,1});
            
            for i=1:length(burst7{jj,1})
                logburst{jj}.duration_of_bursts(i)=burst7{jj,1}{1,i}(end)-burst7{jj,1}{1,i}(1,1);
            end
            
            
            for i=1:length(burst7{jj,1})
                logburst{jj}.spikes_in_bursts(i)=length(burst7{jj,1}{1,i});
            end
        end
        logburst=logburst';   %contains data about the bursts for the table
        
        for i=1:length(M2)
            logburst{i,1}.number_of_bursts=logburst{i,1}.number_of_bursts'; %flip everything for the table
        end
        
        for i=1:length(M2)
            if sum(strcmp(fieldnames(logburst{i,1}), 'spikes_in_bursts')) == 1
                logburst{i,1}.spikes_in_bursts=logburst{i,1}.spikes_in_bursts'; %flip everything for the table
            else
            end
        end
        
        for i=1:length(M2)
            if sum(strcmp(fieldnames(logburst{i,1}), 'duration_of_bursts')) == 1
                logburst{i,1}.duration_of_bursts=logburst{i,1}.duration_of_bursts'; %flip everything for the table
            else
            end
        end
        
        
        %get the firing frequency (Hz) per burst per electrode
        
        fr_of_bursts = zeros(1,length(M2))';
        for i = 1:length(M2)
            if isempty(logburst{i}.number_of_bursts)
                logburst{i}.fr_of_bursts = [];
            else
                for j = 1:length(logburst{i}.spikes_in_bursts)
                    logburst{i}.fr_of_bursts(j) = logburst{i}.spikes_in_bursts(j)/ logburst{i}.duration_of_bursts(j);
                    logburst{i}.fr_of_bursts = logburst{i}.fr_of_bursts';
                end
            end
        end
        
        
        %get the mean ISI of the spikes inside of a burst
        %the timings are located in burst6 for max interval
        
        
        mISIbursts = cell(1,length(M2));
        for i=1:length(M2)
            if isempty(logburst{i}.number_of_bursts)
                mISIbursts{i} = 0;
            else
                mISIbursts{i} = cellfun(@diff,burst7{i},'UniformOutput',0);
                %         mISIbursts{i} = diff(burst7{i})
            end
            
        end
        
        
        mISIbursts=cell(1,length(burst7))'; %contains the average ISI of the bursts in each electrode
        for i=1:length(M2)
            mISIbursts{i}=zeros(1,length(burst7{i}));
            if isempty(logburst{i}.number_of_bursts)
                mISIbursts{i} = 0;
            else
                for j = 1:length(burst7{i})
                    mISIbursts{i}(j) = mean(diff(cell2mat(burst7{i}(j))));
                    logburst{i}.mean_ISI_bursts = mISIbursts{i}';
                end
            end
        end
        
        clear mISIbursts
        
        stdISIbursts=cell(1,length(burst7))'; %contains the std of the ISI of  bursts in each electrode
        for i=1:length(M2)
            stdISIbursts{i}=zeros(1,length(burst7{i}));
            if isempty(logburst{i}.number_of_bursts)
                stdISIbursts{i} = 0;
            else
                for j = 1:length(burst7{i})
                    stdISIbursts{i}(j) = std(diff(cell2mat(burst7{i}(j))));
                    logburst{i}.std_ISI_bursts = stdISIbursts{i}';
                end
            end
        end
        
        clear stdISIbursts
        
        %% calculating  the IFR
        ifr2=cell(1,length(filteredData1(:,1)));
        
        for j=1:length(filteredData1(:,1))
            ifrl=[];
            for i=1:length(ISI58{j,1})
                ifr=1/(ISI58{j,1}(1,i));
                ifrl=[ifrl,ifr];
                ifr2{j}=ifrl;
            end
            %     ifr2{j}=ifrl; %IFR of all units per channel
        end
        ifr2=ifr2';
        
        %padding cell array
        
        ifr4=[];
        for i=1:length(M2)
            ifr3=mean(ifr2{i,1});
            ifr4=[ifr4, ifr3];
        end
        mean_ifr=ifr4';  %average IFR per channel
        
        clear ifr2 ifr ifrl ifr3 ifr4
        
        %% calculating CV
        %coefficient of variance according to file:///C:/Users/Michel/Desktop/Kros%20Ann%20of%20Neur%202015.pdf
        %Kros et al., 2014 Cerebellar Output Controls Generalized Spike-and-Wave Discharge Occurrence
        % this should say something about the regularity of firing throughout the
        % whole recording
        %CV of ISI is sigma/mean of the ISI
        %ISI58 contains all the ISI per channel
        
        meanISI={};
        for i=1:length(ISI58)
            men=mean(ISI58{i,1});
            meanISI{i}=men;
            
        end
        meanISI=meanISI';
        clear men
        
        stdISI={};
        for i=1:length(ISI58)
            stdisi=std(ISI58{i,1});
            stdISI{i}=stdisi;
            
        end
        stdISI=stdISI';
        clear stdisi
        
        CV=[];
        for i=1:length(ISI58)
            kgl=(stdISI{i,1})/(meanISI{i,1});
            CV=[CV kgl];
            
        end
        CV=CV';
        
        clear meanISI kgl
        
        %% calculating CV2
        %CV2 from the same paper as above
        %CV2= 2|ISIn+1-ISIn|/(ISIn+1+ISIn),
        CV21={};
        for i=1:length(ISI58)
            fyt1=[];
            for j=1:length(ISI58{i,1})-1
                fyt=ISI58{i,1}(1,(j+1)) - ISI58{i,1}(1,(j));
                fyt1=[fyt1 fyt];
                fyt1=abs(fyt1);
            end
            fyt1=fyt1*2;
            CV21{i}=fyt1;
            
        end
        CV21=CV21';
        
        CV22={};
        for i=1:length(ISI58)
            fyt1=[];
            for j=1:length(ISI58{i,1})-1
                fyt=ISI58{i,1}(1,(j+1)) + ISI58{i,1}(1,(j));
                fyt1=[fyt1 fyt];
            end
            CV22{i}=fyt1;
            
        end
        CV22=CV22';
        clear fyt1 fyt
        
        CV2={};
        for j=1:length(ISI58)
            CV24=[];
            for i=1:length(ISI58{j,1})-1
                CV23=(CV21{j,1}(1,i))/(CV22{j,1}(1,i));
                CV24=[CV24 CV23];
            end
            CV2{j}=CV24;
            
        end
        CV2=CV2';
        clear CV21 CV22 CV24 CV23
        
        meanCV2={};
        for i=1:length(ISI58)
            mCV2=mean(CV2{i,1});
            meanCV2{i}=mCV2;
            
        end
        meanCV2=meanCV2';
        meanCV2=cell2mat(meanCV2);
        
        %% preparation for table
        
        
        %for the max interval bursts
        number_of_burstsNeuroEx=[];
        for i=1:length(M2)
            noinb=length(burst6{i,1});
            number_of_burstsNeuroEx=[number_of_burstsNeuroEx;noinb];
        end
        clear noinb
        
        %for the logISI bursts
        number_of_burstslog=[];
        for i=1:length(M2)
            noinb=length(burst7{i,1});
            number_of_burstslog=[number_of_burstslog;noinb];
        end
        clear noinb
        
        %     if length(filteredData1(:,1)) > 121
        %         channelIDs =1:length(filteredData1(:,1));
        %         channelIDs=num2cell(channelIDs)';
        %         for i=1:length(filteredData1(:,1))
        %             channelIDs{i}=num2str(channelIDs{i});
        %         end
        %     else
        %     end
        %
        % since we dont have any threshold values we create a vector of
        % zeros for now ( remove it later on)
        
        threshold_value=zeros(1,length(sortedspikes))';
        Units_per_second = Truehits/timesss;  %firing frequency (hz)
        %         BD=sum(number_of_bursts1);
        %         BDSEM = std(number_of_bursts1)/sqrt(length(number_of_bursts1));
        BNeuro=sum(number_of_burstsNeuroEx);
        BNeuroSEM = std(number_of_burstsNeuroEx)/sqrt(length(number_of_burstsNeuroEx));
        BLog=sum(number_of_burstslog);
        BLogSEM = std(number_of_burstslog)/sqrt(length(number_of_burstslog));
        %         negunits=sum(negpksT);
        %         negunitsSEM = std(negpksT)/sqrt(length(negpksT));
        %         posunits=sum(pospeaksT);
        %         posunitsSEM = std(pospeaksT)/sqrt(length(pospeaksT));
        
        
        % calculate the ISI's and STD of ISI
        
        test2=cell(1,length(M2));
        for i=1:length(M2)
            test=diff(M2{i,1});
            test2{i}=test;
        end
        test2=test2'; %contain the ISI all of the channels
        
        meanISI=cell(1,length(M2));
        for i=1:length(M2)
            meanISI{i}=mean(test2{i});
        end
        meanISI=meanISI'; %contains all the meanISI's of each channel
        
        medianISI=cell(1,length(M2));
        for i=1:length(M2)
            medianISI{i}=median(test2{i});
        end
        medianISI=medianISI'; %contains all the meanISI's of each channel
        
        medianISI=cell2mat(medianISI);
        
        stdISI = cell(1,length(M2));
        for i=1:length(M2)
            stdISI{i}=std(test2{i});
        end
        stdISI=stdISI';
        
        %% Generation of Table
        
        % add a check for the rownames to check if there are duplicate
        % names if so change it
        
        %     if length(channelIDs) == length(Truehits)
        %     else
        %         channelIDs = zeros(1,length(Truehits));
        %         channelIDs = 1:length(channelIDs);
        %
        %     end
        %
        %
        %     if length(unique(channelIDs)) == length(channelIDs)
        %     else
        %         channelIDs = zeros(1,length(Truehits));
        %         channelIDs = 1:length(channelIDs);
        %
        %     end
        
        %     channelIDs2 = table2array(totalelectrodes); % this contains all the channels that are active  (for table)
        
        
        
        
        
        %         channelIDs = channelIDs';
        %         channelIDs = num2cell(channelIDs);
        %         channelIDs=cellfun(@num2str,channelIDs,'un',0);
        
        %Generate a table for general data
        
        %check if channelIDs is a cell array with strings
        
        if ~iscell(channelIDs)
            channelIDs = strsplit(num2str(channelIDs))';
        end
        
        T=table(Truehits,meanISI,medianISI,stdISI,number_of_burstsNeuroEx,number_of_burstslog,Units_per_second,mean_ifr,CV,meanCV2,threshold_value,'Rownames',channelIDs,'VariableNames',{'Spikes','mean_ISI','median_ISI','std_ISI','Bursts_max_interval','Bursts_log_ISI','Fire_rate','mean_ifr','mean_CV_ISI','mean_CV2_ISI','threshold_value'});
        
        
        
        clear pospeaksT threshold_value negpksT minamplitude_in_volt maxamplitude_in_volt Units_per_second mean_ifr meanCV2 number_of_bursts1 number_of_burstsNeuroEx number_of_burstslog meanISI stdISI
        
        
        if length(filteredData1(:,1)) > 121 % it seems the spikes or units from a multiwell are  different
            T.Spikes(T.Spikes < 10) =0;
        else
            %     ghy=find(T.maxamplitude_in_volt < 50);  %find any units that have a lower amplitude than +50 mV
            %     T.Truehits(ghy)=0;                   %set them to zero
            %     khy=find(T.minamplitude_in_volt >-50); %find any units that have a higher amplitude than -50 mV
            %     T.Truehits(khy)=0;                    %set them to zero
            T.Spikes(T.Spikes < 10) =0;  %remove any electrode that has 10 or less spikes
            clear ghy khy
        end
        
        
        
        
        newHITS=T.Spikes;
        T=sortrows(T,1,'descend');
        
        for i=0
            T(ismember(T.Spikes,i),:)=[];               %remove anything that is zero
        end
        
        % T(T.maxamplitude_in_volt < 50,:) = [];
        % T=T(~any(ismissing(T),2),:);
        HITSSEM=std(T.Spikes)/sqrt(length(T.Spikes));
        %         sum_negpks=sum(T.negpks);
        %         sum_pospks=sum(T.pospeaks);
        sum_Truehits=sum(T.Spikes)/(size(T,1)-1);
        %         sum_bursts=sum(T.number_of_bursts1);
        sum_bursts1=sum(T.Bursts_max_interval)/(size(T,1)-1);
        sum_bursts2=sum(T.Bursts_log_ISI)/(size(T,1)-1);
        sum_meanFR=sum(T.Fire_rate/(size(T,1)-1)); % account for the sum row mean FR of whole arry for active electrodes
        sum_meanISI=sum(cell2mat(T.mean_ISI)/(size(T,1)-1)); %mean ISI for the whole array (active electrodes)
        sum_stdISI=sum(cell2mat(T.std_ISI)/(size(T,1)-1));
        sum_CV=sum((T.mean_CV_ISI)/(size(T,1)-1));
        
        if isempty(T.median_ISI)
            median_ISI = 0;
        else
            median_ISI=median(T.median_ISI);
        end
        
        sum12=zeros(1,size(T,2));
        %         sum12(1)=sum_negpks;
        %         sum12(2)=sum_pospks;
        sum12(1)=sum_Truehits;
        sum12(2)=sum_meanISI;
        sum12(3)=median_ISI;
        sum12(4)=sum_stdISI;
        %         sum12(7)=sum_bursts;
        sum12(5)=sum_bursts1;
        sum12(6)=sum_bursts2;
        sum12(7)=sum_meanFR;
        sum12(8) = sum(T.mean_ifr)/(size(T,1)-1);
        sum12(9)=sum_CV;
        sum12(10) = sum(T.mean_CV2_ISI)/(size(T,1)-1);
        sum12(11) = sum(T.threshold_value)/(size(T,1)-1);
        clear sum_negpks sum_pospks sum_Truehits sum_bursts sum_bursts1 sum_bursts2 sum_meanFR sum_meanISI sum_stdISI sum_CV median_ISI;
        
        
        sum12=table(sum12(1,1),sum12(1,2),sum12(1,3),sum12(1,4),sum12(1,5),sum12(1,6),sum12(1,7),sum12(1,8),sum12(1,9),sum12(1,10),sum12(1,11),'Rownames',{'Mean'},'VariableNames',{'Spikes','mean_ISI','median_ISI','std_ISI','Bursts_max_interval','Bursts_log_ISI','Fire_rate','mean_ifr','mean_CV_ISI','mean_CV2_ISI','threshold_value'});
        T=[T;sum12];
        
        clear sum12
        
        %% Heatmap generation
        M489 =num2cell(newHITS);
        
        if length(channelIDs) > 121
            ans90 = 1:length(layout(:,1));
            ans90=num2cell(ans90);
            for i=1:length(layout(:,1))
                ans90{i}=num2str(ans90{i});
            end
            
        else
            ans90 = cellstr(('A':'H')')';
            ans90{9} = 'J';
            ans90{10} = 'K';
            ans90{11} ='L';
            ans90{12} = 'M';
        end
        
        %replace 4 with B,10 with C, 16 with D and 22 with E
        ans90 = cell(length(ans90),0)';
        ans90{4}  = 'B';
        ans90{10} = 'C';
        ans90{16} = 'D';
        ans90{22} = 'E';
        
        clear Data1 M489 channelIDs2
        
        %% calculating firing rate/active electrodes/inactive
        %Calculate Firing rate
        %The SPYCODE paper  bologna et al., 2010 stated that they calculated the fire rate and instaneous fire rate over the whole culture
        %They stated that they calculate the FR as the hits per channel averaged over all the active electrodes
        %The IFR is calculatd by
        %Total duration of one signal is 60.2 s
        %M4 contains all the units per channel
        FireR = Truehits/timesss; %per second%--> total amount of units of all channels
        silentelec= find(newHITS < 1); %silent electrodes
        silentelecamount = length(silentelec);
        silentelecnames = channelIDs(silentelec); % which electrode is inactive
        activeelec = find(newHITS >= 1);   %active electrodes
        activeelecamount = length(activeelec);
        activeelecnames = channelIDs(activeelec); %which electrodes were active
        
        
        Bab=table(silentelecamount);
        Bap=table(silentelecnames);
        Bak=table(activeelecamount);
        Bal=table(activeelecnames);
        
        
        clear silentelecamount silentelecnames activeelecamount activeelecnames channelIDs
        
        %% calculating burstiness index
        %burstiness index from Daniel wagenaar neurosci et al.,2005
        % Instead, we used the following method: divide a 5 min recording into 300 1-sec-long
        % time bins and count the number of spikes (total
        % across all electrodes) in each bin. Compute the
        % fraction of the total number of spikes accounted
        % for by the 15% of bins with the largest counts. If
        % the firing rate is tonic, this number, f15, will be
        % close to 0.15. Conversely, if a recording is so
        % bursty that most of the spikes are contained in
        % bursts, f15 will be close to 1, because even at the
        % highest burst rates observed during these experiments, bursts did not occupy 45 1-seclong bins (15%) in a 5 min recording. We then
        % defined a burstiness index (BI), normalized between 0 (no bursts) and 1 (burst dominated) as
        % BI = ( f15 - 0.15)/0.85.
        
        
        bincounts2={};
        binranges=linspace(0,floor(timesss),floor(timesss)*30); %the 30 represents the fps
        binranges4567=binranges;
        for i=1:length(M2)
            if isempty(M2{i})
                bincounts = zeros(1,floor(timesss)*30);
            else
                bincounts=histc(M2{i,1},binranges);
            end
            bincounts2=[bincounts2 bincounts];
        end
        bincounts2=bincounts2';
        bincounts2=vertcat(bincounts2{:});
        bincountssec=bincounts2;
        
        clear bincounts2 binranges bincounts
        
        bincounts21={};
        binranges21=0:timesss;
        for i=1:length(M2)
            if isempty(M2{i})
                bincounts20 = zeros(1,length(binranges21));
            else
                bincounts20=histc(M2{i,1},binranges21);
            end
            bincounts21=[bincounts21 bincounts20];
        end
        bincounts21=bincounts21';
        unitpersecond=bincounts21;
        bincounts21=vertcat(bincounts21{:});
        
        M3=[];
        for i = 1:length(M2)
            M3 = [M3 M2{i}];
        end
        M3 =sort(M3,'ascend');
        binned = histc(M3,0:floor(timesss));
        top15 = floor(length(binned)*0.15);
        
        BI = sum(maxk(binned,top15))/length(M3);
        
        %         if size(bincounts21,1) == 1
        %         else
        %             bincounts21=sum(bincounts21); %if there is only one channel active there is no point in summing it
        %         end
        %         bincounts21=sort(bincounts21,'descend');
        
        %
        %         %15% van 301 bins = 301/100*15=45.15
        %         %So we have to find 45 bins with the highest counts
        %
        %         top9 = bincounts21(1:floor(timesss/100*15));
        %         top9 = sum(top9);
        %         lengthop=sum(Truehits);%--> total number of hits
        %         BIp=top9/lengthop;
        %         BI=(BIp-0.15)/0.85;
        BI=table(BI);
        
        
        clear bincounts21 binranges21 bincounts20 top9 lengthop BIp Truehits M3 binned top15 bincounts21
        
        %% top active channels
        [~,Imax]=max(newHITS);  %determines the channel with the highest units and sets this as the referenec channel
        
        [maxch,imaxch]=maxk(newHITS,10);  %only in matlab 2017 and up
        imaxch2=imaxch(6:10);
        
        clear val maxch olds indolds correctindxolds
        
        %% for the Connectivity maps
        
        
        for i=1:length(M2) %remove anything below 10 spikes
            if length(M2{i,1}) < 10
                M2{i,1} =[];
            else
            end
        end
        
        newM2= layout;
        
        %      textstrings={[] '10' '6' [] [] [] '82' '78' [] [] [] '154' '150' [] [] [] '226' '222' [] '12' '9' '5' '2' [] '84' '81' '77' '74' [] '156' '153' '149' '146' [] '228' '225' '221' '218' '11' '8' '4' '1' [] '83' '80' '76' '73' [] '155' '152' '148' '145' [] '227' '224' '220' '217' [] '7' '3' [] [] [] '79' '75' [] [] [] '151' '147' [] [] [] '223' '219' [] [] '22' '18' [] [] [] '94' '90' [] [] [] '166' '162' [] [] [] '238' '234' [] '24' '21' '17' '14' [] '96' '93' '89' '86' [] '168' '165' '161' '158' [] '240' '237' '233' '230' '23' '20' '16' '13' [] '95' '92' '88' '85' [] '167' '164' '160' '157' [] '239' '236' '232' '229' [] '19' '15' [] [] [] '91' '87' [] [] [] '163' '159' [] [] [] '235' '231' [] [] '34' '30' [] [] [] '106' '102' [] [] [] '178' '174' [] [] [] '250' '246' [] '36' '33' '29' '26' [] '108' '105' '101' '98' [] '180' '177' '173' '170' [] '252' '249' '245' '242' '35' '32' '28' '25' [] '107' '104' '100' '97' [] '179' '176' '172' '169' [] '251' '248' '244' '241' [] '31' '27' [] [] [] '103' '99' [] [] [] '175' '171' [] [] [] '247' '243' [] [] '46' '42' [] [] [] '118' '114' [] [] [] '190' '186' [] [] [] '262' '258' [] '48' '45' '41' '38' [] '120' '117' '113' '110' [] '192' '189' '185' '182' [] '264' '261' '257' '254' '47' '44' '40' '37' [] '119' '116' '112' '109' [] '191' '188' '184' '181' [] '263' '260' '256' '253' [] '43' '39' [] [] [] '115' '111' [] [] [] '187' '183' [] [] [] '259' '255' [] [] '58' '54' [] [] [] '130' '126' [] [] [] '202' '198' [] [] [] '274' '270' [] '60' '57' '53' '50' [] '132' '129' '125' '122' [] '204' '201' '197' '194' [] '276' '273' '269' '266' '59' '56' '52' '49' [] '131' '128' '124' '121' [] '203' '200' '196' '193' [] '275' '272' '268' '265' [] '55' '51' [] [] [] '127' '123' [] [] [] '199' '195' [] [] [] '271' '267' [] [] '70' '66' [] [] [] '142' '138' [] [] [] '214' '210' [] [] [] '286' '282' [] '72' '69' '65' '62' [] '144' '141' '137' '134' [] '216' '213' '209' '206' [] '288' '285' '281' '278' '71' '68' '64' '61' [] '143' '140' '136' '133' [] '215' '212' '208' '205' [] '287' '284' '280' '277' [] '67' '63' [] [] [] '139' '135' [] [] [] '211' '207' [] [] [] '283' '279' []}';
        
        textstrings =[];
        
        %% Network bursts
        waitbar(0 + 0.80,hh,'Performing Post Processing analyses');
        
        % this method is based on first detecting the single channel bursts
        % based on the max interval method.
        if SCBflag == 1
            
            % we need to split the data in seperate wells
            % based on 24 well plate with 16 electrodes in each well
            
            if SCBflag == 1
                
                
                %Step 1 we need to find the a minimum of two synchronized bursts
                
                starttimesbursts2 = [];
                for i = 1:length(burst6)
                    for j = 1:length(burst6{i})
                        starttimesbursts = burst6{i}{j}(1);
                        starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
                    end
                end
                
                uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes
                
                %now we need to put all the times in a giant matrix so we can
                %search in this matrix with the unique burst start times
                
                %convert all the cells into vectors
                % all the vectors are made equal in length by adding in nans
                temp = cell(1,length(burst6))';
                for i = 1:length(burst6)
                    temp{i} = cell2mat(burst6{i});
                end
                
                newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
                newc=cell2mat(newc);
                
                
                % now we need to find if there are multiple channels that start
                % bursting within a similar time window
                channelnumbernnbursts =cell(1,length(burst6))';
                timeofnnbursts =cell(1,length(burst6))';
                for i = 1:length(uniquestarttimesbursts)
                    [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) - fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) + fs.networkburstdetection.synchronizedtimewindow );
                end
                
                
                
                
                
                % check for duplicate channelnumbers if so remove them
                for i =1:length(channelnumbernnbursts)
                    if isempty(channelnumbernnbursts{i})
                    else
                        if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                            channelnumbernnbursts{i} = [];
                            timeofnnbursts{i}=[];
                        else
                            
                        end
                    end
                end
                
                
                % now that we the channels that are synchronzied in their bursting
                % we need to remove the channels that do not fullfull our
                % requirements of have atleast 2 synchronized channels and atleast
                % 50% of the otal amount of channels should participate in the
                % nnburst or else it gets removed
                
                
                for i = 1:length(channelnumbernnbursts)
                    if length(channelnumbernnbursts{i}) <  fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                        channelnumbernnbursts{i} = [];
                        timeofnnbursts{i} = [];
                        uniquestarttimesbursts(i) = nan;
                    end
                end
                
                %clean up by removing empty cells and nan values
                uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
                channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
                timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
                
                % now we need to find the bursts that are part of the synchronized
                % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
                % synchronzied bursts in other channels and then we can see how
                % many channels are participating
                
                
                burst6length =burst6; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
                for i = 1:length(burst6)
                    for j = 1:length(burst6{i})
                        burst6length{i}{j} = length(burst6{i}{j});
                    end
                end
                
                for i = 1:length(burst6) % convert the cell arrays in vectors
                    burst6length{i} = cell2mat(burst6length{i});
                end
                
                
                potentialnnbursts = cell(1,length(channelnumbernnbursts))';
                burstsindexcount=[];
                for i = 1:length(potentialnnbursts)
                    for j = 1:length(channelnumbernnbursts{i})
                        for k = 1:cellfun(@length,(burst6(channelnumbernnbursts{i}(j))))
                            %figure out which bursts the indexes belong to
                            
                            %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
                            %                      burstsindexcount = cumsum( burstsindexcount); % old version
                            burstsindexcount = cumsum( burst6length{channelnumbernnbursts{i}(j)});
                            if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                                correctburst = k;
                                potentialnnbursts{i}{j} = burst6{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                                break
                            end
                        end
                    end
                end
                
                
                % we have to check if the times of the bursts are within acceptable
                
                
                % create variable that is the exact same varible as potentialnnbursts
                % but intead each cell contains the mean + std of that channel to
                % improve the speed
                
                potentialnnburstsmean = potentialnnbursts;
                for i =1 :length(potentialnnbursts)
                    potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 2.5*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
                end
                
                for i = 1:length(potentialnnbursts)
                    for j = 1:length(potentialnnbursts{i})
                        %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                        if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                            potentialnnbursts{i}{j} = [];
                        end
                    end
                end
                
                % now we need to use the synscho bursts to find if there are bursts that
                % fall within the same duration as the synchronized bursts. if they do then
                % they are part of the  potential network bursts
                % we loop through both synchronized bursts just to extra certain we do not
                % miss anything because the starttimes might be the same but the ending
                % time might not be.
                
                mergeburstchannel = cell(1,length(potentialnnbursts))';
                mergeburstnumber  = cell(1,length(potentialnnbursts))';
                tobemergedbursts  = cell(1,length(potentialnnbursts))';
                
                % create vaiable of potneialnnbursts that have all the cells converted into
                % vectors to improve the performance
                potentialnnburstsvector = potentialnnbursts;
                potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
                
                for i = 1:length(potentialnnburstsvector)
                    potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
                    potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
                end
                
                for i =1:length(potentialnnbursts)
                    for k = 1:length(burst6)
                        for l = 1:length(burst6{k})
                            if ~isempty(find(burst6{k}{l} > potentialnnburstsvector{i,2}(1) & burst6{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                                tobemergedbursts{i}{k} =cell2mat(burst6{k}(l)) ;
                                mergeburstchannel{i}{k} = k;
                                mergeburstnumber{i}{k} = l;
                            end
                        end
                    end
                end
                
                
                % clean up the empty  cells
                
                for i =1:length(tobemergedbursts)
                    tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
                    mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
                    mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
                end
                
                %now we need remove the nnbursts that have less than 25% of the whole wwell
                %participating in the nnbursts
                
                % find the number of active channels
                amountactivechannels = length(find(~cellfun(@isempty,M2)));
                mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
                tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
                mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
                % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
                % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
                % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
                
                %the last step is to find duplicates and merge them together
                findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
                
                for i = 1:length(tobemergedbursts)
                    findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
                end
                
                
                
                for i = 1:length(tobemergedbursts)
                    if isempty(findoverlappingnnbursts{i})
                        continue
                    else
                        for k = 2:length(tobemergedbursts)
                            if isempty(findoverlappingnnbursts{k}) || k == i
                                continue
                            else
                                if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                                    % if this is true than there is overlap. so we need to find out
                                    % which one is longer and that will be the one remaining.
                                    if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                        findoverlappingnnbursts{k} = [];
                                    else
                                        findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                        findoverlappingnnbursts{k} = [];
                                    end
                                else
                                end
                            end
                        end
                    end
                end
                
                %lets use logical indezing to get rid of the overlapping nnbursts and
                %finally get our actual nnbursts
                
                tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
                mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
                mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
                findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
                
                % now that we have our nnbursts we can extract the ifnroamtion about the
                % nnbursts
                
                %struct for networkbursts
                networkburstttt =[];
                for i = 1:length(mergeburstnumber)
                    
                    networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
                    networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
                    networkburstttt.amount = length(mergeburstnumber);
                    networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
                    networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
                    networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
                    networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
                end
                
                for i = 1:length(mergeburstnumber)
                    if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                        networkburstttt.IBI(i,1) = 0;
                        continue
                    else
                        networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
                    end
                end
                
                % added the CV of IBI of nnbursts
                if isempty(networkburstttt)
                    networkburstttt.starttime = 0;
                    networkburstttt.endtime = 0;
                    networkburstttt.amount = 0;
                    networkburstttt.duration = 0;
                    networkburstttt.spikesfr_in_nbursts = 0;
                    networkburstttt.nburst_rate = 0;
                    networkburstttt.ISI = 0;
                    networkburstttt.IBI = 0;
                    networkburstttt.CVIBI= 0;
                else
                    networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
                end
                
                
            end
            
            
        elseif SCBflag == 0
            
            starttimesbursts2 = [];
            for i = 1:length(burst7)
                for j = 1:length(burst7{i})
                    starttimesbursts = burst7{i}{j}(1);
                    starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
                end
            end
            
            uniquestarttimesbursts = unique(starttimesbursts2); %these are the unique starttimes
            
            %now we need to put all the times in a giant matrix so we can
            %search in this matrix with the unique burst start times
            
            %convert all the cells into vectors
            % all the vectors are made equal in length by adding in nans
            temp = cell(1,length(burst7))';
            for i = 1:length(burst7)
                temp{i} = cell2mat(burst7{i});
            end
            
            newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
            newc=cell2mat(newc);
            
            
            % now we need to find if there are multiple channels that start
            % bursting at the same time
            channelnumbernnbursts =cell(1,length(burst7))';
            timeofnnbursts =cell(1,length(burst7))';
            for i = 1:length(uniquestarttimesbursts)
                [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) -  fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) +  fs.networkburstdetection.synchronizedtimewindow );
            end
            
            % check for duplicate channelnumbers if so remove them
            for i =1:length(channelnumbernnbursts)
                if isempty(channelnumbernnbursts{i})
                else
                    if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                        channelnumbernnbursts{i} = [];
                        timeofnnbursts{i}=[];
                    else
                        
                    end
                end
            end
            
            % now that we the channels that are synchronzied in their bursting
            % we need to remove the channels that do not fullfull our
            % requirements of have atleast 2 synchronized channels and atleast
            % 50% of the otal amount of channels should participate in the
            % nnburst or else it gets removed
            
            
            for i = 1:length(channelnumbernnbursts)
                if length(channelnumbernnbursts{i}) < fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                    channelnumbernnbursts{i} = [];
                    timeofnnbursts{i} = [];
                    uniquestarttimesbursts(i) = nan;
                end
            end
            
            %clean up by removing empty cells and nan values
            uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
            channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
            timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
            
            % now we need to find the bursts that are part of the synchronized
            % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
            % synchronzied bursts in other channels and then we can see how
            % many channels are participating
            
            burst7length =burst7; % create a cell array that is equal to burst7 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
            for i = 1:length(burst7)
                for j = 1:length(burst7{i})
                    burst7length{i}{j} = length(burst7{i}{j});
                end
            end
            
            for i = 1:length(burst7) % convert the cell arrays in vectors
                burst7length{i} = cell2mat(burst7length{i});
            end
            
            
            potentialnnbursts = cell(1,length(channelnumbernnbursts))';
            burstsindexcount=[];
            for i = 1:length(potentialnnbursts)
                for j = 1:length(channelnumbernnbursts{i})
                    for k = 1:cellfun(@length,(burst7(channelnumbernnbursts{i}(j))))
                        %figure out which bursts the indexes belong to
                        
                        %                      burstsindexcount = cellfun(@length,burst7{channelnumbernnbursts{i}(j)}); % old version that was slower
                        %                      burstsindexcount = cumsum( burstsindexcount); % old version
                        burstsindexcount = cumsum( burst7length{channelnumbernnbursts{i}(j)});
                        if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                            correctburst = k;
                            potentialnnbursts{i}{j} = burst7{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                            break
                        end
                    end
                end
            end
            
            % we have to check if the times of the bursts are within acceptable
            % ( check for nana values
            
            % create variable that is the exact same varible as potentialnnbursts
            % but intead each cell contains the mean + std of that channel to
            % improve the speed
            
            potentialnnburstsmean = potentialnnbursts;
            for i =1 :length(potentialnnbursts)
                potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 2.5*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
            end
            
            for i = 1:length(potentialnnbursts)
                for j = 1:length(potentialnnbursts{i})
                    %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                    if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                        potentialnnbursts{i}{j} = [];
                    end
                end
            end
            
            % now we need to use the synscho bursts to find if there are bursts that
            % fall within the same duration as the synchronized bursts. if they do then
            % they are part of the  potential network bursts
            % we loop through both synchronized bursts just to extra certain we do not
            % miss anything because the starttimes might be the same but the ending
            % time might not be.
            
            mergeburstchannel = cell(1,length(potentialnnbursts))';
            mergeburstnumber  = cell(1,length(potentialnnbursts))';
            tobemergedbursts  = cell(1,length(potentialnnbursts))';
            
            
            % create vaiable of potneialnnbursts that have all the cells converted into
            % vectors to improve the performance
            potentialnnburstsvector = potentialnnbursts;
            potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
            
            
            for i = 1:length(potentialnnburstsvector)
                potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
                potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
            end
            
            for i =1:length(potentialnnbursts)
                for k = 1:length(burst7)
                    for l = 1:length(burst7{k})
                        if ~isempty(find(burst7{k}{l} > potentialnnburstsvector{i,2}(1) & burst7{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                            tobemergedbursts{i}{k} =cell2mat(burst7{k}(l)) ;
                            mergeburstchannel{i}{k} = k;
                            mergeburstnumber{i}{k} = l;
                        end
                    end
                end
            end
            
            % clean up the empty  cells
            
            for i =1:length(tobemergedbursts)
                tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
                mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
                mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
            end
            
            %now we need remove the nnbursts that have less than 50% of the whole wwell
            %participating in the nnbursts
            
            % find the number of active channels
            amountactivechannels = length(find(~cellfun(@isempty,M2)));
            
            mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
            tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
            mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
            % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
            % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
            % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
            
            %the last step is to find duplicates and merge them together
            findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
            
            for i = 1:length(tobemergedbursts)
                findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
            end
            
            
            
            for i = 1:length(tobemergedbursts)
                if isempty(findoverlappingnnbursts{i})
                    continue
                else
                    for k = 2:length(tobemergedbursts)
                        if isempty(findoverlappingnnbursts{k}) || k == i
                            continue
                        else
                            if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  0.1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+0.1)))
                                % if this is true than there is overlap. so we need to find out
                                % which one is longer and that will be the one remaining.
                                if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                    findoverlappingnnbursts{k} = [];
                                else
                                    findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                    findoverlappingnnbursts{k} = [];
                                end
                            else
                                
                                
                            end
                        end
                    end
                end
            end
            
            %lets use logical indezing to get rid of the overlapping nnbursts and
            %finally get our actual nnbursts
            
            tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
            findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            
            % now that we have our nnbursts we can extract the ifnroamtion about the
            % nnbursts
            
            if isempty(findoverlappingnnbursts)
                networkburstttt.amount = 0;
                networkburstttt.duration = 0;
                networkburstttt.spikesfr_in_nbursts = 0;
                networkburstttt.nburst_rate = 0;
                networkburstttt.ISI = 0 ;
                networkburstttt.IBI = 0;
                networkburstttt.CVIBI = 0;
            else
                %struct for networkbursts
                networkburstttt =[];
                for i = 1:length(mergeburstnumber)
                    
                    networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
                    networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
                    networkburstttt.amount = length(mergeburstnumber);
                    networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
                    networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
                    networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
                    networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
                end
                
                for i = 1:length(mergeburstnumber)
                    if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                        networkburstttt.IBI(i,1) = 0;
                        networkburstttt.CVIBI = 0;
                        continue
                    else
                        networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
                    end
                end
                
                if isempty(networkburstttt)
                else
                    networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
                end
                
                
            end
            
            
        end
        
        %% For connectivity maps (Conditonal firing probabilities)
        
        % we will have to split the data aswell into their corresponding wells
        
        
        
        
        
        if cellfun(@isempty,M2)
            Connections = 0;
        else
            spikestimes = [M2{:}]; % this contains all the spikes times
            spikeslocations = zeros(1,length(spikestimes));
            correctcounter = 0;
            
            for i = 1:length(M2)
                if i == 1
                else
                    correctcounter = correctcounter + length(M2{i-1});
                end
                for j = 1:length(M2{i})
                    if i == 1
                        spikeslocations(j) = i;
                    else
                        spikeslocations(j+correctcounter) = i;
                    end
                end
            end
            
            [sortedspikestimes, Indexes] = sort(spikestimes);
            sortedspikeslocations = spikeslocations(Indexes);
            
            % for easier writing
            Ts = sortedspikestimes;
            Cs = sortedspikeslocations;
            
            if Ts < 2^15
                Connections = 0;
            else
                %Now we need to divide the data in chunks of 2^15 spikes (32768)
                
                minchunk = floor(length(Cs)/2^15);
                leftover = length(Cs)-minchunk*2^15;
                divdata = cell(1,minchunk);   %contains channellocations
                divdataTs = cell(1,minchunk); %contains spiketimes
                
                for i =1:minchunk
                    if i == 1
                        divdata{i}(1,:) = Cs(1:2^15);
                        divdataTs{i}(1,:) = Ts(1:2^15);
                    else
                        m = i * 2^15;
                        k = ((i-1) * 2^15) + 1;
                        divdata{i}(1,:) = Cs(k:m);
                        divdataTs{i}(1,:) = Ts(k:m);
                    end
                end
                
                
                %%reorganize the data for each chunk to make it easeir to process it
                
                sortchunks = cell(1,minchunk);
                
                for i =1:length(sortchunks)
                    for j = 1:length(M2) % total amount of channels
                        sortchunks{i}{j} = divdataTs{i}(divdata{i} == j);
                    end
                end
                
                for i =1:length(sortchunks)
                    sortchunks{i} =sortchunks{i}';
                end
                
                % now the spikes in each chunk is sorted to which channel it belongs too
                
                %now we need to calculate the CFP curves
                
                max_t = 0.5; % the max window in which the correlation is calculated over in seconds (500ms)
                binsize = 0.005 ; % 5 ms resolution is used by the paper lefeber et al., 2007
                xbin_centers = 0-binsize:binsize:max_t+binsize; %unwanted bins will be removed
                cc = zeros(size(xbin_centers));
                correctlen = length(cc)-2;
                
                supa=cell(1,length(sortchunks{1})); % change to length(M2)
                CFP = cell(1,length(sortchunks));
                for aa = 1:length(sortchunks) % iteration through the chunks
                    for i=1:length(sortchunks{aa}) % iteration throuch channel '1' one side
                        if isempty(sortchunks{aa}{i,1})
                            supa{i}=[];
                            continue
                        end
                        finalssss=zeros(length(sortchunks{aa}(:,1)),correctlen);
                        for j=1:length(sortchunks{aa}) % iteration throuch channel '2' other side
                            if isempty(sortchunks{aa}{j,1})
                                supa{i}=[];
                                continue
                            else
                                spk_t1 = sortchunks{aa}{j} ; %contains spike train timings in seconds of train 1
                                spk_t2 = sortchunks{aa}{i} ; %contains spike train timings in seconds of train 2
                                if length(spk_t1) < 250 || length(spk_t2) <250 % skip the channels that have less than 250 spikes
                                    continue
                                else
                                    for iSpk = 1:length(spk_t1) % iteration through all the spikes in spiketrain 1
                                        relative_spk_t = spk_t2 - spk_t1(iSpk);
                                        cc = cc + hist(relative_spk_t,xbin_centers); % note that histc puts all spikes outside the bin centers in the first and last bins! delete later.
                                    end
                                    cc = cc(2:end-1); % remove 2 unwanted bins
                                    cc = cc./(length(spk_t1)); % normalize by number of spikes of first input like the conditional firing probability of Lefeber et al ., (2007)
                                    finalssss(j,:) = cc;
                                    finalssss(i,:)=zeros(1,correctlen);  % remove the autocorrelation
                                    cc = zeros(size(xbin_centers)); % make it empty again for the next iteration
                                end
                            end
                        end
                        supa{i}=finalssss;
                    end
                    CFP{aa} = supa';
                end
                
                delay = 0:5:500;
                bingrootte = 0.005;
                % Fs = FileInfo.samplefrequency;
                M=zeros(length(M2),length(M2)); Tt=zeros(length(M2),length(M2)); OFFSET=zeros(length(M2),length(M2)); VORM=zeros(length(M2),length(M2));
                OPP=zeros(length(M2),length(M2)); % in deze matrices gaat het model
                % i is het eerst vurende neuron, j het dan vurende neuron
                allM = cell(1,length(CFP));
                allTt = cell(1,length(CFP));
                allOFFSET = cell(1,length(CFP));
                allVORM = cell(1,length(CFP));
                allOPP = cell(1,length(CFP));
                
                mapping = 1:length(M2);
                AantSpikes = cellfun(@length,sortchunks{1});
                actiefdrempel=250; %threshold for active electrodes
                a=find(AantSpikes>=actiefdrempel); % bekijk alleen kanalen met minstens 250 spikes
                tekenen = 0;
                
                % Here the active channels are selected.  "actiefdrempel" sets the
                % threshold number of spikes recorded in an active channel
                % a is an array that contains the numbers of all active electrodes (1-60)
                % you can set i and j to the indices of a that refer to the channels that
                % you're interested in.
                
                for aa = 1:length(CFP)
                    supa = CFP{aa};
                    for i=1:length(a)
                        for j=1:length(a)
                            AA = (supa{a(i)}(a(j),:));
                            if tekenen==1
                                plot(delay,AA);
                                grid on;
                            end
                            if i~=j
                                if tekenen==1
                                    hold on; V=axis; misfit=0; axis normal;
                                end
                                
                                test=find(AA==max(AA))*(bingrootte/10);
                                Po=[max(AA) 10 test(1) 0]; % eerste gok
                                options=optimset('MaxFunEvals',1e9,'TolFun',1e-20);
                                P=Po;
                                P=fminsearch(@(P) errorfun(delay,AA,P),Po,options);
                                Mtekst=''; tctekst='';
                                if P(3)<1; P(3)=0; end
                                if P(1)<P(4) % M<offset
                                    Mtekst='/ aangepast.      SNR te laag';
                                    tctekst=['/ niet van belang; M=0'];
                                    P(1)=0; P(4)=mean(AA); misfit=1;
                                end
                                if ((P(2)<2) | (P(2)>250)) % v moet liggen tussen 10 en 250 msec
                                    misfit=1; P(1)=0; P(4)=mean(AA);
                                    Mtekst='/ aangepast.   v buiten grenzen.';
                                end
                                if (P(3)>250)  % tau-c > 250
                                    misfit=1;  P(1)=0; P(4)=mean(AA);
                                    Mtekst='/ aangepast.   tc > 250.';
                                end
                                M(a(i),a(j))=P(1); VORM(a(i),a(j))=P(2);
                                Tt(a(i),a(j))=P(3); OFFSET(a(i),a(j))=P(4);
                                OPP(a(i),a(j))=sum((Amsdatafitfun(delay,P)-P(4))*(bingrootte/10));
                                if tekenen==1 % om de fit te tekenen: 1 invullen.
                                    if misfit axis square; end
                                    plot(delay,Amsdatafitfun(delay,P),'r');
                                    text(400,0.7*V(4),['OPP: ' num2str(OPP(a(i),a(j)))]);
                                    text(400,.95*V(4),['M = ' num2str(P(1)) Mtekst]);
                                    text(400,.9*V(4),['tc = ' num2str(P(3)) tctekst]);
                                    text(400,.85*V(4),['offset = ' num2str(P(4))]);
                                    text(400,.8*V(4),['v = ' num2str(P(2))]);
                                    hold off
                                end
                            end
                            if tekenen==1
                                xlabel('Delay [msec]');
                                ylabel(['CFP electr.' num2str(mapping(a(j))) ' (' num2str(AantSpikes(a(j))) ' sp) | electr.' num2str(mapping(a(i))) ' (' num2str(AantSpikes(a(i))) 'sp)']);
                                %             ylabel(['CFP electr.' num2str((a(j))) ' (' num2str(AantSpikes(a(j))) ' sp) | electr.' num2str((a(i))) ' (' num2str(AantSpikes(a(i))) 'sp)']);
                                title(['Conditional firing probability (' datafile ')']);pause
                            end
                        end
                        
                    end
                    allM{aa} = M;
                    allT{aa} = Tt;
                    allVORM{aa} = VORM;
                    allOFFSET{aa} = OFFSET;
                    allOPP{aa} = OPP;
                end
                
                clear A AA Cy V tekenen a i j test DT Mtekst tctekst TotalChance options
                clear AlBekeken Po P V C Xm Xn b h k m n nn status tc x3 misfit
                
                for i =1:length(sortchunks)
                    if i ==1
                        M = allM{i};
                    else
                        M = M + allM{i};
                    end
                end
                
                M = M/length(sortchunks);
                
                
                meanconnect = length(find((M>0)));
                Connections = meanconnect;
                clear meanconnect
            end
        end
        
        waitbar(0 + 1,hh,'Finished Analysis(CSV)');
        
        close(hh)
        %% save variables
        joost =1; %flag for data without voltage traces
        
        %change the channelIDs to numbers fro the GUI
        %save the actual names into a different variable for use later
        HITS2 = HITS;
        temp =  num2cell(1:length(HITS(:,1)));
        HITS(:,1) = temp';
        %add .mat to the selecteddata
        %     selecteddata = [selecteddata,'.mat'];
        mkdir Analyzedfiles
        selecteddata2 = strcat(selecteddata,sprintf('_Well_%d',iiii));
        save([selecteddata2, '.mat'],'parts','electrodecount','multiwell1' ,'joost','M','Tt','VORM','OFFSET','OPP','NetworkBurstStart','networkburstttt','supa','burst6indx','burst7indx','BNeuroSEM','BLogSEM','INDEX1','Connections','BDSEM','posunitsSEM','negunitsSEM','HITSSEM','logburst','posunits','negunits','looo12','Spikeform4','M66','M99','M111','M222','BD','BLog','BNeuro','M88','burst7','textstrings','newM2','Exburst','fs','HITS','timesss','X2','filteredData1','RMS7','noiseall18','noiseall2','burstsinfor','ISI58','Spikeform3','burstview2','burstview3','unitpersecond','burstview19','burstview20','xpoints','ypoints','ends2','starts2','ypointsburst1','Bap','Bal','Bab','Bak','T','selecteddata','layout','ans90','BI','Imax','M2','imaxch','imaxch2','burst6','bincountssec','binranges4567','-v7.3');
        selecteddata1 = strcat(selecteddata2,sprintf('.mat'));
        movefile(selecteddata1,'Analyzedfiles');
 
        
        %% clear variables
        clear networkburstttt
         %% empty all the cells to save time
            filteredData1 = [];
            burst6 = [];
            Spikeform3 = [];
            Spikeform4 = [];
            burstview19 = [];
            burstview20 = [];
            Exburst = [];
            M2 =[];
            logburst =[];
            T = [];
            noiseall18 = [];
            noiseall2 =[];
            burstview2 = [];
            burstview3 =[];
            xpoints = [];
            ypoints =[];
            newM2 = [];
            M88 = [];
            bincountssec = [];
            binranges4567 = [];
            ends2 =[];
            starts2 = [];
            burst7 = [];
            M66 = [];
            M99 = [];
            M88 = [];
            M111 = [];
            M222 = [];
            networkburstttt=[];
    else
        
        Spikeform3 = Data3;
    end
    
    
end




% need to open a special variant of the GUI without any visualisations

clear totaldura


multiwell
msgbox(sprintf('Succesfully completed the analysis of a multiwell'))










