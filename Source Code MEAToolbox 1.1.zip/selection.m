function selection(src,event)
global selecteddata xpoints parts xPoints yPoints timesss M2 cbx989 max1bursts cbx2000 joost

val = cbx2000.Value;
% str = src.String;
% str{val};
% disp(['Selection: ' str{val}]);

% load the data from the correct well
% it starts at well_1

    for i = 2:25
        checked =sprintf('Well_%d',i);
        if isempty(regexp(selecteddata,checked))
            continue
        else
            oldname = sprintf('Well_%d',i);
            selecteddata = strrep(selecteddata,oldname,'Well_1');
        end
    end
    
    if joost == 1
        range2 = cell(1,24);
        UUU= 1:16;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+16;
        end
    else
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
    end
    selecteddata2 = selecteddata;
    replace1 = sprintf('Well_%d',1);
    replace2 = sprintf('Well_%d',val);
    selecteddata = replace(selecteddata,replace1,replace2);
    load(selecteddata,'M2')
    load(selecteddata,'xpoints')
    xpoints=sort(xpoints);
    selecteddata = selecteddata2;
   
    %create a new xpoints variable that contains al the xpoints
    if ~isempty(xpoints)
        timesss = ceil(max(xpoints));
    end
    
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
    %     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    if ~isempty(N)
        s = conv(N,kernel);
        s = s/resolution;
        %Find the index of the kernel center
        center = ceil(length(edges)/2);
        %     Trim out the relevant portion of the spike density
        s = s(center:end-center-1);
        %     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
        t = (1:length(s))*resolution ;
    end
    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy);
    
    if ~isempty(N)
        plot(t,s,'k');
        xlim([0 timesss])
    end
    
    ylabel('Array Wide Firing Rate (Hz)');
    xlabel('Time(s)','Fontsize',20);
    correctxlim = get(gca,'XLim');
    
   
    gg = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    cla(gg);
    
    if ~isempty(N)
        nTotalSpikes = sum(cellfun(@length,M2));
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;
        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            % Save points and update current index
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        
        plot(xPoints, yPoints, 'k')
    end
    cbx989.Value = 0;
    
    %correct ylim
    correctylim = val *12;
    correctylim = (correctylim - 12):2: correctylim;
    set(gca,'YtickLabel',correctylim);
%     xlim(correctxlim);
    title(sprintf('Array Wide Activity of Well %d',val));
end