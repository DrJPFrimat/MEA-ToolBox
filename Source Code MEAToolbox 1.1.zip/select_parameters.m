
% Create a figure window:

global fig cbx99 cbx32 cbx15 cbx16 cbx17 cbx cbx18 cbx19  cbx30 cbx31 cbx28 cbx29 cbx26 cbx27 cbx1 cbx2 cbx3 cbx4 cbx5 cbx6 cbx7 cbx8 cbx9 cbx10 cbx11 cbx12 cbx13 cbx14 cbx20 cbx21 cbx22 cbx23 cbx24 cbx25


fig = uifigure('Position',[300 300 429 476]);
set(fig,'color','white');
uilabel(fig, ...
    'Text', 'Select parameters for visualization', ...
    'Position', [100 420 250 30])

%overall checkbox to select series or groups
cbx99 = uicheckbox(fig,'Position',[15 447 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx99.Text = 'Calculate Data';



% Create a check boxes:
cbx = uicheckbox(fig,'Position',[55 407 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx.Text = 'Fire rate';
cbx.Enable ='off';

cbx1 = uicheckbox(fig,'Position',[55 387 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx1.Text = 'Burst rate';
cbx1.Enable ='off';

cbx2 = uicheckbox(fig,'Position',[55 367 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx2.Text = 'Amount of spikes in burst';
cbx2.Enable ='off';

cbx3 = uicheckbox(fig,'Position',[55 347 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx3.Text = 'Percentage spikes in burst';
cbx3.Enable ='off';

cbx4 = uicheckbox(fig,'Position',[55 327 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx4.Text = 'Coefficient of variation of the ISIs (CV)';
cbx4.Enable ='off';

cbx5 = uicheckbox(fig,'Position',[55 307 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx5.Text = 'Burst duration';
cbx5.Enable ='off';

cbx6 = uicheckbox(fig,'Position',[55 287 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx6.Text = 'Interburst interval';
cbx6.Enable ='off';

cbx7 = uicheckbox(fig,'Position',[55 267 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx7.Text = 'Synchrony';
cbx7.Enable ='off';

cbx8 = uicheckbox(fig,'Position',[55 247 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx8.Text = 'Normalized MAD burst spike number';
cbx8.Enable ='off';

cbx9 = uicheckbox(fig,'Position',[55 227 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx9.Text = 'Median ISI/Mean ISI';
cbx9.Enable ='off';

cbx10 = uicheckbox(fig,'Position',[55 207 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx10.Text = 'ISI';
cbx10.Enable ='off';

cbx11 = uicheckbox(fig,'Position',[55 187 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx11.Text = 'Maximum aplitude of spikes';
cbx11.Enable ='off';

cbx12 = uicheckbox(fig,'Position',[55 167 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx12.Text = 'Amount of bursts';
cbx12.Enable ='off';

cbx13 = uicheckbox(fig,'Position',[55 147 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx13.Text = 'Amount of network bursts';
cbx13.Enable ='off';

cbx14 = uicheckbox(fig,'Position',[55 127 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx14.Text = 'Connections';
cbx14.Enable ='off';

cbx16 = uicheckbox(fig,'Position',[125 407 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx16.Text = 'Mean';
cbx16.Visible = 'off';
cbx16.Enable ='off';

cbx17 = uicheckbox(fig,'Position',[175 407 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx17.Text = 'Median';
cbx17.Visible = 'off';
cbx17.Enable ='off';

cbx18 = uicheckbox(fig,'Position',[130 387 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx18.Text = 'Mean';
cbx18.Visible = 'off';
cbx18.Enable ='off';

cbx19 = uicheckbox(fig,'Position',[180 387 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx19.Text = 'Median';
cbx19.Visible = 'off';
cbx19.Enable ='off';

cbx20 = uicheckbox(fig,'Position',[215 367 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx20.Text = 'Mean';
cbx20.Visible = 'off';
cbx20.Enable ='off';

cbx21 = uicheckbox(fig,'Position',[265 367 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx21.Text = 'Median';
cbx21.Visible = 'off';
cbx21.Enable ='off';


cbx22 = uicheckbox(fig,'Position',[155 307 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx22.Text = 'Mean';
cbx22.Visible = 'off';
cbx22.Enable ='off';

cbx23 = uicheckbox(fig,'Position',[205 307 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx23.Text = 'Median';
cbx23.Visible = 'off';
cbx23.Enable ='off';

cbx24 = uicheckbox(fig,'Position',[175 287 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx24.Text = 'Mean';
cbx24.Visible = 'off';
cbx24.Enable ='off';

cbx25 = uicheckbox(fig,'Position',[225 287 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx25.Text = 'Median';
cbx25.Visible = 'off';
cbx25.Enable ='off';


cbx26 = uicheckbox(fig,'Position',[95 207 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx26.Text = 'Mean';
cbx26.Visible = 'off';
cbx26.Enable ='off';


cbx27 = uicheckbox(fig,'Position',[145 207 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx27.Text = 'Median';
cbx27.Visible = 'off';
cbx27.Enable ='off';


cbx28 = uicheckbox(fig,'Position',[225 187 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx28.Text = 'Mean';
cbx28.Visible = 'off';
cbx28.Enable ='off';

cbx29 = uicheckbox(fig,'Position',[275 187 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx29.Text = 'Median';
cbx29.Visible = 'off';
cbx29.Enable ='off';


cbx30 = uicheckbox(fig,'Position',[175 167 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx30.Text = 'Mean';
cbx30.Visible = 'off';
cbx30.Enable ='off';

cbx31 = uicheckbox(fig,'Position',[225 167 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx31.Text = 'Median';
cbx31.Visible = 'off';
cbx31.Enable ='off';


cbx15 = uicheckbox(fig,'Position',[55 107 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx15.Text = 'Coefficient of variation of IBIs';
cbx15.Enable ='off';


cbx32 = uicheckbox(fig,'Position',[55 87 302 15],...
    'ValueChangedFcn',@(cbx,event) cBoxChanged(cbx));
cbx32.Text = 'Get all Data';
cbx32.Enable ='off';


