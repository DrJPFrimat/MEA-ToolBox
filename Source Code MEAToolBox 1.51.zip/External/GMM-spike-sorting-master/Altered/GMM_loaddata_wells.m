function GMM_loaddata_wells(A,B)

global handles1 data selecteddata channelnames M2 Spikeform3 HITS multiwell1 parts Spikeform4 joost

handles1.newdata = 0;
try
    if multiwell1 == 1
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
        
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if contains(selecteddata,'Well')
                if isempty(regexp(selecteddata,checked))
                    continue
                else
                    oldname = sprintf('Well_%d',i);
                    selecteddata = strrep(selecteddata,oldname,'Well_1');
                end
            else
                selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
            end
        end
        
        
        
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        end
        
        
        allspikes = cell(1,12*parts)';
        allwaves = cell(1,12*parts)';
        allwaves2 = cell(1,12*parts)';
        HITA = cell(2,288)';
        for i = 1:parts
            load(selecteddata,'HITS')
            load(selecteddata,'M2')
            load(selecteddata,'Spikeform3')
            load(selecteddata,'Spikeform4')
            HITA(range2{i}(1):range2{i}(end)) = HITS(1:12);
            HITA(range2{i}(1):range2{i}(end),2) = HITS(1:12,2);
            allspikes(range2{i}(1):range2{i}(end)) = M2(1:12);
%             allspikes(range2{i}(1):range2{i}(end),2) = M2(1:12,2);
            allwaves(range2{i}(1):range2{i}(end)) = Spikeform3(1:12);
            allwaves2(range2{i}(1):range2{i}(end)) = Spikeform4(1:12);
%             allwaves(range2{i}(1):range2{i}(end),2) = Spikeform3(1:12,2);
            replace1 =sprintf('Well_%d',i);
            replace2 = sprintf('Well_%d',i+1);
            selecteddata = replace(selecteddata,replace1,replace2);
        end
        Spikeform4 = allwaves2;
        Spikeform3= allwaves;
        M2 = allspikes;
        clear allwaves allspikes allwaves2
        % for i = 61:288
        %     HITA{i,1} = num2str(HITA{i,1});
        % end
        
        
        channelss = cell(1,288)';
        
        for i = 1:288
            channelss{i} = num2str(i);
            
        end
        
        HITA(:,1) = channelss;
        %
        % for i = 61:288
        %     HITA{i,1} = num2str(HITA{i,1});
        % end
        HITS = HITA;
        clear HITA
    else
    end
    
    
     
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if contains(selecteddata,'Well')
                if isempty(regexp(selecteddata,checked))
                    continue
                else
                    oldname = sprintf('Well_%d',i);
                    selecteddata = strrep(selecteddata,oldname,'Well_1');
                end
            else
                selecteddata = strcat(selecteddata,sprintf('_Well_1.mat'));
            end
        end
    
    
    %     [filename, path]= uigetfile;
    filename =selecteddata;
    if filename~=0
        %% creating the data
        
        if joost == 1
        else
            for i =1:length(Spikeform3)
                Spikeform3(i) = {[Spikeform3{i}, Spikeform4{i}]};
                if size(Spikeform3{i},2) < 10
                    Spikeform3{i} = [];
                end
            end
            
            for i =1:length(Spikeform3)
                Spikeform3(i) = {[Spikeform3{i}, Spikeform4{i}]};
                if size(Spikeform3{i},2) > length(M2{i})
                    removeal1 = abs(size(Spikeform3{i},2) - length(M2{i}));
                    Spikeform3{i}(:,(end-(removeal1-1)):end) = [];
                end
            end
            
        end
        
        
        
        Data3=Spikeform3;
        for i=1:length(Data3)
            if length(Data3{i}) == 1
                Data3{i}=[];
            end
            
        end
        Data3=Data3';
        
        for i=1:length(Data3)
            Data3{i}=Data3{i}';
        end
        
        Data4=M2;
        
        Data4=Data4';
        
        for i=1:length(Data4)
            Data4{i}=Data4{i}';
        end
        
        
        for i=1:length(Data4)
            if isempty(Data4{i})
                continue
            elseif isempty(Data3{i})
                Data4{i}=[];
            else
                ppp=length(Data3{i}(:,1));
                Data4{i}=Data4{i}(1:ppp);
            end
        end
        
        data.waveforms=Data3;
        data.spiketimes=Data4;
        
        % now we need to concatenate the channels together that belong to
        % the same well.
       
       wells_waveforms = cell(1,parts);
       wells_spiketimes =cell(1,parts);
     
        for i = 1:parts
         wells_waveforms{i}  = data.waveforms(i*(1:12));
         wells_spiketimes{i} = data.spiketimes(i*(1:12));
        end
        
        % now we need to concatenate the 12 channels in each well into one
        % cell so we end up with one cell containing all the waveforms for
        % each well

        for i =1:parts
             wells_waveforms{i} = vertcat(wells_waveforms{i}{:});
             wells_spiketimes{i} = vertcat(wells_spiketimes{i}{:});
        end
        
        
        data.waveforms=wells_waveforms;
        data.spiketimes=wells_spiketimes;
        
        
        % We need to correct for overestmation of waveforms in channels
        % that have less than 10 spikes
        correctindx = cellfun(@isempty,M2);
        needscorrectionindx = cellfun(@isempty,Spikeform3);
        [ie,~] = find(needscorrectionindx - correctindx);
        data.waveforms(ie) = [];
        data.spiketimes(ie) = [];
        % remove any channel that less then 10 spikes
        
        
        for i=1:length(data.waveforms)
            if isempty(data.waveforms{i})
                continue
            elseif length(data.waveforms{i}(:,1)) < 10
                data.waveforms{i}=[];
                data.spiketimes{i}=[];
                
            end
        end
        
        %get the index number so we can use it later to find the correct channel
        %name
        
        channelnum=find(~cellfun(@isempty,data.waveforms));
        channelnames=HITS(channelnum);
        
        data.waveforms=data.waveforms(~cellfun('isempty',data.waveforms));
        data.spiketimes=data.spiketimes(~cellfun('isempty',data.spiketimes));
        
        clear Data3 Data4 ppp i Spikeform3 Spikeform4
        
        %check to see if there any finite numbers (nan or inf values)
        %if there are then remvoe the waveforms
        
        
        
        for j=1:length(data.waveforms)
            for i=1:length(data.waveforms{j}(:,1))
                if any(isnan(data.waveforms{j}(i,:))) == 1
                    data.waveforms{j}(i,:)=nan;
                    data.spiketimes{j}(i)=nan;
                else
                    continue
                end
            end
        end
        %remove any nan values
        
        for i=1:length(data.waveforms)
            data.waveforms{i}(~any(~isnan(data.waveforms{i}), 2),:)=[];
            data.spiketimes{i}(~any(~isnan(data.spiketimes{i}), 2),:)=[];
        end
        
        
        %%        load(fullfile(path,filename));
        handles1.data.waveforms = data.waveforms;
        handles1.dataaux.nchannels = length(data.waveforms);
        handles1.newdata = 1;
        handles1.filename = filename;
        
        try
            handles1.data = rmfield(handles1.data,'class_id');
            handles1.data = rmfield(handles1.data,'clustering_space');
            handles1.data = rmfield(handles1.data,'classification_uncertainty');
        catch e
            
        end
        
        
        if ~isfield(data,'class_id')
            handles1.data.class_id = cell(1,handles1.dataaux.nchannels);
            for ch_i = 1:handles1.dataaux.nchannels
                handles1.data.class_id{ch_i} = ...
                    nan(size(handles1.data.waveforms{ch_i},1),1);
            end
            handles1.dataaux.class_id = handles1.data.class_id;
        else
            handles1.data.class_id = data.class_id;
            handles1.dataaux.class_id = handles1.data.class_id;
        end
        
        if ~isfield(data,'clustering_space')
            handles1.data.clustering_space = handles1.data.class_id;
            handles1.data.classification_uncertainty = ...
                handles1.data.class_id;
        else
            handles1.data.clustering_space = data.clustering_space;
            handles1.data.classification_uncertainty = data.classification_uncertainty;
        end
        
        %         if ~isfield(data,'maxuncertainty')
        %             handles1.data.maxuncertainty = 5*ones(handles1.dataaux.nchannels,1);
        %             handles1.dataaux.maxuncertainty = handles1.data.maxuncertainty;
        %         else
        %             handles1.data.maxuncertainty = data.maxuncertainty;
        %             handles1.dataaux.maxuncertainty = data.maxuncertainty;
        %         end
        
        if ~isfield(data,'model')
            handles1.data.model = cell(1,handles1.dataaux.nchannels);
            handles1.dataaux.model = handles1.data.model;
        else
            handles1.data.model = data.model;
            handles1.dataaux.model = handles1.data.model;
        end
        
        if ~isfield(data,'spiketimes')
            handles1.data.spiketimes = cell(1,handles1.dataaux.nchannels);
            for ch_i = 1:handles1.dataaux.nchannels
                handles1.data.spiketimes{ch_i} = ...
                    zeros(size(handles1.data.waveforms{ch_i},1),1);
            end
        else
            handles1.data.spiketimes = data.spiketimes;
        end
        
        
        handles1.dataaux.nelectrodes = size(handles1.data.waveforms{1},3);
        if handles1.dataaux.nelectrodes>1
            nelec=handles1.dataaux.nelectrodes;
            for ch_i = 1:handles1.dataaux.nchannels
                concatwaveforms=[];
                for ielec = 1:nelec
                    concatwaveforms = [concatwaveforms squeeze(handles1.data.waveforms{ch_i}(:,:,ielec))];
                end
                handles1.data.waveforms{ch_i} = concatwaveforms;
            end
        end
    end
catch errormsg
    display(errormsg.message)
end

if isempty(handles1.data.waveforms)
    set(handles1.Figures.Waveforms.maintext ,'String',...
        'Waveforms not loaded.')
elseif ~iscell(handles1.data.waveforms)
    set(handles1.Figures.Waveforms.maintext ,'String',...
        'Waveforms file should be a cell.')
else
    if handles1.newdata
        
        msgaux = [num2str(handles1.dataaux.nchannels) ' wells loaded.'];
        
        handles1.chid = 1;
        set(handles1.Figures.Waveforms.maintext,'String',msgaux)
        %  set(handles1.Figures.Waveforms.filename,'String',handles1.filename)
        
        popupaux= cellfun(@num2str,num2cell(1:handles1.dataaux.nchannels),'Uniformoutput',0);
        set(handles1.Figures.Waveforms.ch_id,'String', popupaux,'Value',handles1.chid)
        handles1.Figures.Waveforms.ch_id.String=channelnames;
        
        GMM_plotwaveforms
        if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
            GMM_showclusters
        end
        
    end
    
end

end
