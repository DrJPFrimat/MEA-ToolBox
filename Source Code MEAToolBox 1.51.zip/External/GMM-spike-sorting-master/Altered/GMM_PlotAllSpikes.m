
function [ ] = GMM_PlotAllSpikes( class_i )

global handles1

class_idx = handles1.data.class_id{handles1.chid}==class_i;
auxplot = handles1.data.waveforms{handles1.chid}';
auxplot = auxplot(:,class_idx);

wave_max = 1000;
if handles1.Config.Plot==1
    if size(auxplot,2)>wave_max
        [v, irand]=sort(rand(1,size(auxplot,2)));
        auxplot = auxplot(:,irand(1:wave_max));
    end
end

plot(auxplot,'color',...
    handles1.dataaux.class_colors(class_i,:))
axis tight
ylim(handles1.Figures.Waveforms.ylim)
box off

end
