function GMM_setCHid(A,B)

global handles1 handles plotforclusters displaychannel

chid = get(handles1.Figures.Waveforms.ch_id,'value');

if isnan(chid)
    set(handles1.Figures.Waveforms.ch_id,...
        'string',num2str(handles1.chid));
    set(handles1.Figures.Waveforms.maintext,'String',...
        'Channel id must be a number.')
elseif ~mod(chid,1)==0
    set(handles1.Figures.Waveforms.ch_id,...
        'string',num2str(handles1.chid));
    set(handles1.Figures.Waveforms.maintext,'String',...
        'Channel id must be an integer.')
elseif chid<=0
    set(handles1.Figures.Waveforms.ch_id,...
        'string',num2str(handles1.chid));
    set(handles1.Figures.Waveforms.maintext,'String',...
        'Channel id must be positive.')
elseif chid>handles1.dataaux.nchannels
    set(handles1.Figures.Waveforms.ch_id,...
        'string',num2str(handles1.chid));
    set(handles1.Figures.Waveforms.maintext,'String',...
        ['We have only ' num2str(handles1.dataaux.nchannels) ...
        'channels in the loaded file.'])
else

    
    handles1.chid = chid;
    
    handles1.Figures.Clusters.viewspikesVector=unique(handles1.data.class_id{handles1.chid}(~isnan(handles1.data.class_id{handles1.chid})));
    
    GMM_plotwaveforms
    if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
        GMM_showclusters
    end
%     figure(handles1.Figures.Waveforms.main)
       checkbox4 = findobj('Tag','checkbox4');
       if isempty(checkbox4)
           if displaychannel == 0
               clear checkbox4
               checkbox4.Value = 0;
           else
           end
           checkbox4.Value = 0;
       end
    if checkbox4.Value == 1
             set(handles1.Figures.Waveforms.maintext,'String',...
            ['Displaying well: ' ...
            num2str(handles1.chid)])
        set(handles1.Figures.Waveforms.maintext,'String',['Displaying well: ',handles1.Figures.Waveforms.ch_id.String(chid)]);
    elseif checkbox4.Value == 0
        set(handles1.Figures.Waveforms.maintext,'String',...
            ['Displaying channel: ' ...
            num2str(handles1.chid)])
        set(handles1.Figures.Waveforms.maintext,'String',['Displaying channel: ',handles1.Figures.Waveforms.ch_id.String(chid)]);
    end
  
    handles1.Figures.Waveforms.maintext.String = strcat( handles1.Figures.Waveforms.maintext.String{1}, handles1.Figures.Waveforms.maintext.String{2});
    
    if chid > 1
        cla(plotforclusters);
        handles1.Figures.Clusters.viewspikesList.Visible = 'off';
        handles1.Figures.Clusters.changemodeBUTTON.Visible = 'off';
        handles1.Figures.Clusters.recalculateButton.Visible = 'off';
        handles1.Figures.Clusters.deleteButton.Visible = 'off';
        handles1.Figures.Waveforms.DispClustersTOGGLE.Visible = 'off';
        handles1.Figures.Waveforms.resetSorting.Visible = 'off';
        handles1.Figures.Waveforms.EditUnsorted.Visible = 'off';
        handles1.Figures.Waveforms.DiscardUnsorted.Visible = 'off';
        handles1.Figures.Waveforms.PlotAllTOGGLE.Visible = 'off';
    end
    
    
end