function GMM_showclusters( A,B )

global handles1 plotforclusters 
handles1.Figures.Clusters.viewspikesList.Visible = 'on';
handles1.Figures.Clusters.changemodeBUTTON.Visible = 'on';
handles1.Figures.Clusters.recalculateButton.Visible = 'on';
handles1.Figures.Clusters.deleteButton.Visible = 'on';

% if 1==1 %isfield(handles1.data,'clustering_space')
    if ~isfield(handles1.Figures,'Clusters') || ~isfield(handles1.Figures.Clusters,'main')
        handles1.Figures.Clusters.main = plotforclusters;
        %         figure('units','normalized','position',[.1 .1 .7 .8]);clf
        %         set(handles1.Figures.Clusters.main, 'MenuBar', 'none');
        
        GMM_drawclusters
    else
        GMM_resetclusters
    end
    GMM_plotclusteringspace(1)
    
    % %  Use this to always activate the stability and crosscorrelation
    % %  analyses
    %     GMM_plotstability(3)
    %     GMM_runxcorr
    
% end
end

function GMM_drawclusters( A,B )
global handles1 plotforclusters plotforclusterstability clustertag buttontag
clustertag = 1 ;

% axes('Parent',handles.uipanel17);
% figure(handles1.Figures.Clusters.main)
% set(gcf,'color','w')

positionaux = [0.04 .45 .4 .45];
handles1.Figures.Clusters.subplots(1) = plotforclusters;
%     subplot('Position',positionaux);cla

% positionaux = [0.55 .45 .4 .45];
% handles1.Figures.Clusters.subplots(2) = ...
%    plotforclusters ;cla
% %    subplot('Position',positionaux);cla


handles1.Figures.Clusters.currentaxes = [1 2];


nof_dimensions = size(handles1.data.clustering_space{handles1.chid},2);
if nof_dimensions==1
    handles1.Figures.Clusters.currentaxes = [1 1];
end

subplotaux = 1;
positionaux = [0.005 .525 .023 .375];
handles1.Figures.Clusters.display_y(subplotaux) = ...
    uicontrol('Style', 'popup',...
    'Units','normalized',...
    'String', 1:nof_dimensions,...
    'Position', positionaux,...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'Callback',@GMM_set_xydim_cluster,...
    'fontsize',15,...
    'horizontalAlignment', 'center','Visible','off');
set(handles1.Figures.Clusters.display_y(subplotaux),'Value',...
    handles1.Figures.Clusters.currentaxes(1))

positionaux = [0.42 .045 .023 .375];
handles1.Figures.Clusters.display_x(subplotaux) = ...
    uicontrol('Style', 'popup',...
    'Units','normalized',...
    'String', 1:nof_dimensions,...
    'Position', positionaux,...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'Callback',@GMM_set_xydim_cluster,...
    'fontsize',15,...
    'horizontalAlignment', 'center','Visible','off');
set(handles1.Figures.Clusters.display_x(subplotaux),'Value',...
    handles1.Figures.Clusters.currentaxes(2))



classlabels = handles1.data.class_id{handles1.chid};
classlabels = unique(classlabels(~isnan(classlabels)));

popupauxGSF = cellfun(@num2str,num2cell(classlabels),'Uniformoutput',0);
popupauxGSF{end+1} = 'all';
nclasses = length(classlabels);

handles1.Figures.Clusters.getspikesfrom = uicontrol('units','normalized',...
    'Style','popup',...
    'Position',[0.17 0.93 0.045 0.02],...
    'String',popupauxGSF,...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'fontsize',15,'Visible','off');
set(handles1.Figures.Clusters.getspikesfrom,'value',nclasses+1)


handles1.Figures.Clusters.viewspikesText = uicontrol('units','normalized',...
    'Style','text',...
    'Position',[0.45 0.83 0.045 0.04],...
    'String','Plot:',...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'fontsize',15,'Visible','off');

handles1.Figures.Clusters.viewspikesList = uicontrol('units','normalized',...
    'Style','list','max',8,'min',1,...
    'Position',[0.7 0.46 0.05 0.08],...
    'String',popupauxGSF,...
    'Value',1,...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'Callback',@GMM_ChangeView,...
    'fontsize',15);


if isfield(handles1.Figures.Clusters,'mode_status')
    switch handles1.Figures.Clusters.mode_status
        case 1
            mode_aux='Waveforms';
        case 2
            mode_aux='Components';
        case 3
            mode_aux='Clusters';
    end
else
    if nclasses>0
        set(handles1.Figures.Clusters.viewspikesList,'value',nclasses+1)
    end
    handles1.Figures.Clusters.mode_status = 1;
    mode_aux = 'Waveforms';
end

handles1.Figures.Clusters.changemodeBUTTON = uicontrol('units','normalized',...
    'Style','pushbutton',...
    'Position',[0.418 0.5 0.1 0.04],...
    'String',mode_aux,...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_ChangeMode,...
    'fontsize',14,...
    'horizontalAlignment', 'center','FontWeight','bold','CData',imread('color_button.png'));

handles1.Figures.Clusters.changevisualizationBUTTON = uicontrol('units','normalized',...
    'Style','togglebutton',...
    'Position',[0.38 0.92 0.05 0.04],...
    'String','%',...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'Callback',@GMM_ChangeVisualization,...
    'fontsize',14,...
    'horizontalAlignment', 'center','Visible','off');



if isfield(handles1.Figures.Clusters,'viewspikesVector')
    if sum(~isnan(handles1.Figures.Clusters.viewspikesVector))
        set(handles1.Figures.Clusters.viewspikesList,'value',handles1.Figures.Clusters.viewspikesVector)
    end
else
    set(handles1.Figures.Clusters.viewspikesList,'value',nclasses+1)
    handles1.Figures.Clusters.viewspikesVector = classlabels;
end
% 
% 
% handles1.Figures.Clusters.mergeButton = uicontrol('units','normalized',...
%     'Style','pushbutton',...
%     'Position',[0.45 0.64 0.05 0.04],...
%     'String','Merge',...
%     'BackgroundColor', [1 1 1]*1,...
%     'ForegroundColor', [1 1 1]*0,...
%     'Callback',@GMM_mergeclusters,...
%     'fontsize',15);

handles1.Figures.Clusters.deleteButton = uicontrol('units','normalized',...
    'Style','pushbutton',...
    'Position',[0.518 0.46 0.1 0.04],...
    'String','Delete',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_deleteclusters,...
    'fontsize',14,'FontWeight','bold','CData',imread('color_button.png'));

handles1.Figures.Clusters.recalculateButton = uicontrol('units','normalized',...
    'Style','pushbutton',...
    'Position',[0.418 0.46 0.1 0.04],...
    'String','ReSort',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_recalculateclusters,...
    'fontsize',14,'FontWeight','bold','CData',imread('color_button.png'));
% 
% 
% handles1.Figures.Clusters.moveto = uicontrol('units','normalized',...
%     'Style','pushbutton',...
%     'Position',[0.55 0.92 0.09 0.04],...
%     'Callback', @GMM_MoveTo,...
%     'BackgroundColor', [1 1 1]*1,...
%     'ForegroundColor', [1 1 1]*0,...
%     'String','Move spikes to:',...
%     'fontsize',15);
% 
classlabels = handles1.data.class_id{handles1.chid};
classlabels = unique(classlabels(~isnan(classlabels)));

popupauxBCK = {num2str(classlabels)};
popupauxBCK{end+1} = 'unsorted';
popupauxBCK{end+1} = 'new cluster';
% popupauxBCK{end+1} = '';
nclasses = length(classlabels);

handles1.Figures.Clusters.selectedBKGNtemplateH = uicontrol('units','normalized',...
    'Style','popup',...
    'Position',[0.65 0.93 0.09 0.02],...
    'String',popupauxBCK,...
    'callback',@GMM_change_bck_template,...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'fontsize',15,'Visible','off'); 
set(handles1.Figures.Clusters.selectedBKGNtemplateH,'value',nclasses+2)

GMM_setselectedspks(zeros(length(handles1.data.class_id{handles1.chid}),1)==1);

handles1.Figures.Clusters.startpolygon = ...
    uicontrol ('Style', 'pushbutton', 'String', 'Select from:','Units',...
    'normalized','Position',[0.075 0.92 0.085 0.04],...
    'Callback', @GMM_startpolygon,...
    'fontsize',14,...
    'BackgroundColor', [1 1 1]*.9,'ForegroundColor', [1 1 1]*0,'Visible','off');

% 
% positionaux = [0.04 .05 .4 .3];
% handles1.Figures.Clusters.crosscorrelation = ...
%     subplot('Position',positionaux);
% axes(handles1.Figures.Clusters.crosscorrelation)
% ylabel('r','fontsize',16)
% xlabel('Time (ms)','fontsize',16)
% title('Cross-correlation','fontsize',18)
% 
% handles1.Figures.Clusters.crosscorrelationN1 = uicontrol('units','normalized',...
%     'Style','popup',...
%     'Position',[0.005 0.335 0.023 0.02],...
%     'String',{num2str(classlabels)},...
%     'Value',1,...
%     'BackgroundColor', [1 1 1]*1,...
%     'ForegroundColor', [1 1 1]*0,...
%     'fontsize',15,...
%     'callback',@GMM_runxcorr,'Visible','off');
% 
% handles1.Figures.Clusters.crosscorrelationN2 = uicontrol('units','normalized',...
%     'Style','popup',...
%     'Position',[0.005 0.3 0.023 0.02],...
%     'String',{num2str(classlabels)},...
%     'Value',1,...
%     'BackgroundColor', [1 1 1]*1,...
%     'ForegroundColor', [1 1 1]*0,...
%     'fontsize',15,...
%     'callback',@GMM_runxcorr,'Visible','off');
% 
% 
% 
positionaux = [0.55 .05 .4 .3];
handles1.Figures.Clusters.subplots(3) = plotforclusterstability ;
% ylabel('Peak-to-valley','fontsize',16)
% xlabel('Time (min)','fontsize',16)
% title('Cluster Stability','fontsize',18)

ax2 = axes('Position', get(handles1.Figures.Clusters.subplots(3),'Position'),...
    'XAxisLocation','top',...
    'YAxisLocation','right',...
    'Xtick',[],...
    'Color','none','Visible','off');

handles1.Figures.Clusters.subplots(4) = ax2;


handles1.Figures.Clusters.stability = uicontrol('units','normalized',...
    'Style','popup',...
    'String',{num2str(classlabels)},...
    'Position',[0.42 0.335 0.023 0.02],...
    'Value',1,...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'fontsize',15,...
    'callback',@GMM_changestability,'Visible','on');

end


function GMM_updateclusters( A,B )
global handles1
% 
% figure(handles1.Figures.Clusters.main)

axes(handles1.Figures.Clusters.subplots(1));cla
% axes(handles1.Figures.Clusters.subplots(2));cla

if ~isfield(handles1.Figures.Clusters,'currentaxes')
    handles1.Figures.Clusters.currentaxes = [1 2];
end

nof_dimensions = size(handles1.data.clustering_space{handles1.chid},2);

subplotaux = 1;


if sum(handles1.Figures.Clusters.currentaxes(1:2)>nof_dimensions)
    handles1.Figures.Clusters.currentaxes(1:2)=1;
end
set(handles1.Figures.Clusters.display_y(subplotaux),...
    'String', 1:nof_dimensions,...
    'Value', handles1.Figures.Clusters.currentaxes(1))

set(handles1.Figures.Clusters.display_x(subplotaux),...
    'String', 1:nof_dimensions,...
    'Value', handles1.Figures.Clusters.currentaxes(2))


classlabels = handles1.data.class_id{handles1.chid};
classlabels = unique(classlabels(~isnan(classlabels)));
popupauxGSF = {num2str(classlabels)};
popupauxGSF{end+1} = 'all';
nclasses = length(classlabels);

set(handles1.Figures.Clusters.getspikesfrom,...
    'String',popupauxGSF,...
    'value',nclasses+1)


set(handles1.Figures.Clusters.viewspikesList,...
    'String',popupauxGSF)

set(handles1.Figures.Clusters.viewspikesList,...
    'Value',length(handles1.Figures.Clusters.viewspikesList))


if isfield(handles1.Figures.Clusters,'mode_status')
    switch handles1.Figures.Clusters.mode_status
        case 1
            mode_aux='Waveforms';
        case 2
            mode_aux='Components';
        case 3
            mode_aux='Clusters';
    end
else
    set(handles1.Figures.Clusters.viewspikesList,'value',nclasses+1)
    handles1.Figures.Clusters.mode_status = 1;
    mode_aux = 'Waveforms';
end

set(handles1.Figures.Clusters.changemodeBUTTON,...
    'String',mode_aux)
    
if isfield(handles1.Figures.Clusters,'viewspikesVector')
    if(~isnan(handles1.Figures.Clusters.viewspikesVector))
        set(handles1.Figures.Clusters.viewspikesList,'value',handles1.Figures.Clusters.viewspikesVector)
    end
else
    set(handles1.Figures.Clusters.viewspikesList,'value',nclasses+1)
    handles1.Figures.Clusters.viewspikesVector = classlabels;
end


popupauxBCK = {num2str(classlabels)};
popupauxBCK{end+1} = 'unsorted';
popupauxBCK{end+1} = 'new cluster';

set(handles1.Figures.Clusters.selectedBKGNtemplateH,...
    'String',popupauxBCK,...
    'value',nclasses+2)

GMM_setselectedspks(zeros(length(handles1.data.class_id{handles1.chid}),1)==1);

% axes(handles1.Figures.Clusters.crosscorrelation)
% cla
% 
% axes(handles1.Figures.Clusters.subplots(3))
% cla
% axes(handles1.Figures.Clusters.subplots(4))
% cla
% 
% set(handles1.Figures.Clusters.crosscorrelationN1,...
%     'String',{num2str(classlabels)},...
%     'Value',1);
% 
% set(handles1.Figures.Clusters.crosscorrelationN2,...
%     'String',{num2str(classlabels)},...
%     'Value',1);
% 
% 
% set(handles1.Figures.Clusters.stability,...
%     'String',{num2str(classlabels)},...
%     'Value',1);

end


function GMM_resetclusters( A,B )
global handles1


classlabels = handles1.data.class_id{handles1.chid};
classlabels = unique(classlabels(~isnan(classlabels)));
nclasses = length(classlabels);

% set(handles1.Figures.Clusters.viewspikesList,'value',nclasses+1)
handles1.Figures.Clusters.viewspikesVector = classlabels;

GMM_updateclusters

end

function [] = GMM_recalculateclusters(A,B)
    
global handles1

    
clusters = handles1.Figures.Clusters.viewspikesVector;
clusters = sort(clusters);

clusterid = handles1.data.class_id{handles1.chid};
idx = 0*clusterid==1;

idel= handles1.data.model{handles1.chid}.class*0==1;

for i_class=1:length(clusters)
    idx=idx | clusterid==clusters(i_class);
    
    idel= idel | handles1.data.model{handles1.chid}.class==clusters(i_class);

end

new_model = GMM_recalculateSorting(handles1.data.clustering_space{handles1.chid}(idx,:));

if ~isempty (new_model)

    handles1.data.model{handles1.chid}.mu=handles1.data.model{handles1.chid}.mu(~idel,:);
    handles1.data.model{handles1.chid}.alpha=handles1.data.model{handles1.chid}.alpha(~idel);
    handles1.data.model{handles1.chid}.S=handles1.data.model{handles1.chid}.S(~idel,:,:);
    handles1.data.model{handles1.chid}.class=handles1.data.model{handles1.chid}.class(~idel);
    nclass = max(handles1.data.model{handles1.chid}.class);
    if isempty(nclass)
        nclass=0;
    end
    
    handles1.data.model{handles1.chid}.mu = cat(1,handles1.data.model{handles1.chid}.mu,new_model.mu);
    handles1.data.model{handles1.chid}.alpha = cat(1,handles1.data.model{handles1.chid}.alpha,...
        new_model.alpha*(1-sum(handles1.data.model{handles1.chid}.alpha)));
    handles1.data.model{handles1.chid}.S = cat(1,handles1.data.model{handles1.chid}.S,new_model.S);
    handles1.data.model{handles1.chid}.class = [handles1.data.model{handles1.chid}.class...
        nclass+new_model.class];

    [~,cluster_probability] = gm_pdf(handles1.data.model{handles1.chid},handles1.data.clustering_space{handles1.chid}(:,:));
    [~,id_cluster] = max(cluster_probability,[],2);

    clusterid(:) = handles1.data.model{handles1.chid}.class(id_cluster);
    
    clusterlabels = unique(clusterid(~isnan(clusterid)));

    for i = 1:length(clusterlabels);

        clusspikes = clusterid==clusterlabels(i);
        handles1.data.class_id{handles1.chid}(clusspikes) = i;

        handles1.data.model{handles1.chid}.class(handles1.data.model{handles1.chid}.class==clusterlabels(i)) = i;

    end
    handles1.Figures.Clusters.viewspikesVector = 1:length(clusterlabels);

    %%

    GMM_plotwaveforms
    if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
        GMM_showclusters
    end

end
end

function [ ] = GMM_deleteclusters(A,B)

global handles1


    %%
    
clusters = handles1.Figures.Clusters.viewspikesVector;
clusters = sort(clusters);

clusterid = handles1.data.class_id{handles1.chid};
idx = 0*clusterid==1;

idel= handles1.data.model{handles1.chid}.class*0==1;

for i_class=1:length(clusters)
    idx=idx | clusterid==clusters(i_class);
    
    idel= idel | handles1.data.model{handles1.chid}.class==clusters(i_class);

end

handles1.data.model{handles1.chid}.mu=handles1.data.model{handles1.chid}.mu(~idel,:);
handles1.data.model{handles1.chid}.alpha=handles1.data.model{handles1.chid}.alpha(~idel)/...
    sum(handles1.data.model{handles1.chid}.alpha(~idel));
handles1.data.model{handles1.chid}.S=handles1.data.model{handles1.chid}.S(~idel,:,:);
handles1.data.model{handles1.chid}.class=handles1.data.model{handles1.chid}.class(~idel);



[~,cluster_probability] = gm_pdf(handles1.data.model{handles1.chid},handles1.data.clustering_space{handles1.chid}(idx,:));
% [~,cluster_probability(:,~idel)] = gm_pdf(handles1.data.model{handles1.chid},handles1.data.clustering_space{handles1.chid}(idx,:));
[~,id_cluster] = max(cluster_probability,[],2);

clusterid(idx) = handles1.data.model{handles1.chid}.class(id_cluster);

% handles1.data.model{handles1.chid}.class(clusters) = clusters(1);

clusterlabels = unique(clusterid(~isnan(clusterid)));

for i = 1:length(clusterlabels);
    
    clusspikes = clusterid==clusterlabels(i);
    handles1.data.class_id{handles1.chid}(clusspikes) = i;
    
    handles1.data.model{handles1.chid}.class(handles1.data.model{handles1.chid}.class==clusterlabels(i)) = i;
    
end
handles1.Figures.Clusters.viewspikesVector = 1:length(clusterlabels);

%%


GMM_plotwaveforms
if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
    GMM_showclusters
end

end


function [ ] = GMM_mergeclusters(A,B)

global handles1

clusters = handles1.Figures.Clusters.viewspikesVector;
clusters = sort(clusters);

clusterid = handles1.data.class_id{handles1.chid};
idx = 0*clusterid==1;
for i=1:length(clusters)
    final_model = min(find(handles1.data.model{handles1.chid}.class==clusters(i)));
    if ~isempty(final_model)
        break;
    end
end
for i_class=1:length(clusters)
    idx=idx | clusterid==clusters(i_class);
    
    
    handles1.data.model{handles1.chid}.class(handles1.data.model{handles1.chid}.class==clusters(i_class)) = ...
        handles1.data.model{handles1.chid}.class(final_model);
end
clusterid(idx)=clusters(i);


clusterlabels = unique(clusterid(~isnan(clusterid)));

for i = 1:length(clusterlabels);
    
    clusspikes = clusterid==clusterlabels(i);
    handles1.data.class_id{handles1.chid}(clusspikes) = i;
    
    handles1.data.model{handles1.chid}.class(handles1.data.model{handles1.chid}.class==clusterlabels(i)) = i;
    
end
handles1.Figures.Clusters.viewspikesVector = 1:length(clusterlabels);

GMM_plotwaveforms
if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
    GMM_showclusters
end


end

function [] = GMM_CheckActiveElements()
global handles1

set(handles1.Figures.Clusters.display_x(1),'enable','on');
set(handles1.Figures.Clusters.display_y(1),'enable','on');
set(handles1.Figures.Clusters.getspikesfrom,'enable', 'on');
set(handles1.Figures.Clusters.changevisualizationBUTTON,'enable', 'on');
set(handles1.Figures.Clusters.startpolygon,'enable','on')

if (get(handles1.Figures.Clusters.changevisualizationBUTTON,'value'))
    set(handles1.Figures.Clusters.startpolygon,'enable','off')
end

switch handles1.Figures.Clusters.mode_status
    case 1
        % Showing Clusters!
        set(handles1.Figures.Clusters.changevisualizationBUTTON,'enable', 'on');
        set(handles1.Figures.Clusters.startpolygon,'enable','on')
    case 2
        % Showing Waveforms!
        set(handles1.Figures.Clusters.getspikesfrom,'enable', 'off');
        set(handles1.Figures.Clusters.display_x(1),'enable','off');
        set(handles1.Figures.Clusters.display_y(1),'enable','off');
        
        
    case 3
        % Showing Components!
        set(handles1.Figures.Clusters.getspikesfrom,'enable', 'off');
        set(handles1.Figures.Clusters.display_x(1),'enable','off');
        set(handles1.Figures.Clusters.display_y(1),'enable','off');
        
        
end



end

function [] = GMM_ChangeVisualization(A,B)
    global handles1

    if get(handles1.Figures.Clusters.changevisualizationBUTTON,'value')
        set(handles1.Figures.Clusters.changevisualizationBUTTON,'string','=')
    else
        set(handles1.Figures.Clusters.changevisualizationBUTTON,'string','%')
    end
    

    GMM_plotclusteringspace(1);

end

function [] = GMM_ChangeMode(A,B)

global handles1


switch handles1.Figures.Clusters.mode_status
    case 1
        % Show Waveforms!
        handles1.Figures.Clusters.mode_status=2;
        next_mode='Components';
        
    case 2
        % Show Components!
        handles1.Figures.Clusters.mode_status=3;
        next_mode='Clusters';

    case 3
       
        % Show Clusters!
        handles1.Figures.Clusters.mode_status=1;
        next_mode='Waveforms';
        
end

set(A,'String',next_mode)


GMM_plotclusteringspace(1)

end

function [] = GMM_ChangeView(A,B)

global handles1

classlabels = handles1.data.class_id{handles1.chid};
classlabels = unique(classlabels(~isnan(classlabels)));
nclasses = length(classlabels);
    
if get(A,'value')>nclasses
handles1.Figures.Clusters.viewspikesVector=1:nclasses;
else
handles1.Figures.Clusters.viewspikesVector=get(A,'value');
end

GMM_plotclusteringspace(1)

end

function [] = GMM_set_xydim_cluster(A,B)

global handles1

subplotaux = [find(handles1.Figures.Clusters.display_y==A) ...
    find(handles1.Figures.Clusters.display_x==A)];

GMM_plotclusteringspace(subplotaux)


end

function [] = GMM_plotclusteringspace(subplotaux)

global handles1


GMM_CheckActiveElements

axes(handles1.Figures.Clusters.subplots(subplotaux));
cla(handles1.Figures.Clusters.subplots(subplotaux));


dimx = get(handles1.Figures.Clusters.display_x(subplotaux),'value');
dimy = get(handles1.Figures.Clusters.display_y(subplotaux),'value');


handles1.Figures.Clusters.currentaxes = [dimy dimx];

class_id = handles1.data.class_id{handles1.chid};
class_id = class_id(~isnan(class_id));
classlabels = unique(class_id);
nclasses = length(classlabels);
if sum(~isnan(handles1.data.clustering_space{handles1.chid}(1:10)))==0
    handles1.Figures.Clusters.mode_status =2;
    set(handles1.Figures.Clusters.changemodeBUTTON,'string','Components');
end
hold on
for class_i = 1:nclasses
%     handles1.Figures.Clusters.viewspikesVector
%     classlabels
    if ismember(class_i,handles1.Figures.Clusters.viewspikesVector)
        plotspikes = handles1.data.class_id{handles1.chid}==class_i;
        auxplot = find(plotspikes);
        wave_max = 1000;
        nwave = length(auxplot);
        if handles1.Config.Plot==1
            
            if nwave>wave_max
                [v, irand]=sort(rand(1,length(auxplot)));
                auxplot = auxplot(irand(1:wave_max));

            end            
        end
        
        switch handles1.Figures.Clusters.mode_status
            case 1
                if(max([dimx dimy])>size(handles1.data.clustering_space{handles1.chid},2))
                    set(handles1.Figures.Clusters.display_x(subplotaux),'value',1);
                    set(handles1.Figures.Clusters.display_y(subplotaux),'value',1);
                    dimx=1;
                    dimy=1;
                end

                if dimx~=dimy
                    plot(handles1.data.clustering_space{handles1.chid}(auxplot,dimx),...
                        handles1.data.clustering_space{handles1.chid}(auxplot,dimy),'.',...
                        'color',handles1.dataaux.class_colors(class_i,:))
                    
%                     try
                        for i_model=find(handles1.data.model{handles1.chid}.class==class_i)


                            weigth = 1+10*handles1.data.model{handles1.chid}.alpha(i_model)...
                                /sum(handles1.data.model{handles1.chid}.alpha);
                            offset = handles1.data.model{handles1.chid}.mu(i_model,[dimx,dimy]);
                            aux=linspace(0,2*pi,20);
                            x=cos(aux);
                            y=sin(aux);

                            circle = [x;y];
                            S = squeeze(handles1.data.model{handles1.chid}.S(i_model,[dimx,dimy],[dimx,dimy]));
                            [U, V] = eig(S);
                            elipse = bsxfun(@plus,offset',U*2*sqrt(V)*circle);
                            plot(elipse(1,:),elipse(2,:),'color',handles1.dataaux.class_colors(class_i,:),'linewidth',weigth)
                            plot(offset(1),offset(2),'o','color','k','markersize',8,'linewidth',4)
                            plot(offset(1),offset(2),'o','color',handles1.dataaux.class_colors(class_i,:),'markersize',8,'linewidth',2)
                        end
%                     catch e
%                         disp('Impossible to plot model elipses.')
%                     end
                    
%                     xlim(minmax(handles1.data.clustering_space{handles1.chid}(:,dimx)'))
%                     ylim(minmax(handles1.data.clustering_space{handles1.chid}(:,dimy)'))
                else
%                     [counts edges] = hist(handles1.data.clustering_space{handles1.chid}(auxplot,dimx),50);
%                     stem(edges(counts~=0),counts(counts~=0),'color',handles1.dataaux.class_colors(class_i,:))
                end
                
            case 2
                if get(handles1.Figures.Clusters.changevisualizationBUTTON,'value')
                    GMM_PlotPrctiles(handles1.data.waveforms{handles1.chid}(plotspikes,:)',...
                        handles1.dataaux.class_colors(class_i,:))
                else
                    plot(handles1.data.waveforms{handles1.chid}(auxplot,:)',...
                        'color',handles1.dataaux.class_colors(class_i,:))
                end
            case 3
                if get(handles1.Figures.Clusters.changevisualizationBUTTON,'value')
                    norm = zscore(handles1.data.clustering_space{handles1.chid});
                    GMM_PlotPrctiles(norm(plotspikes,:)',...
                        handles1.dataaux.class_colors(class_i,:))
                else
                    if (size(handles1.data.model{handles1.chid}.mu,2)>1)
                        norm = zscore(handles1.data.clustering_space{handles1.chid});
                        
                        plot(norm(auxplot,:)',...
                            'color',handles1.dataaux.class_colors(class_i,:))
                    else
                        plot(ones(length(auxplot),1),handles1.data.clustering_space{handles1.chid}(auxplot,1)',...
                            '.','color',handles1.dataaux.class_colors(class_i,:))
                    end    
                end
        end

    end
end
if nclasses == 0 & handles1.Figures.Clusters.mode_status==2
    plotspikes = isnan(handles1.data.class_id{handles1.chid});
    auxplot = find(plotspikes);
    wave_max = 1000;
    nwave = length(auxplot);
    if handles1.Config.Plot==1
        if nwave>wave_max
            [v, irand]=sort(rand(1,length(auxplot)));
            auxplot = auxplot(irand(1:wave_max));
            
        end
    end
    
        
    if get(handles1.Figures.Clusters.changevisualizationBUTTON,'value')
        GMM_PlotPrctiles(handles1.data.waveforms{handles1.chid}(plotspikes,:)',...
            [.8 .8 .8])
    else
        plot(handles1.data.waveforms{handles1.chid}(auxplot,:)',...
            'color',[.8 .8 .8])
    end
end
valid = ~isnan(handles1.data.class_id{handles1.chid});

switch handles1.Figures.Clusters.mode_status
    
    case 1
        if sum(~isnan(handles1.data.clustering_space{handles1.chid}(valid,dimx)))>0
            if dimx~=dimy
                xlim(minmax(handles1.data.clustering_space{handles1.chid}(valid,dimx)'))
                ylim(minmax(handles1.data.clustering_space{handles1.chid}(valid,dimy)'))
            else
                xlim(minmax(handles1.data.clustering_space{handles1.chid}(valid,dimx)'))
                axis tight
            end
        end
        
    case 2
        if sum(valid)==0
            valid = ~valid;
        end
            ymax = max(max(handles1.data.waveforms{handles1.chid}(valid,:)));
            ymin = min(min(handles1.data.waveforms{handles1.chid}(valid,:)));
            ylim([ymin ymax])
            xlim([1 size(handles1.data.waveforms{handles1.chid},2)])
    case 3
        %         ymax = max(max(handles1.data.clustering_space{handles1.chid}(valid,:)));
        %         ymin = min(min(handles1.data.clustering_space{handles1.chid}(valid,:)));
        %         ylim([ymin ymax])
        
        ylim(minmax(norm(:)'))
        xlim([1 size(handles1.data.clustering_space{handles1.chid},2)])
        
end
box off

% axis tight

end

function [] = GMM_changestability(A,B)

GMM_plotstability(3);


end

function [] = GMM_plotstability(subplotaux)

global handles1 plotforclusterstability

GMM_CheckActiveElements

axes(handles1.Figures.Clusters.subplots(4))
cla(handles1.Figures.Clusters.subplots(4));
axes(handles1.Figures.Clusters.subplots(subplotaux))
cla(handles1.Figures.Clusters.subplots(subplotaux));

dimx = handles1.Figures.Clusters.currentaxes(2);
dimy = handles1.Figures.Clusters.currentaxes(1);

class_i = get(handles1.Figures.Clusters.stability,'value');

% 
class_id = handles1.data.class_id{handles1.chid};
class_id = class_id(~isnan(class_id));
classlabels = unique(class_id);
nclasses = length(classlabels);

if(class_i<=nclasses)
    plotspikes = handles1.data.class_id{handles1.chid}==class_i;
   
    %     peaktovalley = diff(minmax(handles1.data.waveforms{handles1.chid}(plotspikes,:))');
    peaktovalley = abs(diff(minmax(handles1.data.waveforms{handles1.chid}(:,:))'));
    max_diff = max(peaktovalley);
    peaktovalley = peaktovalley(plotspikes);
    spks = handles1.data.spiketimes{handles1.chid}(plotspikes)*1000;
    beginend = minmax([spks(:)]');
    timebins = 0:1000:(beginend(end));
    
    hold on
    yyaxis left
    cla(handles1.Figures.Clusters.subplots(subplotaux));
    cla(handles1.Figures.Clusters.subplots(4));
    plot(spks/60000,peaktovalley,'.',...
        'color',handles1.dataaux.class_colors(class_i,:))
    hold off
    %     imagesc(zscore(handles1.data.clustering_space{handles1.chid}(plotspikes,:))');
    %     axis xy
    box off
    
    title('Cluster stability','fontsize',18)
    
    ylim([0 1.2*max_diff])
    xlim([0 max(timebins/60000)])
    ylabel('Peak-to-valley','fontsize',16)
    xlabel('Time (min)','fontsize',16)
%     ax2=handles1.Figures.Clusters.subplots(4);
%     axes(ax2)
    binnedspikes = hist(spks,timebins);
    firing_rate = conv(binnedspikes,rectwin(60),'same')/60;
    hold on
    yyaxis right
    cla(handles1.Figures.Clusters.subplots(subplotaux));
    cla(handles1.Figures.Clusters.subplots(4));
    plot(timebins/60000, firing_rate,'Parent', plotforclusterstability,...
        'color',[1 1 1]*.7,...
        'linewidth',2);
    set(gca,'YColor',[1 1 1]*.7)
    ylabel('Firing rate (Hz)','fontsize',16)
    xlim([0 max(timebins/60000)])
    ylim([0 max([10 max(firing_rate)])])
    hold off
    box off
   
    
end

end


function [ ] = GMM_PlotPrctiles( auxdata,c )

global handles1


auxplotprc = prctile(auxdata',[5,25,50,75,95]);
vecwidth = [1 2 4 2 1];

for i = 1:size(auxplotprc,1)
    hold on
    plot(auxplotprc(i,:),'color',...
        c,'linewidth',...
        vecwidth(i))
    
end
hold off
axis tight
ylim(handles1.Figures.Waveforms.ylim)
box off

end


function [] = GMM_startpolygon(A,B)

global handles1

try
    delete(handles1.Figures.Clusters.polygonhandle)
    delete(handles1.Figures.Clusters.inpolygonhandle)
end
GMM_setselectedspks(zeros(length(handles1.data.class_id{handles1.chid}),1)==1);

set(handles1.Figures.Clusters.startpolygon,'Enable','off') 


axes(handles1.Figures.Clusters.subplots(1))
try
    [vx,vy]=getline(handles1.Figures.Clusters.subplots(1),'close');
catch
    set(handles1.Figures.Clusters.startpolygon,'Enable','on')
    return
end


switch handles1.Figures.Clusters.mode_status
    case 1
        
        getspikesfrom_aux = get(handles1.Figures.Clusters.getspikesfrom,'value');
        getspikesfrom_str = get(handles1.Figures.Clusters.getspikesfrom,'string');
        getspikesfrom = getspikesfrom_str{getspikesfrom_aux};
        if strcmp(getspikesfrom,'all')
            spikes = ones(length(handles1.data.class_id{handles1.chid}),1);
            spikes = spikes & ~isnan(handles1.data.class_id{handles1.chid});
        else
            class_i = str2double(getspikesfrom);
            spikes = handles1.data.class_id{handles1.chid}==class_i;
        end
        
        dimx = get(handles1.Figures.Clusters.display_x(1),'value');
        dimy = get(handles1.Figures.Clusters.display_y(1),'value');
        
        
        xvalues = handles1.data.clustering_space{handles1.chid}(spikes,dimx);
        yvalues = handles1.data.clustering_space{handles1.chid}(spikes,dimy);
        idx = find(spikes);
        INsub = inpolygon(xvalues,yvalues,vx,vy);
        idx = idx(INsub);
        IN = spikes*0==1;
        IN(idx)=1==1;
%         plot(handles1.data.clustering_space{handles1.chid}(plotspikes,dimx),...
%             handles1.data.clustering_space{handles1.chid}(plotspikes,dimy),'.',...
%             'color',handles1.dataaux.class_colors(class_i,:))

        handles1.Figures.Clusters.inpolygonhandle = ...
            plot(xvalues(INsub),yvalues(INsub),'.','color',[1 1 1]*.9);
        
    case 2
        
        spikes =zeros(size(handles1.data.class_id{handles1.chid}));
        getspikesfrom = handles1.Figures.Clusters.viewspikesVector;
        
        for class_i = getspikesfrom(:)'
            spikes = spikes | handles1.data.class_id{handles1.chid}==class_i;
        end
        if isempty(getspikesfrom) | isnan(getspikesfrom)
            spikes = ~spikes;
        end
        %%
        yvalues = handles1.data.waveforms{handles1.chid}(spikes,:);
        xvalues = repmat(1:size(yvalues,2),size(yvalues,1),1);
        
        IN = linexpoly(vx,vy,xvalues,yvalues);        
        IN = find(IN==1);

        %%
        handles1.Figures.Clusters.inpolygonhandle = ...
            plot(xvalues(IN,:)',yvalues(IN,:)',...
            'color',[1 1 1]*0,...
            'linewidth',2);
        
        ispikes=find(spikes==1);
        IN = ispikes(IN);
        
%         plot(handles1.data.waveforms{handles1.chid}(plotspikes,:)',...
%             'color',handles1.dataaux.class_colors(class_i,:))
    case 3
        
        spikes =zeros(size(handles1.data.class_id{handles1.chid}));
        getspikesfrom = handles1.Figures.Clusters.viewspikesVector;
        for class_i = getspikesfrom(:)'
            spikes = spikes | handles1.data.class_id{handles1.chid}==class_i;
        end
        
        
        norm_clustering_space = zscore(handles1.data.clustering_space{handles1.chid});        
        yvalues = norm_clustering_space(spikes,:);
        
%         yvalues = handles1.data.clustering_space{handles1.chid}(spikes,:);
        xvalues = repmat(1:size(yvalues,2),size(yvalues,1),1);
        IN=zeros(1,size(xvalues,1));
        for i=1:size(xvalues,1)
            if ~isempty(polyxpoly(xvalues(i,:),yvalues(i,:),vx,vy))
                IN(i) = 1;
            end
        end
        IN = find(IN==1);
        
        
        handles1.Figures.Clusters.inpolygonhandle = ...
            plot(xvalues(IN,:)',yvalues(IN,:)',...
            'color',[1 1 1]*0,...
            'linewidth',2);
        
        ispikes=find(spikes==1);
        IN = ispikes(IN);
         
%         plot(handles1.data.clustering_space{handles1.chid}(plotspikes,:)',...
%             'color',handles1.dataaux.class_colors(class_i,:))
end

% dimx = get(handles1.Figures.Clusters.display_x(1),'value');
% dimy = get(handles1.Figures.Clusters.display_y(1),'value');
% 
% xvalues = handles1.data.clustering_space{handles1.chid}(:,dimx);
% yvalues = handles1.data.clustering_space{handles1.chid}(:,dimy);
% 
% IN = inpolygon(xvalues,yvalues,vx,vy);
% IN = spikes & IN;

GMM_setselectedspks(IN)
% GMM_change_bck_template(handles1.Figures.Clusters.selectedBKGNtemplateH)

hold(handles1.Figures.Clusters.subplots(1),'on');
handles1.Figures.Clusters.polygonhandle = ...
    plot(handles1.Figures.Clusters.subplots(1),vx,vy,'color',[1 1 1]*.9,'linewidth',3);




% axes(handles1.Figures.Clusters.subplots(2)),cla
% plot(handles1.data.waveforms{handles1.chid}(IN,:)','k')
% box off
% axis tight

% choosedialog

set(handles1.Figures.Clusters.startpolygon,'Enable','on') 

end

function [] = GMM_setselectedspks(spks)
    global handles1
    handles1.Figures.Clusters.SelectedSpks = spks;
    
    GMM_change_bck_template(handles1.Figures.Clusters.selectedBKGNtemplateH)
end

function [] = GMM_MoveTo(A,B)

global handles1

class_id = handles1.data.class_id{handles1.chid};
class_id = class_id(~isnan(class_id));
classlabels = unique(class_id);

IN = handles1.Figures.Clusters.SelectedSpks;
selectedoption = get(handles1.Figures.Clusters.selectedBKGNtemplateH,'value');
alloptions = get(handles1.Figures.Clusters.selectedBKGNtemplateH,'string');
willchange = unique(handles1.data.class_id{handles1.chid}(IN));

switch alloptions{selectedoption}
    case 'unsorted'
        handles1.data.class_id{handles1.chid}(IN) = nan;
    case 'new cluster'
        handles1.data.class_id{handles1.chid}(IN) = ...
            length(classlabels)+1;
        willchange=unique([willchange; length(classlabels)+1]);
    otherwise
        class = str2double(alloptions{selectedoption});
        handles1.data.class_id{handles1.chid}(IN) = ...
            class;
        willchange=unique([willchange; class]);
end


class_id = handles1.data.class_id{handles1.chid};
class_id = class_id(~isnan(class_id));
classlabels_old=classlabels;
classlabels = unique(class_id);

deleted_class=setdiff(classlabels_old,classlabels);
mode=1;
if ~isempty(deleted_class)
    handles1.data.model{handles1.chid}.mu=handles1.data.model{handles1.chid}.mu...
        (handles1.data.model{handles1.chid}.class~=deleted_class,:);
    handles1.data.model{handles1.chid}.S=handles1.data.model{handles1.chid}.S...
        (handles1.data.model{handles1.chid}.class~=deleted_class,:,:);
    handles1.data.model{handles1.chid}.alpha=handles1.data.model{handles1.chid}.alpha...
        (handles1.data.model{handles1.chid}.class~=deleted_class);
    
    handles1.data.model{handles1.chid}.class=handles1.data.model{handles1.chid}.class...
        (handles1.data.model{handles1.chid}.class~=deleted_class);
    
    mode = 0;


    clusterid = handles1.data.class_id{handles1.chid};
    for i = 1:length(classlabels);
        clusspikes = clusterid==classlabels(i);
        handles1.data.class_id{handles1.chid}(clusspikes) = i;

        handles1.data.model{handles1.chid}.class(handles1.data.model{handles1.chid}.class==classlabels(i)) = i;
    end
end
GMM_plotwaveforms(mode,willchange)
GMM_showclusters

end

function GMM_change_bck_template(A,B)

global handles1

%  cla(handles1.Figures.Clusters.subplots(1))
%  cla(handles1.Figures.Clusters.subplots(2))

    
IN = handles1.Figures.Clusters.SelectedSpks;
if sum(IN)>1
    
    plot(handles1.Figures.Clusters.subplots(2),handles1.data.waveforms{handles1.chid}(IN,:)','k')
%     set(handles1.Figures.Clusters.subplots(2),'box','off')
    axis(handles1.Figures.Clusters.subplots(2),'tight')
    hold(handles1.Figures.Clusters.subplots(2),'off')
end

optionselected = get(A,'value');
optionsstr = get(A,'string');

switch optionsstr{optionselected}
    case 'unsorted'
        
    case 'new cluster'
        
    otherwise
        class_i = str2double(optionsstr(optionselected));
    
        auxplot = handles1.data.waveforms{handles1.chid}';
        auxplot = ...
            auxplot(:,handles1.data.class_id{handles1.chid}==class_i);

        auxplotprc = prctile(auxplot',[5,25,50,75,95]);
        vecwidth = [1 2 4 2 1];

        hold(handles1.Figures.Clusters.subplots(2),'on')
        for i = 1:size(auxplotprc,1)
            plot(handles1.Figures.Clusters.subplots(2),auxplotprc(i,:),'color',...
                handles1.dataaux.class_colors(class_i,:),'linewidth',...
                vecwidth(i))
        end
        
end

end


function GMM_runxcorr(A,B)

global handles1

n1 = get(handles1.Figures.Clusters.crosscorrelationN1,'value');
n2 = get(handles1.Figures.Clusters.crosscorrelationN2,'value');


spiketimes = handles1.data.spiketimes{handles1.chid}*1000;

n1spks = spiketimes(handles1.data.class_id{handles1.chid}==n1);
n2spks = spiketimes(handles1.data.class_id{handles1.chid}==n2);

beginend = minmax([n2spks(:); n1spks(:)]');
timebins = (beginend(1)-1000):(beginend(end)+1000);

binnedspikes1 = hist(n1spks,timebins);
binnedspikes2 = hist(n2spks,timebins);

[crosscor,lags] = xcorr(binnedspikes2,binnedspikes1,30,'coeff');


axes(handles1.Figures.Clusters.crosscorrelation)
cla
if n1==n2
   crosscor(lags==0)=0;
end

bar(lags,crosscor,'facecolor',handles1.dataaux.class_colors(n2,:))
box off, axis tight
hold on
plot([0 0],ylim,'--','color',handles1.dataaux.class_colors(n1,:),'linewidth',4)
xlabel('Time (ms)','fontsize',16)
ylabel('r','fontsize',16)
hold off

if n1==n2
   title('Auto-correlogram','fontsize',18)
else
   title(['Cross-correlogram ' int2str(n1) '-' int2str(n2)],'fontsize',18)
end

end