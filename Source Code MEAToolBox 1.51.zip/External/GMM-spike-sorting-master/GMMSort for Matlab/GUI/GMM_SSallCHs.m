function GMM_SSallCHs(A,B)

global handles1

for chi = 1:handles1.dataaux.nchannels
    
    handles1.chid = chi;
%     set(handles1.Figures.Waveforms.ch_id,'String',...
%     set(handles1.Figures.Waveforms.ch_id,'Value',...
%         num2str(handles1.chid))
    handles1.Figures.Waveforms.ch_id.Value=handles1.chid;
    GMM_runSorting
    pause(.1)
    
end

end
