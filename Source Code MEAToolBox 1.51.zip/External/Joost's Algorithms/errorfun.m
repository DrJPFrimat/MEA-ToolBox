function Y=errorfun(x,y,P);
% Deze functie wordt gebruikt bij het fitten van kansverdelingen in
% amsdata.m
fout=sum( ((y-Amsdatafitfun(x,P))).^2   );
if P(1)<0;  fout=(fout+10)^2; end;
if P(3)<0;  fout=(fout+10)^2; end;
if P(4)<0;  fout=(fout+10)^2; end;
Y=fout;