function varargout = parameters(varargin)
% PARAMETERS MATLAB code for parameters.fig
%      PARAMETERS, by itself, creates a new PARAMETERS or raises the existing
%      singleton*.
%
%      H = PARAMETERS returns the handle to a new PARAMETERS or the handle to
%      the existing singleton*.
%
%      PARAMETERS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PARAMETERS.M with the given input arguments.
%
%      PARAMETERS('Property','Value',...) creates a new PARAMETERS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before parameters_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to parameters_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help parameters

% Last Modified by GUIDE v2.5 17-Mar-2021 16:21:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @parameters_OpeningFcn, ...
                   'gui_OutputFcn',  @parameters_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

% --- Executes just before parameters is made visible.
function parameters_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to parameters (see VARARGIN)


% ha = axes('units','normalized', ...
%             'position',[0 0 1 1]);
% 
% % Load in a background image and display it using the correct colors
% % The image used below, is in the Image Processing Toolbox.  If you do not have %access to this toolbox, you can use another image file instead.
% I=imread('background2.tif');
% 
% imshow(I, [], 'XData', [0 .5], 'YData', [0 0.3]);
% 
% 
% % Turn the handlevisibility off so that we don't inadvertently plot into the axes again
% % Also, make the axes invisible
% set(ha,'handlevisibility','off', ...
%             'visible','off')
% % Move the background axes to the bottom
% uistack(ha,'bottom');
% 
global fs changeflag SCBflag

 fs=[];
    fs.standardsettings.minimum_activity_channel = 0.1;
    fs.filtersettings.sampling_frequency=20000;
    fs.filtersettings.cut_off_frequency=200;
    fs.filtersettings.filter_order=2;
    fs.baselinenoise.window=50;
    fs.baselinenoise.purenoisewindow=2;
    fs.baselinenoise.RMS=5;
    fs.unitdetection.minpeakdistance=0;
    fs.unitdetection.minpeakprominence=0;
    fs.burstdetection.ISI=0.1;
    fs.burstdetection.nspikes=10;
    fs.burstdetectionmaxinterval.start=0.17;
    fs.burstdetectionmaxinterval.nspikes=10;
    fs.burstdetectionmaxinterval.IBI=0.3;
    fs.burstdetectionmaxinterval.intraBI=0.2;
    fs.burstdetectionmaxinterval.mindur=0.01;
    fs.burstdetectionlogisi.void=0.7;
    fs.burstdetectionlogisi.nspikes=3;
    fs.networkburstdetection.synchronizedtimewindow = 0.1; % time in seconds
    fs.networkburstdetection.minimumsynchronizedburstcount = 2; % in counts
    fs.networkburstdetection.minimumchannelparticipation = 0.5; % in percentage
    
    set(gcf,'Color','white');
    changeflag = 0;
    SCBflag = 1;


% Choose default command line output for parameters
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes parameters wait for user response (see UIRESUME)
% uiwait(handles.figure1);
end

% --- Outputs from this function are returned to the command line.
function varargout = parameters_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
end
%% filter parameter
% --- Executes during object creation, after setting all properties.
function uitable1_CreateFcn(hObject, eventdata, handles)
global fs
    
    
    fs.filtersettings.sampling_frequency=20000;
    fs.filtersettings.cut_off_frequency=200;
    fs.filtersettings.filter_order=2;
    
    hObject.Data{1,1}=num2str(fs.filtersettings.cut_off_frequency);
    hObject.Data{2,1}=num2str(fs.filtersettings.filter_order);
    hObject.Data{3,1}=num2str(fs.filtersettings.sampling_frequency);
 
end


% --- Executes when entered data in editable cell(s) in uitable1.
function uitable1_CellEditCallback(hObject, eventdata, handles)
global fs
 

currentvals = get(hObject, 'Data');
   
    fs.filtersettings.sampling_frequency=str2double(currentvals{3});
    fs.filtersettings.cut_off_frequency=str2double(currentvals{1});
    fs.filtersettings.filter_order= str2double(currentvals{2});
% assignin('main', 'word_vals', cell2mat(currentvals(2:end)) );



end
%% baseline noise detection parameters

% --- Executes during object creation, after setting all properties.
function uitable4_CreateFcn(hObject, eventdata, handles)
global fs

fs.baselinenoise.window=50;
fs.baselinenoise.purenoisewindow=2;


hObject.Data{1,1}=num2str(fs.baselinenoise.window);
hObject.Data{2,1}=num2str(fs.baselinenoise.purenoisewindow);




end


% --- Executes when entered data in editable cell(s) in uitable4.
function uitable4_CellEditCallback(hObject, eventdata, handles)
global fs
 
currentvals1 = get(hObject, 'Data');
fs.baselinenoise.window=str2double(currentvals1{1});
fs.baselinenoise.purenoisewindow=str2double(currentvals1{2});

% set(handles.uitable4, 'Data', fs.baselinenoise.window{1});

end
%% spike detection parameters
% --- Executes during object creation, after setting all properties.
function uitable5_CreateFcn(hObject, eventdata, handles)
global fs

fs.unitdetection.minpeakdistance=0;
fs.unitdetection.minpeakprominence=0;
fs.baselinenoise.RMS = 5;
fs.standardsettings.minimum_activity_channel = 0.1;
hObject.Data{1,1}=num2str(fs.unitdetection.minpeakdistance);
hObject.Data{2,1}=num2str(fs.unitdetection.minpeakprominence);
hObject.Data{3,1}=num2str(fs.baselinenoise.RMS);
hObject.Data{4,1}=num2str(fs.standardsettings.minimum_activity_channel );




end


% --- Executes when entered data in editable cell(s) in uitable5.
function uitable5_CellEditCallback(hObject, eventdata, handles)
global fs
 
currentvals2 = get(hObject, 'Data');
fs.unitdetection.minpeakdistance=str2double(currentvals2{1});
fs.unitdetection.minpeakprominence=str2double(currentvals2{2});
fs.baselinenoise.RMS=str2double(currentvals2{3});
fs.standardsettings.minimum_activity_channel=str2double(currentvals2{4});

end
%% single channel burst parameters
% --- Executes during object creation, after setting all properties.
function uitable7_CreateFcn(hObject, eventdata, handles)
global fs


fs.burstdetectionmaxinterval.start=0.17;
fs.burstdetectionmaxinterval.nspikes=10;
fs.burstdetectionmaxinterval.IBI=0.3;
fs.burstdetectionmaxinterval.intraBI=0.2;
fs.burstdetectionmaxinterval.mindur=0.01;
hObject.Data{1,1}=num2str(fs.burstdetectionmaxinterval.start);
hObject.Data{2,1}=num2str(fs.burstdetectionmaxinterval.nspikes);
hObject.Data{3,1}=num2str(fs.burstdetectionmaxinterval.IBI);
hObject.Data{4,1}=num2str(fs.burstdetectionmaxinterval.intraBI);
hObject.Data{5,1}=num2str(fs.burstdetectionmaxinterval.mindur);
end


% --- Executes when entered data in editable cell(s) in uitable7.
function uitable7_CellEditCallback(hObject, eventdata, handles)
global fs

currentvals4 = get(hObject, 'Data');
fs.burstdetectionmaxinterval.start=str2double(currentvals4{1});
fs.burstdetectionmaxinterval.nspikes=str2double(currentvals4{2});
fs.burstdetectionmaxinterval.IBI=str2double(currentvals4{3});
fs.burstdetectionmaxinterval.intraBI=str2double(currentvals4{4});
fs.burstdetectionmaxinterval.mindur=str2double(currentvals4{5});
end


% --- Executes during object creation, after setting all properties.
function uitable8_CreateFcn(hObject, eventdata, handles)
global fs

fs.burstdetectionlogisi.void=0.7;
fs.burstdetectionlogisi.nspikes=3;
hObject.Data{1,1}=num2str(fs.burstdetectionlogisi.void);
hObject.Data{2,1}=num2str(fs.burstdetectionlogisi.nspikes);
end


% --- Executes when entered data in editable cell(s) in uitable8.
function uitable8_CellEditCallback(hObject, eventdata, handles)
global fs

currentvals5 = get(hObject, 'Data');

fs.burstdetectionlogisi.void=str2double(currentvals5{1});
fs.burstdetectionlogisi.nspikes=str2double(currentvals5{2});
end
%% Save changes button
% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)

fh = findobj( 'Type', 'Figure', 'Name', 'Main_Menu_Toolbox' );
fh.Children(3).Enable = 'on';
fh.Children(4).Enable = 'on';
close('parameters')
end
%% network burst parameters
% --- Executes when entered data in editable cell(s) in uitable10.
function uitable10_CellEditCallback(hObject, eventdata, handles)
global fs
currentvals55 = get(hObject, 'Data');

fs.networkburstdetection.synchronizedtimewindow = str2double(currentvals55{1}); % time in seconds
fs.networkburstdetection.minimumsynchronizedburstcount = str2double(currentvals55{2}); % in counts
fs.networkburstdetection.minimumchannelparticipation = str2double(currentvals55{3}); % in percentage

end

% --- Executes during object creation, after setting all properties.
function uitable10_CreateFcn(hObject, eventdata, handles)
global fs

fs.networkburstdetection.synchronizedtimewindow = 0.1; % time in seconds
fs.networkburstdetection.minimumsynchronizedburstcount = 2; % in counts
fs.networkburstdetection.minimumchannelparticipation = 0.5; % in percentage

hObject.Data{1,1}=num2str(  fs.networkburstdetection.synchronizedtimewindow);
hObject.Data{2,1}=num2str( fs.networkburstdetection.minimumsynchronizedburstcount);
hObject.Data{3,1} = num2str(fs.networkburstdetection.minimumchannelparticipation);

end
%% check button for just spikes data
% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
global joost flag

if hObject.Value == 1
    joost = 1;
    flag = 1;
else
    joost = 0;
    flag = 0;
end

end

% --- Executes during object creation, after setting all properties.
function checkbox1_CreateFcn(hObject, eventdata, handles)
global joost flag
joost = 0;
flag = 0;
hObject.String = 'Data : Only Spike Timestamps';
hObject.Position =[0.617 0.413 0.2 0.028];
hObject.BackgroundColor=[1 1 1];
hObject.FontWeight = 'bold';
end
%% create file that is compatbile with toolbox
%(standrad file format) the only thing the toolbox needs to know is the raw
%voltage data and what configuration the layout is with the corresponding
%names

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% add a warning saying that ypou need to have converted your raw voltage
% data in a matrix channels x samples
uiwait(warndlg('Please convert your MEA voltage data into a matrix matlab file with channels as rows and the voltage data as columns before proceeding(channels x voltage data) ','Warning'));

    %the first step is naming the file
    userinput = inputdlg('Enter file name: ' , '');
    if isempty(userinput)
    else
        userinput= char(userinput);
        %next we need the raw voltage data that should be a matrix with
        %channels x samples
        [FileName,PathName,~] = uigetfile('.mat');
        cd(PathName)
        userdata = load(FileName);
        userdata = cell2mat(struct2cell(userdata));
        h5create([userinput,'.h5'],'/Data',[size(userdata,1) size(userdata,2)]);
        h5write([userinput,'.h5'],'/Data',userdata);% store the channeldata her in the format of C x T C being the channelnumber and T being the voltage data)
        % now we have the raw voltage data
        % next is indicating what kind of MEA is used
        
        answer = questdlg('What kind of MEA Data is it?', ...
            'MEA Dataset','24 Multiwell','120 channel MEA','60 channel MEA','jj'); % have to indicate the default button (jj) otherwise it won't show all three options
        
        switch answer
            case '24 Multiwell'
                h5writeatt([userinput,'.h5'],'/Data','MeaLayout','24W multiwell') % indicate here what kind of MEA layout it is include 24W if it is a multiwell
                h5create([userinput,'.h5'],'/Channelinfo',[288 1]);
            case '60 channel MEA'
                h5writeatt([userinput,'.h5'],'/Data','MeaLayout','60 channel MEA')
                h5create([userinput,'.h5'],'/Channelinfo',[60 1]);
            case '120 channel MEA'
                h5writeatt([userinput,'.h5'],'/Data','MeaLayout','120 channel MEA')
                h5create([userinput,'.h5'],'/Channelinfo',[120 1]);
        end
        
        % lastly add a flag to the file so the toolbox knows its a created
        % h5 file
        h5writeatt([userinput,'.h5'],'/Data','flag','standard file format')
        msgbox('File Created!')
    end
end

% --- Executes during object creation, after setting all properties.
function pushbutton3_CreateFcn(hObject, eventdata, handles)
hObject.Position =[0.617 0.354 0.189 0.044];
hObject.FontWeight = 'bold';
hObject.String = 'Create compatible hdf5 file';
hObject.Visible = 'off';
end
%% SCB detection method selection (Default is max interval method)
% if SCBflag = 1 then max interval will be used otherwise the log ISI will
% be used

% --- Max interval method
function checkbox2_Callback(hObject, eventdata, handles)
global SCBflag
if hObject.Value == 0
handles.checkbox3.Enable = 'on';

elseif hObject.Value == 1
    handles.checkbox3.Enable = 'off';
end

if hObject.Value == 1
    SCBflag = 1;
end

end

% --- Log ISI method
function checkbox3_Callback(hObject, eventdata, handles)
global SCBflag
if hObject.Value == 0
    handles.checkbox2.Enable = 'on';
elseif hObject.Value == 1
    handles.checkbox2.Enable = 'off';
end

if hObject.Value == 1
    SCBflag = 0;
end

end


% --- Executes during object creation, after setting all properties.
function checkbox2_CreateFcn(hObject, eventdata, handles)
hObject.String = 'Max interval Method';
hObject.BackgroundColor=[1 1 1];
hObject.Value = 1; 
end

% --- Executes during object creation, after setting all properties.
function checkbox3_CreateFcn(hObject, eventdata, handles)
hObject.String = 'Log ISI method';
hObject.BackgroundColor=[1 1 1];
hObject.Enable = 'off';
end
