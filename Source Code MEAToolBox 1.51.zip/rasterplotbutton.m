function rasterplotbutton(cbx,~)
global  cbx98 xPoints yPoints cbx9955 max1bursts M2 cbx989 cbx2000 parts multiwell1 networkburstttt cbx99 starts2 HITS burst6 burst6indx h Imax X2 filteredData1 xpoints burst7 timesss ax cbx159 cbx169 selecteddata
load(selecteddata,'networkburstttt')
if cbx989.Value == 1 % for the rasterplot button
    cbx9955.Enable ='off';
    
    if multiwell1 == 1
        % preparing phase
        % reset the name
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        end
        
        
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
        % load the correct well
        selecteddata2 = selecteddata;
        replace1 = sprintf('Well_%d',1);
        replace2 = sprintf('Well_%d',cbx2000.Value);
        selecteddata = replace(selecteddata,replace1,replace2);
        load(selecteddata,'M2')
        load(selecteddata,'burst6indx')
        
        
        max1bursts= cell(1,length(M2));
        for i = 1:length(M2)
            for j= 1:length(burst6indx{i})
                maxbursts = [burst6indx{i}{j}(1),burst6indx{i}{j}(end)];
                max1bursts{i} = [max1bursts{i},maxbursts];
            end
            
        end
        max1bursts=max1bursts';
        
        max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
        % now lets make it eaasier to index in the xPoints vector by giving each
        % number the correct index so we can just index in the xPoints vector
        
        % the try and catch statements are only temp fix but need to take a
        % look att he code for max interval
        countold = 0;
        for i=1:length(max1bursts)
            try
                countnew = (length(M2{i})*3+countold);
                countold = countnew;
                if isempty(max1bursts{(i+1)})
                else
                    for j = 1:length(max1bursts{(i+1)})
                        
                        max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                    end
                end
            catch
            end
        end
        
        nTotalSpikes = sum(cellfun(@length,M2));
        
        
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;
        
        
        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            % Save points and update current index
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        
        subplot('position',[0.2 0.35 0.7 0.6]);
        hold on
        for i = 1:length(M2)
            try
                for j = 0:2:length(max1bursts{i})-1
                    hold on
                    plot(xPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),yPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),'r')
                end
            catch
            end
        end
    elseif multiwell1 == 0
        subplot('position',[0.2 0.35 0.7 0.6]);
        hold on
        for i = 1:length(M2)
            try
                for j = 0:2:length(max1bursts{i})-1
                    hold on
                    plot(xPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),yPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),'r')
                end
            catch
            end
        end
    end
    
elseif cbx989.Value == 0 && cbx9955.Value == 0
    cbx9955.Enable ='on';
    cbx989.Enable = 'on';
    if multiwell1 == 1
        run('selection.m')
    elseif multiwell1 == 0
        subplot('position',[0.2 0.35 0.7 0.6]);
        hold on
        yy = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
        
        nTotalSpikes = sum(cellfun(@length,M2));
        
        
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;
        
        
        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            % Save points and update current index
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        
        plot(xPoints, yPoints, 'k')
        %     set(gca,'XLim',correctxlim);
        
        
        
    end
elseif cbx9955.Value == 1 
    cbx989.Enable ='off';
      
    if multiwell1 == 1
        %         loc2 = find(strcmp(HITS,mat2str(Imax)));
        %         correctwell = ceil(loc2/parts); %we found the correct well
        %
        %% new method
        val = cbx2000.Value;
        
        for i = 2:25
            checked =sprintf('Well_%d',i);
            if isempty(regexp(selecteddata,checked))
                continue
            else
                oldname = sprintf('Well_%d',i);
                selecteddata = strrep(selecteddata,oldname,'Well_1');
            end
        end
        
        
        range2 = cell(1,24);
        UUU= 1:12;
        for i = 1:24
            range2{i} = UUU;
            UUU=UUU+12;
        end
        
        selecteddata2 = selecteddata;
        replace1 = sprintf('Well_%d',1);
        replace2 = sprintf('Well_%d',val);
        selecteddata = replace(selecteddata,replace1,replace2);
        load(selecteddata,'networkburstttt')
        load(selecteddata,'M2')
        load(selecteddata,'burst6')
        
        nTotalSpikes = sum(cellfun(@length,M2));
       
        
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;

        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            % Save points and update current index
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        
        
        % add if statement to account for no networkbursts
        
        % first we need to find the bursts that are part of the network burst
        % we need to store the index numbers and channelnumbers
        nnetworkburstdisp = cell(1,length(M2));
        if networkburstttt.amount == 0
        else
            for i = 1:length(networkburstttt.starttime)
                for j = 1:length(M2)
                    if isempty(burst6{j})
                        continue
                    else
                        temp = find(M2{j} > networkburstttt.starttime(i) &  M2{j} < networkburstttt.endtime(i));
                        if isempty(temp)
                            continue
                        else
                            temp = [temp(1) temp(end)];
                            nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                        end
                    end
                end
            end
            
            nnetworkburstdisp =   nnetworkburstdisp';
            nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
            
            
            countold = 0;
            for i=1:length(nnetworkburstdisp)
                try
                    countnew = (length(M2{i})*3+countold);
                    countold = countnew;
                    if isempty(nnetworkburstdisp{(i+1)})
                    else
                        for j = 1:length(nnetworkburstdisp{(i+1)})
                            
                            nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                        end
                    end
                catch
                end
            end
            
            
          
            subplot('position',[0.2 0.35 0.7 0.6]);
            hold on
            for i = 1:length(M2)
                try
                    for j = 0:2:length(nnetworkburstdisp{i})-1
                        hold on
                        plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                    end
                catch
                end
            end
            
        end
    else
        %     M2a=load(selecteddata,'M2');
        % plot the network burst detection
        
        % first we need to find the bursts that are part of the network burst
        % we need to store the index numbers and channelnumbers
        nnetworkburstdisp = cell(1,length(M2));
        if networkburstttt.amount == 0
        else
            for i = 1:length(networkburstttt.starttime)
                for j = 1:length(M2)
                    if isempty(burst6{j})
                        continue
                    else
                        temp = find(M2{j} > networkburstttt.starttime(i) &  M2{j} < networkburstttt.endtime(i));
                        if isempty(temp)
                            continue
                        else
                            temp = [temp(1) temp(end)];
                            nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                        end
                    end
                end
            end
            
            nnetworkburstdisp =   nnetworkburstdisp';
            nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
            
            
            countold = 0;
            for i=1:length(nnetworkburstdisp)
                try
                    countnew = (length(M2{i})*3+countold);
                    countold = countnew;
                    if isempty(nnetworkburstdisp{(i+1)})
                    else
                        for j = 1:length(nnetworkburstdisp{(i+1)})
                            
                            nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                        end
                    end
                catch
                end
            end
            
            
          
            subplot('position',[0.2 0.35 0.7 0.6]);
            hold on
            for i = 1:length(M2)
                try
                    for j = 0:2:length(nnetworkburstdisp{i})-1
                        hold on
                        plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                    end
                catch
                end
            end
            
        end
        
        
        
    end
    
elseif cbx9955.Value == 0 && cbx989.Value == 0
     
   cbx989.Enable = 'on';
    yy = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    cla(yy)
    linkaxes(yy,'off')
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
    %     N = N ./timesss; %normalize for total duration to get firing rate
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width so the probabilities sum to 1?
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s = s./resolution;
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
    %Trim out the relevant portion of the spike density
    s = s(center:end-center-1);
    %     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    t = (1:length(s))*resolution ;
    
    plot(t,s,'k');
    xlim([0 timesss])
    ylim([0 max(s)])
    
    ylabel('Array Wide Firing Rate (Hz)');
    xlabel('Time(s)','Fontsize',20);
    % set(gca,'XTick',[]);    % no x numbers
    correctxlim = get(gca,'XLim');
    gg = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    linkaxes(gg,'off')
    cla(gg,'reset')
    gg = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        % Save points and update current index
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    title(['Well ',mat2str(ceil(Imax/12))])
    if multiwell1 == 0
        ylim([0 length(M2)])
    elseif multiwell1 == 1
        correctylim = ceil(Imax/12) * 12;
        correctylim = num2cell((correctylim - 12):2: correctylim+2);
        set(gg,'YTickLabel',correctylim)
        gg.YTickLabel{end} =[];
    end
    ylabel('Channels','Fontsize',20);
    %     title('All Wells');
    linkaxes([gg yy],'x');
end
end
