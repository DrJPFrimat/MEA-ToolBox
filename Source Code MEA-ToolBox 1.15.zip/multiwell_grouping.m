function  correctgroups = multiwell_grouping(groups)

if groups == 1
    prompt = {'Enter which wells belong to Group 1:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 75];
    definput = {'1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 2
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3 4 5 6 7 8 9 10 11 12', '13 14 15 16 17 18 19 20 21 22 23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);  
elseif groups == 3
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3 4 5 6 7 8', '9 10 11 12 13 14 15 16', '17 18 19 20 21 22 23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 4
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:','Enter which wells belong to Group 4:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3 4 5 6', '7 8 9 10 11 12', '13 14 15 16 17 18', '19 20 21 22 23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 5
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:','Enter which wells belong to Group 4:','Enter which wells belong to Group 5:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3 4 5', '6 7 8 9 10', '11 12 13 14 15', '16 17 18 19 20', '21 22 23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 6
     prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:','Enter which wells belong to Group 4:','Enter which wells belong to Group 5:','Enter which wells belong to Group 6:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3 4','5 6 7 8', '9 10 11 12', '13 14 15 16', '17 18 19 20', '21 22 23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 7
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:','Enter which wells belong to Group 4:','Enter which wells belong to Group 5:','Enter which wells belong to Group 6:','Enter which wells belong to Group 7:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3', '4 5 6', '7 8 9', '10 11 12', '13 14 15', '16 17 18', '19 20 21 22 23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 8
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:','Enter which wells belong to Group 4:','Enter which wells belong to Group 5:','Enter which wells belong to Group 6:','Enter which wells belong to Group 7:','Enter which wells belong to Group 8:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3', '4 5 6', '7 8 9', '10 11 12', '13 14 15', '16 17 18', '19 20 21', '22 23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 9
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:','Enter which wells belong to Group 4:','Enter which wells belong to Group 5:','Enter which wells belong to Group 6:','Enter which wells belong to Group 7:','Enter which wells belong to Group 8:','Enter which wells belong to Group 9:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3', '4 5 6', '7 8 9', '10 11 12', '13 14 15', '16 17 18', '19 20 21', '22 23', '24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 10
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:','Enter which wells belong to Group 4:','Enter which wells belong to Group 5:','Enter which wells belong to Group 6:','Enter which wells belong to Group 7:','Enter which wells belong to Group 8:','Enter which wells belong to Group 9:','Enter which wells belong to Group 10:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3', '4 5 6', '7 8 9', '10 11 12', '13 14 15', '16 17', '18', '19 20', '21 22' ,'23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 11
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:','Enter which wells belong to Group 4:','Enter which wells belong to Group 5:','Enter which wells belong to Group 6:','Enter which wells belong to Group 7:','Enter which wells belong to Group 8:','Enter which wells belong to Group 9:','Enter which wells belong to Group 10:','Enter which wells belong to Group 11:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2 3', '4 5 6', '7 8 9', '10 11 12', '13 14', '15', '16 17', '18', '19 20', '21 22' ,'23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
elseif groups == 12
    prompt = {'Enter which wells belong to Group 1:','Enter which wells belong to Group 2:','Enter which wells belong to Group 3:','Enter which wells belong to Group 4:','Enter which wells belong to Group 5:','Enter which wells belong to Group 6:','Enter which wells belong to Group 7:','Enter which wells belong to Group 8:','Enter which wells belong to Group 9:','Enter which wells belong to Group 10:','Enter which wells belong to Group 11:','Enter which wells belong to Group 12:'};
    dlgtitle = 'Grouping Wells together';
    dims = [1 50];
    definput = {'1 2', '3 4', '5 6', '7 8', '9 10', '11 12', '13 14', '15 16', '17 18', '19 20', '21 22' ,'23 24'};
    answer = inputdlg(prompt,dlgtitle,dims,definput);
else
    msgbox('Apologies groups higher than 12 have not been implemented yet')
    return 
end

correctgroups = answer;

end