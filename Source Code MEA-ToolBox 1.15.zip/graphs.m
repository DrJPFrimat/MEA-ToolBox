function varargout = graphs(varargin)
% GRAPHS MATLAB code for graphs.fig
%      GRAPHS, by itself, creates a new GRAPHS or raises the existing
%      singleton*.
%
%      H = GRAPHS returns the handle to a new GRAPHS or the handle to
%      the existing singleton*.
%
%      GRAPHS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GRAPHS.M with the given input arguments.
%
%      GRAPHS('Property','Value',...) creates a new GRAPHS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before graphs_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to graphs_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help graphs

% Last Modified by GUIDE v2.5 07-May-2019 21:55:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @graphs_OpeningFcn, ...
                   'gui_OutputFcn',  @graphs_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

% --- Executes just before graphs is made visible.
function graphs_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to graphs (see VARARGIN)

% Choose default command line output for graphs
handles.output = hObject;
set(gcf,'color','white')
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes graphs wait for user response (see UIRESUME)
% uiwait(handles.figure1);
end

% --- Outputs from this function are returned to the command line.
function varargout = graphs_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
end

% --- Executes during object creation, after setting all properties.
function uitable4_CreateFcn(hObject, eventdata, handles)
global meantotal2 semtotal2 GG1 HH1

hObject.Data = {};
for i=1:length(meantotal2)
    hObject.Data{1,i}=meantotal2(i);
    hObject.Data{2,i}=semtotal2(i);
end

GG1=hObject.Data;
HH1=hObject.RowName;


end


% --- Executes during object creation, after setting all properties.
function uitable5_CreateFcn(hObject, eventdata, handles)
global meantotal4 semtotal4 GG2 HH2

hObject.Data = {};
for i=1:length(meantotal4)
    hObject.Data{1,i}=meantotal4(i);
    hObject.Data{2,i}=semtotal4(i);
    
end
GG2=hObject.Data;
HH2=hObject.RowName;
end


% --- Executes during object creation, after setting all properties.
function uitable1_CreateFcn(hObject, eventdata, handles)
global meantotal1 semtotal1 GG HH meantotal15

hObject.Data = {};
for i=1:length(meantotal1)
    hObject.Data{1,i}=meantotal1(i);
    hObject.Data{2,i}=semtotal1(i);
    hObject.Data{3,i}=meantotal15(i);
end
hObject.RowName{3}='Total Time';
GG=hObject.Data;
HH=hObject.RowName;
end


% --- Executes during object creation, after setting all properties.
function uitable2_CreateFcn(hObject, eventdata, handles)
global meantotal6 semtotal6 GG3 HH3
hObject.Data = {};
for i=1:length(meantotal6)
    hObject.Data{1,i}=meantotal6(i);
    hObject.Data{2,i}=semtotal6(i);
end

GG3=hObject.Data;
HH3=hObject.RowName;
end


% --- Executes during object creation, after setting all properties.
function uitable3_CreateFcn(hObject, eventdata, handles)
global meantotal5 semtotal5 GG4 HH4
hObject.Data = {};
for i=1:length(meantotal5)
    hObject.Data{1,i}=meantotal5(i);
    hObject.Data{2,i}=semtotal5(i);
end

GG4=hObject.Data;
HH4=hObject.RowName;
end


% --- Executes during object creation, after setting all properties.
function uitable6_CreateFcn(hObject, eventdata, handles)
global meantotal3 semtotal3 GG5 HH5
hObject.Data = {};
for i=1:length(meantotal3)
    hObject.Data{1,i}=meantotal3(i);
    hObject.Data{2,i}=semtotal3(i);
end

GG5=hObject.Data;
HH5=hObject.RowName;
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
global files avrrr
testcell=char(files.name); %get all the file names in a char array
%avrrr contains all the indexes of all the groups

message1=sprintf('Do you want to see which files are contained in each bar?');
button99 = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');
while strcmpi(button99, 'Continue')
    try
        prompt = {'See which files are contained in each bar'};
        title1 = 'Select which bar you want to look into';
        dims = [1 75];
        definput = {'1'};
        Jigglypuff = inputdlg(prompt,title1,dims,definput);
        Jigglypuff=str2double(Jigglypuff);
        bbb=Jigglypuff;
%         bbb=avrrr{Jigglypuff};
        msgbox(testcell(bbb,:));  %this is for the means
%         msgbox(bbb);
        message1=sprintf('Do you want to see which files are contained in each bar?');
        button99 = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');
    catch
    end

end
end




% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
global GG HH

ff=cell2table(GG,'RowNames',{HH{1,1},HH{2,1},'empty','empty1'});
FileName = uiputfile('*.xls','Save as');
try 
    writetable(ff,FileName,'WriteRowNames',true);
catch
end
end

% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
global GG5 HH5

ff=cell2table(GG5,'RowNames',{HH5{1,1},HH5{2,1},'empty','empty1'});
FileName = uiputfile('*.xls','Save as');
try
    writetable(ff,FileName);
catch
end
end

% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
global GG2 HH2

ff=cell2table(GG2,'RowNames',{HH2{1,1},HH2{2,1},'empty','empty1'});
FileName = uiputfile('*.xls','Save as');
try
    writetable(ff,FileName);
catch
end
end

% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
global GG3 HH3

ff=cell2table(GG3,'RowNames',{HH3{1,1},HH3{2,1},'empty','empty1'});
FileName = uiputfile('*.xls','Save as');
try
    writetable(ff,FileName);
catch
end
end

% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
global GG1 HH1

ff=cell2table(GG1,'RowNames',{HH1{1,1},HH1{2,1},'empty','empty1'});
FileName = uiputfile('*.xls','Save as');
try
    writetable(ff,FileName);
catch
end
end

% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
global GG4 HH4

ff=cell2table(GG4,'RowNames',{HH4{1,1},HH4{2,1},'empty','empty1'});
FileName = uiputfile('*.xls','Save as');
try
    writetable(ff,FileName);
catch
end
end

% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
global GG6 HH6

ff=cell2table(GG6,'RowNames',{HH6{1,1},HH6{2,1},'empty','empty1'});
FileName = uiputfile('*.xls','Save as');
try
    writetable(ff,FileName);
catch
end
end

% --- Executes during object creation, after setting all properties.
function uitable7_CreateFcn(hObject, eventdata, handles)
global meantotal13 GG6 HH6 semtotal13
hObject.Data = {};
for i=1:length(meantotal13)
    hObject.Data{1,i}=meantotal13(i);
    hObject.Data{2,i}=semtotal13(i);
end

GG6=hObject.Data;
HH6=hObject.RowName;


end


% --- Executes on button press in save all
function pushbutton16_Callback(hObject, eventdata, handles)
global GG GG1 GG2 GG3 GG4 GG5 GG6 files

testcell=char(files.name);
testcell=cellstr(testcell);

for i=1:length(files)
   testcell{i}=matlab.lang.makeValidName(testcell{i});
end



ff=cell2table(GG,'RowNames',{'Combined Units','Combined Units SEM','Total Recording Time','empty1'});
ff1=cell2table(GG1,'RowNames',{'Bursts','Bursts SEM','empty6','empty7'});
ff2=cell2table(GG2,'RowNames',{'NeuroEx Bursts','Neuro Ex SEM','empty8','empty9'});
ff3=cell2table(GG3,'RowNames',{'Positive Units','Positive Units SEM','empty2','empty3'});
ff4=cell2table(GG4,'RowNames',{'Negative Units','Negative Units SEM','empty4','empty5'});
ff5=cell2table(GG5,'RowNames',{'Log ISI Bursts','Log ISI SEM','empty10','empty11'});
ff6=cell2table(GG6,'RowNames',{'Connections','Connections SEM','empty12','empty13'});
ff1.Properties.VariableNames =  testcell;
ff2.Properties.VariableNames =  testcell;
ff3.Properties.VariableNames =  testcell;
ff4.Properties.VariableNames =  testcell;
ff5.Properties.VariableNames =  testcell;
ff6.Properties.VariableNames =  testcell;
ff.Properties.VariableNames =  testcell;


ff9=[ff;ff3;ff4;ff1;ff2;ff5;ff6];
ff9=rows2vars(ff9);
FileName = uiputfile('*.xls','Save as');
try
    writetable(ff9,FileName,'WriteRowNames',true);
catch
end




end

% --- Executes during object creation, after setting all properties.
function axes53_CreateFcn(hObject, eventdata, handles)
global meantotal1 semtotal1 


    b=bar(meantotal1);
    
    for k1 = 1:size(meantotal1,1)
        ctr(k1,:) = bsxfun(@plus, b(1).XData, b(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
        ydt(k1,:) = b(k1).YData;                                     % Individual Bar Heights
    end
    
    hold on
    errorbar(ctr,ydt,semtotal1, '.r')
    
    title('Combined Units over Time')
    ylabel('Amount of Units')
    xlabel('Days in Vitro (DIV)');
    set(gca,'Xticklabel',[0:12.5:100]);
end


% --- Executes during object creation, after setting all properties.
function axes54_CreateFcn(hObject, eventdata, handles)
    global meantotal6 semtotal6

b5=bar(meantotal6);
    for k1 = 1:size(meantotal6,1)
        ctr(k1,:) = bsxfun(@plus, b5(1).XData, b5(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
        ydt(k1,:) = b5(k1).YData;                                     % Individual Bar Heights
    end
    
    hold on
    errorbar(ctr, ydt, semtotal6, '.r')
  
    title('Pos Units over Time')
    ylabel('Pos Unit Count');
    xlabel('Days in Vitro (DIV)');
    set(gca,'Xticklabel',[0 1 4]);
end


% --- Executes during object creation, after setting all properties.
function axes55_CreateFcn(hObject, eventdata, handles)
global meantotal5 semtotal5


    b4=bar(meantotal5);
    for k1 = 1:size(meantotal5,1)
        ctr(k1,:) = bsxfun(@plus, b4(1).XData, b4(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
        ydt(k1,:) = b4(k1).YData;                                     % Individual Bar Heights
    end
    
    hold on
    errorbar(ctr, ydt, semtotal5, '.r')
    
    title('Neg Units over Time')
    ylabel('Neg Unit Count');
    xlabel('Days in Vitro (DIV)');
    set(gca,'Xticklabel',[0:12.5:100]);
end


% --- Executes during object creation, after setting all properties.
function axes56_CreateFcn(hObject, eventdata, handles)
 global meantotal2 semtotal2

    b1=bar(meantotal2);
    for k1 = 1:size(meantotal2,1)
        ctr(k1,:) = bsxfun(@plus, b1(1).XData, b1(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
        ydt(k1,:) = b1(k1).YData;                                     % Individual Bar Heights
    end
    
    hold on
    errorbar(ctr, ydt, semtotal2, '.r')
    title('Bursts over Time')
    ylabel('Burst Count');
    xlabel('Days in Vitro (DIV)');
    set(gca,'Xticklabel',[0:12.5:100]);
end


% --- Executes during object creation, after setting all properties.
function axes57_CreateFcn(hObject, eventdata, handles)
   global meantotal4 semtotal4


     b3=bar(meantotal4);
    for k1 = 1:size(meantotal4,1)
        ctr(k1,:) = bsxfun(@plus, b3(1).XData, b3(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
        ydt(k1,:) = b3(k1).YData;                                     % Individual Bar Heights
    end
    
    hold on
    errorbar(ctr, ydt, semtotal4, '.r')
    
    title('NeuroEx Bursts over Time')
    ylabel('Burst Count');
    xlabel('Days in Vitro (DIV)');
    set(gca,'Xticklabel',[0:12.5:100]);
end


% --- Executes during object creation, after setting all properties.
function axes58_CreateFcn(hObject, eventdata, handles)
    global meantotal3 semtotal3

    b2=bar(meantotal3);
    for k1 = 1:size(meantotal3,1)
        ctr(k1,:) = bsxfun(@plus, b2(1).XData, b2(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
        ydt(k1,:) = b2(k1).YData;                                     % Individual Bar Heights
    end
    
    hold on
    errorbar(ctr, ydt, semtotal3, '.r')
   
    title('LogISI Bursts over Time')
    ylabel('Burst Count');
    xlabel('Days in Vitro (DIV)');
    set(gca,'Xticklabel',[0:12.5:100]);
end


% --- Executes during object creation, after setting all properties.
function axes59_CreateFcn(hObject, eventdata, handles)
 global meantotal13 semtotal13

    b6=bar(meantotal13);
    for k1 = 1:size(meantotal13,1)
        ctr(k1,:) = bsxfun(@plus, b6(1).XData, b6(k1).XOffset');    % Note: ‘XOffset’ Is An Undocumented Feature; This Selects The ‘bar’ Centres
        ydt(k1,:) = b6(k1).YData;                                     % Individual Bar Heights
    end
    
    hold on
    errorbar(ctr, ydt, semtotal13, '.r')
   
    title('Connections over Time')
    ylabel('Connections');
    xlabel('Days in Vitro (DIV)');
    set(gca,'Xticklabel',[0:12.5:100]);
end
