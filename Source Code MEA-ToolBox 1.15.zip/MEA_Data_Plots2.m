%%Prep of GUI
function varargout = MEA_Data_Plots2(varargin)
% MEA_DATA_PLOTS2 MATLAB code for MEA_Data_Plots2.fig
%      MEA_DATA_PLOTS2, by itself, creates a new MEA_DATA_PLOTS2 or raises the existing
%      singleton*.
%
%      H = MEA_DATA_PLOTS2 returns the handle to a new MEA_DATA_PLOTS2 or the handle to
%      the existing singleton*.
%
%      MEA_DATA_PLOTS2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MEA_DATA_PLOTS2.M with the given input arguments.
%
%      MEA_DATA_PLOTS2('Property','Value',...) creates a new MEA_DATA_PLOTS2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MEA_Data_Plots2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MEA_Data_Plots2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MEA_Data_Plots2

% Last Modified by GUIDE v2.5 30-Jun-2020 14:06:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @MEA_Data_Plots2_OpeningFcn, ...
    'gui_OutputFcn',  @MEA_Data_Plots2_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

% --- Executes just before MEA_Data_Plots2 is made visible.
function MEA_Data_Plots2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MEA_Data_Plots2 (see VARARGIN)


% Choose default command line output for MEA_Data_Plots2

% handles.output = hObject;
%
% % Update handles structure
% guidata(hObject, handles);
% set(handles.figure1,'Units','Pixels','Position',get(0,'ScreenSize'));

global HITS ha multiwell1 displaychannel

% global filteredData1
% if isempty(filteredData1)
%     clear global
%     load('test.mat')
% else
%
% end

%  window = figure( 'Name', 'A TabPanel example', ...
%     'MenuBar', 'none', ...
%     'Toolbar', 'none', ...
%     'NumberTitle', 'off' );
% hbox = uix.HBoxFlex('Parent', hObject, 'Spacing', 3);
% tabpanel = uix.TabPanel( 'Parent', ...
%     hbox, ...
%     'Padding', 0);
% htab1 = uix.Panel( 'Parent', tabpanel, 'Padding', 5, 'Title', '1');
% uicontrol( 'Style', 'listbox', 'Parent', htab1, ...
%    ...
%    'BackgroundColor', 'w' );
% set(gcf, 'units','normalized','outerposition',[0 0 1 1]);  % turn on for
% windows

%get the screensize of the monitor

% fh = figure();
% fh.WindowState = 'maximized';

%  set(gcf,'WindowState','maximized')

set(gcf,'units','normalized','position',[0 0 1 1])
set(gcf,'WindowState','fullscreen')
% set(gcf, 'units', 'normalized', 'position', [0.05 0.15 0.9 0.8])

ha = axes('units','normalized', ...
    'position',[0 0 1 1]);
multiwell1 =0;

% Load in a background image and display it using the correct colors
% The image used below, is in the Image Processing T0.06645898234683284oolbox.  If you do not have %access to this toolbox, you can use another image file instead.
%I=imread('backroundPic.jpg');
%I=imread('babyblue.jpg');
I=imread('turqoise.jpg');
imagesc(ha,I);


% Turn the handlevisibility off so that we don't inadvertently plot into the axes again
% Also, make the axes invisible
set(ha,'handlevisibility','off', ...
    'visible','off')
% Move the background axes to the bottom
uistack(ha,'bottom');

COLOR=parula(120); %max 144 colors
colmin=min(cell2mat(HITS(:,2)));
colmax=max(cell2mat(HITS(:,2)));
handles.pushbutton33.String = 'Full Trace View';
for counter = 1 : size(HITS,1)
    if HITS{counter,2} > 10
        set(handles.(sprintf('Toggle_%s',HITS{counter,1})),'BackgroundColor',COLOR(round(120*(HITS{counter,2}-colmin)/(colmax-colmin+1)+0.5),:)); % set color to MEA
    else
        set(handles.(sprintf('Toggle_%s',HITS{counter,1})),'BackgroundColor',[1 1 1]);
    end
end

Pos = genButtonPos([0.035 0.75 0.132 0.041],.05,4);
[handles,hObject] = funControl(handles,hObject);

% PictureName = 'backroundPic.jpg';
% handles = setBackround(handles,PictureName);

Tag      = 'Menu_1'; % tag for menu
flds     = {'Home','Bursts','Connections','Spikes'}; % fields of menu
Position = [0 .951 1 .049]; % position of menu on graph
Callback = {'exampleFunction'}; % callback function

s = funBuildo('menu',Tag,Position,flds); % build structure
handles = funControl('menu',handles,s);  % build object
handles.(Tag).CallBack = Callback;       % set callback
% handles.(Tag).Visible = 'off';

handles.pushbutton2.Visible ='off';
handles.pushbutton3.Visible ='off';
handles.text18.Visible = 'off';
handles.text5.Visible = 'off';
handles.pushbutton34.Visible = 'off';
handles.pushbutton18.Visible = 'off';

% initalize checkbox4 for dislaying the correct message in the spike tab
displaychannel = 0;

%panels
loadPannelExample

handles = selectPage(handles.UIControl,'Home',handles);
[hObject,handles] = setDefinateMotion(handles.UIControl,hObject,handles);


handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


end

% --- Outputs from this function are returned to the command line.
function varargout = MEA_Data_Plots2_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;
end
%% arrangement of channels
% --- Executes on button press in Toggle_D1.
function Toggle_D1_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D1')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E1_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E1')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F1_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F1')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G1_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G1')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H1_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H1')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J1_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J1')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C2_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C1')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D2_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D2')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E2_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E2')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F2_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F2')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G2_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G2')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H2_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H2')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J2_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J2')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K2_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K2')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_B3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'B3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_L3_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'L3')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_A4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'A4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_B4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'B4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_L4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'L4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_M4_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'M4')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_A5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'A5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_B5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'B5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_L5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'L5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_M5_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'M5')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_A6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'A6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_B6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'B6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_L6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'L6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_M6_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'M6')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_A7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'A7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_B7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'B7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_L7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'L7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_M7_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'M7')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_A8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'A8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_B8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'B8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_L8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'L8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_M8_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'M8')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_A9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'A9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_B9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'B9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_L9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'L9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_M9_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'M9')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_B10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'B10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_L10_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'L10')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_C11_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'C11')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D11_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D11')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E11_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E11')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F11_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F11')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G11_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G11')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H11_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H11')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J11_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J11')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_K11_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'K11')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_D12_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'D12')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_E12_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'E12')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_F12_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'F12')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_G12_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'G12')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_H12_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'H12')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
function Toggle_J12_Callback(hObject, eventdata, handles)
global HITS
INDEX=find(strcmp(HITS(:,1),'J12')); %This is the index of cell D1 in the cell HITS
Plot_MEA_Graph(INDEX);
end
%% plots
function Plot_MEA_Graph(INDEX)
global timesss X2 RMS7 filteredData1 Spikeform4 SCBflag noiseall18 noiseall2 M2 M88 burstsinfor HITS Spikeform3 channel963 burstview2 burstview3 yutp unitpersecond burstview19 burstview20 xpoints ypoints fs
%
% figure('units','normalized','outerposition',[0 0 1 1]);
% plot(Spikeform3{INDEX,1});
% %     ylim([-400 400]);
% set(gca,'Xticklabel',[-1:0.4:2.2]);
% ylabel('Voltage in Microvolt');
% xlabel('Time in Milliseconds');
% title(['Negative Unit Waveforms in channel ',HITS{INDEX}])
% set(gcf,'color','white')
% figure('units','normalized','outerposition',[0 0 1 1]);
% plot(Spikeform4{INDEX,1});
% %     ylim([-400 400]);
% set(gca,'Xticklabel',[-1:0.4:2.2]);
% ylabel('Voltage in Microvolt');
% xlabel('Time in Milliseconds');
% title(['Positive Unit Waveforms in channel ',HITS{INDEX}])
% set(gcf,'color','white')

figure('units','normalized','outerposition',[0 0 1 1]);
set(gcf,'color','white')
h1=subplot(5,1,1);
if length(filteredData1(1,:)) == length(X2)
    plot(X2,filteredData1(INDEX,:));
    xlim([0 timesss])
    ylabel('Microvolts');
    xlabel('Time in seconds');
    title(['Channel ', HITS{INDEX}]);
    set(gca,'Fontsize',10);
    hold on
    %     plot(X2,RMS8(INDEX,:),'k');
    plot(X2,RMS7(INDEX,1)*ones(length(X2),1)','k');
    hold on
    plot(X2,-RMS7(INDEX,1)*ones(length(X2),1)','k');
    %     plot(X2,-RMS8(INDEX,:),'k');
    hold on
    if length(noiseall18{INDEX,1}) > fs.filtersettings.sampling_frequency
        plot(noiseall18{INDEX,1}(1:fs.filtersettings.sampling_frequency),noiseall2{INDEX,1}(1:fs.filtersettings.sampling_frequency),'r')
        hold on
        plot(noiseall18{INDEX,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{INDEX,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
    else
        plot(noiseall18{INDEX,1},noiseall2{INDEX,1},'r');
    end
    legend('Filtered Channel','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',8);
    set(legend,...
        'Position',[0.725580141149337 0.937787747362246 0.0836481364816829 0.0527522921562193],...
        'FontSize',8);
end
hold on
subplot(5,1,2);
ypuo = find(ypoints == INDEX);
xpuo = xpoints(ypuo);
ypuo1=INDEX*ones(length(xpuo),1);
ypuo1=ypuo1';
% plot(xpuo,ypuo1,'.','Color',[0 0 0]);
axis([0 60 (INDEX-0.001) (INDEX+0.001)]);
% y1=get(gca,'ylim');
hold on
for i=1:length(xpuo)
    line([xpuo(1,i) xpuo(1,i)],get(gca,'Ylim'),'Color',[0 0 0]);
end
set(gca,'ytick',[])
title(['Rasterplot of Channel ', HITS{INDEX}]);
xlabel('Time in Seconds');
xlim([0 timesss])
hold on
subplot(5,1,3);
if isempty(unitpersecond{INDEX,1})
else
    bar(unitpersecond{INDEX,1});
    title('Units per second over the whole recording');
    xlabel('Time in seconds');
    ylabel('Units per second');
end
xlim([0 timesss])
hold on
subplot(5,1,4);


ISI58={}; %contains all the ISI for all channels
for i=1:length(M2)
    ISI57= diff(M2{i,1});
    ISI58{i}=ISI57;
    ISI58=ISI58';
end

dt = 0.001; % in s, because spike times are in s
isi_edges = 0:dt:0.5; % bin edges for ISI histogram
isi_centers = isi_edges(1:end-1)+dt/2; % for plotting
isih = histc(ISI58{INDEX},isi_edges);
bar(isi_centers,isih(1:end-1))
xlabel('ISI (s)');
ylabel('count');
% histogram(ISI58{INDEX,1},2000,'Normalization','probability');
% xlabel('ISI in milliseconds');
% ylabel('% of total ISI');

title(['Distribution of ISI in channel ',HITS{INDEX}]);
hold on
subplot(5,1,5);
if length(filteredData1(1,:)) == length(X2)
    plot(M2{INDEX,1},M88{INDEX,:},'.','Color',[1 0 0],'Markersize',15);
    xlim([0 timesss])
    ylabel('Microvolts');
    xlabel('Time in seconds');
    hold on
    channel963=filteredData1(INDEX,:);
    for i=1:length(burstview2{INDEX,1})
        plot(X2(burstview2{INDEX,1}(1,i):burstview3{INDEX,1}(1,i)),channel963(burstview2{INDEX,1}(1,i):burstview3{INDEX,1}(1,i)),'Color',[0 0 0]');
        hold on
    end
    
    if SCBflag == 1
        legend('Spikes','SCB(Max interval method)');
    elseif SCBflag == 0
        legend('Spikes','SCB(log ISI method)');
    end
    
    set(legend,...
        'Position',[0.735114229041202 0.0490825696275868 0.0874257942212316 0.0316513753265416]);
    title('Multi-Unit Detection and Burst detection');
end
set(gca,'Fontsize',10);

% figure('units','normalized','outerposition',[0 0 1 1]);
% Table139=struct2table(burstsinfor{INDEX,1});
% uitable('Data',Table139{:,:},'ColumnName',Table139.Properties.VariableNames,...
%     'RowName',Table139.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
set(gcf,'color','white')
% while(1)
%
%     try
%         b=waitforbuttonpress;
%         figure;
%         channel963=filteredData1(INDEX,:);
%         yutp=input('Input number of burst to visualize');
%         h666=subplot(1,1,1);
%         hold on
%         plot(X2(burstview19{INDEX,1}(1,yutp):burstview20{INDEX,1}(1,yutp)),channel963(burstview19{INDEX,1}(1,yutp):burstview20{INDEX,1}(1,yutp)));
%         axes(h666)
%         b666=line([X2(burstview3{INDEX,1}(1,yutp)) X2(burstview3{INDEX,1}(1,yutp))],get(h666,'Ylim'),'Color',[1 0 0]);
%         b666.Color(4)=0.5;
%         b777=line([X2(burstview2{INDEX,1}(1,yutp)) X2(burstview2{INDEX,1}(1,yutp))],get(h666,'Ylim'),'Color',[1 0 0]);
%         b777.Color(4)=0.5;
%         title(['Burstnumber ',num2str(yutp)])
%         xlabel('Time in Seconds');
%         ylabel('Microvolt');
%         promptMessage = sprintf('Do you want to look at a different burst?');
%         button = questdlg(promptMessage, 'Continue', 'Continue', 'Terminate', 'Continue');
%         if strcmpi(button, 'Terminate')
%         end
%         break
%
%     catch
%     end
% end


end
%% rasterplot button
% --- Executes on button press in Rasterplot.
function pushbutton1_Callback(hObject, eventdata, handles)
global cbx98 fs cbx99 xpoints ypoints xPoints yPoints ends2 h starts2 cbx989 cbx9955 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1 rrr
%adapated from plotSPikeRaster by Jeffrey Chiou
Rasterplot1 = figure('units','normalized','outerposition',[0 0 1 1]);
%         postdur = double(floor(timesss));
%         predur = 0;
%         %
%         %     if timesss > 120
%         %         widMS = 10;
%         %     else
%         %         widMS = 1;
%         %     end
%         %     centersPost = [(widMS/2):widMS:postdur +(widMS/2)];
%         %     centersPre = [-(widMS/2):(-widMS):-predur -(widMS/2)];
%         %     centers = [fliplr(centersPre) centersPost];
%         centers = 0:0.03:floor(timesss);
%         widMS = 0.03;
%
%         %remove the first and last numbers of the vector as they are non sense
%         %numbers
%
%         %     centers = centers(2:length(centers)-1);
%         %     if widMS == 1
%         %     centers = centers(:)-0.5;
%         %
%         %     end
%
%         [counts,~] = hist(xpoints,centers);
%         subplot('position',[0.2 0.15 0.7 0.15]); hold on;
%         %     r = ((counts/length(M2))/widMS)*1;        %% spikes/sec
%         r = ((counts/length(M2))/widMS)*33;        %% spikes/sec
%
%         %r = counts/widMS;
%         h = bar(centers,counts);
%         set(h,'FaceColor','k');
%         % set(h,'FaceColor',[0.5 0.5 0.5]);
%         axis([-predur,postdur,0 (max(r)*1.1)]);

resolution = 0.001; %binsize of 1 ms
sigma = 0.1 ; %100 ms STD of gaussian
% Use hist to bin
EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
N = histc(xpoints, EDGES);
%Time ranges form -3*st. dev. to 3*st. dev.
edges = (-3*sigma:resolution:3*sigma);
%Evaluate the Gaussian kernel
kernel = normpdf(edges,0,sigma);
%Multiply by bin width
kernel = kernel.*resolution;
%Convolve spike data with the kernel
if ~isempty(N)
    s = conv(N,kernel);
    s =s/resolution; % to get the firing rate
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
    %     %Trim out the relevant portion of the spike density
    %     s=s(center:1000+center-1);
    s = s(center:end-center-1);
    %     s = (s- min(s))/(max(s) -min(s)); % normalzie numbers to be between 0
    %     and 1
    %     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    t = (1:length(s))*resolution ;
end
    gg = subplot('position',[0.2 0.15 0.7 0.15]); hold on;

    if ~isempty(N)
        plot(t,s,'k');
        xlim([0 timesss])
    end
ylabel('AWFR (Hz)');
xlabel('Time(s)','Fontsize',20);
% set(gca,'XTick',[]);    % no x numbers
correctxlim = get(gca,'XLim');


% calculate the rasterplot
yy = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
if ~isempty(N)
    nTotalSpikes = sum(cellfun(@length,M2));
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        % Save points and update current index
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
end
set(gca,'XLim',correctxlim);
set(gca,'XTick',[]);

%color the bursts in red for max interval method

%allbursts contain all the indices of the bursts in a start followeed by
%the end index of each burst
% the xPoints vector are the time points of each spike sorted in a specific
% manner each time point is represented double ending with a nan.
%this means that one timepoint value of a spike corresponds with 3 spots
%inteh xPoints vector
burst6indx =burst6indx';

% place them in the same configuration as the allbursts cell array

maxbursts= [];

max1bursts= cell(1,length(M2));
for i = 1:length(M2)
    for j= 1:length(burst6indx{i})
        maxbursts = [burst6indx{i}{j}(1),burst6indx{i}{j}(end)];
        max1bursts{i} = [max1bursts{i},maxbursts];
    end
    
end
max1bursts=max1bursts';

max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
% now lets make it easier to index in the xPoints vector by giving each
% number the correct index so we can just index in the xPoints vector

% the try and catch statements are only temp fix but need to take a
% look att he code for max interval
countold = 0;
for i=1:length(max1bursts)
    try
        countnew = (length(M2{i})*3+countold);
        countold = countnew;
        if isempty(max1bursts{(i+1)})
        else
            for j = 1:length(max1bursts{(i+1)})
                
                max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
            end
        end
    catch
    end
end

linkaxes([gg yy],'x');

cbx = [];
% Create a check box to diplay single channel bursts in rasterplot:
cbx989 = uicontrol(Rasterplot1,'Style','checkbox','Position',[10 407 250 1000],...
    'Callback',@(cbx,event) rasterplotbutton(cbx));
cbx989.String = 'Display Single Channel Bursts';
cbx989.BackgroundColor = [1 1 1];
set(gcf,'color','white')
title('Rasterplot of all the Multi Unit Activity and Array wide firing rate','Fontsize',30);


% Create a check box to diplay network bursts in rasterplot:
cbx9955 = uicontrol(Rasterplot1,'Style','checkbox','Position',[10 557 250 300],...
    'Callback',@(cbx,event) rasterplotbutton(cbx));
cbx9955.String = 'Display Network Bursts';
cbx9955.BackgroundColor = [1 1 1];






%
%     if timesss > 100
%         xlim([0 300]);
%     else
%         xlim([0 60]);
%     end

if length(starts2) == 60
    ylim([ 0 60]);
elseif length(starts2) == 120
    ylim([0 120]);
else
    
end
ylabel('Channels','Fontsize',20);



end
%% channelnames
% --- Executes on button press in SilentChannelNames
function pushbutton2_Callback(hObject, eventdata, handles)
global Bap
figure;
uitable('Data',Bap{:,:},'ColumnName',Bap.Properties.VariableNames,...
    'RowName',Bap.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
end


% --- Executes on button press in ActiveChannelNames
function pushbutton3_Callback(hObject, eventdata, handles)
global Bal
figure;
uitable('Data',Bal{:,:},'ColumnName',Bal.Properties.VariableNames,...
    'RowName',Bal.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);
end
%% General Data

% --- Executes during object creation, after setting all properties.
function pushbutton6_CreateFcn(hObject, eventdata, handles)
hObject.Position =[0.559 0.501 0.113 0.048];
end

% --- Executes on button press in General Data.
function pushbutton6_Callback(hObject, eventdata, handles)
global T selecteddata
figure('Name',[selecteddata],'NumberTitle','off','units','normalized','outerposition',[0 0 1 1]);

if iscell(T.mean_ISI)
    T.mean_ISI=cell2mat(T.mean_ISI);
end


if iscell(T.std_ISI)
    T.std_ISI=cell2mat(T.std_ISI);
end

uitable('Data',T{:,:},'ColumnName',T.Properties.VariableNames,...
    'RowName',T.Properties.RowNames,'Units', 'Normalized', 'Position',[0, 0, 1, 1]);



c = uicontrol;
c.Position = [1615,888,175,67];
c.FontWeight = 'bold';
c.ForegroundColor = [0.861,0.832,0.096,0.048];
c.CData = imread('color_button.png');
c.String = 'Save Table';
c.Callback = @savetable;


    function savetable(src,event)
        
        try
            filter={'*.xlsx'};
            % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
            writetable(T,uiputfile(filter),'WriteRowNames',true);
        catch
        end
        
    end
end
%% Heatmap
% --- Executes on button press in Heatmap.
function pushbutton8_Callback(hObject, eventdata, handles)
global layout ans90
figure('units','normalized','outerposition',[0 0 1 1]);



%// Define integer grid of coordinates for the above data
[X,Y] = meshgrid(1:size(layout,2), 1:size(layout,1));

%// Define a finer grid of points
[X88,Y88] = meshgrid(1:0.01:size(layout,2), 1:0.01:size(layout,1));

%// Interpolate the data and show the output
outData = interp2(X,Y,layout, X88, Y88,'linear');

nanvalues=isnan(outData);

layout44=layout;


for i=1:length(layout(:,1))
    for j=1:length(layout(1,:))
        if isnan(layout(i,j))
            layout44(i,j)= 0;
        else
        end
    end
end

%// Interpolate the data and show the output
outData = interp2(X,Y,layout44, X88, Y88,'cubic');

outData(nanvalues)=nan;



imagesc(outData,'AlphaData',~isnan(outData));

%// Cosmetic changes for the axes
set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
set(gca, 'XTickLabel', 1:size(X,2));
set(gca, 'YTickLabel', 1:size(X,1));

%// Add colour bar
colorbar;
% heatmap(layout,ans90,(1:12),true,'Gridlines','-','Colorbar',true,'ShowAllTicks',true,'TickFontSize',30)
set(gca,'XtickLabel', ans90,'Fontsize',20);
set(gcf,'color','white')
title('Multi-Unit Activity over 1 min','Fontsize',30);
colorbar;
end





% --- Executes on button press in colorbar.
function pushbutton10_Callback(hObject, eventdata, handles)
end
%% cross correlation
% --- Executes on button press in Xcrosscorrelation.
function pushbutton12_Callback(hObject, eventdata, handles)
global Imax HITS yup finalssss supa



prompt = {'Which channel do you want to cross correlate with the other channels?'};
title1 = 'Cross Correlation';
dims = [1 75];
definput = {'A8'};
yup = inputdlg(prompt,title1,dims,definput);
Imax=find(strncmpi(HITS,yup,3));

figure('units','normalized','outerposition',[0 0 1 1]);
%stem3(xaxiss,1:120,finalssss);

%
% resolution = 0.1; %binsize of 100 ms
% sigma = 0.1 ; %100 ms STD of gaussian
% % Use hist to bin
% EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
% N = histc(xpoints, EDGES);
% %         N = N ./timesss; %normalize for total duration to get firing rate
% %Time ranges form -3*st. dev. to 3*st. dev.
% edges = (-3*sigma:resolution:3*sigma);
% %Evaluate the Gaussian kernel
% kernel = normpdf(edges,0,sigma);
% %Multiply by bin width so the probabilities sum to 1?
% kernel = kernel.*resolution;
% %Convolve spike data with the kernel
% s = conv(N,kernel);
% s=s/resolution;
% %Find the index of the kernel center
% center = ceil(length(edges)/2);
% %         %Trim out the relevant portion of the spike density
% s = s(center:end-center-1);
% t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
%
%
%

%
% for i = 1:size(supa{Imax},1)
%     hold on
%     plot(supa{Imax}(i,:));
% end
%
%




b=bar3(supa{Imax});
xlabel('Time in milliseconds')
zlabel('Xcrosscorrrelation(%)')
ylabel('Channels')
set(gca,'Xticklabel',[-100:50:150]);
title(['Xcrosscorrelation between all the channels vs channel ', HITS{Imax}]);

for k = 1:length(b)  %change the color to match the heights of the bars
    zdata = b(k).ZData;
    b(k).CData = zdata;
    b(k).FaceColor = 'interp';
end
set(gcf,'color','white')
end
%% Movie
% --- Executes on button press in make movie of the MEA activity over time
% with the 5 highest active channels
function pushbutton14_Callback(hObject, eventdata, handles)
global imaxch layout2 bincountssec filteredData1 HITS binranges4567 ans90 X2 timesss M2 joost

if timesss > 100
    x=1:9000;
    [x y] = meshgrid(x,x);
    figure('position', [0,0, 640, 640]);
    vidfile = VideoWriter('HEATMAP.avi','Motion JPEG AVI');
    open(vidfile);
    
    for i= 1:9000
        if joost == 1
            if length(filteredData1(:,1)) == 60
                layout2= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan bincountssec(7,i) bincountssec(15,i) bincountssec(23,i) bincountssec(31,i) bincountssec(39,i) bincountssec(47,i) nan nan nan; nan nan bincountssec(1,i) bincountssec(8,i) bincountssec(16,i) bincountssec(24,i) bincountssec(32,i) bincountssec(40,i) bincountssec(48,i) bincountssec(55,i) nan nan; nan nan bincountssec(2,i) bincountssec(9,i) bincountssec(17,i) bincountssec(25,i) bincountssec(33,i) bincountssec(41,i) bincountssec(49,i) bincountssec(56,i) nan nan; nan nan bincountssec(3,i) bincountssec(10,i) bincountssec(18,i) bincountssec(26,i) bincountssec(34,i) bincountssec(42,i) bincountssec(50,i) bincountssec(57,i) nan nan; nan nan bincountssec(4,i) bincountssec(11,i) bincountssec(19,i) bincountssec(27,i) bincountssec(35,i) bincountssec(43,i) bincountssec(51,i) bincountssec(58,i) nan nan; nan nan bincountssec(5,i) bincountssec(12,i) bincountssec(20,i) bincountssec(28,i) bincountssec(36,i) bincountssec(44,i) bincountssec(52,i) bincountssec(59,i) nan nan; nan nan bincountssec(6,i) bincountssec(13,i) bincountssec(21,i) bincountssec(29,i) bincountssec(37,i) bincountssec(45,i) bincountssec(53,i) bincountssec(60,i) nan nan;nan nan nan bincountssec(14,i) bincountssec(22,i) bincountssec(30,i) bincountssec(38,i) bincountssec(46,i) bincountssec(54,i) nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
                
                %// Define integer grid of coordinates for the above data
                [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
                
                %// Define a finer grid of points
                [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
                %// Interpolate the data and show the output
                outData = interp2(X, Y, layout2, X88, Y88, 'linear');
                nanvalues=isnan(outData);
                
                layout44=layout2;
                
                
                for iii=1:length(layout2(:,1))
                    for j=1:length(layout2(1,:))
                        if isnan(layout2(iii,j))
                            layout44(iii,j)= 0;
                        else
                        end
                    end
                end
                
                %// Interpolate the data and show the output
                outData = interp2(X,Y,layout44, X88, Y88,'cubic');
                
                outData(nanvalues)=nan;
                set(gcf,'color','white')
                
                imagesc(outData,'AlphaData',~isnan(outData));
                
                %// Cosmetic changes for the axes
                set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
                set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
                set(gca, 'XTickLabel', 1:size(X,2));
                set(gca, 'YTickLabel', 1:size(X,1));
                
                set(gca,'XtickLabel', ans90,'Fontsize',20);
                colorbar;
                title(['Multi-Unit Activity over ',mat2str(timesss),' seconds'],'Fontsize',20);
                caxis([0 5]);
                drawnow
                F(i) = getframe(gcf);
                writeVideo(vidfile,F(i));
                
            else
                %layout2= [-50 -50 -50 bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) -50 -50 -50;-50 -50 bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) -50 -50;-50 bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) -50; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);-50 bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) -50;-50 -50 bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) -50 -50;-50 -50 -50 bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) -50 -50 -50];
                layout2= [nan nan nan bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) nan nan nan; nan nan bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) nan nan; nan bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) nan; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);nan bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) nan; nan nan bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) nan nan; nan nan nan bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) nan nan nan];
                
                %// Define integer grid of coordinates for the above data
                [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
                %// Define a finer grid of points
                [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
                
                %// Interpolate the data and show the output
                outData = interp2(X, Y, layout2, X88, Y88, 'linear');
                
                nanvalues=isnan(outData);
                
                layout44=layout2;
                
                
                for ii=1:length(layout2(:,1))
                    for j=1:length(layout2(1,:))
                        if isnan(layout2(ii,j))
                            layout44(ii,j)= 0;
                        else
                        end
                    end
                end
                
                %// Interpolate the data and show the output
                outData = interp2(X,Y,layout44, X88, Y88,'cubic');
                outData(nanvalues)=nan;
                imagesc(outData,'AlphaData',~isnan(outData));
                set(gcf,'color','white')
                %// Cosmetic changes for the axes
                set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
                set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
                set(gca, 'XTickLabel', 1:size(X,2));
                set(gca, 'YTickLabel', 1:size(X,1));
                set(gca,'XtickLabel', ans90,'Fontsize',20);
                colorbar;
                title(['Multi-Unit Activity over ',mat2str(timesss),' seconds'],'Fontsize',20);
                caxis([0 5]);
                drawnow
                F(i) = getframe(gcf);
                writeVideo(vidfile,F(i));
            end
        else
            if length(filteredData1(:,2)) == 60
                layout2= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan bincountssec(7,i) bincountssec(15,i) bincountssec(23,i) bincountssec(31,i) bincountssec(39,i) bincountssec(47,i) nan nan nan; nan nan bincountssec(1,i) bincountssec(8,i) bincountssec(16,i) bincountssec(24,i) bincountssec(32,i) bincountssec(40,i) bincountssec(48,i) bincountssec(55,i) nan nan; nan nan bincountssec(2,i) bincountssec(9,i) bincountssec(17,i) bincountssec(25,i) bincountssec(33,i) bincountssec(41,i) bincountssec(49,i) bincountssec(56,i) nan nan; nan nan bincountssec(3,i) bincountssec(10,i) bincountssec(18,i) bincountssec(26,i) bincountssec(34,i) bincountssec(42,i) bincountssec(50,i) bincountssec(57,i) nan nan; nan nan bincountssec(4,i) bincountssec(11,i) bincountssec(19,i) bincountssec(27,i) bincountssec(35,i) bincountssec(43,i) bincountssec(51,i) bincountssec(58,i) nan nan; nan nan bincountssec(5,i) bincountssec(12,i) bincountssec(20,i) bincountssec(28,i) bincountssec(36,i) bincountssec(44,i) bincountssec(52,i) bincountssec(59,i) nan nan; nan nan bincountssec(6,i) bincountssec(13,i) bincountssec(21,i) bincountssec(29,i) bincountssec(37,i) bincountssec(45,i) bincountssec(53,i) bincountssec(60,i) nan nan;nan nan nan bincountssec(14,i) bincountssec(22,i) bincountssec(30,i) bincountssec(38,i) bincountssec(46,i) bincountssec(54,i) nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
                
                %// Define integer grid of coordinates for the above data
                [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
                
                %// Define a finer grid of points
                [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
                %// Interpolate the data and show the output
                outData = interp2(X, Y, layout2, X88, Y88, 'linear');
                nanvalues=isnan(outData);
                
                layout44=layout2;
                
                
                for iii=1:length(layout2(:,1))
                    for j=1:length(layout2(1,:))
                        if isnan(layout2(iii,j))
                            layout44(iii,j)= 0;
                        else
                        end
                    end
                end
                
                %// Interpolate the data and show the output
                outData = interp2(X,Y,layout44, X88, Y88,'cubic');
                
                outData(nanvalues)=nan;
                set(gcf,'color','white')
                
                imagesc(outData,'AlphaData',~isnan(outData));
                
                %// Cosmetic changes for the axes
                set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
                set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
                set(gca, 'XTickLabel', 1:size(X,2));
                set(gca, 'YTickLabel', 1:size(X,1));
                
                set(gca,'XtickLabel', ans90,'Fontsize',20);
                colorbar;
                title(['Multi-Unit Activity over ',mat2str(timesss),' min'],'Fontsize',20);
                caxis([0 5]);
                drawnow
                F(i) = getframe(gcf);
                writeVideo(vidfile,F(i));
                
            else
                %layout2= [-50 -50 -50 bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) -50 -50 -50;-50 -50 bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) -50 -50;-50 bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) -50; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);-50 bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) -50;-50 -50 bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) -50 -50;-50 -50 -50 bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) -50 -50 -50];
                layout2= [nan nan nan bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) nan nan nan; nan nan bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) nan nan; nan bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) nan; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);nan bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) nan; nan nan bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) nan nan; nan nan nan bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) nan nan nan];
                
                %// Define integer grid of coordinates for the above data
                [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
                
                
                
                %// Define a finer grid of points
                [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
                
                %// Interpolate the data and show the output
                outData = interp2(X, Y, layout2, X88, Y88, 'linear');
                
                nanvalues=isnan(outData);
                
                layout44=layout2;
                
                
                for ii=1:length(layout2(:,1))
                    for j=1:length(layout2(1,:))
                        if isnan(layout2(ii,j))
                            layout44(ii,j)= 0;
                        else
                        end
                    end
                end
                
                %// Interpolate the data and show the output
                outData = interp2(X,Y,layout44, X88, Y88,'cubic');
                outData(nanvalues)=nan;
                imagesc(outData,'AlphaData',~isnan(outData));
                set(gcf,'color','white')
                %// Cosmetic changes for the axes
                set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
                set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
                set(gca, 'XTickLabel', 1:size(X,2));
                set(gca, 'YTickLabel', 1:size(X,1));
                set(gca,'XtickLabel', ans90,'Fontsize',20);
                colorbar;
                title(['Multi-Unit Activity over ',mat2str(timesss),' min'],'Fontsize',20);
                caxis([0 5]);
                drawnow
                F(i) = getframe(gcf);
                writeVideo(vidfile,F(i));
            end
        end
    end
    close(vidfile)
    
    
else
    
    
    bincounts2={};
    binranges=linspace(0,floor(timesss),floor(timesss)*30); %the 30 represents the fps
    binranges4567=binranges;
    for i=1:length(M2)
        if isempty(M2{i})
            bincounts = zeros(1,floor(timesss)*30);
        else
            bincounts=histc(M2{i,1},binranges);
        end
        bincounts2=[bincounts2 bincounts];
    end
    bincounts2=bincounts2';
    bincounts2=vertcat(bincounts2{:});
    bincountssec=bincounts2;
    
    x=1:size(bincountssec,2);
    [x y] = meshgrid(x,x);
    figure('position', [0,0, 640, 640]);
    vidfile = VideoWriter('HEATMAP.avi','Motion JPEG AVI');
    open(vidfile);
    for i= 1:size(bincountssec,2)
        if length(filteredData1(:,2)) == 60
            layout2= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan bincountssec(7,i) bincountssec(15,i) bincountssec(23,i) bincountssec(31,i) bincountssec(39,i) bincountssec(47,i) nan nan nan; nan nan bincountssec(1,i) bincountssec(8,i) bincountssec(16,i) bincountssec(24,i) bincountssec(32,i) bincountssec(40,i) bincountssec(48,i) bincountssec(55,i) nan nan; nan nan bincountssec(2,i) bincountssec(9,i) bincountssec(17,i) bincountssec(25,i) bincountssec(33,i) bincountssec(41,i) bincountssec(49,i) bincountssec(56,i) nan nan; nan nan bincountssec(3,i) bincountssec(10,i) bincountssec(18,i) bincountssec(26,i) bincountssec(34,i) bincountssec(42,i) bincountssec(50,i) bincountssec(57,i) nan nan; nan nan bincountssec(4,i) bincountssec(11,i) bincountssec(19,i) bincountssec(27,i) bincountssec(35,i) bincountssec(43,i) bincountssec(51,i) bincountssec(58,i) nan nan; nan nan bincountssec(5,i) bincountssec(12,i) bincountssec(20,i) bincountssec(28,i) bincountssec(36,i) bincountssec(44,i) bincountssec(52,i) bincountssec(59,i) nan nan; nan nan bincountssec(6,i) bincountssec(13,i) bincountssec(21,i) bincountssec(29,i) bincountssec(37,i) bincountssec(45,i) bincountssec(53,i) bincountssec(60,i) nan nan;nan nan nan bincountssec(14,i) bincountssec(22,i) bincountssec(30,i) bincountssec(38,i) bincountssec(46,i) bincountssec(54,i) nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
            
            %// Define integer grid of coordinates for the above data
            [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
            
            
            %// Define a finer grid of points
            [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
            
            %// Interpolate the data and show the output
            outData = interp2(X, Y, layout2, X88, Y88, 'linear');
            
            nanvalues=isnan(outData);
            
            layout44=layout2;
            
            
            for i=1:length(layout2(:,1))
                for j=1:length(layout2(1,:))
                    if isnan(layout2(i,j))
                        layout44(i,j)= 0;
                    else
                    end
                end
            end
            
            %// Interpolate the data and show the output
            outData = interp2(X,Y,layout44, X88, Y88,'cubic');
            
            outData(nanvalues)=nan;
            
            
            
            imagesc(outData,'AlphaData',~isnan(outData));
            set(gcf,'color','white')
            %// Cosmetic changes for the axes
            set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
            set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
            set(gca, 'XTickLabel', 1:size(X,2));
            set(gca, 'YTickLabel', 1:size(X,1));
            
            
            
            
            
            
            
            set(gca,'XtickLabel', ans90,'Fontsize',20);
            colorbar;
            title('Multi-Unit Activity over 1 min','Fontsize',20);
            caxis([0 5]);
            drawnow
            F(i) = getframe(gcf);
            writeVideo(vidfile,F(i));
            
        else
            %layout2= [-50 -50 -50 bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) -50 -50 -50;-50 -50 bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) -50 -50;-50 bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) -50; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);-50 bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) -50;-50 -50 bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) -50 -50;-50 -50 -50 bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) -50 -50 -50];
            layout2= [nan nan nan bincountssec(51,i) bincountssec(55,i) bincountssec(59,i) bincountssec(63,i) bincountssec(67,i) bincountssec(71,i) nan nan nan; nan nan bincountssec(47,i) bincountssec(50,i) bincountssec(54,i) bincountssec(58,i) bincountssec(64,i) bincountssec(68,i) bincountssec(72,i) bincountssec(75,i) nan nan; nan bincountssec(45,i) bincountssec(46,i) bincountssec(49,i) bincountssec(53,i) bincountssec(57,i) bincountssec(65,i) bincountssec(69,i) bincountssec(73,i) bincountssec(76,i) bincountssec(77,i) nan; bincountssec(41,i) bincountssec(42,i) bincountssec(43,i) bincountssec(44,i) bincountssec(52,i) bincountssec(56,i) bincountssec(66,i) bincountssec(70,i) bincountssec(74,i) bincountssec(79,i) bincountssec(80,i) bincountssec(81,i); bincountssec(37,i) bincountssec(38,i) bincountssec(39,i) bincountssec(40,i) bincountssec(48,i) bincountssec(60,i) bincountssec(62,i) bincountssec(78,i) bincountssec(82,i) bincountssec(83,i) bincountssec(84,i) bincountssec(85,i); bincountssec(33,i) bincountssec(34,i) bincountssec(35,i) bincountssec(36,i) bincountssec(32,i) bincountssec(31,i) bincountssec(61,i) bincountssec(90,i) bincountssec(86,i) bincountssec(87,i) bincountssec(88,i) bincountssec(89,i); bincountssec(29,i) bincountssec(28,i) bincountssec(27,i) bincountssec(26,i) bincountssec(30,i) bincountssec(1,i) bincountssec(91,i) bincountssec(92,i) bincountssec(96,i) bincountssec(95,i) bincountssec(94,i) bincountssec(93,i); bincountssec(25,i) bincountssec(24,i) bincountssec(23,i) bincountssec(22,i) bincountssec(18,i) bincountssec(2,i) bincountssec(120,i) bincountssec(108,i) bincountssec(100,i) bincountssec(99,i) bincountssec(98,i) bincountssec(97,i); bincountssec(21,i) bincountssec(20,i) bincountssec(19,i) bincountssec(14,i) bincountssec(10,i) bincountssec(6,i) bincountssec(116,i) bincountssec(112,i) bincountssec(104,i) bincountssec(103,i) bincountssec(102,i) bincountssec(101,i);nan bincountssec(17,i) bincountssec(16,i) bincountssec(13,i) bincountssec(9,i) bincountssec(5,i) bincountssec(117,i) bincountssec(113,i) bincountssec(109,i) bincountssec(106,i) bincountssec(105,i) nan; nan nan bincountssec(11,i) bincountssec(12,i) bincountssec(8,i) bincountssec(4,i) bincountssec(118,i) bincountssec(114,i) bincountssec(110,i) bincountssec(107,i) nan nan; nan nan nan bincountssec(11,i) bincountssec(7,i) bincountssec(3,i) bincountssec(119,i) bincountssec(115,i) bincountssec(111,i) nan nan nan];
            
            
            
            
            [X,Y] = meshgrid(1:size(layout2,2), 1:size(layout2,1));
            
            %// Define a finer grid of points
            [X88,Y88] = meshgrid(1:0.01:size(layout2,2), 1:0.01:size(layout2,1));
            
            %// Interpolate the data and show the output
            outData = interp2(X, Y, layout2, X88, Y88, 'linear');
            
            nanvalues=isnan(outData);
            
            layout44=layout2;
            
            
            for i=1:length(layout2(:,1))
                for j=1:length(layout2(1,:))
                    if isnan(layout2(i,j))
                        layout44(i,j)= 0;
                    else
                    end
                end
            end
            
            %// Interpolate the data and show the output
            outData = interp2(X,Y,layout44, X88, Y88,'cubic');
            
            outData(nanvalues)=nan;
            
            imagesc(outData,'AlphaData',~isnan(outData));
            set(gcf,'color','white')
            %// Cosmetic changes for the axes
            set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
            set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
            set(gca, 'XTickLabel', 1:size(X,2));
            set(gca, 'YTickLabel', 1:size(X,1));
            set(gca,'XtickLabel', ans90,'Fontsize',20);
            colorbar;
            title('Multi-Unit Activity over 1 min','Fontsize',20);
            caxis([0 5]);
            drawnow
            F(i) = getframe(gcf);
            writeVideo(vidfile,F(i));
        end
    end
    close(vidfile)
end

figure('position', [0,0, 640, 640]);
vidfile=VideoWriter('MEA activity.avi','Motion JPEG AVI');
open(vidfile);
h1=subplot(5,1,1);
set(gcf,'color','white')
hold on
plot(X2,filteredData1(imaxch(1,1),:));
if timesss > 100
    xlim([0 300]);
else
    xlim([0 60]);
end
ylim([-300 300]);
ylabel(['Channel',HITS(imaxch(1,1))]);
xlabel('Time in Seconds');
hold on
h2=subplot(5,1,2);
plot(X2,filteredData1(imaxch(2,1),:));
if timesss > 100
    xlim([0 300]);
else
    xlim([0 60]);
end
ylim([-300 300]);
ylabel(['Channel',HITS(imaxch(2,1))]);
xlabel('Time in Seconds');
hold on
h3=subplot(5,1,3);
plot(X2,filteredData1(imaxch(3,1),:));
if timesss > 100
    xlim([0 300]);
else
    xlim([0 60]);
end
ylim([-300 300]);
ylabel(['Channel',HITS(imaxch(3,1))]);
xlabel('Time in Seconds');
hold on
h4=subplot(5,1,4);
plot(X2,filteredData1(imaxch(4,1),:));
if timesss > 100
    xlim([0 300]);
else
    xlim([0 60]);
end
ylim([-300 300]);
ylabel(['Channel',HITS(imaxch(4,1))]);
xlabel('Time in Seconds');
hold on
h5=subplot(5,1,5);
plot(X2,filteredData1(imaxch(5,1),:));
if timesss > 100
    xlim([0 300]);
else
    xlim([0 60]);
end
ylim([-300 300]);
ylabel(['Channel',HITS(imaxch(5,1))]);
xlabel('Time in Seconds');
hold on
for j=1:length(binranges4567)
    axes(h1)
    b1=line([binranges4567(1,j) binranges4567(1,j)],get(h1,'Ylim'),'Color',[1 0 0]);
    axes(h2)
    b2=line([binranges4567(1,j) binranges4567(1,j)],get(h2,'Ylim'),'Color',[1 0 0]);
    axes(h3)
    b3=line([binranges4567(1,j) binranges4567(1,j)],get(h3,'Ylim'),'Color',[1 0 0]);
    axes(h4)
    b4=line([binranges4567(1,j) binranges4567(1,j)],get(h4,'Ylim'),'Color',[1 0 0]);
    axes(h5)
    b5=line([binranges4567(1,j) binranges4567(1,j)],get(h5,'Ylim'),'Color',[1 0 0]);
    F(j)=getframe(gcf);
    writeVideo(vidfile,F(j));
    delete(b1);
    delete(b2);
    delete(b3);
    delete(b4);
    delete(b5);
end
close(vidfile)

vid1 = VideoReader('HEATMAP.avi');
vid2 = VideoReader('MEA activity.avi');
% new video
outputVideo = VideoWriter('Combined.avi');
outputVideo.FrameRate = vid1.FrameRate;
open(outputVideo);

while hasFrame(vid1) && hasFrame(vid2)
    img1 = readFrame(vid1);
    img2 = readFrame(vid2);
    
    imgt = horzcat(img1, img2);
    
    
    % record new video
    writeVideo(outputVideo, imgt);
end

close(outputVideo);
delete('HEATMAP.avi');
delete('MEA activity.avi');
message1=sprintf(['Finished making the movie']);
msgbox(message1);
clear message1

end
%% Analyze Data
% --- Analyze Data
function pushbutton16_Callback(hObject, eventdata, handles)
global flag
current=pwd;
addpath(current);
if flag == 1
    run('justspiketimes');
elseif flag == 0
    run('MEAToolboxV3')
end
end
%% top10 active channels callbutton
% --- Executes on button press in Show top 10 active channels.
function pushbutton17_Callback(hObject, eventdata, handles)
global imaxch X2 filteredData1 HITS imaxch2 timesss RMS7 noiseall18 noiseall2 screen1 fs
screen1=get(0,'Screensize');

% figure('NumberTitle','off','Name','Top 10 most active channels','Menubar','figure', 'Resize','on', ...
%     'Units','pixels', 'Position',[1 1 ((screen1(1,3)/2)-100) (screen1(1,4)-100)]);
figure(1);
subplot(5,1,1);
if isempty(imaxch)
    [~,imaxch]=maxk(mat2cell(HITS(:,2)),10);
end

imaxch2=imaxch(6:10);
for i=1:(length(imaxch)/2)
    P=imaxch(i);
    subplot(5,1,i);
    plot(X2,filteredData1(P,:));
    xlim([0 timesss])
    hold on
    %     plot(X2,RMS8(INDEX,:),'k');
    plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
    %     plot(X2,-RMS8(INDEX,:),'k');
    hold on
    if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
        plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
        hold on
        plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
    else
        plot(noiseall18{P,1},noiseall2{P,1},'r');
    end
    ylabel(['Channel',HITS(imaxch(i,1))]);
    xlabel('Time in Seconds');
    title(['Most active channel number ',num2str((i))]);
    
    if i == 1 % we only need one legend
        legend('Filtered Channel','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',8);
        set(legend,...
            'Position',[0.725580141149337 0.937787747362246 0.0836481364816829 0.0527522921562193],...
            'FontSize',8);
    end
    set(gcf,'color','white')
end

% figure('NumberTitle','off','Name','Top 10 most active channels','Menubar','figure', 'Resize','on', ...
%     'Units','pixels', 'Position',[(screen1(1,3)-850) (screen1(1,4)-1080) ((screen1(1,3)/2)-100) (screen1(1,4)-100)]);

figure(2);
subplot(5,1,1);
for i=1:length(imaxch2)
    P=imaxch2(i);
    subplot(5,1,i);
    plot(X2,filteredData1(P,:));
    xlim([0 timesss])
    hold on
    %     plot(X2,RMS8(INDEX,:),'k');
    plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
    %     plot(X2,-RMS8(INDEX,:),'k');
    hold on
    if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
        plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
        hold on
        plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
    else
        plot(noiseall18{P,1},noiseall2{P,1},'r');
    end
    ylabel(['Channel',HITS(imaxch2(i,1))]);
    xlabel('Time in Seconds');
    title(['Most active channel number ',num2str((i+5))]);
    if i == 1
        legend('Filtered Channel','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',8);
        set(legend,...
            'Position',[0.725580141149337 0.937787747362246 0.0836481364816829 0.0527522921562193],...
            'FontSize',8);
    end
    set(gcf,'color','white')
end

%
% screen1=get(0,'Screensize');  %get screensize
% w = screen1(3)*2/3; h = screen1(4)*7/8;           %# width/height of figure
% handles.hFig = figure('NumberTitle','off','Name','Top 10 most active channels','Menubar','figure', 'Resize','off', ...
%     'Units','pixels', 'Position',[w/8 h/10 w h]);
%
% handles.hPan = uipanel('Parent',handles.hFig, ...
%     'Units','pixels', 'Position',[0 0 w-20 h]);
%
% handles.hSld = uicontrol('Parent',handles.hFig, ...
%     'Style','slider', 'Enable','off', ...
%     'Units','pixels', 'Position',[w-20 0 20 h], ...
%     'Min',0-eps, 'Max',0, 'Value',0, ...
%     'Callback',{@Beans,handles.hPan});
%
%
% for i=1:length(imaxch)
%     P=imaxch(i);
%     h1(i)=Jelly(handles);
%     hold on
%     plot((h1(i)),X2,filteredData1(P,:));
%     axis([0 60 -300 300]);
%     ylabel(['Channel',HITS(imaxch(i,1))]);
%     xlabel('Time in Seconds');
%     title(['Most active channel number ',num2str((i))]);
% end



end
%% miscellaneous

% --- Executes on button press in color for inactive channels.
function pushbutton18_Callback(hObject, eventdata, handles)
end


% --- Executes on button press in low activity.
function pushbutton20_Callback(hObject, eventdata, handles)
end


% --- Executes on button press in compare bursts.
function pushbutton23_Callback(hObject, eventdata, handles)
global HITS yup Imax timesss RMS7 noiseall2 noiseall18 filteredData1 X2 channel963 burstview2 burstview3 burstsinfor burstview19 burstview20 yutp ToT ToT2 burst6

% yup=input('Which channel do you want to compare?');
% Imax=find(strncmpi(HITS,yup,3));

prompt = {'Enter Channel to compare the different burst detection methods in'};
title = 'Comparison of burst detection methods';
dims = [1 75];
definput = {'A8'};
Totoro = inputdlg(prompt,title,dims,definput);
Imax=find(strcmp(HITS,Totoro));
comparebursts;

end


%Static Text for High activity
function text8_CreateFcn(hObject, eventdata, handles)
set(hObject, 'String','High Activity');

end


% --- Executes during object creation, after setting all properties.
function text9_CreateFcn(hObject, eventdata, handles)
global HITS maxee
%  if exist('filteredData1','var')
maxee=max([HITS{:,2}]);
set(hObject, 'String',maxee);
%  else
%  end

end


% --- Executes during object creation, name of file
function pushbutton15_CreateFcn(hObject, eventdata, handles)
global selecteddata

set(hObject, 'String', selecteddata);


end
%% load data
% --- Executes on button press in load data.
function pushbutton24_Callback(hObject, eventdata, handles)
global selecteddata filteredData1 burst6 multiwell1 joost

% clear global
clearvars
[selecteddata,folder]=uigetfile('data.mat');
if folder == 0
    return
else
    f = waitbar(0,'Loading File...');
    addpath(folder);
    cd(folder)
    selecteddata144 = selecteddata;
    load(selecteddata);
    selecteddata = selecteddata144;
    waitbar(.5,f,'Loading your data');
    %     if floor(filteredData1)==ceil(filteredData1)
    %         filteredData1=hlp_deserialize(filteredData1);
    %     end
    
    % run('MEA_Data_Plots2.m');
    
    waitbar(1,f,'Loading Complete');
    close(f)
    if multiwell1 == 1 && joost == 0
        close()
        multiwell
    elseif multiwell1 == 1 && joost == 1
         close()
        CSVmultiwell
    else
        %     filteredData1=hlp_deserialize(filteredData1);
        close;
        MEA_Data_Plots2
    end
    
end

end


% --- Executes on button press in connectivity maps
function pushbutton26_Callback(hObject, eventdata, handles)



end
%% get the neuro endpoints

% --- Executes during object creation, after setting all properties.
function pushbutton28_CreateFcn(hObject, eventdata, handles)
hObject.String = 'Neuro Endpoints';
end

% --- Executes on button press in graphs
function pushbutton28_Callback(hObject, eventdata, handles)
global looo12 total17 total16 X2 M2 arrayfiringrate filteredData1 Exburst semfiringrate meanfiringrate meantotal1 semtotal1 meantotal2 semtotal2 meantotal3 semtotal3 meantotal4 semtotal4 meantotal5 semtotal5 meantotal6 semtotal6 meantotal13 semtotal13 meantotal15 semtotal15 files timesss divdate

localpath=pwd;
addpath(localpath);
message1=sprintf('If your analyzed files are not placed in one folder then please press Terminate otherwise press Continue');
button = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');


if strcmpi(button, 'Continue')
    correctfolder=uigetdir; %lets the user select  a folder for analysis
    cd(correctfolder) ; %change the current folder to the user slected one
    files = dir('*.mat');
    %
    %     % sort them based on the div day
    %     if contains(files(1).name,'div')
    %         expression = 'd[i]v';
    %     elseif contains(files(1).name,'DIV')
    %         expression = 'D[I]V';
    %     end
    %     divdate = zeros(1,length(files));
    %     for i=1:length(files)
    %         indxsort = regexp(files(i).name,expression);
    %         indxsort = indxsort(1)+3;
    %         divdate(i) = str2double(files(i).name(indxsort)); %contains all the div days as a number
    %     end
    %
    %     %in the case that div day starts at 0 change it to +1
    %     if divdate(1) == 0
    %         divdate = divdate + 1;
    %     end
    %
    %
    %      divdate=divdate';
    %
    %
    %     [~,I]=sort(divdate); % sort them and get the correct order
    %      files=files(I); % sort the files in correct order based on their div days
    
    %preallocation
    total2=cell(1,length(files));
    total3=cell(1,length(files));
    total4=cell(1,length(files));
    total1=cell(1,length(files));
    total5=cell(1,length(files));
    total6=cell(1,length(files));
    total13=cell(1,length(files));
    total15=cell(1,length(files));
    arrayfiringrate = cell(1,length(files));
    total16=cell(1,length(files));
    total17=cell(1,length(files));
    h = waitbar(0,'Collecting all files');
    for i=1:length(files)
        waitbar(i/length(files))
        selecteddata1=files(i).name;
        total1{i}=load(selecteddata1,'HITS');
        ppp=cell2mat(total1{i}.HITS(:,2));
        ppp=sum(ppp);
        total1{i}=ppp;

        total3{i}=load(selecteddata1,'BLog');
        total3{i}=total3{i}.BLog;
        
        total4{i}=load(selecteddata1,'BNeuro');
        total4{i}=total4{i}.BNeuro;
        
        total5{i}=load(selecteddata1,'negunits');
        total5{i}=total5{i}.negunits;
        
        total6{i}=load(selecteddata1,'posunits');
        total6{i}=total6{i}.posunits;
        
        total13{i}=load(selecteddata1,'Connections');
        total13{i}=total13{i}.Connections;
        
        total15{i}=load(selecteddata1,'timesss');
        total15{i}=total15{i}.timesss;
        
        total16{i}=load(selecteddata1,'Exburst');
        
        total17{i} = load(selecteddata1,'M2');
        
        arrayfiringrate{i} = load(selecteddata1,'T');
        if arrayfiringrate{i}.T.Fire_rate(end) == inf
            arrayfiringrate{i} = arrayfiringrate{i}.T.Fire_rate(1);
        else
            arrayfiringrate{i} = arrayfiringrate{i}.T.Fire_rate(end);
            % arrayfiringrate{i} = mean(arrayfiringrate{i}.T.maxamplitude_in_volt(1:end-1));
            
        end
        
    end
    close(h)
    %Units_per_second
    %adjust total16 for burst statistics
    %first remove any empty structs
    for j=1:length(total16)
        for i =1:length(total16{j}.Exburst)
            if isempty(total16{j}.Exburst{i}.number_of_bursts)
                total16{j}.Exburst{i} = [];
            end
        end
    end
    
    %remove any empty cells
    for i = 1:length(total16)
        total16{i}.Exburst=total16{i}.Exburst(~cellfun('isempty',total16{i}.Exburst));
    end
    
    for i=1:length(total16)
        total16{i} = total16{i}.Exburst; % this contains the amount of channels that contain bursts per file
    end
    total16=total16';
    
    %now we need to average across channels within each file
    %convert inner structs into cells
    %the fieldnames will disspear but it will be easier to work it the
    %numbers
    %fieldnames in order were
    %number_of_bursts
    %duration_of_bursts
    %spikes_in_bursts
    %fr_of_bursts
    %mean_ISI_bursts
    %std_ISI_bursts
    %IBI
    
    for i =1:length(total16)
        for j=1:length(total16{i})
            if isempty(total16{i})
                total16{i} = 0;
            else
                total16{i}{j}=struct2cell(total16{i}{j});
            end
            
        end
    end
    
    %check to see if every if aligned in the same dimensions
    for i =1:length(total16)
        if isempty(total16{i})
        else
            for j =1:length(total16{i})
                if size(total16{i}{j}{4},1) == 1
                    total16{i}{j}{4} = total16{i}{j}{4}';
                end
            end
        end
    end
    
    % concatenated all the bursts together per file
    for i =1:length(total16)
        if isempty(total16{i})
        elseif size(total16{i},1) == 1
            total16{i} = total16{i}{1};
        else
            total16{i} = cellfun(@vertcat, total16{i}{:}, 'UniformOutput',false);
        end
    end
    
    %now we average
    
    for i=1:length(total16)
        if isempty(total16{i})
        else
            total16{i}{1}=size(total16{i}{1},1);
            for j=2:length(total16{i})
                total16{i}{j}=mean(total16{i}{j});
            end
        end
    end
    
    
    %now we can average across multiple files that belong to each other
    
    %we have to remove the empty cells
    %   NN = length(total16(cellfun('isempty',total16))); %how many files dont have any bursts
    
    
    %     %will have to make a new divdate for bursts
    %     divdatebursts = divdate;
    %     divdatebursts(find(cellfun('isempty',total16))) = [];
    %
    %     total16(cellfun('isempty',total16))=[];
    %
    %     %preallocation
    %     %meanvalues over multiple files
    %     meanburstsstats = cell(1,length(unique(divdatebursts)));
    %     for i=1:length(unique(divdatebursts))
    %         temp = unique(divdatebursts);
    %         meanburstsstats{i} = cellfun(@vertcat, total16{divdatebursts == temp(i)}, 'UniformOutput',false);
    %         for j=1:length(meanburstsstats{i})
    %             meanburstsstats{i}{j} = mean(meanburstsstats{i}{j});
    %         end
    %     end
    %
    %     %SEMvalues over multiple files of the bursts stats
    %
    %     semburstsstats = cell(1,length(unique(divdatebursts)));
    %     for i=1:length(unique(divdatebursts))
    %         temp = unique(divdatebursts);
    %         semburstsstats{i} = cellfun(@vertcat, total16{divdatebursts == temp(i)}, 'UniformOutput',false);
    %         for j=1:length(semburstsstats{i})
    %             semburstsstats{i}{j} = std(semburstsstats{i}{j})/sqrt(length(semburstsstats{i}{j}));
    %
    %         end
    %     end
    %
    %
    %     %Calulate the percentage of spikes participating in bursts
    %
    %
    %     %rerun the creation of Exburst thning
    %
    %     for i=1:length(files)
    %         selecteddata1=files(i).name;
    %         total16{i}=load(selecteddata1,'Exburst');
    %     end
    %
    %     perspikesburst2=cell(1,length(total17));
    %     perspikesbursts=zeros(1,length(M2));
    %     for k = 1:length(total17)
    %         for i=1:length(M2)
    %             if isempty(total16{k}.Exburst{i}.number_of_bursts)
    %                 perspikesbursts(i) = 0;
    %             else
    %                 perspikesbursts(i) = ((sum(total16{k}.Exburst{i}.spikes_in_bursts))/size(total17{k}.M2{i},2))*100';   % the cell array contains the amount of spikes that are part of a burst per channel
    %                 perspikesbursts(perspikesbursts == 0)=[];    %remove all zeros
    %                 if length(perspikesbursts) == 1 %if there is only one values it means that tehre is only one hcannel with bursts so don't do anything
    %                 else
    %                     perspikesbursts = mean(perspikesbursts);
    %                 end
    %
    %                 perspikesburst2{k} = perspikesbursts;
    %             end
    %         end
    %     end
    %
    %     perspikesburst2(cellfun('isempty',perspikesburst2))=[];
    %     perspikesburst2 = cell2mat(perspikesburst2);
    %     %average it over all channels
    %     meanper= zeros(1,length(unique(divdatebursts)));
    %     for i=1:length(unique(divdatebursts))
    %         temp = unique(divdatebursts);
    %         meanper(i)=mean(perspikesburst2(divdatebursts == temp(i)));
    %     end
    %
    %     semper= zeros(1,length(unique(divdatebursts)));
    %     for i=1:length(unique(divdatebursts))
    %         temp = unique(divdatebursts);
    %         semper(i)=std(perspikesburst2(divdatebursts == temp(i)))/sqrt(length(perspikesburst2(divdatebursts == temp(i))));
    %     end
    %
    %
    %
    %     %change the cells into vectors
    %
    %     total1=cell2mat(total1);
    %     total2=cell2mat(total2);
    %     total3=cell2mat(total3);
    %     total4=cell2mat(total4);
    %     total5=cell2mat(total5);
    %     total6=cell2mat(total6);
    %     total13=cell2mat(total13);
    %     total15=cell2mat(total15);
    %     arrayfiringrate=cell2mat(arrayfiringrate);
    %
    %
    %     %preallocation
    %     meantotal1 = zeros(1,length(unique(divdate)));
    %     meantotal2 = zeros(1,length(unique(divdate)));
    %     meantotal3 = zeros(1,length(unique(divdate)));
    %     meantotal4 = zeros(1,length(unique(divdate)));
    %     meantotal5 = zeros(1,length(unique(divdate)));
    %     meantotal6 = zeros(1,length(unique(divdate)));
    %     meantotal13 = zeros(1,length(unique(divdate)));
    %     meantotal15 = zeros(1,length(unique(divdate)));
    %     meanfiringrate = zeros(1,length(unique(divdate)));
    %
    %     %average over the div days
    %     for i = 1:length(unique(divdate))
    %         temp = unique(divdate);
    %         meantotal1(i) = mean(total1(divdate == temp(i)));
    %         meantotal2(i) = mean(total2(divdate == temp(i)));
    %         meantotal3(i) = mean(total3(divdate == temp(i)));
    %         meantotal4(i) = mean(total4(divdate == temp(i)));
    %         meantotal5(i) = mean(total5(divdate == temp(i)));
    %         meantotal6(i) = mean(total6(divdate == temp(i)));
    %         meantotal13(i) = mean(total13(divdate == temp(i)));
    %         meantotal15(i) = mean(total15(divdate == temp(i)));
    %         meanfiringrate(i) = mean(arrayfiringrate(divdate == temp(i)));
    %     end
    %
    %     clear temp
    %
    %     %now we do the same but for the SEM
    %
    %     %preallocation
    %     semtotal1 = zeros(1,length(unique(divdate)));
    %     semtotal2 = zeros(1,length(unique(divdate)));
    %     semtotal3 = zeros(1,length(unique(divdate)));
    %     semtotal4 = zeros(1,length(unique(divdate)));
    %     semtotal5 = zeros(1,length(unique(divdate)));
    %     semtotal6 = zeros(1,length(unique(divdate)));
    %     semtotal13 = zeros(1,length(unique(divdate)));
    %     semtotal15 = zeros(1,length(unique(divdate)));
    %     semfiringrate = zeros(1,length(unique(divdate)));
    %
    %
    %     %sem over the div days
    %     for i = 1:length(unique(divdate))
    %         temp = unique(divdate);
    %         semtotal1(i) = std(total1(divdate == temp(i)))/sqrt(length(total1(divdate == temp(i))));
    %         semtotal2(i) = std(total2(divdate == temp(i)))/sqrt(length(total2(divdate == temp(i))));
    %         semtotal3(i) = std(total3(divdate == temp(i)))/sqrt(length(total3(divdate == temp(i))));
    %         semtotal4(i) = std(total4(divdate == temp(i)))/sqrt(length(total4(divdate == temp(i))));
    %         semtotal5(i) = std(total5(divdate == temp(i)))/sqrt(length(total5(divdate == temp(i))));
    %         semtotal6(i) = std(total6(divdate == temp(i)))/sqrt(length(total6(divdate == temp(i))));
    %         semtotal13(i) = std(total13(divdate == temp(i)))/sqrt(length(total13(divdate == temp(i))));
    %         semtotal15(i) = std(total15(divdate == temp(i)))/sqrt(length(total15(divdate == temp(i))));
    %         semfiringrate(i) = std(arrayfiringrate(divdate == temp(i)))/sqrt(length(arrayfiringrate(divdate == temp(i))));
    %     end
    %     clear temp
    %
    %
    
    
    
    %     %% PCI and PLI
    %     %     % convenient variables
    %     npnts   = size(filteredData1,2);
    %     ntrials = 1 ;
    %     srate   = 20000;
    %     %% setup connectivity parameters
    %
    %     PLIchan = cell(1,length(filteredData1(:,1)));
    %     PCIchan = cell(1,length(filteredData1(:,1)));
    %     hh = waitbar(0,'Calculating the PLI and PCI');
    %     for i = 1:length(filteredData1(:,1))
    %         waitbar(i/length(filteredData1(:,1)));
    %         for j=1:length(filteredData1(:,1))
    %
    %             % channels for connectivity
    %             chan1idx = i;
    %             chan2idx = j;
    %
    %             % create a complex Morlet wavelet
    %             cent_freq = 8;
    %             time      = -1.5:1/srate:1.5;
    %             s         = 8/(2*pi*cent_freq);
    %             wavelet   = exp(1i*2*pi*cent_freq*time );
    %             half_wavN = (length(time)-1)/2;
    %
    %             % FFT parameters
    %             nWave = length(time);
    %             nData = size(filteredData1,2);
    %             nConv = nWave + nData - 1;
    %
    %             % FFT of wavelet (check nfft)
    %             waveletX = fft(wavelet,nConv);
    %             waveletX = waveletX ./ max(waveletX);
    %
    %             % initialize output time-frequency data
    %             phase_data = zeros(2,length(X2));
    %             real_data  = zeros(2,length(X2));
    %
    %
    %
    %             % analytic signal of channel 1
    %             dataX = fft(filteredData1(chan1idx,:),nConv);
    %             as = ifft(waveletX.*dataX,nConv);
    %             as = as(half_wavN+1:end-half_wavN);
    %
    %             % collect real and phase data
    %             phase_data(1,:) = angle(as); % extract phase angles
    %     %         real_data(1,:)  = real(as); % extract the real part (projection onto real axis)
    %
    %             % analytic signal of channel 2
    %             dataX = fft(filteredData1(chan2idx,:),nConv);
    %             as = ifft(waveletX.*dataX,nConv);
    %             as = as(half_wavN+1:end-half_wavN);
    %
    %             % collect real and phase data
    %             phase_data(2,:) = angle(as);
    %     %         real_data(2,:)  = real(as);
    %
    %
    %
    %             PCIchan{i}(j) = abs(mean(exp(1i*(phase_data(1,:) - phase_data(2,:)))));
    %     %         phase_synchronization1 = [phase_synchronization1,phase_synchronization];
    %             PLIchan{i}(j) = abs(mean(sign(imag(exp(1i*(phase_data(1,:) - phase_data(2,:)))))));
    %     %         phase_lag_index1 = [phase_lag_index1,phase_lag_index];
    %
    %         end
    %     %     PLIchan{i} = phase_lag_index1;
    %     %     PCIchan{i} = phase_synchronization1;
    %         chan1idx = chan1idx + 1;
    %     %     phase_lag_index1=zeros(1,length(filteredData1(:,1)));
    %     %     phase_synchronization1 = zeros(1,length(filteredData1(:,1)));
    %
    %     end
    %     close(hh)
    %     for i=1:length(filteredData1(:,1))
    %         PLIchan{i} = nanmean(PLIchan{i});
    %         PCIchan{i} =nanmean(PCIchan{i});
    %     end
    %
    %     PLIchan = mean(cell2mat(PLIchan));
    %     PCIchan =mean(cell2mat(PCIchan));
    
    
    
    
    
    
    
    run('cBoxChanged');
    
    %     run('select_parameters');
    
    
    %     run('graphs')
    
    
elseif strcmpi(button, 'Terminate')
    
    prompt = {'Name the folder'};
    title1 = 'Select the folder to hold the analyzed files';
    dims = [1 75];
    definput = {'All_Analyzed_Files'};
    Jigglypuff = inputdlg(prompt,title1,dims,definput);
    
    correctfolder=uigetdir; %lets the user select  a folder where the new fodler will be created
    cd(correctfolder) ; %change the current folder to the user selected one
    mkdir([Jigglypuff{1}]);
    cd(Jigglypuff{1});
    ppp=pwd;
    
    
    message1=sprintf(['Select the folders to move the analyzed files from to your the newly created ', definput{1}]);
    button2 = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');
    
    
    while strcmpi(button2,'Continue')
        
        correctfolder2=uigetdir; %lets the user select  a folder to move
        cd(correctfolder2) ;
        files1 = dir('*.mat');
        
        for n=1:numel(files1)
            movefile([files1(n).name],ppp);
        end
        
        message1=sprintf(['Select the folders to move the analyzed files from to your the newly created ', definput{1}]);
        button2 = questdlg(message1, 'Question', 'Continue', 'Terminate', 'Continue');
        
        
        
        
        if strcmpi(button2,'Terminate')
            message1=sprintf(['You have put all the analyzed files to make the graphs into ', definput{1}]);
            button3 = questdlg(message1, 'Question', 'Yes', 'No', 'Continue');
            if strcmpi(button3,'Yes')
                cd(ppp);
                files = dir('*.mat');
                
                yuuuu=cell(1,length(files));
                for i=1:length(files)
                    yuuuu{i}=files(i).name;
                end
                
                out=regexp(yuuuu,'\d+','match');
                out=out';
                
                for i=1:length(files)
                    out{i}=cell2mat(out{i});
                end
                
                
                [~,I]=sort(out);
                files=files(I);
                out=out(I);
                avrrr={};
                j=0;
                
                for i=1:length(files)
                    try
                        i=j+1;
                        avrrr{i}=find(contains(out,out{i}));
                        j=avrrr{i}(end);
                    catch
                    end
                    
                    
                end
                
                avrrr=avrrr(~cellfun('isempty',avrrr));  %remove empty spaces  this cell array contains the indices that need to be avaraged
                
                
                clear promptMessage totaldura button incc I out j i
                
                %preallocation
                total2=cell(1,length(files));
                total3=cell(1,length(files));
                total4=cell(1,length(files));
                total1=cell(1,length(files));
                total5=cell(1,length(files));
                total6=cell(1,length(files));
                total13=cell(1,length(files));
                total15=cell(1,length(files));
                arrayfiringrate = cell(1,length(files));
                total16=cell(1,length(files));
                total17=cell(1,length(files));
                h = waitbar(0,'Collecting all files');
                for i=1:length(files)
                    waitbar(i/length(files))
                    selecteddata1=files(i).name;
                    total1{i}=load(selecteddata1,'HITS');
                    ppp=cell2mat(total1{i}.HITS(:,2));
                    ppp=sum(ppp);
                    total1{i}=ppp;
                    
%                     total2{i}=load(selecteddata1,'BD');
%                     total2{i}=total2{i}.BD;
                    
                    total3{i}=load(selecteddata1,'BLog');
                    total3{i}=total3{i}.BLog;
                    
                    total4{i}=load(selecteddata1,'BNeuro');
                    total4{i}=total4{i}.BNeuro;
                    
                    total5{i}=load(selecteddata1,'negunits');
                    total5{i}=total5{i}.negunits;
                    
                    total6{i}=load(selecteddata1,'posunits');
                    total6{i}=total6{i}.posunits;
                    
                    total13{i}=load(selecteddata1,'Connections');
                    total13{i}=total13{i}.Connections;
                    
                    total15{i}=load(selecteddata1,'timesss');
                    total15{i}=total15{i}.timesss;
                    
                    total16{i}=load(selecteddata1,'Exburst');
                    
                    total17{i} = load(selecteddata1,'M2');
                    
                    arrayfiringrate{i} = load(selecteddata1,'T');
                    if arrayfiringrate{i}.T.Units_per_second(end) == inf
                        arrayfiringrate{i} = arrayfiringrate{i}.T.Units_per_second(1);
                    else
                        arrayfiringrate{i} = arrayfiringrate{i}.T.Units_per_second(end);
                        % arrayfiringrate{i} = mean(arrayfiringrate{i}.T.maxamplitude_in_volt(1:end-1));
                        
                    end
                    
                end
                close(h)
                %Units_per_second
                %adjust total16 for burst statistics
                %first remove any empty structs
                for j=1:length(total16)
                    for i =1:length(total16{j}.Exburst)
                        if isempty(total16{j}.Exburst{i}.number_of_bursts)
                            total16{j}.Exburst{i} = [];
                        end
                    end
                end
                
                %remove any empty cells
                for i = 1:length(total16)
                    total16{i}.Exburst=total16{i}.Exburst(~cellfun('isempty',total16{i}.Exburst));
                end
                
                for i=1:length(total16)
                    total16{i} = total16{i}.Exburst; % this contains the amount of channels that contain bursts per file
                end
                total16=total16';
                
                %now we need to average across channels within each file
                %convert inner structs into cells
                %the fieldnames will disspear but it will be easier to work it the
                %numbers
                %fieldnames in order were
                %number_of_bursts
                %duration_of_bursts
                %spikes_in_bursts
                %fr_of_bursts
                %mean_ISI_bursts
                %std_ISI_bursts
                %IBI
                
                for i =1:length(total16)
                    for j=1:length(total16{i})
                        if isempty(total16{i})
                            total16{i} = 0;
                        else
                            total16{i}{j}=struct2cell(total16{i}{j});
                        end
                        
                    end
                end
                
                %check to see if every if aligned in the same dimensions
                for i =1:length(total16)
                    if isempty(total16{i})
                    else
                        for j =1:length(total16{i})
                            if size(total16{i}{j}{4},1) == 1
                                total16{i}{j}{4} = total16{i}{j}{4}';
                            end
                        end
                    end
                end
                
                % concatenated all the bursts together per file
                for i =1:length(total16)
                    if isempty(total16{i})
                    elseif size(total16{i},1) == 1
                        total16{i} = total16{i}{1};
                    else
                        total16{i} = cellfun(@vertcat, total16{i}{:}, 'UniformOutput',false);
                    end
                end
                
                %now we average
                
                for i=1:length(total16)
                    if isempty(total16{i})
                    else
                        total16{i}{1}=size(total16{i}{1},1);
                        for j=2:length(total16{i})
                            total16{i}{j}=mean(total16{i}{j});
                        end
                    end
                end
                
                %get the SEM of the connections here
                %                 for i=1:length(avrrr)
                %                     total14(i)= std(total13(avrrr{i}))/sqrt(length(total13(avrrr{i})));
                %                 end
                %
                %                 for i=1:length(avrrr)
                %                     total1(i)=(total1(avrrr{i}));  %% add mean here
                %                     total2(i)=(total2(avrrr{i}));
                %                     total3(i)=(total3(avrrr{i}));
                %                     total4(i)=(total4(avrrr{i}));
                %                     total5(i)=(total5(avrrr{i}));
                %                     total6(i)=(total6(avrrr{i}));
                %                     total7(i)=(total7(avrrr{i}));
                %                     total8(i)=(total8(avrrr{i}));
                %                     total9(i)=(total9(avrrr{i}));
                %                     total10(i)=(total10(avrrr{i}));
                %                     total11(i)=(total11(avrrr{i}));
                %                     total12(i)=(total12(avrrr{i}));
                %                     total13(i)=(total13(avrrr{i}));
                %                 end
                %
                %                 total1(length(avrrr):end)=[];
                %                 total2(length(avrrr):end)=[];
                %                 total3(length(avrrr):end)=[];
                %                 total4(length(avrrr):end)=[];
                %                 total5(length(avrrr):end)=[];
                %                 total6(length(avrrr):end)=[];
                %                 total7(length(avrrr):end)=[];
                %                 total8(length(avrrr):end)=[];
                %                 total9(length(avrrr):end)=[];
                %                 total10(length(avrrr):end)=[];
                %                 total11(length(avrrr):end)=[];
                %                 total12(length(avrrr):end)=[];
                %                 total13(length(avrrr):end)=[];
                %                 total14(length(avrrr):end)=[];
                run('cBoxChanged');
                
            end
            
        end
        
        
        
        
        
        
        
        
        
    end
end

end
%% heatmap panel
% --- Executes during object creation, after setting all properties.
function axes27_CreateFcn(hObject, eventdata, handles)
global layout ans90

% if exist('X2','var') == 1
%// Define integer grid of coordinates for the above data
[X,Y] = meshgrid(1:size(layout,2), 1:size(layout,1));

%// Define a finer grid of points
[X88,Y88] = meshgrid(1:0.01:size(layout,2), 1:0.01:size(layout,1));

%// Interpolate the data and show the output
outData = interp2(X,Y,layout, X88, Y88,'linear');

nanvalues=isnan(outData);

layout44=layout;


for i=1:length(layout(:,1))
    for j=1:length(layout(1,:))
        if isnan(layout(i,j))
            layout44(i,j)= 0;
        else
        end
    end
end

%// Interpolate the data and show the output
outData = interp2(X,Y,layout44, X88, Y88,'cubic');

outData(nanvalues)=nan;



imagesc(outData,'AlphaData',~isnan(outData));

%// Cosmetic changes for the axes
set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
set(gca, 'XTickLabel', 1:size(X,2));
set(gca, 'YTickLabel', 1:size(X,1));

%// Add colour bar
% colorbar;
% heatmap(layout,ans90,(1:12),true,'Gridlines','-','Colorbar',true,'ShowAllTicks',true,'TickFontSize',30)
set(gca,'XtickLabel', ans90,'Fontsize',5);
title('Multi-Unit Activity over 1 min','Fontsize',8);
% colorbar;
% else
%     plot(1,1)
% end

end
%% old
% --- Executes during object creation, after setting all properties.
function uitable10_CreateFcn(hObject, eventdata, handles)
global T Bak Bab BI GG joost
hObject.Visible = 'off';
if joost == 1
    hObject.Data{1,1}=0;
    hObject.Data{1,2}=0;
    hObject.Data{1,3}=0;
    hObject.Data{1,4}=0;
    hObject.Data{1,5}=0;
    hObject.Data{1,6}=0;
    hObject.Data{1,7}=0;
    hObject.Data{1,8}=0;
    hObject.Data{1,9}=0;
else
    
    GG=hObject;
    % h=findobj('Tag','uitable10');
    
    %     hObject.Data{1,1}=num2str(T.negpks(end));
    %     hObject.Data{1,2}=num2str(T.pospeaks(end));
    %     hObject.Data{1,3}=num2str(T.Truehits(end));
    %     hObject.Data{1,4}=num2str(T.number_of_bursts1(end));
    %     hObject.Data{1,5}=num2str(T.number_of_burstsNeuroEx(end));
    %     hObject.Data{1,6}=num2str(T.number_of_burstslog(end));
    %     hObject.Data{1,7}=num2str(Bak.activeelecamount);
    %     hObject.Data{1,8}=num2str(Bab.silentelecamount);
    %     hObject.Data{1,9}=num2str(BI.BI);
end







end


% --- Executes during object creation, after setting all properties.
function pushbutton31_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
end
% --- Executes on button press in save table.
function pushbutton31_Callback(hObject, eventdata, handles)
global GG


yeeha=str2double(GG.Data);
yeehat=table(yeeha(1,1),yeeha(1,2),yeeha(1,3),yeeha(1,4),yeeha(1,5),yeeha(1,6),yeeha(1,7),yeeha(1,8),yeeha(1,9),'VariableNames',{'Neg_Units', 'Pos_Units', 'Com_Units', 'Bursts', 'Bursts_Max', 'Bursts_LogISI', 'Active_Electrodes', 'Silent_Electrodes','BI'});

try
    filter={'*.xlsx'};
    % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
    writetable(yeehat,uiputfile(filter),'WriteRowNames',true);
catch
end
end
%% test for CNN
% --- Executes on button press in CNN test
function pushbutton32_Callback(hObject, eventdata, handles)
% the idea is that when you press this button it will give the channels a
% different color if the CNN predictetd that the channel was a artifact
% rather  than signal
global INDEX1 HITS

change=HITS(INDEX1); %This contains the correct channel names
for i=1:length(change)
    A1='Toggle_';
    A2=change{i};
    A3=strcat(A1,A2);
    set(handles.(A3),'BackgroundColor','green');
end
end
%% full trace view button
% --- Executes on button press in full trace view
function pushbutton33_Callback(hObject, eventdata, handles)
global filteredData1 joost

if joost == 1
    msgdlg('There are no voltage traces')
else
    prompt = {'Enter window length (s)'};
    title = 'Check all the channels';
    dims = [1 35];
    definput = {'1'};
    jitters = inputdlg(prompt,title,dims,definput);
    
    window=str2double(jitters{1})*10000;
    
    filteredData1=filteredData1';
    multichanplot(filteredData1,window,'ylim',[-100 100])
    filteredData1=filteredData1';
end
end
%% old 2

% --- Executes on button press in color
function pushbutton34_Callback(hObject, eventdata, handles)
end


% --- Executes on button press in Spike sorting (test)
function pushbutton37_Callback(hObject, eventdata, handles)
global M2 Spikeform3 data HITS channelnames
f = waitbar(0,'Collecting the waveforms...');

Data3=Spikeform3;
for i=1:length(Data3)
    if length(Data3{i}) == 1
        Data3{i}=[];
    end
    
end
Data3=Data3';

for i=1:length(Data3)
    Data3{i}=Data3{i}';
end

Data4=M2;
waitbar(.5,f,'Structering the waveforms');
Data4=Data4';

for i=1:length(Data4)
    Data4{i}=Data4{i}';
end


for i=1:length(Data4)
    if isempty(Data4{i})
        continue
    elseif isempty(Data3{i})
        Data4{i}=[];
    else
        ppp=length(Data3{i}(:,1));
        Data4{i}=Data4{i}(1:ppp);
    end
end

data.waveforms=Data3;
data.spiketimes=Data4;

% remove any channel that less then 10 spikes


for i=1:length(data.waveforms)
    if isempty(data.waveforms{i})
        continue
    elseif length(data.waveforms{i}(:,1)) < 10
        data.waveforms{i}=[];
        data.spiketimes{i}=[];
        
    end
end

%get the index number so we can use it later to find the correct channel
%name

channelnum=find(~cellfun(@isempty,data.waveforms));
channelnames=HITS(channelnum);

data.waveforms=data.waveforms(~cellfun('isempty',data.waveforms));
data.spiketimes=data.spiketimes(~cellfun('isempty',data.spiketimes));

clear Data3 Data4 ppp i Spikeform3 Spikeform4

%check to see if there any finite numbers (nan or inf values)
%if there are then remvoe the waveforms



for j=1:length(data.waveforms)
    for i=1:length(data.waveforms{j}(:,1))
        if any(isnan(data.waveforms{j}(i,:))) == 1
            data.waveforms{j}(i,:)=nan;
            data.spiketimes{j}(i)=nan;
        else
            continue
        end
    end
end
%remove any nan values

for i=1:length(data.waveforms)
    data.waveforms{i}(~any(~isnan(data.waveforms{i}), 2),:)=[];
    data.spiketimes{i}(~any(~isnan(data.spiketimes{i}), 2),:)=[];
end

waitbar(1,f,'Loading Complete');


GMMsort;
GMM_loaddata;
close(f)
end
%% heatmap panel
% --- Executes during object creation, after setting all properties.
function uipanel2_CreateFcn(hObject, eventdata, handles)

global layout ans90

% p = uipanel('Position',[.472 .037 .176 .358]);
% p.Visible = 'off';


hObject.Title={};
hObject.BackgroundColor=[1 1 1];
% hObject.Position=[.45 .037 .176 .358];
% ax.Position = [0.0487253242795294 0.0370287057730822 0.948071613075621 0.926208651399492];
% if exist('X2','var') == 1
%// Define integer grid of coordinates for the above data
[X,Y] = meshgrid(1:size(layout,2), 1:size(layout,1));

%// Define a finer grid of points
[X88,Y88] = meshgrid(1:0.01:size(layout,2), 1:0.01:size(layout,1));

%// Interpolate the data and show the output
outData = interp2(X,Y,layout, X88, Y88,'linear');

nanvalues=isnan(outData);

layout44=layout;


for i=1:length(layout(:,1))
    for j=1:length(layout(1,:))
        if isnan(layout(i,j))
            layout44(i,j)= 0;
        else
        end
    end
end

%// Interpolate the data and show the output
outData = interp2(X,Y,layout44, X88, Y88,'cubic');

outData(nanvalues)=nan;


ax = axes(hObject);
imagesc(outData,'AlphaData',~isnan(outData));

%// Cosmetic changes for the axes
set(gca, 'XTick', linspace(1,size(X88,2),size(X,2)));
set(gca, 'YTick', linspace(1,size(X88,1),size(X,1)));
set(gca, 'XTickLabel', 1:size(X,2));
set(gca, 'YTickLabel', 1:size(X,1));

%// Add colour bar
% colorbar;
% heatmap(layout,ans90,(1:12),true,'Gridlines','-','Colorbar',true,'ShowAllTicks',true,'TickFontSize',30)
set(gca,'XtickLabel', ans90,'Fontsize',5);
% title('Multi-Unit Activity over 1 min','Fontsize',8);
% colorbar;
% else
%     plot(1,1)
% end

delete(hObject.Children(2))


end
%% rasterplot panel
% --- Executes during object creation, after setting all properties.
function uipanel3_CreateFcn(hObject, eventdata, handles)
global xpoints ypoints ends2 starts2 ypointsburst1 timesss joost M2 burst6


hObject.Title={};
ax = axes(hObject);
hObject.BackgroundColor=[1 1 1];
% hObject.Position=[.673 .037 .176 .358];

resolution = 0.001; %binsize of 1 ms
sigma = 0.1 ; %100 ms STD of gaussian
% Use hist to bin
EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
N = histc(xpoints, EDGES);
%Time ranges form -3*st. dev. to 3*st. dev.
edges = (-3*sigma:resolution:3*sigma);
%Evaluate the Gaussian kernel
kernel = normpdf(edges,0,sigma);
%Multiply by bin width
kernel = kernel.*resolution;
%Convolve spike data with the kernel
if isempty(N)
    return
else
    s = conv(N,kernel);
    s =s/resolution; % to get the firing rate
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
    %     %Trim out the relevant portion of the spike density
    %     s=s(center:1000+center-1);
    s = s(center:end-center-1);
    %     s = (s- min(s))/(max(s) -min(s)); % normalzie numbers to be between 0
    %     and 1
    %     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    t = (1:length(s))*resolution ;
    gg = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    plot(t,s,'k');
    xlim([0 timesss])
    ylabel('AWFR (Hz)','Fontsize',7);
    xlabel('Time(s)','Fontsize',10);
    % set(gca,'XTick',[]);    % no x numbers
    correctxlim = get(gca,'XLim');
    
    
    % calculate the rasterplot
    yy = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        % Save points and update current index
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(xPoints, yPoints, 'k')
    set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    ylabel('Channels');
    if length(burst6) == 60
        ylim([0 60])
    elseif length(burst6) == 120
        ylim([0 120])
    end
    % end
    
    % delete(hObject.Children(3))
    % delete(hObject.Children(2))
    
end
end
%% top 10 most active channel panel
% --- Executes during object creation, after setting all properties.
function uipanel4_CreateFcn(hObject, eventdata, handles)
global imaxch X2 filteredData1 HITS imaxch2 timesss RMS7 noiseall18 noiseall2 joost fs

ax = axes(hObject);
hObject.Title={};

hObject.BackgroundColor=[1 1 1];
% hObject.Position=[.009 .033 .398 .348];
% ax.Position = [0.0487253242795294 0.0370287057730822 0.948071613075621 0.926208651399492];

if joost == 1
else
    [~,imaxch] = maxk(cell2mat(HITS(:,2)),10);
    P=imaxch(1);
    subplot(511);
    plot(X2,filteredData1(P,:));
    xlim([0 timesss]);
    
    hold on
    plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
        plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
        hold on
        plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
    else
        plot(noiseall18{P,1},noiseall2{P,1},'r');
    end
    ylabel(['',HITS(imaxch(1,1))]);
    set(gca,'xtick',[])
    title('Top 5 most active channels');
    oooo=legend('Trace','Positive Threshold','Negative Threshold','Unit-Free Period','Fontsize',5);
    oooo.FontSize=5;
    set(legend,...
        'Position',[1.24000978654402e-05 0.000245518612941189 0.15825374906255 0.105329946515524],...
        'FontSize',5);
    
    P=imaxch(2);
    subplot(512);
    plot(X2,filteredData1(P,:));
    xlim([0 timesss]);
    
    hold on
    plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
        plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
        hold on
        plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
    else
        plot(noiseall18{P,1},noiseall2{P,1},'r');
    end
    ylabel(['',HITS(imaxch(2,1))]);
    set(gca,'xtick',[])
    
    P=imaxch(3);
    subplot(513);
    plot(X2,filteredData1(P,:));
    xlim([0 timesss]);
    
    hold on
    plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
        plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
        hold on
        plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
    else
        plot(noiseall18{P,1},noiseall2{P,1},'r');
    end
    ylabel(['',HITS(imaxch(3,1))]);
    set(gca,'xtick',[])
    
    P=imaxch(4);
    subplot(514);
    plot(X2,filteredData1(P,:));
    xlim([0 timesss]);
    
    hold on
    plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
        plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
        hold on
        plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
    else
        plot(noiseall18{P,1},noiseall2{P,1},'r');
    end
    ylabel(['',HITS(imaxch(4,1))]);
    set(gca,'xtick',[])
    
    P=imaxch(5);
    subplot(515);
    plot(X2,filteredData1(P,:));
    xlim([0 timesss]);
    
    hold on
    plot(X2,RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    plot(X2,-RMS7(P,1)*ones(length(X2),1)','k');
    hold on
    if length(noiseall18{P,1}) > fs.filtersettings.sampling_frequency
        plot(noiseall18{P,1}(1:fs.filtersettings.sampling_frequency),noiseall2{P,1}(1:fs.filtersettings.sampling_frequency),'r')
        hold on
        plot(noiseall18{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),noiseall2{P,1}((fs.filtersettings.sampling_frequency+1):(fs.filtersettings.sampling_frequency*2)),'r')
    else
        plot(noiseall18{P,1},noiseall2{P,1},'r');
    end
    ylabel(['',HITS(imaxch(5,1))]);
    xlabel('Time in Seconds');
    
end




end
%% connections panel
%% save figures
% --- Executes on button press in pushbutton65.
function pushbutton65_Callback(hObject, eventdata, handles)

startingFolder = userpath;
defaultFileName = fullfile(startingFolder, '*.*');
[baseFileName, folder] = uiputfile(defaultFileName, 'Specify a name');
if baseFileName == 0
    return;
else
    f=figure('visible','off');
    copyobj(handles.uipanel7.Children(2), f);
    print(f,baseFileName,'-dtiff','-r1200')
    extension1 = '.tif';
    movefile(strcat(baseFileName,extension1),folder,'f');
    close(f);
end


end

% --- Executes during object creation, after setting all properties.
function pushbutton65_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Export Figure';
hObject.Position = [0.7045 0.513 0.111 0.027];
hObject.FontWeight = 'bold';
end


% --- Executes on button press in pushbutton66.
function pushbutton66_Callback(hObject, eventdata, handles)

startingFolder = userpath;
defaultFileName = fullfile(startingFolder, '*.*');
[baseFileName, folder] = uiputfile(defaultFileName, 'Specify a name');
if baseFileName == 0
    return;
else
    f=figure('visible','off');
    copyobj(handles.uipanel6.Children(2), f);
    print(f,baseFileName,'-dtiff','-r1200')
    extension1 = '.tif';
    movefile(strcat(baseFileName,extension1),folder);
    close(f);
end
end

% --- Executes during object creation, after setting all properties.
function pushbutton66_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Export Figure';
hObject.Position = [0.296 0.513 0.111 0.027];
hObject.FontWeight = 'bold';
end


% --- Executes on button press in pushbutton67.
function pushbutton67_Callback(hObject, eventdata, handles)
end

% --- Executes during object creation, after setting all properties.
function pushbutton67_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Export Figure';
hObject.FontWeight = 'bold';
hObject.Position = [0.296 0.01 0.111 0.027];
end



% --- Executes on button press in pushbutton68.
function pushbutton68_Callback(hObject, eventdata, handles)
end

% --- Executes during object creation, after setting all properties.
function pushbutton68_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Export Figure';
hObject.FontWeight = 'bold';
hObject.Position = [0.7045 0.01 0.111 0.027];
end
%% actual code for the connection panel
% --- display only the top 200 connections
function checkbox3_Callback(hObject, eventdata, handles)
global only200
if hObject.Value == 1
    only200 = 1;
elseif hObject.Value == 0
    only200 = 0;
end

end

% --- display only the top 200 connections
function checkbox3_CreateFcn(hObject, eventdata, handles)
global only200

only200 = 0;
hObject.Visible ='off';
hObject.String = 'Display Max 200';
hObject.BackgroundColor = [0.97 0.98 0.98];
hObject.Position = [0.878 0.544 0.059 0.048];

end

% --- save button for connections
function pushbutton61_Callback(hObject, eventdata, handles)
global Connections looo12

if hObject.Value == 1
    Connections = looo12;
end

end

% --- save button for connections
function pushbutton61_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.BackgroundColor = [.97,.98,.98];
hObject.String = 'Save';
hObject.Position = [0.861 0.678 0.096 0.048];
end

% --- Checkbox for arrows or lines
function checkbox2_Callback(hObject, eventdata, handles)
global arrowss

if hObject.Value == 1
    arrowss = 1;
elseif hObject.Value == 0
    arrowss = 0;
end

end

% --- Checkbox for arrows or lines
function checkbox2_CreateFcn(hObject, eventdata, handles)
global arrowss
arrowss = 0;

hObject.BackgroundColor = [.97,.98,.98];
% hObject.Visible = 'off';
hObject.String = 'Display Direction';
hObject.Position = [0.878 0.608 0.059 0.028];

end


% --- Change threshold connectivity matrix
function pushbutton60_Callback(hObject, eventdata, handles)
global thrconnec indx23


prompt = {'Threshold Value for the connectivity matrix'};
dlgtitle = 'Connectivity Matrix Threshold';
if indx23 == 1
    definput = {'1'};
elseif indx23 == 2
    definput = {'0.7'};
end
opts.Interpreter = 'tex';
answer = inputdlg(prompt,dlgtitle,[1 55],definput,opts);

if thrconnec ~= str2double(answer)
    thrconnec = str2double(answer);
else
    if indx23 == 1
        thrconnec = 1;
    elseif indx23 == 2
        thrconnec = 0.7;
    end
end



end


% --- change threshold connectivity matrix
function pushbutton60_CreateFcn(hObject, eventdata, handles)
global thrconnec indx23
hObject.Visible = 'off';
hObject.Position = [0.861 0.755 0.096 0.048];

if indx23 == 1
    thrconnec = 1;
elseif indx23 == 2
    thrconnec = 0.7;
end

end


% --- Executes during object creation, after setting all properties.
function pushbutton63_CreateFcn(hObject, eventdata, handles)
hObject.Visible ='off';
hObject.Position =[0.418 0.513 0.111 0.027];
end


% --- Executes during object creation, after setting all properties.
function pushbutton62_CreateFcn(hObject, eventdata, handles)
hObject.Visible ='off';
hObject.Position =[0.009 0.513 0.111 0.027];
end

% --- Executes on all connections
function pushbutton62_Callback(hObject, eventdata, handles)
global supa only200 newM2 looo12 textstrings selecteddata indx23 timesss finalssss thrconnec HITS filteredData1 M2 arrowss Ghibli  jitters M

if indx23 == 2
    
    supa1 = supa;
    %gotta turn the numbers around for the max function
    for i=1:length(M2)
        supa1{i}=supa1{i}';
    end
    
    for i=1:length(M2)
        supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
    end
    
    
    HITS48=HITS;
    
    lp=rand(1,length(HITS))+rand(1,length(HITS));
    kp=rand(1,length(HITS))+rand(1,length(HITS));
    ml=rand(1,length(HITS))+0.68;
    lp=lp+kp+ml;
    lp=lp';
    for i=1:length(HITS)
        HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
    end
    
    
    if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
        layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
    elseif length(filteredData1(:,1)) > 121
        layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
    else %% for 120 channel MEA
        layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
    end
    
    %     ax = axes(hObject);
    imagesc(layout4,'AlphaData',~isnan(layout4));
    
    if length(textstrings) > 400
        [x, y] = meshgrid(1:24);
        for i=[24 23 22 21 20]
            x(i,:)=[];
            y(i,:)=[];
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    else
        [x, y] = meshgrid(1:12);
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    end
    
    
    %         waitbar(0 + 0.9,hh,'Drawing the Connections');
    top60=cell2mat(supa1);
    top60(top60 < thrconnec) = 0;
    % change nan values into zeros
    
    %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
    
    [B,I]=sort(top60,'descend');   % order them
    ghg=find(B == 0); %remove all the zeros
    I(ghg)=[];
    
    
    if length(filteredData1(:,1)) == 60
        I=I(:)/60;
    else
        I=I(:)/120;
    end
    
    if only200 == 1 %display only the top 200 connections
        if length(I) > 200
            I=I(1:200);
        end
    end
    
    %each 120 elements belong to one channel
    %firsst column will be the origin of the line
    %2nd column will be the destination of the line
    I(:,2)=floor(I(:,1));
    I(:,3)=I(:,1) - I(:,2);
    
    if length(filteredData1(:,1)) == 60
        I(:,3)=I(:,3)*60;
    else
        I(:,3)=I(:,3)*120;
    end
    
    I(:,3)=round(I(:,3));
    I(:,2)=ceil(I(:,1));
    I(I<1) = 1;
    ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
    removeindx = find(cell2mat(HITS(:,2)) <= 10);
    
    I(ismember(I(:,2),removeindx)) =0;
    I(ismember(I(:,2),removeindx),3) =0;
    I(ismember(I(:,2),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),1) =0;
    I(ismember(I(:,3),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),3) =0;
    
    for i = length(I):-1:1
        if I(i,1) == 0
            I(i,:) = [];
        end
    end
    
    for i=1:size(I,1)
        yutr=I(i,2);
        
        kk=ag(ag==yutr); % added for joosts method
        lll=find(layout4 == HITS48{kk,2});
        [r,c] = ind2sub(size(layout4),lll);
        
        k=I(i,3);
        llll=find(layout4 == HITS48{k,2});
        [rr,cc] = ind2sub(size(layout4),llll);
        hold on
        if arrowss == 1
            nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
        elseif arrowss == 0
            nnn=line([c cc],[r rr],'Color','r');
        end
        drawnow;
        colmin=min(top60(:));
        colmax=max(top60(:));
        COLOR1=parula(length(top60));
        goodcolor=COLOR1(round(length(top60)*(top60(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
        nnn.Color=goodcolor;
        cbn=colorbar;
        cbn.Colormap=parula(length(top60));
        cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        
    end
    
    set(gca,'visible','off');
    set(gca,'Colormap',[1 1 1]);
    %     save([selecteddata '.mat'],'looo12','-append','-v6')
else
    
    
    % %     edges = 0:0.001:timesss;
    % %     edges=edges(1:end-1);
    %1 bin is 1ms
    
    % %     supa=cell(1,length(M2));
    % %     for i=1:length(M2)
    % %          waitbar(i/length(M2))
    % %         if isempty(M2{i,1})
    % %             supa{i}=[];
    % %             continue
    % %         end
    % %
    % %
    % %         finalssss=zeros(length(filteredData1(:,1)),301);
    % %         for j=1:length(M2)
    % %
    % %             if isempty(M2{j,1})
    % %                 %             finalssss(j,:)=[];
    % %                 supa{i}=[];
    % %                 continue
    % %             else
    % %                 binned_data=histc((M2{j,1}),edges);  %get bins of 1 ms  %target spike train
    % %                 binned_data1=histc((M2{i,1}),edges); %reference spike train
    % %
    % %                 xc = xcorr(binned_data,binned_data1);
    % %
    % %                 xc = xc(round(length(xc)/2)-150:round(length(xc)/2)+150);
    % %                 xc = xc /(sqrt(length(find(binned_data > 0))*length(find(binned_data1 > 0)))); % Normalization by the product of X and Y spikes
    % %
    % %                 finalssss(j,:)=xc;
    % %                 finalssss(i,:)=zeros(1,301);  % remove the autocorrelation
    % %             end
    % %
    % %
    % %         end
    % %         supa{i}=finalssss;
    % %     end
    % %     supa=supa';
    % %
    % %     close(hh)
    %% old
    %     supa1 = supa; old
    %
    %     for i=1:length(M2)
    %         if isempty(supa1{i})
    %             continue
    %         end
    %         M = max(supa1{i}(:));          %depict the cross correlation in percentages
    %         supa1{i}=supa1{i}/M;
    %     end
    %
    
    %gotta turn the numbers around for the max function
    %     for i=1:length(M2)
    %         supa1{i}=supa1{i}';
    %     end
    %
    %     for i=1:length(M2)
    %         supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
    %     end
    %
    %%
    if isempty(M)
        msgbox('there are no connections!')
    else
        supa1=cell(1,length(M2))';
        for i = 1:length(M2) % added for joost's method
            supa1{i} = M(i,:)';
            
        end
        
        %higher than 70% we will draw a line (spikecode did this aswell
        %so now the only thing we need to do is draw a line if the number exceeds
        %0.7 or 70% SPYCODE threshhold
        
        %use the below layout structure to get the correct position
        
        %So what needs to happen is 3 things, we will first check if in supa
        %soemthing has passed the 0.7 mark and if it does the next thing it will do
        %is search in the layout for the correct position and the last step is to
        %draw a line
        
        %we have to make the numbers uin HITS all unqiue so we won't have issues with duplicates
        
        HITS48=HITS;
        lp=rand(1,length(HITS))+rand(1,length(HITS));
        kp=rand(1,length(HITS))+rand(1,length(HITS));
        ml=rand(1,length(HITS))+0.68;
        lp=lp+kp+ml;
        lp=lp';
        
        for i=1:length(HITS)
            HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
        end
        
        if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
            layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
        elseif length(filteredData1(:,1)) > 121
            layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
        else
            layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
        end
        
        axes22 = axes(handles.uipanel6);
        %     ax = axes(hObject);
        imagesc(layout4,'AlphaData',~isnan(layout4));
        
        if length(textstrings) > 400
            [x, y] = meshgrid(1:24);
            for i=[24 23 22 21 20]
                x(i,:)=[];
                y(i,:)=[];
            end
            hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
                'HorizontalAlignment', 'center');
        else
            [x, y] = meshgrid(1:12);
            hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
                'HorizontalAlignment', 'center');
        end
        
        
        
        
        
        top60=cell2mat(supa1);
        
        %     top60(top60 < mean(maxk(top60,10)) + (2*std(maxk(top60,10))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
        %     top60(top60 < 0.7) = 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
        
        
        % the suer can introduce an additional threshold
        if handles.pushbutton60.Value == 1
            top60(top60 < (mean(M,'all','omitnan') + thrconnec*std(M,1,'all','omitnan'))) = 0; % new
        end
        top60(isnan(top60)) =0; %new
        %     top60(top60 == 0) =[];
        
        
        [B,I]=sort(top60,'descend');   % order them
        ghg=find(B == 0); %remove all the zeros
        I(ghg)=[];
        
        if only200 == 1 %display only the top 200 connections
            if length(I) > 200
                I=I(1:200);
                B = B(1:200);
            end
        end
        
        if length(supa1{1}) == 60 % changed it due to the just spike times
            I=I(:)/60;
        else
            I=I(:)/120;
        end
        
        
        %each 120 elements belong to one channel
        %firsst column will be the origin of the line
        %2nd column will be the destination of the line
        I(:,2)=floor(I(:,1));
        I(:,3)=I(:,1) - I(:,2);
        
        if length(supa1{1}) == 60 % changed it due to the kjust spike times
            I(:,3)=I(:,3)*60;
        else
            I(:,3)=I(:,3)*120;
        end
        
        I(:,3)=round(I(:,3));
        I(:,2)=ceil(I(:,1));
        I(I<1) = 1;
        ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
        
        removeindx = find(cell2mat(HITS(:,2)) <= 10);
        
        I(ismember(I(:,2),removeindx)) =0;
        I(ismember(I(:,2),removeindx),3) =0;
        I(ismember(I(:,2),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),1) =0;
        I(ismember(I(:,3),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),3) =0;
        
        for i = length(I):-1:1
            if I(i,1) == 0
                I(i,:) = [];
            end
        end
        
        looo12 = size(I,1);
        
        for i=1:size(I,1)
            yutr=I(i,2);
            kk=ag(ag == yutr); %new
            lll=find(layout4 == HITS48{kk,2});
            [r,c] = ind2sub(size(layout4),lll);
            
            k=I(i,3);
            llll=find(layout4 == HITS48{k,2});
            [rr,cc] = ind2sub(size(layout4),llll);
            hold on
            if arrowss == 1
                nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
            elseif arrowss == 0
                nnn = line([c cc],[r rr],'Color','r');
            end
            drawnow;
            colmin=0;
            %         colmin=min(B(:));
            colmax=max(B(:));
            COLOR1=parula(length(B));
            goodcolor=COLOR1(round(length(B)*(B(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
            nnn.Color=goodcolor;
            cbn=colorbar;
            cbn.Colormap=parula(length(B));
            cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
            
        end
        
        set(gca,'visible','off');
        set(gca,'Colormap',[1 1 1]);
        %     save([selecteddata '.mat'],'looo12','-append','-v6')
    end
end

text84_ButtonDownFcn(handles.text84,eventdata,handles)
handles.text84.Visible = 'on';
clear supa1 supa
end

% --- Executes on 60 strongest connections
function pushbutton63_Callback(hObject, eventdata, handles)
global supa newM2 looo textstrings indx23 selecteddata timesss finalssss thrconnec HITS filteredData1 M2 M arrowss


if indx23 == 2 % cross correlation
    supa1 = supa;
    %gotta turn the numbers around for the max function
    for i=1:length(M2)
        supa1{i}=supa1{i}';
    end
    
    for i=1:length(M2)
        supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
    end
    
    
    HITS48=HITS;
    
    lp=rand(1,length(HITS))+rand(1,length(HITS));
    kp=rand(1,length(HITS))+rand(1,length(HITS));
    ml=rand(1,length(HITS))+0.68;
    lp=lp+kp+ml;
    lp=lp';
    for i=1:length(HITS)
        HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
    end
    
    
    if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
        layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
    elseif length(filteredData1(:,1)) > 121
        layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
    else %% for 120 channel MEA
        layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
    end
    
    ax = axes(hObject);
    imagesc(layout4,'AlphaData',~isnan(layout4));
    
    if length(textstrings) > 400
        [x, y] = meshgrid(1:24);
        for i=[24 23 22 21 20]
            x(i,:)=[];
            y(i,:)=[];
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    else
        [x, y] = meshgrid(1:12);
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    end
    
    
    %         waitbar(0 + 0.9,hh,'Drawing the Connections');
    top60=cell2mat(supa1);
    top60(top60 < thrconnec) = 0;
    
    
    %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
    
    [B,I]=sort(top60,'descend');   % order them
    ghg=find(B == 0); %remove all the zeros
    I(ghg)=[];
    
    %get the top60 connections if the length of I is longer than 60
    if length(I) > 60
        I=I(1:60);
    end
    
    if length(filteredData1(:,1)) == 60
        I=I(:)/60;
    else
        I=I(:)/120;
    end
    
    
    %each 120 elements belong to one channel
    %firsst column will be the origin of the line
    %2nd column will be the destination of the line
    I(:,2)=floor(I(:,1));
    I(:,3)=I(:,1) - I(:,2);
    
    if length(filteredData1(:,1)) == 60
        I(:,3)=I(:,3)*60;
    else
        I(:,3)=I(:,3)*120;
    end
    
    I(:,3)=round(I(:,3));
    I(:,2)=ceil(I(:,1));
    I(I<1) = 1;
    ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
    removeindx = find(cell2mat(HITS(:,2)) <= 10);
    
    I(ismember(I(:,2),removeindx)) =0;
    I(ismember(I(:,2),removeindx),3) =0;
    I(ismember(I(:,2),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),1) =0;
    I(ismember(I(:,3),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),3) =0;
    
    for i = length(I):-1:1
        if I(i,1) == 0
            I(i,:) = [];
        end
    end
    
    for i=1:size(I,1)
        yutr=I(i,2);
        
        kk=ag(ag==yutr); % added for joosts method
        lll=find(layout4 == HITS48{kk,2});
        [r,c] = ind2sub(size(layout4),lll);
        
        k=I(i,3);
        llll=find(layout4 == HITS48{k,2});
        [rr,cc] = ind2sub(size(layout4),llll);
        hold on
        if arrowss == 1
            nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
        elseif arrowss == 0
            nnn=line([c cc],[r rr],'Color','r');
        end
        drawnow;
        colmin=min(top60(:));
        colmax=max(top60(:));
        COLOR1=parula(length(top60));
        goodcolor=COLOR1(round(length(top60)*(top60(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
        nnn.Color=goodcolor;
        cbn=colorbar;
        cbn.Colormap=parula(length(top60));
        cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
    end
    
    set(gca,'visible','off');
    set(gca,'Colormap',[1 1 1]);
else
    supa1=cell(1,length(M2))';
    
    if isempty(M)
        msgbox('there are no connections!')
    else
        for i = 1:length(M2) % added for joost's method
            supa1{i} = M(i,:)';
        end
        % remove channels that have less than 10 spikes
        %     supa1 =supa;
        %     supa1(cell2mat(HITS(:,2)) <= 10) = {[]};
        %     removeindx = (cell2mat(HITS(:,2)) <= 10);
        %
        %
        %     for i = 1:length(M2)
        %         supa1{i}(removeindx,:) = 0;
        %     end
        
        %     for i=1:length(M2)
        %         if isempty(supa1{i})
        %             continue
        %         end
        %         M = max(supa1{i}(:));          %depict the cross correaltion in percentages
        %         supa1{i}=supa1{i}/M;
        %     end
        
        
        %gotta turn the numbers around for the max function
        %     for i=1:length(M2)
        %         supa1{i}=supa1{i}';
        %     end
        %
        %     for i=1:length(M2)
        %         supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
        %     end
        
        %higher than 70% we will draw a line (spikecode this this aswell
        %so now the only thing we need to do is draw a line if the number exceeds
        %0.7 or 70% SPYCODE threshhold
        
        %use the below layout structure to get the correct position
        
        %So what needs to happen is 3 things, we will first check if in supa
        %soemthing has passed the 0.7 mark and if it does the next thing it will do
        %is search in the layout for the correct position and the last step is to
        %draw a line
        
        %we have to make the numbers uin HITS all unqiue so we won't have issues with duplicates
        
        HITS48=HITS;
        
        lp=rand(1,length(HITS))+rand(1,length(HITS));
        kp=rand(1,length(HITS))+rand(1,length(HITS));
        ml=rand(1,length(HITS))+0.68;
        lp=lp+kp+ml;
        lp=lp';
        for i=1:length(HITS)
            HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
        end
        
        
        if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
            layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
        elseif length(filteredData1(:,1)) > 121
            layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
        else %% for 120 channel MEA
            layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
        end
        
        %     ax = axes(hObject);
        axes23 = axes(handles.uipanel7);
        
        imagesc(layout4,'AlphaData',~isnan(layout4));
        
        if length(textstrings) > 400
            [x, y] = meshgrid(1:24);
            for i=[24 23 22 21 20]
                x(i,:)=[];
                y(i,:)=[];
            end
            hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
                'HorizontalAlignment', 'center');
        else
            [x, y] = meshgrid(1:12);
            hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
                'HorizontalAlignment', 'center');
        end
        
        
        %         waitbar(0 + 0.9,hh,'Drawing the Connections');
        top60=cell2mat(supa1);
        if handles.pushbutton60.Value == 1
            top60(top60 < (mean(M,'all','omitnan') + thrconnec*std(M,1,'all','omitnan'))) = 0; % new
        end
        
        % change nan values into zeros
        top60(isnan(top60)) =0; %% new added for joost's method
        %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
        
        [B,I]=sort(top60,'descend');   % order them
        ghg=find(B == 0); %remove all the zeros
        I(ghg)=[];
        
        %get the top60 connections if the length of I is longer than 60
        if length(I) > 60
            I = I(1:60);
            B = B(1:60);
        end
        
        if length(supa1{1}) == 60 % changed it due to the kjust spike times
            I=I(:)/60;
        else
            I=I(:)/120;
        end
        
        
        %each 120 elements belong to one channel
        %firsst column will be the origin of the line
        %2nd column will be the destination of the line
        I(:,2)=floor(I(:,1));
        I(:,3)=I(:,1) - I(:,2);
        
        if length(supa1{1}) == 60 % changed it due to the kjust spike times
            I(:,3)=I(:,3)*60;
        else
            I(:,3)=I(:,3)*120;
        end
        
        I(:,3)=round(I(:,3));
        I(:,2)=ceil(I(:,1));
        I(I<1) = 1;
        ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
        removeindx = find(cell2mat(HITS(:,2)) <= 10);
        
        I(ismember(I(:,2),removeindx)) =0;
        I(ismember(I(:,2),removeindx),3) =0;
        I(ismember(I(:,2),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),1) =0;
        I(ismember(I(:,3),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),3) =0;
        
        for i = length(I):-1:1
            if I(i,1) == 0
                I(i,:) = [];
            end
        end
        
        for i=1:size(I,1)
            yutr=I(i,2);
            
            kk=ag(ag==yutr); % added for joosts method
            lll=find(layout4 == HITS48{kk,2});
            [r,c] = ind2sub(size(layout4),lll);
            
            k=I(i,3);
            llll=find(layout4 == HITS48{k,2});
            [rr,cc] = ind2sub(size(layout4),llll);
            hold on
            if arrowss == 1
                nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
            elseif arrowss == 0
                nnn=line([c cc],[r rr]);
            end
            drawnow;
            colmin=0;
            %         colmin=min(B(:));
            colmax=max(B(:));
            COLOR1=parula(length(B));
            goodcolor=COLOR1(round(length(B)*(B(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
            nnn.Color=goodcolor;
            cbn=colorbar;
            cbn.Colormap=parula(length(B));
            cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
            
        end
        
        set(gca,'visible','off');
        colorbar
        set(gca,'Colormap',[1 1 1]);
        
        
        
    end
    clear supa1 supa
end
end

% Connection panel for all connections (Only show the top 200 and display
% the total connections)
function uipanel6_ButtonDownFcn(hObject, eventdata, handles)


end


% --- Executes during object creation, after setting all properties.
function uipanel6_CreateFcn(hObject, eventdata, handles)
hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.009 .54 .398 .358];
end


% --- Executes during object creation, after setting all properties.
function uipanel7_CreateFcn(hObject, eventdata, handles)
hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
%hObject.Position=[.01 .037 .398 .358];
hObject.Position=[.418 .54 .398 .358];
end


% ----------------60 strongest connections
function uipanel7_ButtonDownFcn(hObject, eventdata, handles)

end

% This button when pressed allows the user to select the method to
% determine the connections for the maps
function pushbutton38_Callback(hObject, eventdata, handles)
global indx23 thrconnec

% list = {'Conditional firing probabilities','Cross Correlation'};
% [indx23,~] = listdlg('PromptString','Select a Method','SelectionMode','single','ListString',list);
indx23 = 1; %CFP
if indx23 == 1
    thrconnec = 1;
elseif indx23 == 2
    thrconnec = 0.7;
end


hObject.Visible = 'off';
handles.pushbutton39.Visible = 'on' ;
handles.pushbutton41.Visible = 'on' ;
handles.checkbox2.Visible = 'on';
handles.pushbutton60.Visible ='off';
handles.pushbutton61.Visible = 'off';
handles.checkbox3.Visible = 'on';
handles.pushbutton12.Visible ='off';
handles.pushbutton62.Visible ='on';
handles.pushbutton63.Visible ='on';
handles.pushbutton65.Visible ='on';
handles.pushbutton66.Visible ='on';
% handles.pushbutton67.Visible ='on';
% handles.pushbutton68.Visible ='on';
end


%This is the creation of the button 38 (code here is only to make the
%button invisible
function pushbutton38_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off' ;
hObject.String = 'Load';
end


% --- this button is for channel A
function uipanel8_CreateFcn(hObject, eventdata, handles)

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.009 .037 .398 .358];


end


% -for Channel A
function uipanel8_ButtonDownFcn(hObject, eventdata, handles)

end


% --- Executes on button press inchannel; A
function pushbutton39_Callback(hObject, eventdata, handles)
global jitters Ghibli textstrings HITS indx23 supa  newM2 looop  filteredData1 M2  thrconnec timesss finalssss M arrowss


prompt = {'Enter Channel name A:'};
title = 'Connectivity Map';
dims = [1 35];
definput = {'A1'};
jitters{1} = inputdlg(prompt,title,dims,definput);

if indx23 == 1
    Ghibli(1)=find(strcmp(textstrings(:,1),jitters{1}));
elseif  indx23 == 2
    textstrings1 = HITS(:,1);
    Ghibli(1)=find(strcmp(textstrings1(:,1),jitters{1}));
end

% yup=input('Which channel do you want to cross correlate?');
% Ghibli=find(strncmpi(HITS,yup,3));
if indx23 == 2
    
    
    supa1 = supa;
    %gotta turn the numbers around for the max function
    for i=1:length(M2)
        supa1{i}=supa1{i}';
    end
    
    for i=1:length(M2)
        supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
    end
    
    
    HITS48=HITS;
    
    lp=rand(1,length(HITS))+rand(1,length(HITS));
    kp=rand(1,length(HITS))+rand(1,length(HITS));
    ml=rand(1,length(HITS))+0.68;
    lp=lp+kp+ml;
    lp=lp';
    for i=1:length(HITS)
        HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
    end
    
    
    if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
        layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
    elseif length(filteredData1(:,1)) > 121
        layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
    else %% for 120 channel MEA
        layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
    end
    
    ax = axes(hObject);
    imagesc(layout4,'AlphaData',~isnan(layout4));
    
    if length(textstrings) > 400
        [x, y] = meshgrid(1:24);
        for i=[24 23 22 21 20]
            x(i,:)=[];
            y(i,:)=[];
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    else
        [x, y] = meshgrid(1:12);
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    end
    
    
    %         waitbar(0 + 0.9,hh,'Drawing the Connections');
    top60=cell2mat(supa1);
    top60(top60 < thrconnec) = 0;
    % change nan values into zeros
    
    %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
    
    [B,I]=sort(top60,'descend');   % order them
    ghg=find(B == 0); %remove all the zeros
    I(ghg)=[];
    
    %get the top60 connections if the length of I is longer than 60
    if length(I) > 60
        I=I(1:60);
    end
    
    if length(filteredData1(:,1)) == 60
        I=I(:)/60;
    else
        I=I(:)/120;
    end
    
    
    %each 120 elements belong to one channel
    %firsst column will be the origin of the line
    %2nd column will be the destination of the line
    I(:,2)=floor(I(:,1));
    I(:,3)=I(:,1) - I(:,2);
    
    if length(filteredData1(:,1)) == 60
        I(:,3)=I(:,3)*60;
    else
        I(:,3)=I(:,3)*120;
    end
    
    I(:,3)=round(I(:,3));
    I(:,2)=ceil(I(:,1));
    I(I<1) = 1;
    ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
    removeindx = find(cell2mat(HITS(:,2)) <= 10);
    
    I(ismember(I(:,2),removeindx)) =0;
    I(ismember(I(:,2),removeindx),3) =0;
    I(ismember(I(:,2),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),1) =0;
    I(ismember(I(:,3),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),3) =0;
    
    for i = length(I):-1:1
        if I(i,1) == 0
            I(i,:) = [];
        end
    end
    
    %also delete connections that do not involve the channel of interest
    %     correctindex = find(I(:,2) == Ghibli(1));
    %     correctindex2 = find(I(:,3) == Ghibli(1));
    %     indexfull = [correctindex;correctindex2]; % this contains the indeices that have connections with the channel of interest
    %
    for i = length(I):-1:1
        if I(i,2) == Ghibli(1) || I(i,3) == Ghibli(1)
        else
            I(i,:) = [];
        end
    end
    
    
    
    
    looop= 0 ;
    
    for i=1:size(I,1)
        yutr=I(i,2);
        looop = looop+1;
        kk=ag(ag==yutr); % added for joosts method
        lll=find(layout4 == HITS48{kk,2});
        [r,c] = ind2sub(size(layout4),lll);
        
        k=I(i,3);
        llll=find(layout4 == HITS48{k,2});
        [rr,cc] = ind2sub(size(layout4),llll);
        hold on
        if arrowss == 1
            nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
        elseif arrowss == 0
            nnn=line([c cc],[r rr],'Color','r');
        end
        drawnow;
        colmin=min(top60(:));
        colmax=max(top60(:));
        COLOR1=parula(length(top60));
        goodcolor=COLOR1(round(length(top60)*(top60(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
        nnn.Color=goodcolor;
        cbn=colorbar;
        cbn.Colormap=parula(length(top60));
        cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        
    end
    
    
    set(gca,'visible','off');
    set(gca,'Colormap',[1 1 1]);
    
else
    if isempty(M)
        msgbox('there are no connections!')
    else
        supa1=cell(1,length(M2))';
        for i = 1:length(M2) % added for joost's method
            supa1{i} = M(i,:)';
            
        end
        % need to change the numbers from the user input as the index doesnt
        % match anymore
        
        Ghibli(1)=find(strcmp(HITS(:,1),jitters{1}));
        % %     edges = 0:0.001:timesss;
        % %     edges=edges(1:end-1);
        %1 bin is 1ms
        
        
        % %     supa=cell(1,length(M2));
        % %     for i=1:length(M2)
        % %         waitbar(i/length(M2))
        % %         if isempty(M2{i,1})
        % %             supa{i}=[];
        % %             continue
        % %         end
        % %
        % %         finalssss=zeros(length(filteredData1(:,1)),301);
        % %         for j=1:length(M2)
        % %
        % %             if isempty(M2{j,1})
        % %                 %             finalssss(j,:)=[];
        % %                 supa{i}=[];
        % %                 continue
        % %             else
        % %                 binned_data=histc((M2{j,1}),edges);  %get bins of 1 ms  %target spike train
        % %                 binned_data1=histc((M2{i,1}),edges); %reference spike train
        % %
        % %                 xc = xcorr(binned_data, binned_data1);
        % %
        % %                 xc = xc(round(length(xc)/2)-150:round(length(xc)/2)+150);
        % %                 xc = xc /(sqrt(length(find(binned_data > 0))*length(find(binned_data1 > 0)))); % Normalization by the product of X and Y spikes
        % %
        % %                 finalssss(j,:)=xc;
        % %                 finalssss(i,:)=zeros(1,301);  % remove the autocorrealtion
        % %             end
        % %
        % %
        % %         end
        % %         supa{i}=finalssss;
        % %     end
        % %     supa=supa';
        % %     close(hh)
        % %
        
        %     supa1 = supa;
        %     %     for i=1:length(M2)
        %     %         if isempty(supa1{i})
        %     %             continue
        %     %         end
        %     %         M = max(supa1{i}(:));          %depict the cross correaltion in percentages
        %     %         supa1{i}=supa1{i}/M;
        %     %     end
        %     %
        %     %
        %
        %     %gotta turn the numbers around for the max function
        %     for i=1:length(M2)
        %         supa1{i}=supa1{i}';
        %     end
        %
        %     for i=1:length(M2)
        %         supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
        %     end
        
        %higher than 70% we will draw a line (spikecode this this aswell
        %so now the only thing we need to do is draw a line if the number exceeds
        %0.7 or 70% SPYCODE threshhold
        
        %use the below layout structure to get the correct position
        
        %So what needs to happen is 3 things, we will first check if in supa
        %soemthing has passed the 0.7 mark and if it does the next thing it will do
        %is search in the layout for the correct position and the last step is to
        %draw a line
        
        %we have to make the numbers uin HITS all unqiue so we won't have issues with duplicates
        
        HITS48=HITS;
        lp=rand(1,120)+rand(1,120);
        kp=rand(1,120)+rand(1,120);
        ml=rand(1,120)+0.68;
        lp=lp+kp+ml;
        lp=lp';
        for i=1:length(HITS)
            HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
        end
        
        
        
        
        if length(filteredData1(:,1)) == 60
            layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
        elseif length(filteredData1(:,1)) > 121
            layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
        else
            layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
        end
        
        ax24 = axes(handles.uipanel8);
        %     ax=axes(hObject);
        imagesc(layout4,'AlphaData',~isnan(layout4));
        
        if length(textstrings) > 400
            [x, y] = meshgrid(1:24);
            for i=[24 23 22 21 20]
                x(i,:)=[];
                y(i,:)=[];
            end
            hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
                'HorizontalAlignment', 'center');
        else
            [x, y] = meshgrid(1:12);
            hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
                'HorizontalAlignment', 'center');
        end
        
        
        top60=cell2mat(supa1);
        if handles.pushbutton60.Value == 1
            top60(top60 < (mean(M,'all','omitnan') + thrconnec*std(M,1,'all','omitnan'))) = 0; % new
        end
        
        top60(isnan(top60)) =0; %% new added for joost's method
        
        [B,I]=sort(top60,'descend');   % order them
        ghg=find(B == 0); %remove all the zeros
        I(ghg)=[];
        
        
        if length(supa1{1}) == 60 % changed it due to the kjust spike times
            I=I(:)/60;
        else
            I=I(:)/120;
        end
        
        
        %each 120 elements belong to one channel
        %firsst column will be the origin of the line
        %2nd column will be the destination of the line
        I(:,2)=floor(I(:,1));
        I(:,3)=I(:,1) - I(:,2);
        
        if length(supa1{1}) == 60 % changed it due to the kjust spike times
            I(:,3)=I(:,3)*60;
        else
            I(:,3)=I(:,3)*120;
        end
        
        I(:,3)=round(I(:,3));
        I(:,2)=ceil(I(:,1));
        I(I<1) = 1;
        ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
        removeindx = find(cell2mat(HITS(:,2)) <= 10);
        
        I(ismember(I(:,2),removeindx)) =0;
        I(ismember(I(:,2),removeindx),3) =0;
        I(ismember(I(:,2),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),1) =0;
        I(ismember(I(:,3),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),3) =0;
        
        for i = length(I):-1:1
            if I(i,1) == 0
                I(i,:) = [];
            end
        end
        %also delete connections that do not involve the channel of interest
        
        for i = length(I):-1:1
            if I(i,2) == Ghibli(1) || I(i,3) == Ghibli(1)
            else
                I(i,:) = [];
            end
        end
        
        looop=0;
        
        for i=1:size(I,1)
            yutr=I(i,2);
            looop =looop+1;
            kk=ag(ag==yutr); % added for joosts method
            lll=find(layout4 == HITS48{kk,2});
            [r,c] = ind2sub(size(layout4),lll);
            
            k=I(i,3);
            llll=find(layout4 == HITS48{k,2});
            [rr,cc] = ind2sub(size(layout4),llll);
            hold on
            if arrowss == 1
                nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
            elseif arrowss == 0
                nnn=line([c cc],[r rr],'Color','r');
            end
            drawnow;
            colmin=0;
            %         colmin=min(B(:));
            colmax=max(B(:));
            COLOR1=parula(length(B));
            goodcolor=COLOR1(round(length(B)*(B(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
            nnn.Color=goodcolor;
            cbn=colorbar;
            cbn.Colormap=parula(length(B));
            cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
            
        end
        
        
        set(gca,'visible','off');
        set(gca,'Colormap',[1 1 1]);
    end
    clear supa1 supa
    
    text82_ButtonDownFcn(handles.text82,eventdata,handles)
    handles.text82.Visible = 'on';
    set(handles.Pannel_9.Text,'String',strjoin(['The Connectivity Map for Channel', jitters{1}]));
end
end

% --- Executes during object creation, after setting all properties.
function pushbutton39_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
end


% --- Channel B
function uipanel9_CreateFcn(hObject, eventdata, handles)

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.418 .037 .398 .358];

% hObject.Position=[.418 .54 .398 .358];
end

% Channel B
function pushbutton41_Callback(hObject, eventdata, handles)
global jitters Ghibli textstrings HITS indx23 supa newM2  looop2  filteredData1 M2 thrconnec timesss finalssss M arrowss


prompt = {'Enter Channel name B:'};
title = 'Connectivity Map';
dims = [1 35];
definput = {'B1'};
jitters{2} = inputdlg(prompt,title,dims,definput);

if indx23 == 1
    Ghibli(2)=find(strcmp(textstrings(:,1),jitters{2}));
elseif  indx23 == 2
    textstrings1 = HITS(:,1);
    Ghibli(2)=find(strcmp(textstrings1(:,1),jitters{2}));
end

% yup=input('Which channel do you want to cross correlate?');
% Ghibli=find(strncmpi(HITS,yup,3));

if indx23 == 2
    
    supa1 = supa;
    %gotta turn the numbers around for the max function
    for i=1:length(M2)
        supa1{i}=supa1{i}';
    end
    
    for i=1:length(M2)
        supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
    end
    
    
    HITS48=HITS;
    
    lp=rand(1,length(HITS))+rand(1,length(HITS));
    kp=rand(1,length(HITS))+rand(1,length(HITS));
    ml=rand(1,length(HITS))+0.68;
    lp=lp+kp+ml;
    lp=lp';
    for i=1:length(HITS)
        HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
    end
    
    
    if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
        layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
    elseif length(filteredData1(:,1)) > 121
        layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
    else %% for 120 channel MEA
        layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
    end
    
    ax = axes(hObject);
    imagesc(layout4,'AlphaData',~isnan(layout4));
    
    if length(textstrings) > 400
        [x, y] = meshgrid(1:24);
        for i=[24 23 22 21 20]
            x(i,:)=[];
            y(i,:)=[];
        end
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    else
        [x, y] = meshgrid(1:12);
        hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
            'HorizontalAlignment', 'center');
    end
    
    
    %         waitbar(0 + 0.9,hh,'Drawing the Connections');
    top60=cell2mat(supa1);
    top60(top60 < thrconnec) = 0;
    % change nan values into zeros
    
    %      top60(top60 < mean((top60)) + (3*std((top60))))= 0;  % take the 10 highest peak values and threhsold the threhold bassed on these peak values
    
    [B,I]=sort(top60,'descend');   % order them
    ghg=find(B == 0); %remove all the zeros
    I(ghg)=[];
    
    %get the top60 connections if the length of I is longer than 60
    if length(I) > 60
        I=I(1:60);
    end
    
    if length(filteredData1(:,1)) == 60
        I=I(:)/60;
    else
        I=I(:)/120;
    end
    
    
    %each 120 elements belong to one channel
    %firsst column will be the origin of the line
    %2nd column will be the destination of the line
    I(:,2)=floor(I(:,1));
    I(:,3)=I(:,1) - I(:,2);
    
    if length(filteredData1(:,1)) == 60
        I(:,3)=I(:,3)*60;
    else
        I(:,3)=I(:,3)*120;
    end
    
    I(:,3)=round(I(:,3));
    I(:,2)=ceil(I(:,1));
    I(I<1) = 1;
    ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
    removeindx = find(cell2mat(HITS(:,2)) <= 10);
    
    I(ismember(I(:,2),removeindx)) =0;
    I(ismember(I(:,2),removeindx),3) =0;
    I(ismember(I(:,2),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),1) =0;
    I(ismember(I(:,3),removeindx),2) =0;
    I(ismember(I(:,3),removeindx),3) =0;
    
    for i = length(I):-1:1
        if I(i,1) == 0
            I(i,:) = [];
        end
    end
    
    %also delete connections that do not involve the channel of interest
    %     correctindex = find(I(:,2) == Ghibli(1));
    %     correctindex2 = find(I(:,3) == Ghibli(1));
    %     indexfull = [correctindex;correctindex2]; % this contains the indeices that have connections with the channel of interest
    %
    for i = length(I):-1:1
        if I(i,2) == Ghibli(2) || I(i,3) == Ghibli(2)
        else
            I(i,:) = [];
        end
    end
    
    
    
    
    looop2= 0 ;
    
    for i=1:size(I,1)
        yutr=I(i,2);
        looop2 = looop2+1;
        kk=ag(ag==yutr); % added for joosts method
        lll=find(layout4 == HITS48{kk,2});
        [r,c] = ind2sub(size(layout4),lll);
        
        k=I(i,3);
        llll=find(layout4 == HITS48{k,2});
        [rr,cc] = ind2sub(size(layout4),llll);
        hold on
        if arrowss == 1
            nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
        elseif arrowss == 0
            nnn=line([c cc],[r rr],'Color','r');
        end
        drawnow;
        colmin=min(top60(:));
        colmax=max(top60(:));
        COLOR1=parula(length(top60));
        goodcolor=COLOR1(round(length(top60)*(top60(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
        nnn.Color=goodcolor;
        cbn=colorbar;
        cbn.Colormap=parula(length(top60));
        cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        
    end
    
    
    
    set(gca,'visible','off');
    set(gca,'Colormap',[1 1 1]);
else
    if isempty(M)
        msgbox('there are no connections!')
    else
        
        supa1=cell(1,length(M2))';
        for i = 1:length(M2) % added for joost's method
            supa1{i} = M(i,:)';
            
        end
        
        
        
        % need to change the numbers from the user input as the index doesnt
        % match anymore
        if length(filteredData1(:,1)) > 121
            Ghibli(2)=find(strcmp(textstrings(:,1),jitters{2}));
        else
            Ghibli(2)=find(strcmp(HITS(:,1),jitters{2}));
        end
        
        % %     edges = 0:0.001:timesss;
        % %     edges=edges(1:end-1);
        %1 bin is 1ms
        
        % %     supa=cell(1,length(M2));
        % %     for i=1:length(M2)
        % %             waitbar(i/length(M2))
        % %         if isempty(M2{i,1})
        % %             supa{i}=[];
        % %             continue
        % %         end
        % %
        % %         finalssss=zeros(length(filteredData1(:,1)),301);
        % %         for j=1:length(M2)
        % %
        % %             if isempty(M2{j,1})
        % %                 %             finalssss(j,:)=[];
        % %                 supa{i}=[];
        % %                 continue
        % %             else
        % %                 binned_data=histc((M2{j,1}),edges);  %get bins of 1 ms  %target spike train
        % %                 binned_data1=histc((M2{i,1}),edges); %reference spike train
        % %
        % %                 xc = xcorr(binned_data, binned_data1);
        % %
        % %                 xc = xc(round(length(xc)/2)-150:round(length(xc)/2)+150);
        % %                 xc = xc /(sqrt(length(find(binned_data > 0))*length(find(binned_data1 > 0)))); % Normalization by the product of X and Y spikes
        % %
        % %                 finalssss(j,:)=xc;
        % %                 finalssss(i,:)=zeros(1,301);  % remove the autocorrealtion
        % %             end
        % %
        % %
        % %         end
        % %         supa{i}=finalssss;
        % %     end
        % %     supa=supa';
        % %
        % %     close(hh)
        
        %     supa1 = supa;
        %     %     for i=1:length(M2)
        %     %         if isempty(supa1{i})
        %     %             continue
        %     %         end
        %     %         M = max(supa1{i}(:));          %depict the cross correaltion in percentages
        %     %         supa1{i}=supa1{i}/M;
        %     %     end
        %
        %
        %     %gotta turn the numbers around for the max function
        %     for i=1:length(M2)
        %         supa1{i}=supa1{i}';
        %     end
        %
        %     for i=1:length(M2)
        %         supa1{i}=max(supa1{i})';  %this will give us the peak values of the bar graphs
        %     end
        
        %higher than 70% we will draw a line (spikecode this this aswell
        %so now the only thing we need to do is draw a line if the number exceeds
        %0.7 or 70% SPYCODE threshhold
        
        %use the below layout structure to get the correct position
        
        %So what needs to happen is 3 things, we will first check if in supa
        %soemthing has passed the 0.7 mark and if it does the next thing it will do
        %is search in the layout for the correct position and the last step is to
        %draw a line
        
        %we have to make the numbers uin HITS all unqiue so we won't have issues with duplicates
        
        HITS48=HITS;
        lp=rand(1,120)+rand(1,120);
        kp=rand(1,120)+rand(1,120);
        ml=rand(1,120)+0.68;
        lp=lp+kp+ml;
        lp=lp';
        for i=1:length(HITS)
            HITS48{i,2}=HITS48{i,2}+lp(i); %so in order to make each number unique i added a random number between 0 and 1
        end
        
        
        % it seems that you cannot leave the other channel empty
        %i will put zeros in the empty spaces
        
        
        if length(filteredData1(:,1)) == 60  %% for a 60 channel MEA
            layout4= [nan nan nan nan nan nan nan nan nan  nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan HITS48{7,2} HITS48{15,2} HITS48{23,2} HITS48{31,2} HITS48{39,2} HITS48{47,2} nan nan nan; nan nan HITS48{1,2} HITS48{8,2} HITS48{16,2} HITS48{24,2} HITS48{32,2} HITS48{40,2} HITS48{48,2} HITS48{55,2} nan nan; nan nan HITS48{2,2} HITS48{9,2} HITS48{17,2} HITS48{25,2} HITS48{33,2} HITS48{41,2} HITS48{49,2} HITS48{56,2} nan nan; nan nan HITS48{3,2} HITS48{10,2} HITS48{18,2} HITS48{26,2} HITS48{34,2} HITS48{42,2} HITS48{50,2} HITS48{57,2} nan nan; nan nan HITS48{4,2} HITS48{11,2} HITS48{19,2} HITS48{27,2} HITS48{35,2} HITS48{43,2} HITS48{51,2} HITS48{58,2} nan nan; nan nan HITS48{5,2} HITS48{12,2} HITS48{20,2} HITS48{28,2} HITS48{36,2} HITS48{44,2} HITS48{52,2} HITS48{59,2} nan nan; nan nan HITS48{6,2} HITS48{13,2} HITS48{21,2} HITS48{29,2} HITS48{37,2} HITS48{45,2} HITS48{53,2} HITS48{60,2} nan nan;nan nan nan HITS48{14,2} HITS48{22,2} HITS48{30,2} HITS48{38,2} HITS48{46,2} HITS48{54,2} nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan;nan nan nan nan nan nan nan nan nan nan nan nan];
        elseif length(filteredData1(:,1)) > 121
            layout4=[nan HITS48{12,2} HITS48{11,2} nan nan HITS48{24,2} HITS48{23,2} nan nan HITS48{36,2} HITS48{35,2} nan nan HITS48{48,2} HITS48{47,2} nan nan HITS48{60,2} HITS48{59,2} nan nan HITS48{72,2} HITS48{71,2} nan;HITS48{10,2} HITS48{9,2} HITS48{8,2} HITS48{7,2} HITS48{22,2} HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{34,2} HITS48{33,2} HITS48{32,2} HITS48{31,2} HITS48{46,2} HITS48{45,2} HITS48{44,2} HITS48{43,2} HITS48{58,2} HITS48{57,2} HITS48{56,2} HITS48{55,2} HITS48{70,2} HITS48{69,2} HITS48{68,2} HITS48{67,2};HITS48{6,2} HITS48{5,2} HITS48{4,2} HITS48{3,2} HITS48{18,2} HITS48{17,2} HITS48{16,2} HITS48{15,2} HITS48{30,2} HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{42,2} HITS48{41,2} HITS48{40,2} HITS48{39,2} HITS48{54,2} HITS48{53,2} HITS48{52,2} HITS48{51,2} HITS48{66,2} HITS48{65,2} HITS48{64,2} HITS48{63,2};nan HITS48{2,2} HITS48{1,2} nan nan HITS48{14,2} HITS48{13,2} nan nan HITS48{26,2} HITS48{25,2} nan nan HITS48{38,2} HITS48{37,2} nan nan HITS48{50,2} HITS48{49,2} nan nan HITS48{62,2} HITS48{61,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{84,2} HITS48{83,2} nan nan HITS48{96,2} HITS48{95,2} nan nan HITS48{108,2} HITS48{107,2} nan nan HITS48{120,2} HITS48{119,2} nan nan HITS48{132,2} HITS48{131,2} nan nan HITS48{144,2} HITS48{143,2} nan; HITS48{82,2} HITS48{81,2} HITS48{80,2} HITS48{79,2} HITS48{94,2} HITS48{93,2} HITS48{92,2} HITS48{91,2} HITS48{106,2} HITS48{105,2} HITS48{104,2} HITS48{103,2} HITS48{118,2} HITS48{117,2} HITS48{116,2} HITS48{115,2} HITS48{130,2} HITS48{129,2} HITS48{128,2} HITS48{127,2} HITS48{142,2} HITS48{141,2} HITS48{140,2} HITS48{139,2}; HITS48{78,2} HITS48{77,2} HITS48{76,2} HITS48{75,2} HITS48{90,2} HITS48{89,2} HITS48{88,2} HITS48{87,2} HITS48{102,2} HITS48{101,2} HITS48{100,2} HITS48{99,2} HITS48{114,2} HITS48{113,2} HITS48{112,2} HITS48{111,2} HITS48{126,2} HITS48{125,2} HITS48{124,2} HITS48{123,2} HITS48{138,2} HITS48{137,2} HITS48{136,2} HITS48{135,2}; nan HITS48{74,2} HITS48{73,2} nan nan HITS48{86,2} HITS48{85,2} nan nan HITS48{98,2} HITS48{97,2} nan nan HITS48{110,2} HITS48{109,2} nan nan HITS48{122,2} HITS48{121,2} nan nan HITS48{134,2} HITS48{133,2} nan; nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan;nan HITS48{156,2} HITS48{155,2} nan nan HITS48{168,2} HITS48{167,2} nan nan HITS48{180,2} HITS48{179,2} nan nan HITS48{192,2} HITS48{191,2} nan nan HITS48{204,2} HITS48{203,2} nan nan HITS48{216,2} HITS48{215,2} nan; HITS48{154,2} HITS48{153,2} HITS48{152,2} HITS48{151,2} HITS48{166,2} HITS48{165,2} HITS48{164,2} HITS48{163,2} HITS48{178,2} HITS48{177,2} HITS48{176,2} HITS48{175,2} HITS48{190,2} HITS48{189,2} HITS48{188,2} HITS48{187,2} HITS48{202,2} HITS48{201,2} HITS48{200,2} HITS48{199,2} HITS48{214,2} HITS48{213,2} HITS48{212,2} HITS48{211,2}; HITS48{150,2} HITS48{149,2} HITS48{148,2} HITS48{147,2} HITS48{162,2} HITS48{161,2} HITS48{160,2} HITS48{159,2} HITS48{174,2} HITS48{173,2} HITS48{172,2} HITS48{171,2} HITS48{186,2} HITS48{185,2} HITS48{184,2} HITS48{183,2} HITS48{198,2} HITS48{197,2} HITS48{196,2} HITS48{195,2} HITS48{210,2} HITS48{209,2} HITS48{208,2} HITS48{207,2}; nan HITS48{146,2} HITS48{145,2} nan nan HITS48{158,2} HITS48{157,2} nan nan HITS48{170,2} HITS48{169,2} nan nan HITS48{182,2} HITS48{181,2} nan nan HITS48{194,2} HITS48{193,2} nan nan HITS48{206,2} HITS48{205,2} nan;nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan; nan HITS48{228,2} HITS48{227,2} nan nan HITS48{240,2} HITS48{239,2} nan nan HITS48{252,2} HITS48{251,2} nan nan HITS48{264,2} HITS48{263,2} nan nan HITS48{276,2} HITS48{275,2} nan nan HITS48{288,2} HITS48{287,2} nan; HITS48{226,2} HITS48{225,2} HITS48{224,2} HITS48{223,2} HITS48{238,2} HITS48{237,2} HITS48{236,2} HITS48{235,2} HITS48{250,2} HITS48{249,2} HITS48{248,2} HITS48{247,2} HITS48{262,2} HITS48{261,2} HITS48{260,2} HITS48{259,2} HITS48{274,2} HITS48{273,2} HITS48{272,2} HITS48{271,2} HITS48{286,2} HITS48{285,2} HITS48{284,2} HITS48{283,2}; HITS48{222,2} HITS48{221,2} HITS48{220,2} HITS48{219,2} HITS48{234,2} HITS48{233,2} HITS48{232,2} HITS48{231,2} HITS48{246,2} HITS48{245,2} HITS48{244,2} HITS48{243,2} HITS48{258,2} HITS48{257,2} HITS48{256,2} HITS48{255,2} HITS48{270,2} HITS48{269,2} HITS48{268,2} HITS48{267,2} HITS48{282,2} HITS48{281,2} HITS48{280,2} HITS48{279,2}; nan HITS48{218,2} HITS48{217,2} nan nan HITS48{230,2} HITS48{229,2} nan nan HITS48{242,2} HITS48{241,2} nan nan HITS48{254,2} HITS48{253,2} nan nan HITS48{266,2} HITS48{265,2} nan nan HITS48{278,2} HITS48{277,2} nan];
        else
            layout4= [nan nan nan HITS48{51,2} HITS48{55,2} HITS48{59,2} HITS48{63,2} HITS48{67,2} HITS48{71,2} nan nan nan;nan nan HITS48{47,2} HITS48{50,2} HITS48{54,2} HITS48{58,2} HITS48{64,2} HITS48{68,2} HITS48{72,2} HITS48{75,2} nan nan;nan HITS48{45,2} HITS48{46,2} HITS48{49,2} HITS48{53,2} HITS48{57,2} HITS48{65,2} HITS48{69,2} HITS48{73,2} HITS48{76,2} HITS48{77,2} nan; HITS48{41,2} HITS48{42,2} HITS48{43,2} HITS48{44,2} HITS48{52,2} HITS48{56,2} HITS48{66,2} HITS48{70,2} HITS48{74,2} HITS48{79,2} HITS48{80,2} HITS48{81,2}; HITS48{37,2} HITS48{38,2} HITS48{39,2} HITS48{40,2} HITS48{48,2} HITS48{60,2} HITS48{62,2} HITS48{78,2} HITS48{82,2} HITS48{83,2} HITS48{84,2} HITS48{85,2}; HITS48{33,2} HITS48{34,2} HITS48{35,2} HITS48{36,2} HITS48{32,2} HITS48{31,2} HITS48{61,2} HITS48{90,2} HITS48{86,2} HITS48{87,2} HITS48{88,2} HITS48{89,2}; HITS48{29,2} HITS48{28,2} HITS48{27,2} HITS48{26,2} HITS48{30,2} HITS48{1,2} HITS48{91,2} HITS48{92,2} HITS48{96,2} HITS48{95,2} HITS48{94,2} HITS48{93,2}; HITS48{25,2} HITS48{24,2} HITS48{23,2} HITS48{22,2} HITS48{18,2} HITS48{2,2} HITS48{120,2} HITS48{108,2} HITS48{100,2} HITS48{99,2} HITS48{98,2} HITS48{97,2}; HITS48{21,2} HITS48{20,2} HITS48{19,2} HITS48{14,2} HITS48{10,2} HITS48{6,2} HITS48{116,2} HITS48{112,2} HITS48{104,2} HITS48{103,2} HITS48{102,2} HITS48{101,2};nan HITS48{17,2} HITS48{16,2} HITS48{13,2} HITS48{9,2} HITS48{5,2} HITS48{117,2} HITS48{113,2} HITS48{109,2} HITS48{106,2} HITS48{105,2} nan;nan nan HITS48{15,2} HITS48{12,2} HITS48{8,2} HITS48{4,2} HITS48{118,2} HITS48{114,2} HITS48{110,2} HITS48{107,2} nan nan;nan nan nan HITS48{11,2} HITS48{7,2} HITS48{3,2} HITS48{119,2} HITS48{115,2} HITS48{111,2} nan nan nan];
        end
        
        ax33 = axes(handles.uipanel9);
        %     ax=axes(hObject);
        imagesc(layout4,'AlphaData',~isnan(layout4));
        set(gca,'visible','off');
        set(gca,'Colormap',[1 1 1]);
        if length(textstrings) > 400
            [x, y] = meshgrid(1:24);
            for i=[24 23 22 21 20]
                x(i,:)=[];
                y(i,:)=[];
            end
            hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
                'HorizontalAlignment', 'center');
        else
            [x, y] = meshgrid(1:12);
            hStrings = text(x(:), y(:), textstrings(:), ...  % Plot the strings
                'HorizontalAlignment', 'center');
        end
        
        
        top60=cell2mat(supa1);
        if handles.pushbutton60.Value == 1
            top60(top60 < (mean(M,'all','omitnan') + thrconnec*std(M,1,'all','omitnan'))) = 0; % new
        end
        
        top60(isnan(top60)) =0; %% new added for joost's method
        
        [B,I]=sort(top60,'descend');   % order them
        ghg=find(B == 0); %remove all the zeros
        I(ghg)=[];
        
        
        if length(supa1{1}) == 60 % changed it due to the kjust spike times
            I=I(:)/60;
        else
            I=I(:)/120;
        end
        
        
        %each 120 elements belong to one channel
        %firsst column will be the origin of the line
        %2nd column will be the destination of the line
        I(:,2)=floor(I(:,1));
        I(:,3)=I(:,1) - I(:,2);
        
        if length(supa1{1}) == 60 % changed it due to the kjust spike times
            I(:,3)=I(:,3)*60;
        else
            I(:,3)=I(:,3)*120;
        end
        
        I(:,3)=round(I(:,3));
        I(:,2)=ceil(I(:,1));
        I(I<1) = 1;
        ag=find(~cellfun(@isempty,M2)); % we find which channels are active!
        removeindx = find(cell2mat(HITS(:,2)) <= 10);
        
        I(ismember(I(:,2),removeindx)) =0;
        I(ismember(I(:,2),removeindx),3) =0;
        I(ismember(I(:,2),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),1) =0;
        I(ismember(I(:,3),removeindx),2) =0;
        I(ismember(I(:,3),removeindx),3) =0;
        
        for i = length(I):-1:1
            if I(i,1) == 0
                I(i,:) = [];
            end
        end
        %also delete connections that do not involve the channel of interest
        correctindex = find(I(:,2) == Ghibli(2));
        correctindex2 = find(I(:,3) == Ghibli(2));
        indexfull = [correctindex;correctindex2]; % this contains the indeices that have connections with the channel of interest
        
        for i = length(I):-1:1
            if I(i,2) == Ghibli(2) || I(i,3) == Ghibli(2)
            else
                I(i,:) = [];
            end
        end
        
        
        
        looop2 = 0;
        
        for i=1:size(I,1)
            looop2 = looop2+1;
            yutr=I(i,2);
            
            kk=ag(ag==yutr); % added for joosts method
            lll=find(layout4 == HITS48{kk,2});
            [r,c] = ind2sub(size(layout4),lll);
            
            k=I(i,3);
            llll=find(layout4 == HITS48{k,2});
            [rr,cc] = ind2sub(size(layout4),llll);
            hold on
            if arrowss == 1
                nnn = quiver(c(1),r(1),cc(1) - c(1) ,rr(1) - r(1));
            elseif arrowss == 0
                nnn=line([c cc],[r rr],'Color','r');
            end
            drawnow;
            colmin=0;
            %         colmin=min(B(:));
            colmax=max(B(:));
            COLOR1=parula(length(B));
            goodcolor=COLOR1(round(length(B)*(B(i,1)-colmin)/(colmax-colmin+1)+0.5),:);
            nnn.Color=goodcolor;
            cbn=colorbar;
            cbn.Colormap=parula(length(B));
            cbn.TickLabels=0:1/(length(cbn.TickLabels)-1):1;
        end
        
    end
    
    
    clear supa1 supa
    
    
    text83_ButtonDownFcn(handles.text83,eventdata,handles)
    handles.text83.Visible = 'on';
    set(handles.Pannel_11.Text,'String',strjoin(['The Connectivity Map for Channel', jitters{2}]));
end
end


% --- Executes during object creation, after setting all properties.
function pushbutton41_CreateFcn(hObject, eventdata, handles)

hObject.Visible = 'off';

end


% --channel B
function uipanel9_ButtonDownFcn(hObject, eventdata, handles)
end


% --- Executes during object creation, after setting all properties.
function text82_CreateFcn(hObject, eventdata, handles)

hObject.String = {};
hObject.Visible = 'off' ;


end

function text82_ButtonDownFcn(hObject, eventdata, handles)
global looop PorcoRosso jitters
PorcoRosso=[];
PorcoRosso =(['Connections for Channel: ',jitters{1},'is', num2str(looop)]);
PorcoRosso = strjoin(PorcoRosso);
set(hObject, 'String', PorcoRosso);


end


% --- Executes during object creation, after setting all properties.
function text83_CreateFcn(hObject, eventdata, handles)

hObject.String = {};
hObject.Visible = 'off' ;


end

function text83_ButtonDownFcn(hObject, eventdata, handles)
global looop2 PorcoRosso jitters
PorcoRosso=[];
PorcoRosso =(['Connections for Channel: ',jitters{2},'is', num2str(looop2)]);
PorcoRosso = strjoin(PorcoRosso);
set(hObject, 'String', PorcoRosso);


end


% --- Executes during object creation, after setting all properties.
function text84_CreateFcn(hObject, eventdata, handles)
hObject.String = {};
hObject.Visible = 'off' ;
hObject.Position = [0.01 0.5152 0.298 0.02];
end

function text84_ButtonDownFcn(hObject, eventdata, handles)
global looo12 PorcoRosso

PorcoRosso=[];
PorcoRosso =(['Amount of Connections for all Channels is ',num2str(looo12)]);
set(hObject, 'String', PorcoRosso);

end
%% bursts panel and network bursts panel

% panel to rerun burst detection
function uipanel20_CreateFcn(hObject, eventdata, handles)
global maxinterval cbox1 cbox2 logISI fs push1 text1 text2 text3 multiwell1 networkburstttt networkbursttttold xpoints timesss text4 text5 text6 text7 push5 edit8 edit9 edit10 text8 text9 text10 selecteddata burst6indxold burst7indxold push2 push3 push4 edit1 edit2 edit3 burst6indx burst7indx edit4 edit5 edit6 edit7 M2 Totoro ISI58 Exburst burst6 burst7 maxinterval1 logisi1 logburst burst6old burst7old Exburstold logburstold pushed pushed1 Imax ...
    table2 table3 Table680 Table139 Table679 HITS X2 overlap overlapp filteredData1 dx cbox101

hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Title = {};
hObject.Position=[.009 .009 .806 .224];

% Create a check box to display max interval method
cbox1 = uicontrol(hObject,'Style','checkbox','Position',[10 167 200 25],...
    'Callback',@(cbx,event) Chan(cbx));
cbox1.String = 'Max Interval Method';
cbox1.FontSize = 12;
cbox1.BackgroundColor = [1 1 1];

% Create a check box to display log isi method
cbox2 = uicontrol(hObject,'Style','checkbox','Position',[10 107 200 25],...
    'Callback',@(cbx,event) Chan2(cbx));
cbox2.String = 'Log ISI Method';
cbox2.FontSize = 12;
cbox2.BackgroundColor = [1 1 1];

% Create a check box to basing the nb detection on the overlapping bursts
cbox101 = uicontrol(hObject,'Style','checkbox','Position',[10 47 200 25],...
    'Callback',@(cbx,event) Chan3(cbx));
cbox101.String = 'Overlapping SCBs';
cbox101.FontSize = 12;
cbox101.BackgroundColor = [1 1 1];
cbox101.Visible = 'off';


%% max interval buttons
% Create a edit box to start interval
edit1 = uicontrol(hObject,'Style','edit','Position',[250 187 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.start),'Callback',@(cbx,event) editChan(cbx));
edit1.FontSize = 12;
edit1.BackgroundColor = [1 1 1];

text1 = uicontrol(hObject,'Style','text','Position',[250 207 50 19],...
    'Enable','on','String','Start','Tooltip','Burst Start Interval (s)');
text1.FontSize = 12;
text1.BackgroundColor = [1 1 1];


% Create a edit box to n spikes max
edit2 = uicontrol(hObject,'Style','edit','Position',[250 127 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.nspikes),'Callback',@(cbx,event) editChan(cbx));
edit2.FontSize = 12;
edit2.BackgroundColor = [1 1 1];

text2 = uicontrol(hObject,'Style','text','Position',[250 147 50 19],...
    'Enable','on','String','Spikes','Tooltip','Number of spikes (n)');
text2.FontSize = 12;
text2.BackgroundColor = [1 1 1];


% Create a edit box to IBI duration
edit3 = uicontrol(hObject,'Style','edit','Position',[350 187 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.IBI),'Callback',@(cbx,event) editChan(cbx));
edit3.FontSize = 12;
edit3.BackgroundColor = [1 1 1];

text3 = uicontrol(hObject,'Style','text','Position',[350 207 50 19],...
    'Enable','on','String','Inter','Tooltip','Inter Burst Interval (s)');
text3.FontSize = 12;
text3.BackgroundColor = [1 1 1];


% Create a edit box to intraburst interval
edit4 = uicontrol(hObject,'Style','edit','Position',[350 127 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.intraBI),'Callback',@(cbx,event) editChan(cbx));
edit4.FontSize = 12;
edit4.BackgroundColor = [1 1 1];

text4 = uicontrol(hObject,'Style','text','Position',[350 147 50 19],...
    'Enable','on','String','Intra','Tooltip','Intra Burst Interval (s)');
text4.FontSize = 12;
text4.BackgroundColor = [1 1 1];



% Create a edit box to minimum duration
edit5 = uicontrol(hObject,'Style','edit','Position',[450 157 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionmaxinterval.mindur),'Callback',@(cbx,event) editChan(cbx));
edit5.FontSize = 12;
edit5.BackgroundColor = [1 1 1];

text5 = uicontrol(hObject,'Style','text','Position',[450 177 70 19],...
    'Enable','on','String','Duration','Tooltip','Minimum burst duration (s)');
text5.FontSize = 12;
text5.BackgroundColor = [1 1 1];

%% logISI buttons

% Create a edit box to nspikes logisi
edit6 = uicontrol(hObject,'Style','edit','Position',[250 67 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionlogisi.nspikes),'Callback',@(cbx,event) editChan(cbx));
edit6.FontSize = 12;
edit6.BackgroundColor = [1 1 1];

text6 = uicontrol(hObject,'Style','text','Position',[250 87 50 19],...
    'Enable','on','String','Spikes','Tooltip','Number of spikes (n)');
text6.FontSize = 12;
text6.BackgroundColor = [1 1 1];


% Create a edit box to void
edit7 = uicontrol(hObject,'Style','edit','Position',[250 7 50 15],...
    'Enable','off','String',mat2str(fs.burstdetectionlogisi.void),'Callback',@(cbx,event) editChan(cbx));
edit7.FontSize = 12;
edit7.BackgroundColor = [1 1 1];

text7 = uicontrol(hObject,'Style','text','Position',[250 27 50 19],...
    'Enable','on','String','Void','Tooltip','Void Threshold');
text7.FontSize = 12;
text7.BackgroundColor = [1 1 1];

%% Rerun buttons
% Create a pushbutton for rerun
push1 = uicontrol(hObject,'Style','pushbutton','Position',[700 27 200 19],...
    'Visible','off','String','Burst Detection','Callback',@(cbx,event) rerun(cbx));
push1.FontSize = 12;
push1.BackgroundColor = [1 1 1];

%revert back to default settings
push2 = uicontrol(hObject,'Style','pushbutton','Position',[1100 27 200 19],...
    'Visible','off','String','Revert to Default','Callback',@(cbx,event) revertback(cbx));
push2.FontSize = 12;
push2.BackgroundColor = [1 1 1];

%select channel
push3 = uicontrol(hObject,'Style','pushbutton','Position',[700 57 200 19],...
    'Visible','off','String','Select Channel','Callback',@(cbx,event) selectch(cbx));
push3.FontSize = 12;
push3.BackgroundColor = [1 1 1];


%statistics
push4 = uicontrol(hObject,'Style','pushbutton','Position',[1100 57 200 19],...
    'Visible','off','String','Statistics','Callback',@(cbx,event) stats1(cbx));
push4.FontSize = 12;
push4.BackgroundColor = [1 1 1];

push5 = uicontrol(hObject,'Style','pushbutton','Position',[700 27 200 19],...
    'Visible','off','String','Network Burst Detection','Callback',@(cbx,event) rerunnnbursts(cbx));
push5.FontSize = 12;
push5.BackgroundColor = [1 1 1];

%% rerun network burst buttons

edit8 = uicontrol(hObject,'Style','edit','Position',[250 7 50 15],...
    'Enable','off','String',mat2str(  fs.networkburstdetection.synchronizedtimewindow),'Callback',@(cbx,event) editChan(cbx));
edit8.FontSize = 12;
edit8.BackgroundColor = [1 1 1];

text8 = uicontrol(hObject,'Style','text','Position',[250 27 50 19],...
    'Enable','on','String','Time window','Tooltip','Time window for synchronized bursts (s)');
text8.FontSize = 12;
text8.BackgroundColor = [1 1 1];

edit9 = uicontrol(hObject,'Style','edit','Position',[350 7 50 15],...
    'Enable','off','String',mat2str( fs.networkburstdetection.minimumsynchronizedburstcount),'Callback',@(cbx,event) editChan(cbx));
edit9.FontSize = 12;
edit9.BackgroundColor = [1 1 1];
text9 = uicontrol(hObject,'Style','text','Position',[350 27 50 19],...
    'Enable','on','String','Synchronized bursts','Tooltip','Minimum synchronzied burst amount (n)');
text9.FontSize = 12;
text9.BackgroundColor = [1 1 1];

edit10 = uicontrol(hObject,'Style','edit','Position',[450 7 50 15],...
    'Enable','off','String',mat2str( fs.networkburstdetection.minimumchannelparticipation),'Callback',@(cbx,event) editChan(cbx));
edit10.FontSize = 12;
edit10.BackgroundColor = [1 1 1];

text10 = uicontrol(hObject,'Style','text','Position',[450 27 50 19],...
    'Enable','on','String','Channels','Tooltip','Minimum amount of channels participating (%)');
text10.FontSize = 12;
text10.BackgroundColor = [1 1 1];

    function rerun(source,~)
        %% max interval method
        if maxinterval == 1
            %we have to get the ISI first
            test2=cell(1,length(M2));
            for i=1:length(M2)
                test=diff(M2{i,1});
                test2{i}=test;
            end
            test2=test2'; %contain the ISI all of the channels
            
            for i =1:length(test2)
                test2{i}(2,:)=1:length(test2{i});    %add the index of the ISI in each cell
            end
            
            % remove any cell that has less than 3 spikes
            
            for i=1:length(test2)
                if size(test2{i},2) < 3
                    test2{i}=[];
                end
            end
            %first part would be to detect the start of the bursts
            
            %maximum start of the burst is 170 ms between the first two spikes of a
            %burst
            hh = waitbar(0,'Recalculating the bursts according to the max interval method');
            
            burst6=cell(1,length(M2));
            for ii=1:length(M2)
                waitbar(ii/length(M2))
                if isempty(test2{ii})
                    burst6{ii} = [];
                else
                    idx = find(test2{ii}(1,:) < fs.burstdetectionmaxinterval.start);
                    maxbursts=round(length(test2{ii})/fs.burstdetectionmaxinterval.nspikes); %you have to have atleast 3 spikes per burst and therefore you have a max limit on the maount of bursts
                    
                    %check to see if the amount of bursts is normal if not remove it
                    
                    burst4=cell(1,length(idx));
                    for j=1:length(idx)
                        burst3=[];
                        for i=idx(j):length(test2{ii})
                            if test2{ii}(1,i) < fs.burstdetectionmaxinterval.intraBI     %max ISI of interburstspikes is 300 ms
                                burst = test2{ii}(2,i);    %get the indices of the spikes so its easier to work it
                                burst3{i} = burst;
                            else
                                break;
                            end
                        end
                        burst3 = vertcat(burst3{:});
                        burst4{j}=burst3;    %now we have our found our bursts that start with a ISI of 170 ms and have a ISI wihtin the bursts of max 300 ms
                    end
                    clear burst burst3
                    
                    for i=1:length(burst4)
                        if length(burst4{1,i}) < fs.burstdetectionmaxinterval.nspikes   %removed any burst that had less than 3 spikes
                            burst4{1,i}=[];
                        end
                    end
                    burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                    
                    %merging/removal of duplicates
                    
                    NewVector = cellfun(@(x) x(end), burst4); % get all the last number of each detected burst
                    
                    for i = 1:length(NewVector)
                        try
                            if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them (its based on the last number as in the duplicated bursts they are the same)
                                burst4{i+1} = [];
                            end
                        catch
                        end
                    end
                    
                    burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                    
                    %now we need to get the real spike times for the other parameters
                    %now we need to check if the time between the bursts is a minimal
                    %of 200 ms otherwise merge
                    
                    burst5={};
                    for i=1:length(burst4)-1
                        j=i+1;
                        if M2{ii,1}(burst4{1,j}(1,1))- M2{ii,1}(burst4{1,i}(end)) < fs.burstdetectionmaxinterval.IBI   %if the distance between the last spike of the previous burst is not longer than 200 ms comapred to the first spike of the next bursts it will be merged into one bursts
                            burst5{i}=vertcat(burst4{1,i},burst4{1,j});
                        else
                            
                            burst5{i}=burst4{1,i};
                            burst5{j}=burst4{1,j};
                        end
                    end
                    
                    clear burst4
                    %last check is to see if the total duration of the bursts is atleast 10 ms
                    for i=1:length(burst5)
                        if M2{ii,1}(burst5{1,i}(end)) - M2{ii,1}(burst5{1,i}(1,1)) < fs.burstdetectionmaxinterval.mindur
                            burst5{1,i}=[];
                        end
                    end
                    burst5=burst5(~cellfun('isempty',burst5)); %sort the correct amount of bursts
                    burst6{ii}=burst5;
                end
            end
            close(hh)
            clear burst5 test2 idx test maxbursts messsage1
            burst6=burst6';  %these are the indices of the spikes
            %we have to convert them to their actual spike timings
            burst6indx= burst6;
            
            for i=1:length(M2)
                for j=1:length(burst6{i,1})
                    burst6{i,1}{1,j}=M2{i,1}(burst6{i,1}{1,j});  %now we have the correct spike timings!
                end
            end
            
            Exburst=cell(1,length(M2));
            for jj=1:length(M2)
                Exburst{jj}.number_of_bursts=1:length(burst6{jj,1});
                
                for i=1:length(burst6{jj,1})
                    Exburst{jj}.duration_of_bursts(i)=burst6{jj,1}{1,i}(end)-burst6{jj,1}{1,i}(1,1);
                end
                
                for i=1:length(burst6{jj,1})
                    Exburst{jj}.spikes_in_bursts(i)=length(burst6{jj,1}{1,i});
                end
            end
            Exburst=Exburst';   %contains data about the bursts for the table
            
            for i=1:length(M2)
                Exburst{i,1}.number_of_bursts=Exburst{i,1}.number_of_bursts'; %flip everything for the table
            end
            
            for i=1:length(M2)
                if sum(strcmp(fieldnames(Exburst{i,1}), 'spikes_in_bursts')) == 1
                    Exburst{i,1}.spikes_in_bursts=Exburst{i,1}.spikes_in_bursts'; %flip everything for the table
                end
            end
            
            for i=1:length(M2)
                if sum(strcmp(fieldnames(Exburst{i,1}), 'duration_of_bursts')) == 1
                    Exburst{i,1}.duration_of_bursts=Exburst{i,1}.duration_of_bursts'; %flip everything for the table
                end
            end
            
            clear mona
            
            %get the firing frequency (Hz) per burst per electrode
            
            fr_of_bursts = zeros(1,length(M2))';
            for i = 1:length(M2)
                if isempty(Exburst{i}.number_of_bursts)
                    Exburst{i}.fr_of_bursts = [];
                else
                    for j = 1:length(Exburst{i}.spikes_in_bursts)
                        Exburst{i}.fr_of_bursts(j) = Exburst{i}.spikes_in_bursts(j)/ Exburst{i}.duration_of_bursts(j);
                        Exburst{i}.fr_of_bursts = Exburst{i}.fr_of_bursts';
                    end
                end
            end
            
            
            %get the mean ISI of the spikes inside of a burst
            %the timings are located in burst6 for max interval
            
            
            mISIbursts = cell(1,length(M2));
            for i=1:length(M2)
                if isempty(Exburst{i}.number_of_bursts)
                    mISIbursts{i} = 0;
                else
                    mISIbursts{i} = cellfun(@diff,burst6{i},'UniformOutput',0);
                end
                
            end
            
            
            mISIbursts=cell(1,length(burst6))'; %contains the average ISI of the bursts in each electrode
            for i=1:length(M2)
                mISIbursts{i}=zeros(1,length(burst6{i}));
                if isempty(Exburst{i}.number_of_bursts)
                    mISIbursts{i} = 0;
                else
                    for j = 1:length(burst6{i})
                        mISIbursts{i}(j) = mean(diff(cell2mat(burst6{i}(j))));
                        Exburst{i}.mean_ISI_bursts = mISIbursts{i}';
                    end
                end
            end
            
            clear mISIbursts
            
            stdISIbursts=cell(1,length(burst6))'; %contains the std of the ISI of  bursts in each electrode
            for i=1:length(M2)
                stdISIbursts{i}=zeros(1,length(burst6{i}));
                if isempty(Exburst{i}.number_of_bursts)
                    stdISIbursts{i} = 0;
                else
                    for j = 1:length(burst6{i})
                        stdISIbursts{i}(j) = std(diff(cell2mat(burst6{i}(j))));
                        Exburst{i}.std_ISI_bursts = stdISIbursts{i}';
                    end
                end
            end
            
            clear stdISIbursts
            
            %calculate the IBI
            
            IBI2=[];
            for i =1:length(burst6)
                if isempty(burst6{i})
                    continue
                else
                    for j =1:length(burst6{i})-1
                        IBI = burst6{i}{j+1}(1) - burst6{i}{j}(end);
                        IBI2=[IBI2,IBI];
                    end
                end
                Exburst{i}.IBI = IBI2';  %this contains all the IBI's per electrode
                IBI2 =[];
            end
            
            
            % create a conditional to produce a error if burst6 and burst6indx
            % are not the same
            
            assert( length(find(~cellfun(@isempty,burst6))) == length(find(~cellfun(@isempty,burst6indx))));
            clear i j jj IBI2 ii fr_of_bursts IBI
            maxinterval1 = 1;
            if isempty(Exburst{Imax}.number_of_bursts)
                push4.Visible = 'on';
                push4.Enable = 'off';
            else
                push4.Enable = 'on';
            end
            save(selecteddata,'Exburst','burst6','','-append');
            %     msgbox('Max Interval Burst Detection Finished')
        elseif logISI == 1
            %% log ISI method
            %first thing we need to do is make the log ISI histograms
            logisi1 = 1;
            
            
            logISI_hist = cell(1,length(M2));
            binsss= cell(1,length(M2));
            for i = 1:length(M2)
                if isempty(ISI58{i})
                    logISI_hist{i} = [];
                    continue
                else
                    maxWin = ceil(log10(max(ISI58{i})));
                    binss = logspace(0,maxWin,maxWin*10);           % equally spaced logarithmic bins using logspace
                    ISIlog_hist = histc(ISI58{i},binss);                     % this is the actual log ISI histogram
                    ISIlog_hist_area = sum(ISIlog_hist);
                    ISIlog_hist_norm = ISIlog_hist./ISIlog_hist_area;    % normalization
                    ISIlog_hist_norm = ISIlog_hist_norm(:);
                    binss = binss(:);
                end
                logISI_hist{i} = ISIlog_hist_norm;
                binsss{i} = binss ;
            end
            clear binss ISIlog_hist_norm  ISIlog_hist maxWin
            logISI_hist = logISI_hist';
            binsss = binsss';  % remember this is in ms!
            
            
            %smooth the log ISI histograms
            smoothed_logISI = cell(1,length(M2));
            for i = 1:length(M2)
                if isempty(logISI_hist{i})
                    smoothed_logISI{i} = [];
                    continue
                else
                    smoothed_logISI{i} = smooth(logISI_hist{i},5,'lowess') ;   % smooth the logISI histograms
                end
            end
            smoothed_logISI = smoothed_logISI';
            
            %now we need to find the peaks in the smoothed ISI log
            %histograms throw away channels that do not have a peak before
            %100 ms
            
            
            intraburstpeaks = cell(1,length(M2));
            logISIpeaks = cell(1,length(M2));
            logISIlocs = cell(1,length(M2));
            
            for i =1:length(M2)
                if isempty(smoothed_logISI{i})
                    intraburstpeaks{i} =[];
                    continue
                else
                    [peaks,locs] = findpeaks(smoothed_logISI{i},'minpeakdistance',2); %2 points from 'A self-adapting approach for the detection of burstsand network bursts in neuronal cultures'
                end
                
                temp1 = binsss{i}(locs);
                %now we need to check if there is peak before 100 ms
                if numel(peaks) == 1
                    intraburstpeaks{i} = [];
                elseif numel(find(temp1 < 100)) > 1 %if we have more than 1 peak then take the biggest value
                    [~,I] = max(peaks(find(temp1 < 100)));
                    intraburstpeaks{i} =  temp1(I);
                    %                 elseif find(temp1 < 100) == 1   %there is one peak before 100 ms
                    %                     intraburstpeaks{i} = temp1(find(temp1 < 100));
                elseif numel(find(temp1 < 100)) == 1
                    [~,I] = find(temp1 < 100);
                    intraburstpeaks{i} =  temp1(I);
                    
                else % no peaks before 100 ms so we discontinue the burst analysis
                    intraburstpeaks{i} = [];
                end
                
                if isempty(intraburstpeaks{i})
                    logISIlocs{i} = [];
                    logISIpeaks{i} =[];
                else
                    logISIpeaks{i} = peaks;
                    logISIlocs{i} = binsss{i}(locs);
                end
            end
            intraburstpeaks = intraburstpeaks'; % this cell contains all the intraburst peaks in ms!
            logISIpeaks =  logISIpeaks'; %y coordinates of the peaks in counts
            logISIlocs = logISIlocs'; %x coordinates of the peaks in ms
            clear locs peaks temp1 I
            
            %Now we need to find the correct interburst interval using the void parameter if that
            %fails than we set it at 100 ms
            % We do this by comparing the first peak or the intraburst peak with the
            % subsequent peaks
            
            
            interburstlogISI = cell(1,length(M2));
            
            for i = 1:length(M2)
                if isempty(logISIlocs{i})
                    interburstlogISI{i} = [];
                    continue
                else
                    %lets find the min value between each peak pair
                    % we can find the index in the locs cells
                    maxiterations = numel(logISIlocs{i});
                    index_intraburst = find(logISIlocs{i} == intraburstpeaks{i});
                    for j = (index_intraburst+1):length(logISIlocs{i})
                        
                        temp1 = min(smoothed_logISI{i}(find(smoothed_logISI{i} == logISIpeaks{i}(index_intraburst)):find(smoothed_logISI{i} == logISIpeaks{i}(j))));
                        %calculate how well the peaks are seperated
                        void =  1 - (temp1 / sqrt(logISIpeaks{i}(index_intraburst) * logISIpeaks{i}(j)));
                        if void > fs.burstdetectionlogisi.void
                            if temp1 == 0 %if the lowest number is equal to zero
                                temp2 = find(smoothed_logISI{i} == 0,find(find(smoothed_logISI{i} == 0) > find(smoothed_logISI{i} == logISIpeaks{i}(index_intraburst),1),1)) ;
                                temp2 = temp2(end);
                                interburstlogISI{i} = binsss{i}(temp2);
                            else
                                interburstlogISI{i} = binsss{i}(find(smoothed_logISI{i} == temp1,1)); %this is in ms
                                break
                            end
                        else
                            interburstlogISI{i} = 100; %if the method cant find any peaks that are well seperated it will be put at 100 ms
                        end
                    end
                end
            end
            interburstlogISI =interburstlogISI';   %this contains all the interburst intervals in ms
            
            %combine both numbers in one cell
            
            ISIthh = cell(2,length(M2))';
            
            for i =1:length(M2)
                
                ISIthh{i,1} = interburstlogISI{i}/1000; %convert in seconds
                ISIthh{i,2} = intraburstpeaks{i}/1000;  %convert in seconds
                
            end
            
            % add a extra criteria because getting values of above 1s for
            % interburst intervals is too high
            
            
            for i = 1:length(M2)
                if isempty(ISIthh)
                    continue
                else
                    if ISIthh{i,1} > 1
                        ISIthh{i,1} = 0.1;
                    end
                end
            end
            
            
            
            %Added an extra control to esnure that both the intraburst
            %ISI's and interburst ISI are complete
            
            
            for i = 1:length(M2)
                if isempty(ISIthh{i,1})
                    if isempty(ISIthh{i,2})
                    else
                        ISIthh{i,1} = 0.1;
                    end
                else
                end
            end
            
            %the first column of ISIthh contains the interburst ISI thresholds and the
            %2nd column contains the intrasburst ISI thresholds (everything is in
            %seconds
            
            test2=cell(1,length(M2));
            for i=1:length(M2)
                test=diff(M2{i,1});
                test2{i}=test;
            end
            test2=test2'; %contain the ISI all of the channels % in seconds
            
            
            
            %first part would be to detect the start of the bursts
            
            %maximum start of the burst is the isi of the first peak found before
            %the found intraburst peak
            hh = waitbar(0,'Recalculating the bursts according to the log ISI method');
            burst7=cell(1,length(M2));
            for ii=1:length(M2)
                waitbar(ii/length(M2))
                if isempty(M2{ii}) || length(M2{ii}) < 3
                    burst7{ii}={};
                elseif isempty(ISIthh{ii,2})
                    burst7{ii}={};
                else
                    test=test2{ii,1};
                    test(2,:)=1:length(test);
                    
                    idx = find(test(1,:) < ISIthh{ii,2}(1));   % here we find the indexes of potential burst cores
                    length(idx);
                    
                    maxbursts=round(length(test)/3); %you have to have atleast 3 spikes per burst and therefore you have a max limit on the maount of bursts
                    
                    %check to see if the amount of bursts is normal if not remove it
                    
                    burst4={};
                    for j=1:length(idx)
                        burst3=[];
                        for i=idx(j):length(test(1,:))
                            if test(1,i) < ISIthh{ii,1}    %max ISI of interburstspikes is the found interburst interval with the void parameter if not than it is set at 100 ms
                                burst = test(2,i);    %get the indices of the spike so its easier to work it
                                burst3{i} = burst;
                                %         burst3{i}=burst;
                            else
                                break;
                            end
                        end
                        
                        if isempty(burst3)
                        else
                            burst3 = vertcat(burst3{:});
                        end
                        burst4{j}=burst3;    %now we have our found our bursts with a max intraburst ISI of the first peak of the logISI
                        
                    end
                    clear burst burst3
                    
                    for i=1:length(burst4)
                        if length(burst4{1,i}) < fs.burstdetectionlogisi.nspikes   %removed any burst that had less than 3 spikes
                            burst4{1,i}=[];
                        else
                            
                        end
                    end
                    
                    burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                    
                    %merging/removal of duplicates
                    
                    
                    NewVector = cellfun(@(x) x(end), burst4); % get all the last number of each detected burst
                    
                    
                    for i = 1:length(NewVector)
                        try
                            if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them ( its based on the last number as in the duplicated bursts they are the same)
                                burst4{i+1} = [];
                            else
                                
                            end
                        catch
                        end
                    end
                    
                    burst4=burst4(~cellfun('isempty',burst4)); %remove any empty cell
                    
                    %now we need to check if the time between the found bursts is
                    %not below the interbursts ISI thresholds if it is lower than
                    %we will merge them
                    
                    
                    burst5={};
                    
                    for i=1:length(burst4)-1
                        j=i+1;
                        if M2{ii,1}(burst4{1,j}(1,1))- M2{ii,1}(burst4{1,i}(end)) < ISIthh{ii,1}(1)   %if the distance between the last spike of the previous burst is not longer than the ISI threshold found of the interburst compared to the first spike of the next bursts it will be merged into one burst
                            burst5{i}=vertcat(burst4{1,i},burst4{1,j});
                        else
                            
                            burst5{i}=burst4{1,i};
                            burst5{j}=burst4{1,j};
                        end
                    end
                    
                    clear burst4
                    
                    
                    NewVector = cellfun(@(x) x(end), burst5); % get all the last number of each detected burst
                    
                    
                    for i = 1:length(NewVector)
                        try
                            if NewVector(i) == NewVector(i+1) %find duplicated bursts and removes them ( its based on the last number as in the duplicated bursts they are the same)
                                burst5{i+1} = [];
                            else
                                
                            end
                        catch
                        end
                    end
                    
                    burst5=burst5(~cellfun('isempty',burst5)); %remove any empty cell
                    %
                    burst7{ii}=burst5;
                end
                
            end
            close(hh)
            clear burst5 test2 idx test maxbursts ISIthh yy ii NewVector
            burst7=burst7'; %these contain the burst according to the log ISI method
            burst7indx=burst7;
            
            for i=1:length(M2)
                for j=1:length(burst7{i,1})
                    burst7{i,1}{1,j}=M2{i,1}(burst7{i,1}{1,j});  %now we have the correct spike timings!
                end
            end
            
            logburst=cell(1,length(M2));
            for jj=1:length(M2)
                logburst{jj}.number_of_bursts=1:length(burst7{jj,1});
                
                for i=1:length(burst7{jj,1})
                    logburst{jj}.duration_of_bursts(i)=burst7{jj,1}{1,i}(end)-burst7{jj,1}{1,i}(1,1);
                end
                
                
                for i=1:length(burst7{jj,1})
                    logburst{jj}.spikes_in_bursts(i)=length(burst7{jj,1}{1,i});
                end
            end
            logburst=logburst';   %contains data about the bursts for the table
            
            for i=1:length(M2)
                logburst{i,1}.number_of_bursts=logburst{i,1}.number_of_bursts'; %flip everything for the table
            end
            
            for i=1:length(M2)
                if sum(strcmp(fieldnames(logburst{i,1}), 'spikes_in_bursts')) == 1
                    logburst{i,1}.spikes_in_bursts=logburst{i,1}.spikes_in_bursts'; %flip everything for the table
                else
                end
            end
            
            for i=1:length(M2)
                if sum(strcmp(fieldnames(logburst{i,1}), 'duration_of_bursts')) == 1
                    logburst{i,1}.duration_of_bursts=logburst{i,1}.duration_of_bursts'; %flip everything for the table
                else
                end
            end
            
            
            %get the firing frequency (Hz) per burst per electrode
            
            fr_of_bursts = zeros(1,length(M2))';
            for i = 1:length(M2)
                if isempty(logburst{i}.number_of_bursts)
                    logburst{i}.fr_of_bursts = [];
                else
                    for j = 1:length(logburst{i}.spikes_in_bursts)
                        logburst{i}.fr_of_bursts(j) = logburst{i}.spikes_in_bursts(j)/ logburst{i}.duration_of_bursts(j);
                        logburst{i}.fr_of_bursts = logburst{i}.fr_of_bursts';
                    end
                end
            end
            
            
            %get the mean ISI of the spikes inside of a burst
            %the timings are located in burst6 for max interval
            
            
            mISIbursts = cell(1,length(M2));
            for i=1:length(M2)
                if isempty(logburst{i}.number_of_bursts)
                    mISIbursts{i} = 0;
                else
                    mISIbursts{i} = cellfun(@diff,burst7{i},'UniformOutput',0);
                    %         mISIbursts{i} = diff(burst7{i})
                end
                
            end
            
            
            mISIbursts=cell(1,length(burst7))'; %contains the average ISI of the bursts in each electrode
            for i=1:length(M2)
                mISIbursts{i}=zeros(1,length(burst7{i}));
                if isempty(logburst{i}.number_of_bursts)
                    mISIbursts{i} = 0;
                else
                    for j = 1:length(burst7{i})
                        mISIbursts{i}(j) = mean(diff(cell2mat(burst7{i}(j))));
                        logburst{i}.mean_ISI_bursts = mISIbursts{i}';
                    end
                end
            end
            
            clear mISIbursts
            
            stdISIbursts=cell(1,length(burst7))'; %contains the std of the ISI of  bursts in each electrode
            for i=1:length(M2)
                stdISIbursts{i}=zeros(1,length(burst7{i}));
                if isempty(logburst{i}.number_of_bursts)
                    stdISIbursts{i} = 0;
                else
                    for j = 1:length(burst7{i})
                        stdISIbursts{i}(j) = std(diff(cell2mat(burst7{i}(j))));
                        logburst{i}.std_ISI_bursts = stdISIbursts{i}';
                    end
                end
            end
            
            if isempty(logburst{Imax}.number_of_bursts)
                handles.pushbutton4.Enable = 'off';
                handles.pushbutton4.Visible = 'on';
            else
                handles.pushbutton4.Enable = 'on';
            end
            clear stdISIbursts binss ISIlog_hist_area j jj i maxiterations smoothed_logISI temp1 temp2 void logISIpeaks logISIlocs logISI_hist
            %     msgbox('Log ISI Burst Detection Finished')
            save(selecteddata,'logburst','burst7','','-append');
        end
        
        push3.Visible = 'on';
        push4.Visible = 'on';
        
        %% plotting
        
        x=X2;
        y=filteredData1(Imax,:);
        
        if logISI == 1 && maxinterval == 0 && length(filteredData1) > fs.filtersettings.sampling_frequency
            panel11 = findobj('Tag','uipanel11');
            axes(panel11(1));
            tt = subplot(2,1,1);
            cla(tt)
            plot(tt,x,y);
            hold on
            channel963=filteredData1(Imax,:);
            hold on;
            title('Default log ISI Bursts Detected');
            xlabel('Time(s)')
            ylabel('Voltage(uV)')
            for i=1:length(burst7old{Imax,1})
                plot(X2(find(X2 == burst7old{Imax,1}{1,i}(1,1)): find(X2 == burst7old{Imax,1}{1,i}(end))),channel963(find(X2 == burst7old{Imax,1}{1,i}(1,1)): find(X2 == burst7old{Imax,1}{1,i}(end))),'Color',[1 0 0]);
                hold on
            end
            pp = subplot(2,1,2);
            cla(pp)
            plot(pp,x,y);
            hold on
            title('New log ISI Bursts Detected');
            xlabel('Time(s)')
            ylabel('Voltage(uV)')
            for i=1:length(burst7{Imax,1})
                plot(X2(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),channel963(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),'Color',[1 0 0]);
                hold on
            end
            linkaxes([pp tt],'xy');
            
        elseif maxinterval == 1 && logISI == 0 && length(filteredData1) > fs.filtersettings.sampling_frequency
            panel11 = findobj('Tag','uipanel11');
            axes(panel11(1));
            tt = subplot(2,1,1);
            cla(tt)
            plot(tt,x,y);
            hold on
            channel963=filteredData1(Imax,:);
            hold on;
            title('Default Max Interval Bursts Detected');
            xlabel('Time(s)')
            ylabel('Voltage(uV)')
            
            for i=1:length(burst6old{Imax,1})
                plot(X2(find(X2 == burst6old{Imax,1}{1,i}(1,1)): find(X2 == burst6old{Imax,1}{1,i}(end))),channel963(find(X2 == burst6old{Imax,1}{1,i}(1,1)): find(X2 == burst6old{Imax,1}{1,i}(end))),'Color',[1 0 0]);
                hold on
            end
            
            pp = subplot(2,1,2);
            cla(pp)
            plot(pp,x,y);
            hold on
            title('New Max Interval Bursts Detected');
            xlabel('Time(s)')
            ylabel('Voltage(uV)')
            for i=1:length(burst6{Imax,1})
                plot(X2(find(X2 == burst6{Imax,1}{1,i}(1,1)): find(X2 == burst6{Imax,1}{1,i}(end))),channel963(find(X2 == burst6{Imax,1}{1,i}(1,1)): find(X2 == burst6{Imax,1}{1,i}(end))),'Color',[1 0 0]);
                hold on
            end
            %     plot(x,y)
            %     title('New Max Interval Bursts Detected');
            %     xlabel('Time(s)')
            %     ylabel('Voltage(uV)')
            %     hold on
            %     plot(
            linkaxes([pp tt],'xy');
        elseif maxinterval == 0 && logISI == 1 && length(filteredData1) < fs.filtersettings.sampling_frequency
            panel11 = findobj('Tag','uipanel11');
            axes(panel11(1));
            tt = subplot(2,1,1,'Parent',panel11);
            cla(tt)
            %             plot(tt,x,y);
            %             hold on
            %             channel963=filteredData1(Imax,:);
            hold on;
            title('Default log ISI Bursts Detected');
            xlabel('Time(s)')
            tt.YTickLabel =[];
            legend('off')
            ylabel('-')
            burst7indxold =burst7indxold';
            nTotalSpikes = sum(cellfun(@length,M2));
            xPoints = NaN(nTotalSpikes*3,1);
            yPoints = xPoints;
            currentInd = 1;
            halfSpikeHeight = 1/2;
            for trials = 1:length(M2)
                nSpikes = length(M2{trials});
                nanSeparator = NaN(1,nSpikes);
                
                trialXPoints = [ M2{trials} + 0;...
                    M2{trials} + 0; nanSeparator ];
                trialXPoints = trialXPoints(:);
                
                trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                    (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
                trialYPoints = trialYPoints(:);
                
                % Save points and update current index
                xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
                yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
                currentInd = currentInd + nSpikes*3;
            end
            % place them in the same configuration as the allbursts cell array
            
            maxbursts= [];
            
            max1bursts= cell(1,length(M2));
            for i = 1:length(burst7indxold)
                for j= 1:length(burst7indxold{i})
                    maxbursts = [burst7indxold{i}{j}(1),burst7indxold{i}{j}(end)];
                    max1bursts{i} = [max1bursts{i},maxbursts];
                end
                
            end
            max1bursts=max1bursts';
            
            max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
            % now lets make it easier to index in the xPoints vector by giving each
            % number the correct index so we can just index in the xPoints vector
            
            % the try and catch statements are only temp fix but need to take a
            % look att he code for max interval
            countold = 0;
            for i=1:length(max1bursts)
                try
                    countnew = (length(M2{i})*3+countold);
                    countold = countnew;
                    if isempty(max1bursts{(i+1)})
                    else
                        for j = 1:length(max1bursts{(i+1)})
                            
                            max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                        end
                    end
                catch
                end
            end
            
            
            hold on
            for i = 1:length(M2)
                try
                    for j = 0:2:length(max1bursts{i})-1
                        hold on
                        plot(xPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),yPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),'r')
                    end
                catch
                end
            end
            ylim([Imax-0.5 Imax])
            
            pp = subplot(2,1,2,'Parent',panel11);
            cla(pp)
            %             plot(pp,x,y);
            hold on
            title('New log ISI Bursts Detected');
            xlabel('Time(s)')
            ylabel('-')
            
            
            burst7indx =burst7indx';
            nTotalSpikes = sum(cellfun(@length,M2));
            xPoints = NaN(nTotalSpikes*3,1);
            yPoints = xPoints;
            currentInd = 1;
            halfSpikeHeight = 1/2;
            for trials = 1:length(M2)
                nSpikes = length(M2{trials});
                nanSeparator = NaN(1,nSpikes);
                
                trialXPoints = [ M2{trials} + 0;...
                    M2{trials} + 0; nanSeparator ];
                trialXPoints = trialXPoints(:);
                
                trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                    (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
                trialYPoints = trialYPoints(:);
                
                % Save points and update current index
                xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
                yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
                currentInd = currentInd + nSpikes*3;
            end
            % place them in the same configuration as the allbursts cell array
            
            maxbursts= [];
            
            max1bursts= cell(1,length(M2));
            for i = 1:length(burst7indx)
                for j= 1:length(burst7indx{i})
                    maxbursts = [burst7indx{i}{j}(1),burst7indx{i}{j}(end)];
                    max1bursts{i} = [max1bursts{i},maxbursts];
                end
                
            end
            max1bursts=max1bursts';
            
            max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
            % now lets make it easier to index in the xPoints vector by giving each
            % number the correct index so we can just index in the xPoints vector
            
            % the try and catch statements are only temp fix but need to take a
            % look att he code for max interval
            countold = 0;
            for i=1:length(max1bursts)
                try
                    countnew = (length(M2{i})*3+countold);
                    countold = countnew;
                    if isempty(max1bursts{(i+1)})
                    else
                        for j = 1:length(max1bursts{(i+1)})
                            
                            max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                        end
                    end
                catch
                end
            end
            
            %             subplot('position',[0.2 0.15 0.7 0.8],'Parent',panel11 );
            hold on
            for i = 1:length(M2)
                try
                    for j = 0:2:length(max1bursts{i})-1
                        hold on
                        plot(xPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),yPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),'r')
                    end
                catch
                end
            end
            
            legend('off')
            pp.YTickLabel =[];
            ylim([Imax-0.5 Imax])
            
            %     plot(x,y)
            %     title('New Max Interval Bursts Detected');
            %     xlabel('Time(s)')
            %     ylabel('Voltage(uV)')
            %     hold on
            %     plot(
            linkaxes([pp tt],'xy');
            
        elseif maxinterval == 1 && logISI == 0 && length(filteredData1) < fs.filtersettings.sampling_frequency
            panel11 = findobj('Tag','uipanel11');
            axes(panel11(1));
            tt = subplot(2,1,1,'Parent',panel11);
            cla(tt)
            %             plot(tt,x,y);
            %             hold on
            %             channel963=filteredData1(Imax,:);
            hold on;
            title('Default Max Interval Bursts Detected');
            xlabel('Time(s)')
            tt.YTickLabel =[];
            legend('off')
            ylabel('-')
            burst6indxold =burst6indxold';
            nTotalSpikes = sum(cellfun(@length,M2));
            xPoints = NaN(nTotalSpikes*3,1);
            yPoints = xPoints;
            currentInd = 1;
            halfSpikeHeight = 1/2;
            for trials = 1:length(M2)
                nSpikes = length(M2{trials});
                nanSeparator = NaN(1,nSpikes);
                
                trialXPoints = [ M2{trials} + 0;...
                    M2{trials} + 0; nanSeparator ];
                trialXPoints = trialXPoints(:);
                
                trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                    (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
                trialYPoints = trialYPoints(:);
                
                % Save points and update current index
                xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
                yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
                currentInd = currentInd + nSpikes*3;
            end
            % place them in the same configuration as the allbursts cell array
            
            maxbursts= [];
            
            max1bursts= cell(1,length(M2));
            for i = 1:length(burst6indxold)
                for j= 1:length(burst6indxold{i})
                    maxbursts = [burst6indxold{i}{j}(1),burst6indxold{i}{j}(end)];
                    max1bursts{i} = [max1bursts{i},maxbursts];
                end
                
            end
            max1bursts=max1bursts';
            
            max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
            % now lets make it easier to index in the xPoints vector by giving each
            % number the correct index so we can just index in the xPoints vector
            
            % the try and catch statements are only temp fix but need to take a
            % look att he code for max interval
            countold = 0;
            for i=1:length(max1bursts)
                try
                    countnew = (length(M2{i})*3+countold);
                    countold = countnew;
                    if isempty(max1bursts{(i+1)})
                    else
                        for j = 1:length(max1bursts{(i+1)})
                            
                            max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                        end
                    end
                catch
                end
            end
            
            
            hold on
            for i = 1:length(M2)
                try
                    for j = 0:2:length(max1bursts{i})-1
                        hold on
                        plot(xPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),yPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),'r')
                    end
                catch
                end
            end
            ylim([Imax-0.5 Imax])
            
            pp = subplot(2,1,2,'Parent',panel11);
            cla(pp)
            %             plot(pp,x,y);
            hold on
            title('New Max Interval Bursts Detected');
            xlabel('Time(s)')
            ylabel('-')
            
            
            burst6indx =burst6indx';
            nTotalSpikes = sum(cellfun(@length,M2));
            xPoints = NaN(nTotalSpikes*3,1);
            yPoints = xPoints;
            currentInd = 1;
            halfSpikeHeight = 1/2;
            for trials = 1:length(M2)
                nSpikes = length(M2{trials});
                nanSeparator = NaN(1,nSpikes);
                
                trialXPoints = [ M2{trials} + 0;...
                    M2{trials} + 0; nanSeparator ];
                trialXPoints = trialXPoints(:);
                
                trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                    (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
                trialYPoints = trialYPoints(:);
                
                % Save points and update current index
                xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
                yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
                currentInd = currentInd + nSpikes*3;
            end
            % place them in the same configuration as the allbursts cell array
            
            maxbursts= [];
            
            max1bursts= cell(1,length(M2));
            for i = 1:length(burst6indx)
                for j= 1:length(burst6indx{i})
                    maxbursts = [burst6indx{i}{j}(1),burst6indx{i}{j}(end)];
                    max1bursts{i} = [max1bursts{i},maxbursts];
                end
                
            end
            max1bursts=max1bursts';
            
            max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
            % now lets make it easier to index in the xPoints vector by giving each
            % number the correct index so we can just index in the xPoints vector
            
            % the try and catch statements are only temp fix but need to take a
            % look att he code for max interval
            countold = 0;
            for i=1:length(max1bursts)
                try
                    countnew = (length(M2{i})*3+countold);
                    countold = countnew;
                    if isempty(max1bursts{(i+1)})
                    else
                        for j = 1:length(max1bursts{(i+1)})
                            
                            max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                        end
                    end
                catch
                end
            end
            
            %             subplot('position',[0.2 0.15 0.7 0.8],'Parent',panel11 );
            hold on
            for i = 1:length(M2)
                try
                    for j = 0:2:length(max1bursts{i})-1
                        hold on
                        plot(xPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),yPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),'r')
                    end
                catch
                end
            end
            
            legend('off')
            pp.YTickLabel =[];
            ylim([Imax-0.5 Imax])
            
            %     plot(x,y)
            %     title('New Max Interval Bursts Detected');
            %     xlabel('Time(s)')
            %     ylabel('Voltage(uV)')
            %     hold on
            %     plot(
            linkaxes([pp tt],'xy');
        end
        
        
        dx=1; % this is the window in which the slide will operate (Seconds)
        % cla
        % plot(ax,x,y);
        axes1=gca;
        Xlim11=axes1.XLim;
        Ylim11=axes1.YLim;
        
        % xlabel('Time in seconds');
        % title(['Channel ', HITS{Imax}]);
        set(gca,'Fontsize',10);
        
        % Set appropriate axis limits and settings
        set(gcf,'doublebuffer','on');
        [tb,~] = axtoolbar(tt,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        [tb,~] = axtoolbar(pp,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        % % This avoids flickering when updating the axis
        % set(axes1,'xlim',[0 dx]); % window
        % % find the values that is the largest for the axis and set the limit to the
        % % highest
        
        if length(filteredData1) < fs.filtersettings.sampling_frequency
            
        else
            if abs(min(y)) > max(y)
                set(axes1,'ylim',[min(y) abs(min(y))]);
            else
                set(axes1,'ylim',[-max(y) max(y)]);
            end
            
            axes1.XLim=Xlim11;
            axes1.YLim=Ylim11;
        end
    end

    function rerunnnbursts(source,handles,eventdata)
        
        if maxinterval == 1
            
            hh = waitbar(0,'Recalculating the network burst using the max interval detected bursts');
            starttimesbursts2 = [];
            for i = 1:length(burst6)
                for j = 1:length(burst6{i})
                    starttimesbursts = burst6{i}{j}(1);
                    starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
                end
            end
            
            uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes
            
            %now we need to put all the times in a giant matrix so we can
            %search in this matrix with the unique burst start times
            
            %convert all the cells into vectors
            % all the vectors are made equal in length by adding in nans
            temp = cell(1,length(burst6))';
            for i = 1:length(burst6)
                temp{i} = cell2mat(burst6{i});
            end
            
            newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
            newc=cell2mat(newc);
            
            
            % now we need to find if there are multiple channels that start
            % bursting at the same time
            channelnumbernnbursts =cell(1,length(burst6))';
            timeofnnbursts =cell(1,length(burst6))';
            for i = 1:length(uniquestarttimesbursts)
                [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) -  fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) +  fs.networkburstdetection.synchronizedtimewindow );
            end
            
            
            % check for duplicate channelnumbers if so remove them
            for i =1:length(channelnumbernnbursts)
                if isempty(channelnumbernnbursts{i})
                else
                    if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                        channelnumbernnbursts{i} = [];
                        timeofnnbursts{i}=[];
                    else
                        
                    end
                end
            end
            
            
            
            
            
            
            % now that we the channels that are synchronzied in their bursting
            % we need to remove the channels that do not fullfull our
            % requirements of have atleast 2 synchronized channels and atleast
            % 50% of the otal amount of channels should participate in the
            % nnburst or else it gets removed
            
            
            for i = 1:length(channelnumbernnbursts)
                if length(channelnumbernnbursts{i}) < fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                    channelnumbernnbursts{i} = [];
                    timeofnnbursts{i} = [];
                    uniquestarttimesbursts(i) = nan;
                end
            end
            
            %clean up by removing empty cells and nan values
            uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
            channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
            timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
            
            % now we need to find the bursts that are part of the synchronized
            % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
            % synchronzied bursts in other channels and then we can see how
            % many channels are participating
            waitbar(0 + 0.2,hh,'Recalculating the network burst using the max interval detected bursts');
            
            burst6length =burst6; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
            for i = 1:length(burst6)
                for j = 1:length(burst6{i})
                    burst6length{i}{j} = length(burst6{i}{j});
                end
            end
            
            for i = 1:length(burst6) % convert the cell arrays in vectors
                burst6length{i} = cell2mat(burst6length{i});
            end
            
            
            potentialnnbursts = cell(1,length(channelnumbernnbursts))';
            burstsindexcount=[];
            for i = 1:length(potentialnnbursts)
                for j = 1:length(channelnumbernnbursts{i})
                    for k = 1:cellfun(@length,(burst6(channelnumbernnbursts{i}(j))))
                        %figure out which bursts the indexes belong to
                        
                        %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
                        %                      burstsindexcount = cumsum( burstsindexcount); % old version
                        burstsindexcount = cumsum( burst6length{channelnumbernnbursts{i}(j)});
                        if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                            correctburst = k;
                            potentialnnbursts{i}{j} = burst6{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                            break
                        end
                    end
                end
            end
            
            % we have to check if the times of the bursts are within acceptable
            % ( check for nana values
            
            % create variable that is the exact same varible as potentialnnbursts
            % but intead each cell contains the mean + std of that channel to
            % improve the speed
            
            
            potentialnnburstsmean = potentialnnbursts;
            for i =1 :length(potentialnnbursts)
                potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 25*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
            end
            
            for i = 1:length(potentialnnbursts)
                for j = 1:length(potentialnnbursts{i})
                    %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                    if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                        potentialnnbursts{i}{j} = [];
                    end
                end
            end
            
            
            
            waitbar(0 + 0.6,hh,'Recalculating the network burst using the max interval detected bursts');
            
            % now we need to use the synscho bursts to find if there are bursts that
            % fall within the same duration as the synchronized bursts. if they do then
            % they are part of the  potential network bursts
            % we loop through both synchronized bursts just to extra certain we do not
            % miss anything because the starttimes might be the same but the ending
            % time might not be.
            
            mergeburstchannel = cell(1,length(potentialnnbursts))';
            mergeburstnumber  = cell(1,length(potentialnnbursts))';
            tobemergedbursts  = cell(1,length(potentialnnbursts))';
            
            % create vaiable of potneialnnbursts that have all the cells converted into
            % vectors to improve the performance
            potentialnnburstsvector = potentialnnbursts;
            potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
            
            
            for i = 1:length(potentialnnburstsvector)
                potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
                potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
            end
            
            for i =1:length(potentialnnbursts)
                for k = 1:length(burst6)
                    for l = 1:length(burst6{k})
                        if ~isempty(find(burst6{k}{l} > potentialnnburstsvector{i,2}(1) & burst6{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                            tobemergedbursts{i}{k} =cell2mat(burst6{k}(l)) ;
                            mergeburstchannel{i}{k} = k;
                            mergeburstnumber{i}{k} = l;
                        end
                    end
                end
            end
            
            
            
            % clean up the empty  cells
            
            for i =1:length(tobemergedbursts)
                tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
                mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
                mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
            end
            
            %now we need remove the nnbursts that have less than 50% of the whole wwell
            %participating in the nnbursts
            
            % find the number of active channels
            amountactivechannels = length(find(~cellfun(@isempty,M2)));
            
            mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
            tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
            mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
            % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
            % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
            % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
            
            %the last step is to find duplicates and merge them together
            findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
            
            for i = 1:length(tobemergedbursts)
                findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
            end
            
            
            waitbar(0 + 0.8,hh,'Recalculating the network burst using the max interval detected bursts');
            
            for i = 1:length(tobemergedbursts)
                if isempty(findoverlappingnnbursts{i})
                    continue
                else
                    for k = 2:length(tobemergedbursts)
                        if isempty(findoverlappingnnbursts{k}) || k == i
                            continue
                        else
                            if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                                % if this is true than there is overlap. so we need to find out
                                % which one is longer and that will be the one remaining.
                                if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                    findoverlappingnnbursts{k} = [];
                                else
                                    findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                    findoverlappingnnbursts{k} = [];
                                end
                            else
                                
                                
                            end
                        end
                    end
                end
            end
            
            %lets use logical indezing to get rid of the overlapping nnbursts and
            %finally get our actual nnbursts
            
            tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
            findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            
            % now that we have our nnbursts we can extract the ifnroamtion about the
            % nnbursts
            
            if isempty(findoverlappingnnbursts)
                networkburstttt.amount = 0;
                networkburstttt.duration = 0;
                networkburstttt.spikesfr_in_nbursts = 0;
                networkburstttt.nburst_rate = 0;
                networkburstttt.ISI = 0 ;
                networkburstttt.IBI = 0;
                networkburstttt.CVIBI = 0;
            else
                %struct for networkbursts
                networkburstttt =[];
                for i = 1:length(mergeburstnumber)
                    
                    networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
                    networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
                    networkburstttt.amount = length(mergeburstnumber);
                    networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
                    networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
                    networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
                    networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
                end
                
                for i = 1:length(mergeburstnumber)
                    if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                        networkburstttt.IBI(i,1) = 0;
                        networkburstttt.CVIBI = 0;
                        continue
                    else
                        networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
                    end
                end
                
                if isempty(networkburstttt)
                else
                    networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
                end
                
                
            end
            
            save(selecteddata,'networkburstttt','-append')
            close(hh)
        elseif logISI == 1
            hh = waitbar(0,'Recalculating the network burst using the log ISI detcted bursts');
            starttimesbursts2 = [];
            for i = 1:length(burst7)
                for j = 1:length(burst7{i})
                    starttimesbursts = burst7{i}{j}(1);
                    starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
                end
            end
            
            uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes
            
            %now we need to put all the times in a giant matrix so we can
            %search in this matrix with the unique burst start times
            
            %convert all the cells into vectors
            % all the vectors are made equal in length by adding in nans
            temp = cell(1,length(burst7))';
            for i = 1:length(burst7)
                temp{i} = cell2mat(burst7{i});
            end
            
            newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
            newc=cell2mat(newc);
            
            
            % now we need to find if there are multiple channels that start
            % bursting at the same time
            channelnumbernnbursts =cell(1,length(burst7))';
            timeofnnbursts =cell(1,length(burst7))';
            for i = 1:length(uniquestarttimesbursts)
                [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) -  fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) +  fs.networkburstdetection.synchronizedtimewindow );
            end
            
            
            
            
            % check for duplicate channelnumbers if so remove them
            for i =1:length(channelnumbernnbursts)
                if isempty(channelnumbernnbursts{i})
                else
                    if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                        channelnumbernnbursts{i} = [];
                        timeofnnbursts{i}=[];
                    else
                        
                    end
                end
            end
            
            
            % now that we the channels that are synchronzied in their bursting
            % we need to remove the channels that do not fullfull our
            % requirements of have atleast 2 synchronized channels and atleast
            % 50% of the otal amount of channels should participate in the
            % nnburst or else it gets removed
            
            
            for i = 1:length(channelnumbernnbursts)
                if length(channelnumbernnbursts{i}) < fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                    channelnumbernnbursts{i} = [];
                    timeofnnbursts{i} = [];
                    uniquestarttimesbursts(i) = nan;
                end
            end
            
            %clean up by removing empty cells and nan values
            uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
            channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
            timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
            
            % now we need to find the bursts that are part of the synchronized
            % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
            % synchronzied bursts in other channels and then we can see how
            % many channels are participating
            
            waitbar(0 + 0.2,hh,'Recalculating the network burst using the log ISI detected bursts');
            burst7length =burst7; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
            for i = 1:length(burst7)
                for j = 1:length(burst7{i})
                    burst7length{i}{j} = length(burst7{i}{j});
                end
            end
            
            for i = 1:length(burst7) % convert the cell arrays in vectors
                burst7length{i} = cell2mat(burst7length{i});
            end
            
            
            potentialnnbursts = cell(1,length(channelnumbernnbursts))';
            burstsindexcount=[];
            for i = 1:length(potentialnnbursts)
                for j = 1:length(channelnumbernnbursts{i})
                    for k = 1:cellfun(@length,(burst7(channelnumbernnbursts{i}(j))))
                        %figure out which bursts the indexes belong to
                        
                        %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
                        %                      burstsindexcount = cumsum( burstsindexcount); % old version
                        burstsindexcount = cumsum( burst7length{channelnumbernnbursts{i}(j)});
                        if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                            correctburst = k;
                            potentialnnbursts{i}{j} = burst7{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                            break
                        end
                    end
                end
            end
            
            % we have to check if the times of the bursts are within acceptable
            % ( check for nana values
            
            
            % create variable that is the exact same varible as potentialnnbursts
            % but intead each cell contains the mean + std of that channel to
            % improve the speed
            
            
            potentialnnburstsmean = potentialnnbursts;
            for i =1 :length(potentialnnbursts)
                potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 25*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
            end
            
            for i = 1:length(potentialnnbursts)
                for j = 1:length(potentialnnbursts{i})
                    %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                    if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                        potentialnnbursts{i}{j} = [];
                    end
                end
            end
            
            
            
            % now we need to use the synscho bursts to find if there are bursts that
            % fall within the same duration as the synchronized bursts. if they do then
            % they are part of the  potential network bursts
            % we loop through both synchronized bursts just to extra certain we do not
            % miss anything because the starttimes might be the same but the ending
            % time might not be.
            
            mergeburstchannel = cell(1,length(potentialnnbursts))';
            mergeburstnumber  = cell(1,length(potentialnnbursts))';
            tobemergedbursts  = cell(1,length(potentialnnbursts))';
            
            
            % create vaiable of potneialnnbursts that have all the cells converted into
            % vectors to improve the performance
            potentialnnburstsvector = potentialnnbursts;
            potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
            
            
            for i = 1:length(potentialnnburstsvector)
                potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
                potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
            end
            
            for i =1:length(potentialnnbursts)
                for k = 1:length(burst7)
                    for l = 1:length(burst7{k})
                        if ~isempty(find(burst7{k}{l} > potentialnnburstsvector{i,2}(1) & burst7{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                            tobemergedbursts{i}{k} =cell2mat(burst7{k}(l)) ;
                            mergeburstchannel{i}{k} = k;
                            mergeburstnumber{i}{k} = l;
                        end
                    end
                end
            end
            
            % clean up the empty  cells
            
            for i =1:length(tobemergedbursts)
                tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
                mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
                mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
            end
            
            %now we need remove the nnbursts that have less than 50% of the whole wwell
            %participating in the nnbursts
            
            % find the number of active channels
            amountactivechannels = length(find(~cellfun(@isempty,M2)));
            
            mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
            tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
            mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
            % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
            % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
            % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
            
            %the last step is to find duplicates and merge them together
            findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
            
            for i = 1:length(tobemergedbursts)
                findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
            end
            
            waitbar(0 + 0.6,hh,'Recalculating the network burst using the log ISI detected bursts');
            
            for i = 1:length(tobemergedbursts)
                if isempty(findoverlappingnnbursts{i})
                    continue
                else
                    for k = 2:length(tobemergedbursts)
                        if isempty(findoverlappingnnbursts{k}) || k == i
                            continue
                        else
                            if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                                % if this is true than there is overlap. so we need to find out
                                % which one is longer and that will be the one remaining.
                                if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                    findoverlappingnnbursts{k} = [];
                                else
                                    findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                    findoverlappingnnbursts{k} = [];
                                end
                            else
                                
                                
                            end
                        end
                    end
                end
            end
            
            %lets use logical indezing to get rid of the overlapping nnbursts and
            %finally get our actual nnbursts
            
            tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
            findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            
            % now that we have our nnbursts we can extract the ifnroamtion about the
            % nnbursts
            waitbar(0 + 0.8,hh,'Recalculating the network burst using the log ISI detected bursts');
            if isempty(findoverlappingnnbursts)
                networkburstttt.amount = 0;
                networkburstttt.duration = 0;
                networkburstttt.spikesfr_in_nbursts = 0;
                networkburstttt.nburst_rate = 0;
                networkburstttt.ISI = 0 ;
                networkburstttt.IBI = 0;
                networkburstttt.CVIBI = 0;
            else
                %struct for networkbursts
                networkburstttt =[];
                for i = 1:length(mergeburstnumber)
                    
                    networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
                    networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
                    networkburstttt.amount = length(mergeburstnumber);
                    networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
                    networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
                    networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
                    networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
                end
                
                for i = 1:length(mergeburstnumber)
                    if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                        networkburstttt.IBI(i,1) = 0;
                        networkburstttt.CVIBI = 0;
                        continue
                    else
                        networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
                    end
                end
                
                if isempty(networkburstttt)
                else
                    networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
                end
                
            end
            save(selecteddata,'networkburstttt','-append')
            close(hh)
        elseif overlapp == 1
            hh = waitbar(0,'Recalculating the network burst based on overlapping SCBs');
            starttimesbursts2 = [];
            for i = 1:length(overlap)
                for j = 1:length(overlap{i})
                    starttimesbursts = overlap{i}{j}(1);
                    starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
                end
            end
            
            uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes
            
            %now we need to put all the times in a giant matrix so we can
            %search in this matrix with the unique burst start times
            
            %convert all the cells into vectors
            % all the vectors are made equal in length by adding in nans
            temp = cell(1,length(overlap))';
            for i = 1:length(overlap)
                temp{i} = cell2mat(overlap{i});
            end
            
            newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
            newc=cell2mat(newc);
            
            
            % now we need to find if there are multiple channels that start
            % bursting at the same time
            channelnumbernnbursts =cell(1,length(overlap))';
            timeofnnbursts =cell(1,length(overlap))';
            for i = 1:length(uniquestarttimesbursts)
                [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) -  fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) +  fs.networkburstdetection.synchronizedtimewindow );
            end
            
            
            
            % check for duplicate channelnumbers if so remove them
            for i =1:length(channelnumbernnbursts)
                if isempty(channelnumbernnbursts{i})
                else
                    if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
                        channelnumbernnbursts{i} = [];
                        timeofnnbursts{i}=[];
                    else
                        
                    end
                end
            end
            
            
            
            % now that we the channels that are synchronzied in their bursting
            % we need to remove the channels that do not fullfull our
            % requirements of have atleast 2 synchronized channels and atleast
            % 50% of the otal amount of channels should participate in the
            % nnburst or else it gets removed
            
            
            for i = 1:length(channelnumbernnbursts)
                if length(channelnumbernnbursts{i}) < fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
                    channelnumbernnbursts{i} = [];
                    timeofnnbursts{i} = [];
                    uniquestarttimesbursts(i) = nan;
                end
            end
            
            %clean up by removing empty cells and nan values
            uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
            channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
            timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));
            
            % now we need to find the bursts that are part of the synchronized
            % bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
            % synchronzied bursts in other channels and then we can see how
            % many channels are participating
            
            waitbar(0 + 0.2,hh,'Recalculating the network burst based on overlapping SCBs');
            
            overlaplength =overlap; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
            for i = 1:length(overlap)
                for j = 1:length(overlap{i})
                    overlaplength{i}{j} = length(overlap{i}{j});
                end
            end
            
            for i = 1:length(overlap) % convert the cell arrays in vectors
                overlaplength{i} = cell2mat(overlaplength{i});
            end
            
            
            potentialnnbursts = cell(1,length(channelnumbernnbursts))';
            burstsindexcount=[];
            for i = 1:length(potentialnnbursts)
                for j = 1:length(channelnumbernnbursts{i})
                    for k = 1:cellfun(@length,(overlap(channelnumbernnbursts{i}(j))))
                        %figure out which bursts the indexes belong to
                        
                        %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
                        %                      burstsindexcount = cumsum( burstsindexcount); % old version
                        burstsindexcount = cumsum( overlaplength{channelnumbernnbursts{i}(j)});
                        if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                            correctburst = k;
                            potentialnnbursts{i}{j} = overlap{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                            break
                        end
                    end
                end
            end
            
            % we have to check if the times of the bursts are within acceptable
            % ( check for nana values
            
            
            %remove empty cells
            potentialnnbursts(cellfun('isempty',potentialnnbursts))=[];
            % create variable that is the exact same varible as potentialnnbursts
            % but intead each cell contains the mean + std of that channel to
            % improve the speed
            
            
            potentialnnburstsmean = potentialnnbursts;
            for i =1 :length(potentialnnbursts)
                potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 25*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
            end
            
            for i = 1:length(potentialnnbursts)
                for j = 1:length(potentialnnbursts{i})
                    %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
                    if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
                        potentialnnbursts{i}{j} = [];
                    end
                end
            end
            
            
            % now we need to use the synscho bursts to find if there are bursts that
            % fall within the same duration as the synchronized bursts. if they do then
            % they are part of the  potential network bursts
            % we loop through both synchronized bursts just to extra certain we do not
            % miss anything because the starttimes might be the same but the ending
            % time might not be.
            
            mergeburstchannel = cell(1,length(potentialnnbursts))';
            mergeburstnumber  = cell(1,length(potentialnnbursts))';
            tobemergedbursts  = cell(1,length(potentialnnbursts))';
            
            % create vaiable of potneialnnbursts that have all the cells converted into
            % vectors to improve the performance
            potentialnnburstsvector = potentialnnbursts;
            potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);
            
            
            for i = 1:length(potentialnnburstsvector)
                potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
                potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
            end
            
            for i =1:length(potentialnnbursts)
                for k = 1:length(overlap)
                    for l = 1:length(overlap{k})
                        if ~isempty(find(overlap{k}{l} > potentialnnburstsvector{i,2}(1) & overlap{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                            tobemergedbursts{i}{k} =cell2mat(overlap{k}(l)) ;
                            mergeburstchannel{i}{k} = k;
                            mergeburstnumber{i}{k} = l;
                        end
                    end
                end
            end
            
            
            % clean up the empty  cells
            
            for i =1:length(tobemergedbursts)
                tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
                mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
                mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
            end
            
            %now we need remove the nnbursts that have less than 50% of the whole wwell
            %participating in the nnbursts
            
            % find the number of active channels
            amountactivechannels = length(find(~cellfun(@isempty,M2)));
            
            mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels * fs.networkburstdetection.minimumchannelparticipation) = [];
            % channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
            % timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
            % potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];
            
            %the last step is to find duplicates and merge them together
            findoverlappingnnbursts = cell(1,length(tobemergedbursts))';
            
            for i = 1:length(tobemergedbursts)
                findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
            end
            
            waitbar(0 + 0.6,hh,'Recalculating the network burst based on overlapping SCBs');
            
            for i = 1:length(tobemergedbursts)
                if isempty(findoverlappingnnbursts{i})
                    continue
                else
                    for k = 2:length(tobemergedbursts)
                        if isempty(findoverlappingnnbursts{k}) || k == i
                            continue
                        else
                            if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                                % if this is true than there is overlap. so we need to find out
                                % which one is longer and that will be the one remaining.
                                if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                                    findoverlappingnnbursts{k} = [];
                                else
                                    findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                                    findoverlappingnnbursts{k} = [];
                                end
                            else
                                
                                
                            end
                        end
                    end
                end
            end
            
            %lets use logical indezing to get rid of the overlapping nnbursts and
            %finally get our actual nnbursts
            
            tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
            mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
            findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
            
            % now that we have our nnbursts we can extract the ifnroamtion about the
            % nnbursts
            waitbar(0 + 0.8,hh,'Recalculating the network burst based on overlapping SCBs');
            if isempty(findoverlappingnnbursts)
                networkburstttt.amount = 0;
                networkburstttt.duration = 0;
                networkburstttt.spikesfr_in_nbursts = 0;
                networkburstttt.nburst_rate = 0;
                networkburstttt.ISI = 0 ;
                networkburstttt.IBI = 0;
                networkburstttt.CVIBI = 0;
            else
                %struct for networkbursts
                networkburstttt =[];
                for i = 1:length(mergeburstnumber)
                    
                    networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
                    networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
                    networkburstttt.amount = length(mergeburstnumber);
                    networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
                    networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
                    networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
                    networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
                end
                
                for i = 1:length(mergeburstnumber)
                    if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
                        networkburstttt.IBI(i,1) = 0;
                        networkburstttt.CVIBI = 0;
                        continue
                    else
                        networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
                    end
                end
                
                if isempty(networkburstttt)
                else
                    networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
                end
                
            end
            save(selecteddata,'networkburstttt','-append')
            close(hh)
        end
        
        nTotalSpikes = sum(cellfun(@length,M2));
        
        
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;
        
        
        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            % Save points and update current index
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        
        
        %% plotting
        if logISI == 1 && maxinterval == 0
            %% default paramaters
            panel11 = findobj('Tag','uipanel11');
            pp = subplot(2,1,1,'Parent',panel11);
            nnetworkburstdisp = cell(1,length(M2));
            if isempty(networkbursttttold)
                networkbursttttold.amount = 0;
            end
            
            if networkbursttttold.amount == 0
                cla(pp)
            else
                for i = 1:length(networkbursttttold.starttime)
                    for j = 1:length(M2)
                        if isempty(burst7{j})
                            continue
                        else
                            temp = find(M2{j} > networkbursttttold.starttime(i) &  M2{j} < networkbursttttold.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(pp,'YTickLabel',correctylim)
                    pp.YTickLabel{end} =[];
                    title(['Network bursts detected with default parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(pp)
                
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end
            
            %% new paramaters
            tt = subplot(2,1,2,'Parent',panel11);
            if networkburstttt.amount == 0
                cla(tt)
            else
                for i = 1:length(networkburstttt.starttime)
                    for j = 1:length(M2)
                        if isempty(burst7{j})
                            continue
                        else
                            temp = find(M2{j} > networkburstttt.starttime(i) &  M2{j} < networkburstttt.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(tt,'YTickLabel',correctylim)
                    tt.YTickLabel{end} =[];
                    title(['Network bursts detected with new parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(tt)
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end
            
        elseif maxinterval == 1 && logISI == 0
            %% old parameters
            panel11 = findobj('Tag','uipanel11');
            pp = subplot(2,1,1,'Parent',panel11);
            
            nnetworkburstdisp = cell(1,length(M2));
            
            if isempty(networkbursttttold)
                networkbursttttold.amount = 0;
            end
            
            if networkbursttttold.amount == 0
                cla(pp)
            else
                for i = 1:length(networkbursttttold.starttime)
                    for j = 1:length(M2)
                        if isempty(burst6{j})
                            continue
                        else
                            temp = find(M2{j} > networkbursttttold.starttime(i) &  M2{j} < networkbursttttold.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(pp,'YTickLabel',correctylim)
                    pp.YTickLabel{end} =[];
                    title(['Network bursts detected with default parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(pp)
                
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end
            
            %% new parameters
            nnetworkburstdisp = cell(1,length(M2));
            tt = subplot(2,1,2,'Parent',panel11);
            if networkburstttt.amount == 0
                cla(tt)
            else
                for i = 1:length(networkburstttt.starttime)
                    for j = 1:length(M2)
                        if isempty(burst6{j})
                            continue
                        else
                            temp = find(M2{j} > networkburstttt.starttime(i) &  M2{j} < networkburstttt.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(tt,'YTickLabel',correctylim)
                    tt.YTickLabel{end} =[];
                    title(['Network bursts detected with new parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(tt)
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end
        elseif overlapp == 1 && maxinterval == 0 && logISI == 0
            %% old parameters
            panel11 = findobj('Tag','uipanel11');
            pp = subplot(2,1,1,'Parent',panel11);
            if isempty(networkbursttttold)
                networkbursttttold.amount = 0;
            end
            
            nnetworkburstdisp = cell(1,length(M2));
            if networkbursttttold.amount == 0
                cla(pp)
            else
                for i = 1:length(networkbursttttold.starttime)
                    for j = 1:length(M2)
                        if isempty(burst6{j})
                            continue
                        else
                            temp = find(M2{j} > networkbursttttold.starttime(i) &  M2{j} < networkbursttttold.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(pp,'YTickLabel',correctylim)
                    pp.YTickLabel{end} =[];
                    title(['Network bursts detected with default parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(pp)
                
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end
            
            %% new parameters
            nnetworkburstdisp = cell(1,length(M2));
            tt = subplot(2,1,2,'Parent',panel11);
            if networkburstttt.amount == 0
                cla(tt)
            else
                for i = 1:length(networkburstttt.starttime)
                    for j = 1:length(M2)
                        if isempty(burst6{j})
                            continue
                        else
                            temp = find(M2{j} > networkburstttt.starttime(i) &  M2{j} < networkburstttt.endtime(i));
                            if isempty(temp)
                                continue
                            else
                                temp = [temp(1) temp(end)];
                                nnetworkburstdisp{j} = [nnetworkburstdisp{j} temp];
                            end
                        end
                    end
                end
                
                nnetworkburstdisp =   nnetworkburstdisp';
                nnetworkburstdisp =cellfun(@(x) x*3,  nnetworkburstdisp,'un',0); % now the contains the correct index of the bursts per channel
                
                
                countold = 0;
                for i=1:length(nnetworkburstdisp)
                    try
                        countnew = (length(M2{i})*3+countold);
                        countold = countnew;
                        if isempty(nnetworkburstdisp{(i+1)})
                        else
                            for j = 1:length(nnetworkburstdisp{(i+1)})
                                
                                nnetworkburstdisp{(i+1)}(j) = nnetworkburstdisp{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                            end
                        end
                    catch
                    end
                end
                
                
                
                
                xlabel('Time (s)');
                ylabel('Channels');
                
                if multiwell1 == 0
                    ylim([0 length(M2)])
                elseif multiwell1 == 1
                    correctylim = ceil(Imax/12) * 12;
                    correctylim = num2cell((correctylim - 12):2: correctylim+2);
                    set(tt,'YTickLabel',correctylim)
                    tt.YTickLabel{end} =[];
                    title(['Network bursts detected with new parameters (Well ',mat2str(ceil(Imax/12)),')']);
                    
                end
                cla(tt)
                hold on
                for i = 1:length(M2)
                    try
                        for j = 0:2:length(nnetworkburstdisp{i})-1
                            hold on
                            plot(xPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),yPoints(nnetworkburstdisp{i}(j+1):nnetworkburstdisp{i}(j+2)),'b')
                        end
                    catch
                    end
                end
                
            end
            
        end
        
        linkaxes([pp tt],'xy');
        set(gcf,'doublebuffer','on');
        [tb,~] = axtoolbar(tt,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        [tb,~] = axtoolbar(pp,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        
    end

    function revertback(source,~)
        
        if maxinterval == 1 && logISI == 0
            burst6=burst6old;
            Exburst=Exburstold;
            burst6indx=burst6indxold;
            burst7indx = burst7indxold;
            fs.burstdetectionmaxinterval.start=0.05;
            fs.burstdetectionmaxinterval.nspikes=4;
            fs.burstdetectionmaxinterval.IBI=0.1;
            fs.burstdetectionmaxinterval.intraBI=0.1;
            fs.burstdetectionmaxinterval.mindur=0.03;
            edit5.String = '0.03';
            edit4.String = '0.1';
            edit3.String = '0.1';
            edit2.String = '4';
            edit1.String = '0.05';
            fs.networkburstdetection.synchronizedtimewindow = 0.1; % time in seconds
            fs.networkburstdetection.minimumsynchronizedburstcount = 2; % in counts
            fs.networkburstdetection.minimumchannelparticipation = 0.25; % in percentage
            edit8.String = '0.1';
            edit9.String = '2';
            edit10.String = '0.25';
        elseif logISI == 1 && maxinterval == 0
            burst7=burst7old;
            logburst=logburstold;
            fs.burstdetectionlogisi.void=0.7;
            fs.burstdetectionlogisi.nspikes=3;
            edit6.String ='3';
            edit7.String ='0.7';
            fs.networkburstdetection.synchronizedtimewindow = 0.1; % time in seconds
            fs.networkburstdetection.minimumsynchronizedburstcount = 2; % in counts
            fs.networkburstdetection.minimumchannelparticipation = 0.25; % in percentage
            edit8.String = '0.1';
            edit9.String = '2';
            edit10.String = '0.25';
        elseif logISI == 0 && maxinterval == 0 && overlapp == 1
            networkburstttt=networkbursttttold;
            fs.networkburstdetection.synchronizedtimewindow = 0.1; % time in seconds
            fs.networkburstdetection.minimumsynchronizedburstcount = 2; % in counts
            fs.networkburstdetection.minimumchannelparticipation = 0.25; % in percentage
            edit8.String = '0.1';
            edit9.String = '2';
            edit10.String = '0.25';
        end
    end

    function selectch(handles,~)
        prompt = {'Enter Channel to compare the different burst detection methods in'};
        title = 'Comparison of burst detection methods';
        dims = [1 75];
        definput = {'A8'};
        newname = inputdlg(prompt,title,dims,definput);
        if isempty(newname)
            return
        end
        Imax=find(strcmp(HITS,newname{1}));
        change1 =  findobj('String',strjoin(['Channel', Totoro]));
        %         if isempty(change1)
        %              change1 =  findobj('String',strjoin(['Channel', Totoro1]));
        %         end
        change1.String = strjoin(['Channel',newname]);
        Totoro = newname;
        
        rerun
    end

    function stats1(source,~)
        push45 = findobj('Tag','pushbutton45');
        figure('units','normalized','outerposition',[0 0 1 1]);
        fig = gcf;
        set(gcf,'color','white')
        
        % change the orientation of the fr_of_bursts
        
        if size(Exburst{Imax}.fr_of_bursts,1) == 1
            Exburst{Imax}.fr_of_bursts = Exburst{Imax}.fr_of_bursts';
        end
        
        if size(logburst{Imax}.fr_of_bursts,1) == 1
            logburst{Imax}.fr_of_bursts = logburst{Imax}.fr_of_bursts';
        end
        
        
        
        if maxinterval == 1 && isempty(push45.UserData)
            if size(Exburstold{Imax}.fr_of_bursts,1) == 1
                Exburstold{Imax}.fr_of_bursts = Exburstold{Imax}.fr_of_bursts';
            end
            
            if length(Exburst{Imax}.IBI) == length(Exburst{Imax}.duration_of_bursts) % if the length are not equal add a nan value
            else
                Exburst{Imax}.IBI(end+1) = nan;
                Exburstold{Imax}.IBI(end+1) = nan;
            end
            
            if size(Exburst{Imax}.IBI,1) == 1
                Exburst{Imax}.IBI = Exburst{Imax}.IBI';
            end
            
            if size(Exburstold{Imax}.IBI,1) > size(Exburstold{Imax}.number_of_bursts,1)
                Exburstold{Imax}.IBI(isnan(Exburstold{Imax}.IBI)) =[];
            end
            
            if length(Exburstold{Imax}.IBI) == length(Exburstold{Imax}.duration_of_bursts) % if the length are not equal add a nan value
            else
                
                Exburstold{Imax}.IBI(end+1) = nan;
            end
            
            Table680=struct2table(Exburst{Imax});
            Table679=struct2table(Exburstold{Imax});
            table2 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/4 .05 1/4 .9], 'Data', Table679{:,:},'ColumnName',Table679.Properties.VariableNames,...
                'RowName',Table679.Properties.RowNames);
            text(0.24, 1.06,'Statistics of default max interval Bursts')
            table3 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/2 .05 1/4 .9], 'Data', Table680{:,:},'ColumnName',Table680.Properties.VariableNames,...
                'RowName',Table680.Properties.RowNames);
            text(0.57, 1.06,'Statistics of new max interval Bursts')
            
        elseif logISI == 1 && isempty(push45.UserData)
            if size(logburstold{Imax}.fr_of_bursts,1) == 1
                logburstold{Imax}.fr_of_bursts = logburstold{Imax}.fr_of_bursts';
            end
            
            Table680=struct2table(logburst{Imax});
            Table679=struct2table(logburstold{Imax});
            table2 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/4 .05 1/4 .9], 'Data', Table679{:,:},'ColumnName',Table679.Properties.VariableNames,...
                'RowName',Table679.Properties.RowNames);
            text(0.24, 1.06,'Statistics of default ISI Bursts')
            table3 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/2 .05 1/4 .9], 'Data', Table680{:,:},'ColumnName',Table680.Properties.VariableNames,...
                'RowName',Table680.Properties.RowNames);
            text(0.57, 1.06,'Statistics of new log ISI Bursts')
        elseif ~isempty(push45.UserData)
            networkbursttable = networkburstttt;
            networkbursttable.amount = 1:networkbursttable.amount;
            networkbursttable.networkburstnumber = networkbursttable.amount';
            networkbursttable  = rmfield(networkbursttable,'amount');
            networkbursttable  = rmfield(networkbursttable,'nburst_rate');
            networkbursttable  = rmfield(networkbursttable,'CVIBI');
            P = [7 1 2 3 4 5 6 ];
            networkbursttable = orderfields(networkbursttable,P);
            
            
            networkbursttableold = networkbursttttold;
            networkbursttableold.amount = 1:networkbursttableold.amount;
            networkbursttableold.networkburstnumber = networkbursttableold.amount';
            networkbursttableold  = rmfield(networkbursttableold,'amount');
            networkbursttableold  = rmfield(networkbursttableold,'nburst_rate');
            networkbursttableold  = rmfield(networkbursttableold,'CVIBI');
            P = [7 1 2 3 4 5 6 ];
            networkbursttableold = orderfields(networkbursttableold,P);
            
            
            if isempty(networkbursttable.networkburstnumber)
                networkbursttable.networkburstnumber = 0;
                networkbursttable.starttime = 0;
                networkbursttable.endtime = 0;
            end
            
            if isempty(networkbursttableold.networkburstnumber)
                networkbursttableold.networkburstnumber = 0;
                networkbursttableold.starttime = 0;
                networkbursttableold.endtime = 0;
            end
            
            networkbursttablenew=struct2table(networkbursttable);
            networkbursttablenold=struct2table(networkbursttableold);
            table2 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/4 .05 1/4 .9], 'Data',  networkbursttablenew{:,:},'ColumnName', networkbursttablenew.Properties.VariableNames,...
                'RowName', networkbursttablenew.Properties.RowNames);
            text(0.24, 1.06,'Statistics of new detected network bursts')
            table3 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/2 .05 1/4 .9], 'Data', networkbursttablenold{:,:},'ColumnName',networkbursttablenold.Properties.VariableNames,...
                'RowName',networkbursttablenold.Properties.RowNames);
            text(0.57, 1.06,'Statistics of old detected network bursts')
        end
        
        
        set(gca,'visible','off')
        
        %         c = uicontrol;
        %         c.Position = [1535,888,175,67];
        %         c.FontWeight = 'bold';
        %         c.ForegroundColor = [0.861,0.832,0.096,0.048];
        %         c.CData = imread('color_button.png');
        %         c.String = 'Save Table';
        %         c.Callback = @savetable;
        
        
        %% if the new burst detection results in no brusts detected remove the option for the user to select the statistics button
        
        if isempty(Exburst{Imax}.duration_of_bursts) % if the length are not equal add a nan value
            push4.Enable = 'off';
        else
            push4.Enable = 'on';
        end
        
    end

    function savetable(src,event)
        
        
        list = {'Save Table 1','Save Table 2','Save Table 3'};
        [indx23,~] = listdlg('PromptString','Select which table to save','SelectionMode','single','ListString',list);
        if isempty(indx23)
        else
            if indx23 == 1
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table139,uiputfile(filter),'WriteRowNames',true);
            elseif indx23 == 2
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table679,uiputfile(filter),'WriteRowNames',true);
                
            else
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table680,uiputfile(filter),'WriteRowNames',true);
            end
        end
        
    end

    function Chan(source,~)
        maxinterval = 0;
        push45 = findobj('Tag','pushbutton45');
        if ~isempty(push45.UserData) && cbox1.Value == 1
            edit8.Enable = 'on';
            edit9.Enable ='on';
            edit10.Enable ='on';
            maxinterval = 1;
            cbox2.Value = 0;
            cbox2.Enable ='off';
            
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            push5.Visible ='on';
        elseif ~isempty(push45.UserData) && cbox1.Value == 0
            edit8.Enable = 'off';
            edit9.Enable ='off';
            edit10.Enable ='off';
            maxinterval = 0;
            
            cbox2.Enable ='on';
            
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            push5.Visible ='off';
        elseif source.Value == 1 && cbox1.Value == 1
            maxinterval = 1;
            %             text1.Enable = 'on';
            %             text2.Enable = 'on';
            %             text3.Enable = 'on';
            %             text4.Enable = 'on';
            %             text5.Enable = 'on';
            edit2.Enable = 'on';
            edit1.Enable = 'on';
            edit3.Enable = 'on';
            edit4.Enable = 'on';
            edit5.Enable = 'on';
            cbox2.Enable = 'off';
            cbox2.Value = 0;
            push1.Visible ='on';
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
        elseif source.Value == 0 && cbox1.Value == 0
            maxinterval = 0;
            %             text1.Enable = 'off';
            %             text2.Enable = 'off';
            %             text3.Enable = 'off';
            %             text4.Enable = 'off';
            %             text5.Enable = 'off';
            edit2.Enable = 'off';
            edit1.Enable = 'off';
            edit3.Enable = 'off';
            edit4.Enable = 'off';
            edit5.Enable = 'off';
            cbox2.Enable = 'on';
            push1.Visible ='off';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            
            
        end
    end

    function Chan2(source,~)
        logISI = 0;
        push45 = findobj('Tag','pushbutton45');
        if ~isempty(push45.UserData) && cbox2.Value == 1
            edit8.Enable = 'on';
            edit9.Enable ='on';
            edit10.Enable ='on';
            logISI= 1;
            cbox1.Value = 0;
            cbox1.Enable ='off';
            
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            push5.Visible ='on';
        elseif ~isempty(push45.UserData) && cbox2.Value == 0
            edit8.Enable = 'off';
            edit9.Enable ='off';
            edit10.Enable ='off';
            logISI = 0;
            
            cbox1.Enable ='on';
            
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            push5.Visible ='off';
        elseif source.Value == 1 && cbox2.Value == 1
            logISI = 1;
            %             text6.Enable = 'on';
            %             text7.Enable = 'on';
            edit6.Enable = 'on';
            edit7.Enable = 'on';
            cbox1.Enable = 'off';
            cbox1.Value = 0;
            push1.Visible ='on';
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
        elseif source.Value == 0 && cbox2.Value == 0
            logISI = 0;
            %             text6.Enable = 'off';
            %             text7.Enable = 'off';
            edit6.Enable = 'off';
            edit7.Enable = 'off';
            cbox1.Enable = 'on';
            push1.Visible ='off';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            
            
        end
    end

    function Chan3(source,~)
        overlapp = 0;
        push45 = findobj('Tag','pushbutton45');
        if ~isempty(push45.UserData) && cbox101.Value == 1
            overlapp = 1;
            edit8.Enable = 'on';
            edit9.Enable ='on';
            edit10.Enable ='on';
            
            cbox1.Value = 0;
            cbox1.Enable ='off';
            cbox2.Value = 0;
            cbox2.Enable ='off';
            
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            push5.Visible ='on';
        elseif ~isempty(push45.UserData) && cbox101.Value == 0
            edit8.Enable = 'off';
            edit9.Enable ='off';
            edit10.Enable ='off';
            logISI = 0;
            maxinterval = 0;
            cbox1.Enable ='on';
            cbox2.Enable ='on';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            push5.Visible ='off';
        elseif source.Value == 1 && cbox101.Value == 1
            overlapp = 1;
            %             text6.Enable = 'on';
            %             text7.Enable = 'on';
            edit6.Enable = 'on';
            edit7.Enable = 'on';
            cbox1.Enable = 'off';
            cbox1.Value = 0;
            cbox2.Enable = 'off';
            cbox2.Value = 0;
            push1.Visible ='on';
            push2.Visible ='on';
            push3.Visible ='on';
            push4.Visible ='on';
            
        elseif source.Value == 0 && cbox101.Value == 0
            logISI = 0;
            maxinterval = 0;
            %             text6.Enable = 'off';
            %             text7.Enable = 'off';
            edit6.Enable = 'off';
            edit7.Enable = 'off';
            cbox1.Enable = 'on';
            cbox2.Enable = 'on';
            push1.Visible ='off';
            push2.Visible ='off';
            push3.Visible ='off';
            push4.Visible ='off';
            
        end
    end

    function editChan(~,~)
        
        if (str2double(edit1.String) > 0 && str2double(edit1.String) < 1)
            if str2double(edit1.String) ~= 0.17   % if its not the default value change the value in the fs struct
                fs.burstdetectionmaxinterval.start = str2double(edit1.String);
            else
                
            end
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 0.5 seconds','Burst Start Interval Error')
        end
        
        if (str2double(edit2.String) > 0 && str2double(edit2.String) < 1000)
            if str2double(edit2.String) ~= 10   % if its not the default value change the value in the fs struct
                fs.burstdetectionmaxinterval.nspikes = str2double(edit2.String);
            else
                
            end
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1000 spikes','Spike Number Error')
        end
        
        
        
        if (str2double(edit3.String) > 0 && str2double(edit3.String) < 1)
            if str2double(edit3.String) ~= 0.3   % if its not the default value change the value in the fs struct
                fs.burstdetectionmaxinterval.IBI = str2double(edit3.String);
            else
            end
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1 second','Inter Burst Interval Error')
        end
        
        
        if (str2double(edit4.String) > 0 && str2double(edit4.String) < 1)
            if str2double(edit4.String) ~= 0.2   % if its not the default value change the value in the fs struct
                fs.burstdetectionmaxinterval.intraBI = str2double(edit4.String);
            else
            end
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1 second','Intra Burst Interval Error')
        end
        
        
        if (str2double(edit5.String) > 0 && str2double(edit5.String) < 100)
            if str2double(edit5.String) ~= 0.01   % if its not the default value change the value in the fs struct
                fs.burstdetectionmaxinterval.mindur = str2double(edit5.String);
            else
            end
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 100 seconds','Minimum Burst Duration Error')
        end
        
        
        if (str2double(edit6.String) > 0 && str2double(edit6.String) < 1000)
            if str2double(edit6.String) ~= 10   % if its not the default value change the value in the fs struct
                fs.burstdetectionlogisi.nspikes = str2double(edit6.String);
            else
                
            end
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1000 spikes','Amount of Spikes Error')
        end
        
        
        
        if (str2double(edit7.String) > 0 && str2double(edit7.String) < 1)
            if str2double(edit7.String) ~= 0.7   % if its not the default value change the value in the fs struct
                fs.burstdetectionlogisi.void = str2double(edit7.String);
            else
            end
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1','Void Parameter Error')
        end
        
        if (str2double(edit8.String) > 0 && str2double(edit8.String) < 1)
            fs.networkburstdetection.synchronizedtimewindow = str2double(edit8.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1 seconds','Network Burst synchronized time window Error')
        end
        
        if (str2double(edit9.String) > 0 && str2double(edit9.String) < 10)
            fs.networkburstdetection.minimumsynchronizedburstcount = str2double(edit9.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 10','Network Burst minimum synchronzied bursts amount Error')
        end
        
        if (str2double(edit10.String) > 0 && str2double(edit10.String) < 1)
            fs.networkburstdetection.minimumchannelparticipation = str2double(edit10.String);
        else % we give an errormessage
            errordlg('Please provide a number between 0 and 1 ','Network Burst minimum channel participation Error')
        end
        
        
        
    end
end


% ---
function uipanel11_CreateFcn(hObject, eventdata, handles)
global ax axes1 dx

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
ax=axes(hObject);
axes1=gca;
dx = 1;
hObject.UserData = 1992;
% hObject.Position=[.009 .785 .806 .119];
hObject.Position=[.009 .302 .806 .603];
% panel1 = hObject;
% panel2 = uipanel('Parent',panel1);
% set(panel1,'Position',[0 0.05 1 1]);
% set(panel2,'Position',[-1 0 1 2]);
end


% --- Select the channel to display the detected bursts for that channel
function pushbutton42_Callback(hObject, eventdata, handles)
global HITS Imax h h1 h2 fs h3 overlap overlapburst burst6 burst7 Totoro ax dx tb M2 filteredData1 X2 timesss axes1 Xlim11 Ylim11 cbx109 cbx119 cbx129 cbx139 cbx98 cbx99 cbx159 cbx169 joost

prompt = {'Enter Channel to compare the different burst detection methods in'};
title = 'Comparison of burst detection methods';
dims = [1 75];
definput = {'A8'};
Totoro = inputdlg(prompt,title,dims,definput);
if isempty(Totoro)
    return
end
Imax=find(strcmp(HITS,Totoro{1}));

%clean the axes before plotting new one otherwise they will overlap
if isstruct(h)  % if it's a struct is means that the program has just started and there is nothing to delete
else
    delete(h)
end

if isstruct(h1)
else
    delete(h1)
end

if isstruct(h2)
else
    delete(h2)
end


if isstruct(h3)
else
    delete(h3)
end
%% display the channel in uipanel11
if length(filteredData1) < fs.filtersettings.sampling_frequency
    
    peanel11 = findobj('Tag','uipanel11');
    % calculate the rasterplot
    yy = subplot('position',[0.2 0.15 0.7 0.8],'Parent',peanel11);
    cla(yy)
    nTotalSpikes = sum(cellfun(@length,M2));
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        % Save points and update current index
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    % find the spikes assocaited with the selected channel and plot
    plot(yy,xPoints, yPoints, 'k')
    ylim([Imax-0.5 Imax])
    
    set(yy,'XLim',[0 timesss]);
    set(yy,'YTick',[]);
    ylabel('-')
    xlabel('Time(s)')
    yy.Title.String = (['Channel ',mat2str(Imax)]);
    %     title(['Well ',mat2str(ceil(Imax/12))])
    [tb,~] = axtoolbar(yy,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    legend('Spikes')
    cbx109.Enable = 'off';
    cbx119.Enable = 'off';
else
    x=X2;
    y=filteredData1(Imax,:);
    
    if size(handles.uipanel11.Children,1) == 1
        delete(handles.uipanel11.Children(1));
    end
    
    if size(handles.uipanel11.Children,1) == 2
        delete(handles.uipanel11.Children(2));
        delete(handles.uipanel11.Children(1));
    end
    
    ax = axes(handles.uipanel11);
    cla(ax)
    plot(ax,x,y);
    axes1=gca;
    axes1.XLim =[0 timesss];
    Xlim11=axes1.XLim;
    Ylim11=axes1.YLim;
    
    
    ylabel(ax,'Microvolts');
    xlabel(ax,'Time(s)');
    % xlabel('Time in seconds');
    % title(['Channel ', HITS{Imax}]);
    set(axes1,'Fontsize',10);
    
    % Set appropriate axis limits and settings
    set(gcf,'doublebuffer','on');
    [tb,~] = axtoolbar(ax,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    % This avoids flickering when updating the axis
    set(axes1,'xlim',[0 dx]); % window
    % find the values that is the largest for the axis and set the limit to the
    % highest
    
    if abs(min(y)) > max(y)
        set(axes1,'ylim',[min(y) abs(min(y))]);
    else
        set(axes1,'ylim',[-max(y) max(y)]);
    end
    
    % Generate constants for use in uicontrol initialization
    % pos=get(axes1,'position');
    % Newpos=[pos(1) pos(2)-0.1 pos(3) 0.05];
    % Newpos=[0.009 0.75 0.806 0.03];
    Newpos=[.009 .272 .806 .03];
    
    % This will create a slider which is just underneath the axis
    %  but still leaves room for the axis labels above the slider
    xmax=max(x);
    % S=['set(axes1,''xlim'',get(gcbo,''value'')+[0 ' num2str(dx) '])'];
    
    h=uicontrol('style','slider',...
        'units','normalized','position',Newpos,...
        'callback',@callbackfn,'min',0,'max',xmax-dx);
    h.Visible = 'off';
    axes1.XLim = Xlim11;
    axes1.YLim = Ylim11;
    cbx109.Enable = 'on';
    cbx119.Enable = 'on';
end
    function callbackfn(~,~)
        set(axes1,'xlim',get(gcbo,'value')+[0 dx]);
    end



%% display the buttons in uipanel12


cbx129.Enable = 'on';
cbx139.Enable = 'on';
cbx98.Enable = 'off';
cbx99.Enable = 'off';
cbx159.Enable = 'off';
cbx169.Enable = 'on';

cbx109.Visible = 'on';
cbx119.Visible = 'on';
cbx129.Visible = 'on';
cbx139.Visible = 'on';
cbx98.Visible = 'on';
cbx99.Visible = 'on';
cbx159.Visible = 'on';
cbx169.Visible = 'on';


% uipanel13_ButtonDownFcn(handles.uipanel13, eventdata, handles)
% uipanel14_ButtonDownFcn(handles.uipanel14, eventdata, handles)
% text83_ButtonDownFcn(handles.text83,eventdata,handles)
% handles.text83.Visible = 'on';
set(handles.Pannel_25.Text,'String',strjoin(['Channel', Totoro]));
% set(handles.Pannel_26.Text,'String',strjoin(['Bursts detected in channel', Totoro, 'with the Max interval Method']));
% set(handles.Pannel_27.Text,'String',strjoin(['Bursts detected in channel', Totoro, 'with the log ISI Method']));
% set(handles.Pannel_29.Text,'String',strjoin(['Bursts detected in channel', Totoro, 'with the BD Method']));
set(handles.pushbutton43,'Visible','on');
set(handles.pushbutton44,'Visible','on');
set(handles.pushbutton45,'Visible','on');
set(handles.pushbutton46,'Visible','off');
set(handles.pushbutton47,'Visible','on');
set(handles.pushbutton48,'Visible','on');
%% overlappping bursts
%The main goal is find overlapping bursts or bursts that are detected by
% both SCB detection methods.

overlap = {};
for iii = 1:length(burst6)
    for j =1:length(burst6{iii})
        if isempty(burst6{iii})
            continue
        else
            for k = 1:length(burst7{iii})
                temp1 = isequal(burst6{iii}(j),burst7{iii}(k));
                if temp1 == 1
                    overlap{iii}(j) = burst6{iii}(j); % if they are exactly the same put in new vector
                elseif temp1 == 0 % even if they not exactly the same we need to check if the values are not similar. if the values are within each other range of 100 ms the SCBs will still be counted as overlapping bursts
                    %
                    %                     check1 = find(burst7{i}{k} >= burst6{i}{j}(1) & burst7{i}{k} <= burst6{i}{j}(end));
                    %                     if ~isempty(check1)
                    %                         overlap{i}(j) = burst6{i}(j);
                    %                     end
                end
            end
        end
    end
end

overlap= overlap';

%remove empty cells
for iii =1:length(overlap)
    if isempty(overlap{iii})
        continue
    else
        overlap{iii}(cellfun('isempty',overlap{iii}))=[];
    end
end
%% stats of overlapping bursts

overlapburst=cell(1,length(overlap))';
for jj=1:length(overlap)
    overlapburst{jj}.number_of_bursts=1:length(overlap{jj,1});
    
    for i=1:length(overlap{jj,1})
        overlapburst{jj}.duration_of_bursts(i)=overlap{jj,1}{1,i}(end)-overlap{jj,1}{1,i}(1,1);
    end
    
    
    for i=1:length(overlap{jj,1})
        overlapburst{jj}.spikes_in_bursts(i)=length(overlap{jj,1}{1,i});
    end
end
%         overlapburst=overlapburst';   %contains data about the bursts for the table

for i=1:length(overlap)
    overlapburst{i,1}.number_of_bursts=overlapburst{i,1}.number_of_bursts'; %flip everything for the table
end

for i=1:length(overlap)
    if sum(strcmp(fieldnames(overlapburst{i,1}), 'spikes_in_bursts')) == 1
        overlapburst{i,1}.spikes_in_bursts=overlapburst{i,1}.spikes_in_bursts'; %flip everything for the table
    else
    end
end

for i=1:length(overlap)
    if sum(strcmp(fieldnames(overlapburst{i,1}), 'duration_of_bursts')) == 1
        overlapburst{i,1}.duration_of_bursts=overlapburst{i,1}.duration_of_bursts'; %flip everything for the table
    else
    end
end

clear mona

%get the firing frequency (Hz) per burst per electrode

fr_of_bursts = zeros(1,length(overlap))';
for i = 1:length(overlap)
    if isempty(overlapburst{i}.number_of_bursts)
        overlapburst{i}.fr_of_bursts = [];
    else
        for j = 1:length(overlapburst{i}.spikes_in_bursts)
            overlapburst{i}.fr_of_bursts(j) = overlapburst{i}.spikes_in_bursts(j)/ overlapburst{i}.duration_of_bursts(j);
            overlapburst{i}.fr_of_bursts = overlapburst{i}.fr_of_bursts';
        end
    end
end


%get the mean ISI of the spikes inside of a burst
%the timings are located in burst6 for max interval


mISIbursts = cell(1,length(overlap));
for i=1:length(overlap)
    if isempty(overlapburst{i}.number_of_bursts)
        mISIbursts{i} = 0;
    else
        mISIbursts{i} = cellfun(@diff,overlap{i},'UniformOutput',0);
    end
    
end


mISIbursts=cell(1,length(overlap))'; %contains the average ISI of the bursts in each electrode
for i=1:length(overlap)
    mISIbursts{i}=zeros(1,length(overlap{i}));
    if isempty(overlapburst{i}.number_of_bursts)
        mISIbursts{i} = 0;
    else
        for j = 1:length(overlap{i})
            mISIbursts{i}(j) = mean(diff(cell2mat(overlap{i}(j))));
            overlapburst{i}.mean_ISI_bursts = mISIbursts{i}';
        end
    end
end

clear mISIbursts

stdISIbursts=cell(1,length(overlap))'; %contains the std of the ISI of  bursts in each electrode
for i=1:length(overlap)
    stdISIbursts{i}=zeros(1,length(overlap{i}));
    if isempty(overlapburst{i}.number_of_bursts)
        stdISIbursts{i} = 0;
    else
        for j = 1:length(overlap{i})
            stdISIbursts{i}(j) = std(diff(cell2mat(overlap{i}(j))));
            overlapburst{i}.std_ISI_bursts = stdISIbursts{i}';
        end
    end
end

clear stdISIbursts

%calculate the IBI

IBI2=[];
for i =1:length(overlap)
    if isempty(overlap{i})
        continue
    else
        for j =1:length(overlap{i})-1
            IBI = overlap{i}{j+1}(1) - overlap{i}{j}(end);
            IBI2=[IBI2,IBI];
        end
    end
    overlapburst{i}.IBI = IBI2';  %this contains all the IBI's per electrode
    IBI2 =[];
end


clear IBI2
end


% ---
function pushbutton42_CreateFcn(hObject, eventdata, handles)

hObject.Visible = 'off';

end

%  Button section
function uipanel12_CreateFcn(hObject, eventdata, handles)
global Imax filteredData1 X2 fs channel963 M2 M88 ypoints timesss xpoints burst7indx burst6indx max1bursts burst6 cbx98  cbx99  cbx169  dx ax burst7 RMS7 cbx109 cbx119 cbx129 cbx139 cbx159

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.009 .009 .806 .224];
x=X2;
if isempty(Imax)
    Imax =1 ;
end
y=filteredData1(Imax,:);
%% the actual buttons
% Create a check box to diplay detected spikes
cbx109 = uicontrol(hObject,'Style','checkbox','Position',[10 207 200 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx109.String = 'Display Detected Spikes';
cbx109.FontSize = 8;
cbx109.BackgroundColor = [1 1 1];

% Create a check box to diplay thresholds
cbx119 = uicontrol(hObject,'Style','checkbox','Position',[10 187 200 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx119.String = 'Display Detected Thresholds';
cbx119.FontSize = 8;
cbx119.BackgroundColor = [1 1 1];

% Create a check box to diplay log ISI detected bursts
cbx129 = uicontrol(hObject,'Style','checkbox','Position',[10 167 300 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx129.String = 'Display Detected log ISI single channel bursts';
cbx129.FontSize = 8;
cbx129.BackgroundColor = [1 1 1];

% Create a check box to diplay max interval detected bursts
cbx139 = uicontrol(hObject,'Style','checkbox','Position',[10 147 300 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx139.String = 'Display Detected Max interval single channel bursts';
cbx139.FontSize = 8;
cbx139.BackgroundColor = [1 1 1];

%% network burst related buttons
% Create a check box to diplay single channel bursts in rasterplot:
cbx98 = uicontrol(hObject,'Style','checkbox','Position',[10 107 250 15],...
    'Callback',@(cbx,event) cBoxChanged1(cbx));
cbx98.String = 'Display Single Channel Bursts';
cbx98.BackgroundColor = [1 1 1];

% title('Rasterplot of all the Multi Unit Activity and Array wide firing rate','Fontsize',30);

% Create a check box to diplay network bursts in rasterplot:
cbx99 = uicontrol(hObject,'Style','checkbox','Position',[10 87 250 15],...
    'Callback',@(cbx,event) cBoxChanged1(cbx));
cbx99.String = 'Display Network Spikes';
cbx99.BackgroundColor = [1 1 1];

cbx159 = uicontrol(hObject,'Style','checkbox','Position',[10 67 250 15],...
    'Callback',@(cbx,event) cBoxChanged1(cbx));
cbx159.String = 'Display Network Burst Detection';
cbx159.BackgroundColor = [1 1 1];


cbx169 = uicontrol(hObject,'Style','checkbox','Position',[10 127 250 15],...
    'Callback',@(cbx,event) Changed1(cbx));
cbx169.String = 'Display Detected Overlapping Bursts';
cbx169.BackgroundColor = [1 1 1];
%%
cbx109.Visible = 'off';
cbx119.Visible = 'off';
cbx129.Visible = 'off';
cbx139.Visible = 'off';
cbx98.Visible = 'off';
cbx99.Visible = 'off';
cbx159.Visible = 'off';
cbx169.Visible = 'off';

slidec = uicontrol(hObject,'Style','edit','Position',[1000 107 50 25],...
    'Callback',@(cbx,event) Temp_call(cbx));
slidec.String = '1';
slidec.FontSize = 8;
slidec.BackgroundColor = [1 1 1];
slidec.Visible ='off';

%% callback functions for the buttons
    function Temp_call(src,~)
        str=get(src,'String');
        if isempty(str2double(str))
            set(src,'string','0');
            warndlg('Input must be numerical');
        else
            dx = str2double(src.String);
        end
    end

% will have to make a if statement for all possible combinations later

    function Changed1(source,~)
        if length(filteredData1) < fs.filtersettings.sampling_frequency && cbx139.Value == 1
            
            peanel11 = findobj('Tag','uipanel11');
            burst6indx =burst6indx';
            nTotalSpikes = sum(cellfun(@length,M2));
            xPoints = NaN(nTotalSpikes*3,1);
            yPoints = xPoints;
            currentInd = 1;
            halfSpikeHeight = 1/2;
            for trials = 1:length(M2)
                nSpikes = length(M2{trials});
                nanSeparator = NaN(1,nSpikes);
                
                trialXPoints = [ M2{trials} + 0;...
                    M2{trials} + 0; nanSeparator ];
                trialXPoints = trialXPoints(:);
                
                trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                    (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
                trialYPoints = trialYPoints(:);
                
                % Save points and update current index
                xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
                yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
                currentInd = currentInd + nSpikes*3;
            end
            % place them in the same configuration as the allbursts cell array
            
            maxbursts= [];
            
            max1bursts= cell(1,length(M2));
            for i = 1:length(burst6indx)
                for j= 1:length(burst6indx{i})
                    maxbursts = [burst6indx{i}{j}(1),burst6indx{i}{j}(end)];
                    max1bursts{i} = [max1bursts{i},maxbursts];
                end
                
            end
            max1bursts=max1bursts';
            
            max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
            % now lets make it easier to index in the xPoints vector by giving each
            % number the correct index so we can just index in the xPoints vector
            
            % the try and catch statements are only temp fix but need to take a
            % look att he code for max interval
            countold = 0;
            for i=1:length(max1bursts)
                try
                    countnew = (length(M2{i})*3+countold);
                    countold = countnew;
                    if isempty(max1bursts{(i+1)})
                    else
                        for j = 1:length(max1bursts{(i+1)})
                            
                            max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                        end
                    end
                catch
                end
            end
            
            subplot('position',[0.2 0.15 0.7 0.8],'Parent',peanel11);
            hold on
            for i = 1:length(M2)
                try
                    for j = 0:2:length(max1bursts{i})-1
                        hold on
                        plot(xPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),yPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),'r')
                    end
                catch
                end
            end
            legend('Spikes','Single Channel bursts')
        elseif length(filteredData1) < fs.filtersettings.sampling_frequency && cbx169.Value == 1
            
            peanel11 = findobj('Tag','uipanel11');
            burst6indx =burst6indx';
            nTotalSpikes = sum(cellfun(@length,M2));
            xPoints = NaN(nTotalSpikes*3,1);
            yPoints = xPoints;
            currentInd = 1;
            halfSpikeHeight = 1/2;
            for trials = 1:length(M2)
                nSpikes = length(M2{trials});
                nanSeparator = NaN(1,nSpikes);
                
                trialXPoints = [ M2{trials} + 0;...
                    M2{trials} + 0; nanSeparator ];
                trialXPoints = trialXPoints(:);
                
                trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                    (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
                trialYPoints = trialYPoints(:);
                
                % Save points and update current index
                xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
                yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
                currentInd = currentInd + nSpikes*3;
            end
            % place them in the same configuration as the allbursts cell array
            
            maxbursts= [];
            
            max1bursts= cell(1,length(M2));
            for i = 1:length(burst6indx)
                for j= 1:length(burst6indx{i})
                    maxbursts = [burst6indx{i}{j}(1),burst6indx{i}{j}(end)];
                    max1bursts{i} = [max1bursts{i},maxbursts];
                end
                
            end
            max1bursts=max1bursts';
            
            max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
            % now lets make it easier to index in the xPoints vector by giving each
            % number the correct index so we can just index in the xPoints vector
            
            % the try and catch statements are only temp fix but need to take a
            % look att he code for max interval
            countold = 0;
            for i=1:length(max1bursts)
                try
                    countnew = (length(M2{i})*3+countold);
                    countold = countnew;
                    if isempty(max1bursts{(i+1)})
                    else
                        for j = 1:length(max1bursts{(i+1)})
                            
                            max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                        end
                    end
                catch
                end
            end
            
            subplot('position',[0.2 0.15 0.7 0.8],'Parent',peanel11);
            hold on
            for i = 1:length(M2)
                try
                    for j = 0:2:length(max1bursts{i})-1
                        hold on
                        plot(xPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),yPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),'r')
                    end
                catch
                end
            end
            legend('Spikes','Single Channel bursts')
        elseif  length(filteredData1) < fs.filtersettings.sampling_frequency && cbx129.Value == 1
            peanel11 = findobj('Tag','uipanel11');
            burst7indx =burst7indx';
            nTotalSpikes = sum(cellfun(@length,M2));
            xPoints = NaN(nTotalSpikes*3,1);
            yPoints = xPoints;
            currentInd = 1;
            halfSpikeHeight = 1/2;
            for trials = 1:length(M2)
                nSpikes = length(M2{trials});
                nanSeparator = NaN(1,nSpikes);
                
                trialXPoints = [ M2{trials} + 0;...
                    M2{trials} + 0; nanSeparator ];
                trialXPoints = trialXPoints(:);
                
                trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                    (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
                trialYPoints = trialYPoints(:);
                
                % Save points and update current index
                xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
                yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
                currentInd = currentInd + nSpikes*3;
            end
            % place them in the same configuration as the allbursts cell array
            
            maxbursts= [];
            
            max1bursts= cell(1,length(M2));
            for i = 1:length(burst7indx)
                for j= 1:length(burst7indx{i})
                    maxbursts = [burst7indx{i}{j}(1),burst7indx{i}{j}(end)];
                    max1bursts{i} = [max1bursts{i},maxbursts];
                end
                
            end
            max1bursts=max1bursts';
            
            max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
            % now lets make it easier to index in the xPoints vector by giving each
            % number the correct index so we can just index in the xPoints vector
            
            % the try and catch statements are only temp fix but need to take a
            % look att he code for max interval
            countold = 0;
            for i=1:length(max1bursts)
                try
                    countnew = (length(M2{i})*3+countold);
                    countold = countnew;
                    if isempty(max1bursts{(i+1)})
                    else
                        for j = 1:length(max1bursts{(i+1)})
                            
                            max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                        end
                    end
                catch
                end
            end
            
            subplot('position',[0.2 0.15 0.7 0.8],'Parent',peanel11);
            hold on
            for i = 1:length(M2)
                try
                    for j = 0:2:length(max1bursts{i})-1
                        hold on
                        plot(xPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),yPoints(max1bursts{i}(j+1):max1bursts{i}(j+2)),'r')
                    end
                catch
                end
            end
            legend('Spikes','Single Channel bursts')
        elseif length(filteredData1) < fs.filtersettings.sampling_frequency
            %
            peanel11 = findobj('Tag','uipanel11');
            % calculate the rasterplot
            yy = subplot('position',[0.2 0.15 0.7 0.8],'Parent',peanel11);
            cla(yy)
            nTotalSpikes = sum(cellfun(@length,M2));
            xPoints = NaN(nTotalSpikes*3,1);
            yPoints = xPoints;
            currentInd = 1;
            halfSpikeHeight = 1/2;
            for trials = 1:length(M2)
                nSpikes = length(M2{trials});
                nanSeparator = NaN(1,nSpikes);
                
                trialXPoints = [ M2{trials} + 0;...
                    M2{trials} + 0; nanSeparator ];
                trialXPoints = trialXPoints(:);
                
                trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                    (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
                trialYPoints = trialYPoints(:);
                
                % Save points and update current index
                xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
                yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
                currentInd = currentInd + nSpikes*3;
            end
            % find the spikes assocaited with the selected channel and plot
            plot(yy,xPoints, yPoints, 'k')
            ylim([Imax-0.5 Imax])
            
            set(yy,'XLim',[0 timesss]);
            set(yy,'YTick',[]);
            ylabel('-')
            xlabel('Time(s)')
            title(['Channel ',mat2str(Imax)])
            %     title(['Well ',mat2str(ceil(Imax/12))])
            [tb,~] = axtoolbar(yy,{'pan','datacursor','zoomin','zoomout','restoreview'});
            tb.Visible = 'on';
            legend('Spikes')
            %color the bursts in red for max interval method
            
            %allbursts contain all the indices of the bursts in a start followeed by
            %the end index of each burst
            % the xPoints vector are the time points of each spike sorted in a specific
            % manner each time point is represented double ending with a nan.
            %this means that one timepoint value of a spike corresponds with 3 spots
            %inteh xPoints vector
            
            
            
            
            
        else
            x=X2;
            y=filteredData1(Imax,:);
            if source.Value == 1 && strcmp(source.String,'Display Detected Spikes')
                hold(ax,'on')
                if isempty(M88{Imax}) || length(M88{Imax}) < 10
                else
                    plot(ax,M2{Imax},M88{Imax},'.','Color',[1 0 0]);
                end
            elseif source.Value == 0 && strcmp(source.String,'Display Detected Spikes')
                cla(ax)
                hold(ax,'on')
                plot(ax,x,y);
            elseif source.Value == 1 && strcmp(source.String,'Display Detected Thresholds')
                hold(ax,'on')
                plot(ax,X2,RMS7(Imax,1)*ones(length(X2),1)','k');
                hold(ax,'on')
                plot(ax,X2,-RMS7(Imax,1)*ones(length(X2),1)','k');
            elseif source.Value == 0 && strcmp(source.String,'Display Detected Thresholds')
                cla(ax)
                hold(ax,'on')
                plot(ax,x,y);
            elseif source.Value == 1 && strcmp(source.String,'Display Detected Spikes') && cbx119.Value == 1 || source.Value == 1 && strcmp(source.String,'Display Detected Thresholds') && cbx109.Value == 1
                hold(ax,'on')
                plot(ax,M2{Imax},M88{Imax},'.','Color',[1 0 0]);
                hold(ax,'on')
                plot(ax,X2,RMS7(Imax,1)*ones(length(X2),1)','k');
                hold(ax,'on')
                plot(ax,X2,-RMS7(Imax,1)*ones(length(X2),1)','k');
            elseif source.Value == 0 && strcmp(source.String,'Display Detected Spikes') && cbx119.Value == 0 || source.Value == 0 && strcmp(source.String,'Display Detected Thresholds') && cbx119.Value == 0
                cla(ax)
                hold(ax,'on')
                plot(ax,x,y);
            elseif cbx109.Value == 1 && cbx119.Value == 0
                cla(ax)
                hold(ax,'on')
                plot(ax,x,y)
                hold(ax,'on')
                plot(ax,M2{Imax},M88{Imax},'.','Color',[1 0 0]);
            elseif cbx109.Value == 0 && cbx119.Value == 1
                cla(ax)
                hold(ax,'on')
                plot(ax,x,y)
                hold(ax,'on')
                plot(ax,X2,RMS7(Imax,1)*ones(length(X2),1)','k');
                hold(ax,'on')
                plot(ax,X2,-RMS7(Imax,1)*ones(length(X2),1)','k');
            elseif cbx129.Value == 1 && cbx139.Value == 0
                cla(ax)
                plot(ax,x,y);
                hold(ax,'on')
                channel963=filteredData1(Imax,:);
                for i=1:length(burst7{Imax,1})
                    plot(ax,X2(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),channel963(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),'Color',[0 1 0]);
                    hold(ax,'on')
                end
            elseif cbx139.Value == 1 && cbx129.Value == 0
                cla(ax)
                plot(ax,x,y);
                hold(ax,'on')
                channel963=filteredData1(Imax,:);
                for i=1:length(burst6{Imax,1})
                    plot(ax,X2(find(X2 == burst6{Imax,1}{1,i}(1,1)): find(X2 == burst6{Imax,1}{1,i}(end))),channel963(find(X2 == burst6{Imax,1}{1,i}(1,1)): find(X2 == burst6{Imax,1}{1,i}(end))),'Color',[0 1 0]);
                    hold(ax,'on')
                end
            elseif cbx139.Value == 0 && cbx129.Value == 0 && cbx169.Value == 0
                cla(ax)
                plot(ax,x,y);
            elseif cbx129.Value == 1 && cbx139.Value == 0
                hold(ax,'on')
                channel963=filteredData1(Imax,:);
                for i=1:length(burst7{Imax,1})
                    plot(ax,X2(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),channel963(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),'Color',[0 1 0]);
                    hold(ax,'on')
                end
                
            elseif cbx129.Value == 1 && cbx139.Value == 1
                cla(ax)
                plot(ax,x,y);
                hold(ax,'on')
                channel963=filteredData1(Imax,:);
                for i=1:length(burst6{Imax,1})
                    plot(ax,X2(find(X2 == burst6{Imax,1}{1,i}(1,1)): find(X2 == burst6{Imax,1}{1,i}(end))),channel963(find(X2 == burst6{Imax,1}{1,i}(1,1)): find(X2 == burst6{Imax,1}{1,i}(end))),'Color',[0 0 0]);
                    hold(ax,'on')
                end
                hold(ax,'on')
                channel963=filteredData1(Imax,:);
                for i=1:length(burst7{Imax,1})
                    plot(ax,X2(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),channel963(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),'Color',[0 1 0]);
                    hold(ax,'on')
                end
            elseif cbx169.Value == 1
                %% intersection to confirm overlapping bursts
                
                %The main goal is find overlapping bursts or bursts that are detected by
                % both SCB detection methods.
                
                overlap = {};
                for i = 1:length(burst6)
                    for j =1:length(burst6{i})
                        if isempty(burst6{i})
                            continue
                        else
                            for k = 1:length(burst7{i})
                                temp1 = isequal(burst6{i}(j),burst7{i}(k));
                                if temp1 == 1
                                    overlap{i}(j) = burst6{i}(j); % if they are exactly the same put in new vector
                                elseif temp1 == 0 % even if they not exactly the same we need to check if the values are not similar. if the values are within each other range of 100 ms the SCBs will still be counted as overlapping bursts
                                    %
                                    %                     check1 = find(burst7{i}{k} >= burst6{i}{j}(1) & burst7{i}{k} <= burst6{i}{j}(end));
                                    %                     if ~isempty(check1)
                                    %                         overlap{i}(j) = burst6{i}(j);
                                    %                     end
                                end
                            end
                        end
                    end
                end
                
                overlap= overlap';
                
                %remove empty cells
                for i =1:length(overlap)
                    if isempty(overlap{i})
                        continue
                    else
                        overlap{i}(cellfun('isempty',overlap{i}))=[];
                    end
                end
                
                cla(ax)
                plot(ax,x,y);
                hold(ax,'on')
                channel963=filteredData1(Imax,:);
                
                for i=1:length(overlap{Imax,1})
                    plot(ax,X2(find(X2 == overlap{Imax,1}{1,i}(1,1)): find(X2 == overlap{Imax,1}{1,i}(end))),channel963(find(X2 == overlap{Imax,1}{1,i}(1,1)): find(X2 == overlap{Imax,1}{1,i}(end))),'Color',[0 0 0]);
                    hold(ax,'on')
                end
                
            elseif cbx169.Value == 0
                cla(ax)
                hold(ax,'on')
                plot(ax,x,y);
            end
        end
    end


end


% panel to display bursts detected with the log isi
function uipanel13_CreateFcn(hObject, eventdata, handles)

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.009 .371 .806 .119];

end


% llll
function uipanel13_ButtonDownFcn(hObject, eventdata, handles)
global Imax timesss filteredData1 X2 channel963 M2 M88 burst7 axes4 Ylim11 Xlim11 h2
%
% if length(hObject.Children) == 1
%     delete(hObject.Children);
%     %     cla(hObject.Children,'reset')
% end















%% this used to be to code to just visualzie the log ISI detected bursts
% ax = axes(hObject);
% x = X2;
% y = filteredData1(Imax,:);
% dx = 10;
%
% plot(x,y,'Color',[0, 0.4470, 0.7410]);
% axes4=gca;
% Xlim11=axes4.XLim;
% Ylim11=axes4.YLim;
% hold on
% plot(M2{Imax},M88{Imax},'.','Color',[1 0 0]);
% %     Ylim11=axes4.YLim;
% %     Xlim11=axes4.XLim;
% %     axis([Xlim11(1) Xlim11(2) Ylim11(1) Ylim11(2)]);
% %     if timesss > 200
% %         axis([0 300 -300 300]);
% %     elseif timesss == 120
% %          xlim([0 120]);
% %           ylim([-50 50]);
% %     else
% %         axis([0 60 -300 300]);
% %     end
% ylabel('Microvolts');
% % xlabel('Time in seconds');
% hold on
% channel963=filteredData1(Imax,:);
% for i=1:length(burst7{Imax,1})
%     plot(X2(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),channel963(find(X2 == burst7{Imax,1}{1,i}(1,1)): find(X2 == burst7{Imax,1}{1,i}(end))),'Color',[0 0 0]);
%     hold on
% end
%
% set(gca,'Fontsize',10);
%
% set(gcf,'doublebuffer','on');
%
% % This avoids flickering when updating the axis
% set(axes4,'xlim',[0 dx]); % window
% % find the values that is the largest for the axis and set the limit to the
% % highest
%
% if abs(min(y)) > max(y)
%     set(axes4,'ylim',[min(y) abs(min(y))]);
% else
%     set(axes4,'ylim',[-max(y) max(y)]);
% end
%
% % Generate constants for use in uicontrol initialization
% pos=get(axes4,'position');
% % Newpos=[pos(1) pos(2)-0.1 pos(3) 0.05];
% Newpos=[0.009 0.337 0.806 0.03];
% % This will create a slider which is just underneath the axis
% %  but still leaves room for the axis labels above the slider
% xmax=max(x);
% % S=['set(axes4,''xlim'',get(gcbo,''value'')+[0 ' num2str(dx) '])'];
%
% %% Setting up callback string to modify XLim of axis (gca)
% %% based on the position of the slider (gcbo)
%
% h2=uicontrol('style','slider',...
%     'units','normalized','position',Newpos,...
%     'callback',@callbackfn,'min',0,'max',xmax-dx);
%
%
%     function callbackfn(source,eventdata)
%
%
%         set(axes4,'xlim',get(gcbo,'value')+[0 dx]);
%     end
%
% h2.Visible = 'off'; % slider visibility
%
%
% %     legend('MUA','Filtered trace','logISI Bursts');
% %     set(legend,...
% %     'Position',[0.846148129705432 0.178533551689525 0.100652110539831 0.0437445307601885]);
% % %     title('Multi-Unit Detection and Burst detection');
% %     set(gca,'Fontsize',10);
%
% axes4.XLim = Xlim11;
% axes4.YLim = Ylim11;



end


%panel to display the BD method
function uipanel14_CreateFcn(hObject, eventdata, handles)
hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position=[.009 .164 .806 .119];
end


% -plotting
function uipanel14_ButtonDownFcn(hObject, eventdata, handles)
% global Imax timesss filteredData1 X2 channel963 burstview2 burstview3 M2 M88 axes3 Ylim11 Xlim11 h3
%
% if length(hObject.Children) == 1
%     delete(hObject.Children);
%     %     cla(hObject.Children,'reset')
% end
%
%
% ax = axes(hObject);
% x = X2;
% y = filteredData1(Imax,:);
% dx = 10;
%
% plot(x,y,'Color',[0, 0.4470, 0.7410]);
% axes3=gca;
% Xlim11=axes3.XLim;
% Ylim11=axes3.YLim;
% %     Ylim11=axes3.YLim;
% %     Xlim11=axes3.XLim;
% %     axis([Xlim11(1) Xlim11(2) Ylim11(1) Ylim11(2)]);
%
% hold on
% plot(M2{Imax},M88{Imax},'.','Color',[1 0 0]);
%
%
% %     if timesss > 200
% %         axis([0 300 -300 300]);
% %     elseif timesss == 120
% %          xlim([0 120]);
% %          ylim([-50 50]);
% %     else
% %         axis([0 60 -300 300]);
% %     end
% ylabel('Microvolts');
% %     xlabel('Time in seconds');
% hold on
% channel963=filteredData1(Imax,:);
% for i=1:length(burstview2{Imax,1})
%     plot(X2(burstview2{Imax,1}(1,i):burstview3{Imax,1}(1,i)),channel963(burstview2{Imax,1}(1,i):burstview3{Imax,1}(1,i)),'Color',[0 0 0]);
%     hold on
% end
%
% set(gca,'Fontsize',10);
%
% set(gcf,'doublebuffer','on');
% set(axes3,'xlim',[0 dx]); % window
%
%
% if abs(min(y)) > max(y)
%     set(axes3,'ylim',[min(y) abs(min(y))]);
% else
%     set(axes3,'ylim',[-max(y) max(y)]);
% end
%
% % Generate constants for use in uicontrol initialization
% pos=get(axes3,'position');
% % Newpos=[pos(1) pos(2)-0.1 pos(3) 0.05];
% Newpos=[0.009 0.13 0.806 0.03];
% % This will create a slider which is just underneath the axis
% %  but still leaves room for the axis labels above the slider
% xmax=max(x);
% % S=['set(axes3,''xlim'',get(gcbo,''value'')+[0 ' num2str(dx) '])'];
%
% %% Setting up callback string to modify XLim of axis (gca)
% %% based on the position of the slider (gcbo)
%
% h3=uicontrol('style','slider',...
%     'units','normalized','position',Newpos,...
%     'callback',@callbackfn,'min',0,'max',xmax-dx);
%
%     function callbackfn(source,eventdata)
%         set(axes3,'xlim',get(gcbo,'value')+[0 dx]);
%     end
%
% %     legend('MUA','Filtered Trace','Bologna Bursts V1');
% %     set(legend,...
% %     'Position',[0.842507645123231 0.386305637789156 0.0874257942212315 0.043668121099472]);
% % %     title('Multi-Unit Detection and Burst detection');
% %     set(gca,'Fontsize',10);
%
% h3.Visible = 'off'; % sldier visibility
%
% axes3.XLim = Xlim11;
% axes3.YLim = Ylim11;


end


% --- Switch view to network bursts
function pushbutton43_Callback(hObject, eventdata, handles)
global cbx98 fs X2 filteredData1 cbx99 xpoints Imax Totoro dx ypoints xPoints yPoints ends2 h cbx169 starts2 tb cbx109 cbx119 cbx129 cbx139 burst6 ypointsburst1 timesss joost M2 burst6indx max1bursts Rasterplot1 rrr ax cbx159

if hObject.Value == 1 && isempty(hObject.UserData)
    %     cla(ax);
    %adapated from plotSPikeRaster by Jeffrey Chiou
    resolution = 0.001; %binsize of 1 ms
    sigma = 0.1 ; %100 ms STD of gaussian
    % Use hist to bin
    EDGES = (min(xpoints)-100*resolution:resolution:max(xpoints)+100*resolution);
    N = histc(xpoints, EDGES);
    %Time ranges form -3*st. dev. to 3*st. dev.
    edges = (-3*sigma:resolution:3*sigma);
    %Evaluate the Gaussian kernel
    kernel = normpdf(edges,0,sigma);
    %Multiply by bin width
    kernel = kernel.*resolution;
    %Convolve spike data with the kernel
    s = conv(N,kernel);
    s =s/resolution; % to get the firing rate
    %Find the index of the kernel center
    center = ceil(length(edges)/2);
    %Trim out the relevant portion of the spike density
    s = s(center:end-center-1);
    %     t = (0:length(s)-1)*resolution - abs(min(xpoints))-100*resolution;
    t = (1:length(s))*resolution ;
    gg = subplot('position',[0.2 0.15 0.7 0.15],'Parent',handles.uipanel11);
    
    %     gg = subplot(ax,'position',[0.2 0.15 0.7 0.15]);
    %     hold(ax,'on');
    plot(gg,t,s,'k');
    xlim(gg,[0 timesss])
    ylim(gg,[0 max(s)])
    ylabel('AWFR (Hz)');
    xlabel('Time in seconds','Fontsize',30);
    % set(gca,'XTick',[]);    % no x numbers
    correctxlim = get(gca,'XLim');
    [tb,~] = axtoolbar(gg,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    
    
    % calculate the rasterplot
    
    %     hold(ax,'on');
    yy = subplot('position',[0.2 0.35 0.7 0.6],'Parent',handles.uipanel11);
    nTotalSpikes = sum(cellfun(@length,M2));
    
    
    xPoints = NaN(nTotalSpikes*3,1);
    yPoints = xPoints;
    currentInd = 1;
    
    
    halfSpikeHeight = 1/2;
    for trials = 1:length(M2)
        nSpikes = length(M2{trials});
        nanSeparator = NaN(1,nSpikes);
        
        trialXPoints = [ M2{trials} + 0;...
            M2{trials} + 0; nanSeparator ];
        trialXPoints = trialXPoints(:);
        
        trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
            (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
        trialYPoints = trialYPoints(:);
        
        % Save points and update current index
        xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
        yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
        currentInd = currentInd + nSpikes*3;
    end
    
    plot(yy,xPoints, yPoints, 'k')
    set(gca,'XLim',correctxlim);
    set(gca,'XTick',[]);
    [tb,~] = axtoolbar(yy,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    
    %color the bursts in red for max interval method
    
    %allbursts contain all the indices of the bursts in a start followeed by
    %the end index of each burst
    % the xPoints vector are the time points of each spike sorted in a specific
    % manner each time point is represented double ending with a nan.
    %this means that one timepoint value of a spike corresponds with 3 spots
    %inteh xPoints vector
    burst6indx =burst6indx';
    
    % place them in the same configuration as the allbursts cell array
    
    maxbursts= [];
    
    max1bursts= cell(1,length(M2));
    for i = 1:length(M2)
        for j= 1:length(burst6indx{i})
            maxbursts = [burst6indx{i}{j}(1),burst6indx{i}{j}(end)];
            max1bursts{i} = [max1bursts{i},maxbursts];
        end
        
    end
    max1bursts=max1bursts';
    
    max1bursts =cellfun(@(x) x*3, max1bursts,'un',0); % now the contains the correct index of the bursts per channel
    % now lets make it easier to index in the xPoints vector by giving each
    % number the correct index so we can just index in the xPoints vector
    
    % the try and catch statements are only temp fix but need to take a
    % look att he code for max interval
    countold = 0;
    for i=1:length(max1bursts)
        try
            countnew = (length(M2{i})*3+countold);
            countold = countnew;
            if isempty(max1bursts{(i+1)})
            else
                for j = 1:length(max1bursts{(i+1)})
                    
                    max1bursts{(i+1)}(j) = max1bursts{(i+1)}(j) + countold; %should contain the correct indices of the bursts
                end
            end
        catch
        end
    end
    
    linkaxes([gg yy],'x');
    
    
    
    %     if timesss > 100
    %         xlim(yy,[0 300]);
    %     else
    %         xlim(yy,[0 60]);
    %     end
    
    if length(starts2) == 60
        ylim(yy,[ 0 60]);
    elseif length(starts2) == 120
        ylim(yy,[0 120]);
    end
    ylabel('Channels','Fontsize',30);
    hObject.UserData = 1;
    
    h.Visible = 'off';
    cbx109.Enable = 'off';
    cbx119.Enable = 'off';
    cbx129.Enable = 'off';
    cbx139.Enable = 'off';
    cbx98.Enable = 'on';
    cbx99.Enable = 'off';
    cbx159.Enable = 'on';
    cbx169.Enable = 'off';
    hObject.String = 'Return View';
    handles.pushbutton45.Enable = 'off';
    handles.pushbutton44.Enable = 'off';
    handles.pushbutton42.Enable = 'off';
elseif hObject.Value == 1 && hObject.UserData == 1
    x=X2;
    y=filteredData1(Imax,:);
    
    delete(handles.uipanel11.Children(2));
    delete(handles.uipanel11.Children(1));
    ax = axes(handles.uipanel11);
    if length(filteredData1) < fs.filtersettings.sampling_frequency
        
        peanel11 = findobj('Tag','uipanel11');
        % calculate the rasterplot
        yy = subplot('position',[0.2 0.15 0.7 0.8],'Parent',peanel11);
        cla(yy)
        nTotalSpikes = sum(cellfun(@length,M2));
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;
        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            % Save points and update current index
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        % find the spikes assocaited with the selected channel and plot
        plot(yy,xPoints, yPoints, 'k')
        ylim([Imax-0.5 Imax])
        
        set(yy,'XLim',[0 timesss]);
        set(yy,'YTick',[]);
        ylabel('-')
        xlabel('Time(s)')
        yy.Title.String = (['Channel ',mat2str(Imax)]);
        %     title(['Well ',mat2str(ceil(Imax/12))])
        [tb,~] = axtoolbar(yy,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        legend('Spikes')
        cbx109.Enable = 'off';
        cbx119.Enable = 'off';
    else
        plot(ax,x,y);
        axes1 = gca;
        Xlim11=axes1.XLim;
        Ylim11=axes1.YLim;
        
        
        ylabel(ax,'Microvolts');
        xlabel(ax,'Time(s)');
        % xlabel('Time in seconds');
        % title(['Channel ', HITS{Imax}]);
        set(axes1,'Fontsize',10);
        
        % Set appropriate axis limits and settings
        set(gcf,'doublebuffer','on');
        [tb,~] = axtoolbar(ax,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        % This avoids flickering when updating the axis
        set(axes1,'xlim',[0 dx]); % window
        % find the values that is the largest for the axis and set the limit to the
        % highest
        
        if abs(min(y)) > max(y)
            set(axes1,'ylim',[min(y) abs(min(y))]);
        else
            set(axes1,'ylim',[-max(y) max(y)]);
        end
        axes1.XLim = Xlim11;
        axes1.YLim = Ylim11;
        cbx109.Enable = 'on';
        cbx119.Enable = 'on';
    end
    %% display the buttons in uipanel12
    
    
    cbx129.Enable = 'on';
    cbx139.Enable = 'on';
    cbx98.Enable =  'off';
    cbx99.Enable =  'off';
    cbx159.Enable = 'off';
    cbx169.Enable = 'on';
    
    cbx109.Visible = 'on';
    cbx119.Visible = 'on';
    cbx129.Visible = 'on';
    cbx139.Visible = 'on';
    cbx98.Visible =  'on';
    cbx99.Visible =  'on';
    cbx159.Visible = 'on';
    cbx169.Visible = 'on';
    handles.pushbutton45.Enable = 'on';
    handles.pushbutton44.Enable = 'on';
    handles.pushbutton42.Enable = 'on';
    set(handles.Pannel_25.Text,'String',strjoin(['Channel', Totoro]));
    hObject.UserData = [];
    hObject.String = 'Switch View';
    %     uipanel11_CreateFcn(handles.uipanel11, eventdata, handles)
end

end

% ---switch button
function pushbutton43_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.755 0.096 0.048];
hObject.Visible = 'off';
hObject.String = 'Switch View';


end


% --- Rerun burst detection
function pushbutton44_Callback(hObject, eventdata, handles)
global pushed ax pushed1 push1 push2 push3 push4 edit8 edit9 edit10 text8 text9 text10 push5 edit1 edit2 fs edit3 edit4 M2 edit5 burst6indx burst7indx burst6indxold burst7indxold edit6 edit7 timesss filteredData1 X2 cbox1 cbox2 maxinterval dx logISI Imax Exburst Exburstold logburstold logburst burst6 burst6old burst7old burst7 cbx109 cbx119 cbx129 cbx139 cbx98 cbx99 cbx159 cbx169
% first we need to present a new screen that allows the user to choose what
% to rerun and what  kind of parameters the user can change
pushed = 1;
pushed1 = 1;
logISI = 0;
maxinterval =0;
burst6old=burst6;
burst7old=burst7;
logburstold=logburst;
Exburstold=Exburst;
burst6indxold=burst6indx;
burst7indxold=burst7indx;
push1.Visible ='off';
push2.Visible ='off';
push3.Visible ='off';
push4.Visible ='off';
push5.Visible ='off';
edit8.Visible ='off';
edit9.Visible ='off';
edit10.Visible ='off';
text8.Visible ='off';
text9.Visible ='off';
text10.Visible = 'off';
% run('parameters1')
if hObject.Value == 1 && isempty(hObject.UserData)
    hObject.String = 'Finish Burst Detection';
    %     gg = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    %     yy = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    gg = subplot('position',[0.2 0.15 0.7 0.15],'Parent',handles.uipanel11); hold on;
    yy = subplot('position',[0.2 0.35 0.7 0.6],'Parent',handles.uipanel11); hold on;
    set(cbx98,'Visible','off');
    cbx99.Visible = 'off';
    cbx109.Visible = 'off';
    cbx119.Visible = 'off';
    cbx129.Visible = 'off';
    cbx139.Visible = 'off';
    cbx159.Visible = 'off';
    cbx169.Visible = 'off';
    handles.uipanel12.Visible = 'off';
    handles.uipanel20.Visible = 'on';
    hObject.UserData = 2;
    handles.pushbutton45.Enable = 'off';
    handles.pushbutton43.Enable = 'off';
    handles.pushbutton42.Enable = 'off';
    handles.pushbutton47.Enable = 'off';
    handles.pushbutton48.Enable = 'off';
elseif hObject.Value == 1 && hObject.UserData == 2
    hObject.String = 'Rerun Burst Detection';
    %     uipanel11_ButtonDownFcn(handles.uipanel11, eventdata, handles)
    x=X2;
    y=filteredData1(Imax,:);
    
    delete(handles.uipanel11.Children(2));
    delete(handles.uipanel11.Children(1));
    ax = axes(handles.uipanel11);
    if length(filteredData1) < fs.filtersettings.sampling_frequency
        
        peanel11 = findobj('Tag','uipanel11');
        % calculate the rasterplot
        yy = subplot('position',[0.2 0.15 0.7 0.8],'Parent',peanel11);
        cla(yy)
        nTotalSpikes = sum(cellfun(@length,M2));
        xPoints = NaN(nTotalSpikes*3,1);
        yPoints = xPoints;
        currentInd = 1;
        halfSpikeHeight = 1/2;
        for trials = 1:length(M2)
            nSpikes = length(M2{trials});
            nanSeparator = NaN(1,nSpikes);
            
            trialXPoints = [ M2{trials} + 0;...
                M2{trials} + 0; nanSeparator ];
            trialXPoints = trialXPoints(:);
            
            trialYPoints = [ (trials-halfSpikeHeight)*ones(1,nSpikes);...
                (trials+halfSpikeHeight)*ones(1,nSpikes); nanSeparator ];
            trialYPoints = trialYPoints(:);
            
            % Save points and update current index
            xPoints(currentInd:currentInd+nSpikes*3-1) = trialXPoints;
            yPoints(currentInd:currentInd+nSpikes*3-1) = trialYPoints;
            currentInd = currentInd + nSpikes*3;
        end
        % find the spikes assocaited with the selected channel and plot
        plot(yy,xPoints, yPoints, 'k')
        ylim([Imax-0.5 Imax])
        
        set(yy,'XLim',[0 timesss]);
        set(yy,'YTick',[]);
        ylabel('-')
        xlabel('Time(s)')
        title(['Channel ',mat2str(Imax)])
        %     title(['Well ',mat2str(ceil(Imax/12))])
        [tb,~] = axtoolbar(yy,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        legend('Spikes')
        cbx109.Enable = 'off';
        cbx119.Enable = 'off';
    else
        plot(ax,x,y);
        axes1 = gca;
        Xlim11=axes1.XLim;
        Ylim11=axes1.YLim;
        
        
        ylabel(ax,'Microvolts');
        xlabel(ax,'Time(s)');
        % xlabel('Time in seconds');
        % title(['Channel ', HITS{Imax}]);
        set(axes1,'Fontsize',10);
        
        % Set appropriate axis limits and settings
        set(gcf,'doublebuffer','on');
        [tb,~] = axtoolbar(ax,{'pan','datacursor','zoomin','zoomout','restoreview'});
        tb.Visible = 'on';
        % This avoids flickering when updating the axis
        set(axes1,'xlim',[0 dx]); % window
        % find the values that is the largest for the axis and set the limit to the
        % highest
        
        if abs(min(y)) > max(y)
            set(axes1,'ylim',[min(y) abs(min(y))]);
        else
            set(axes1,'ylim',[-max(y) max(y)]);
        end
        axes1.XLim = Xlim11;
        axes1.YLim = Ylim11;
        cbx109.Enable = 'on';
        cbx119.Enable = 'on';
    end
    cbx98.Visible = 'on';
    cbx99.Visible = 'on';
    
    cbx129.Visible = 'on';
    cbx139.Visible = 'on';
    cbx159.Visible = 'on';
    cbx169.Visible = 'on';
    
    cbx109.Visible = 'on';
    cbx119.Visible = 'on';
    cbx129.Enable = 'on';
    cbx139.Enable = 'on';
    cbx98.Enable =  'off';
    cbx99.Enable =  'off';
    cbx159.Enable = 'off';
    cbx169.Enable = 'on';
    
    handles.uipanel12.Visible = 'on';
    handles.uipanel20.Visible = 'off';
    hObject.UserData = [] ;
    handles.pushbutton45.Enable = 'on';
    handles.pushbutton43.Enable = 'on';
    handles.pushbutton42.Enable = 'on';
    handles.pushbutton47.Enable = 'on';
    handles.pushbutton48.Enable = 'on';
    % reset buttons to zero when finish burst detection is pressed
    if cbox1.Value == 1
        cbox1.Value = 0;
        cbox2.Enable ='on';
        
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        
        edit6.Enable = 'off';
        edit7.Enable = 'off';
    end
    if cbox2.Value == 1
        cbox2.Value =0 ;
        cbox1.Enable = 'on';
        
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        
        edit6.Enable = 'off';
        edit7.Enable = 'off';
    end
end




end


% --- General Zoom
function pushbutton44_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.678 0.096 0.048];
hObject.Visible = 'off';
hObject.String = 'Rerun Burst Detection';
end


% --- rerun network burst detection
function pushbutton45_Callback(hObject, eventdata, handles)
global pushed ax pushed1 text2 text1 text3 text6 text7 cbox101 edit8 edit9 edit10 text8 text9 text10 networkburstttt networkbursttttold push1 push5 edit6 edit7 text4 text5 edit1 edit2 edit3 edit4 edit5 filteredData1 X2 maxinterval INDEX2 dx logISI Imax cbox1 cbox2 Exburst Exburstold logburstold logburst burst6 burst6old burst7old burst7 cbx109 cbx119 cbx129 cbx139 cbx98 cbx99 cbx159 cbx169
pushed = 1;
pushed1 = 1;
logISI = 0;
maxinterval =0;
burst6old=burst6;
burst7old=burst7;
logburstold=logburst;
Exburstold=Exburst;
networkbursttttold = networkburstttt;
edit8.Visible ='on';
edit9.Visible ='on';
edit10.Visible ='on';
text8.Visible ='on';
text9.Visible ='on';
text10.Visible = 'on';


% run('parameters1')
if hObject.Value == 1 && isempty(hObject.UserData)
    hObject.String = 'Finish Network Burst Detection';
    %     gg = subplot('position',[0.2 0.15 0.7 0.15]); hold on;
    %     yy = subplot('position',[0.2 0.35 0.7 0.6]); hold on;
    gg = subplot('position',[0.2 0.15 0.7 0.15],'Parent',handles.uipanel11); hold on;
    yy = subplot('position',[0.2 0.35 0.7 0.6],'Parent',handles.uipanel11); hold on;
    set(cbx98,'Visible','off');
    push1.Visible = 'off';
    push5.Visible = 'off';
    cbx99.Visible = 'off';
    cbx109.Visible = 'off';
    cbx119.Visible = 'off';
    cbx129.Visible = 'off';
    cbx139.Visible = 'off';
    cbx159.Visible = 'off';
    cbx169.Visible = 'off';
    handles.uipanel12.Visible = 'off';
    handles.uipanel20.Visible = 'on';
    hObject.UserData = 2;
    handles.pushbutton44.Enable = 'off';
    handles.pushbutton43.Enable = 'off';
    handles.pushbutton42.Enable = 'off';
    handles.pushbutton47.Enable = 'off';
    handles.pushbutton48.Enable = 'off';
    edit2.Visible = 'off';
    edit1.Visible = 'off';
    edit3.Visible = 'off';
    edit4.Visible = 'off';
    edit5.Visible = 'off';
    edit6.Visible = 'off';
    edit7.Visible = 'off';
    text1.Visible = 'off';
    text2.Visible = 'off';
    text3.Visible = 'off';
    text4.Visible = 'off';
    text5.Visible = 'off';
    text6.Visible = 'off';
    text7.Visible = 'off';
    cbox101.Visible = 'on';
elseif hObject.Value == 1 && hObject.UserData == 2
    hObject.String = 'Rerun Network Burst Detection';
    push1.Visible ='on';
    push5.Visible ='off';
    %     uipanel11_ButtonDownFcn(handles.uipanel11, eventdata, handles)
    x=X2;
    y=filteredData1(Imax,:);
    
    delete(handles.uipanel11.Children(2));
    delete(handles.uipanel11.Children(1));
    ax = axes(handles.uipanel11);
    
    plot(ax,x,y);
    axes1 = gca;
    Xlim11=axes1.XLim;
    Ylim11=axes1.YLim;
    
    
    ylabel(ax,'Microvolts');
    xlabel(ax,'Time(s)');
    % xlabel('Time in seconds');
    % title(['Channel ', HITS{Imax}]);
    set(axes1,'Fontsize',10);
    
    % Set appropriate axis limits and settings
    set(gcf,'doublebuffer','on');
    [tb,~] = axtoolbar(ax,{'pan','datacursor','zoomin','zoomout','restoreview'});
    tb.Visible = 'on';
    % This avoids flickering when updating the axis
    set(axes1,'xlim',[0 dx]); % window
    % find the values that is the largest for the axis and set the limit to the
    % highest
    
    if abs(min(y)) > max(y)
        set(axes1,'ylim',[min(y) abs(min(y))]);
    else
        set(axes1,'ylim',[-max(y) max(y)]);
    end
    axes1.XLim = Xlim11;
    axes1.YLim = Ylim11;
    
    cbx98.Visible = 'on';
    cbx99.Visible = 'on';
    cbx109.Visible = 'on';
    cbx119.Visible = 'on';
    cbx129.Visible = 'on';
    cbx139.Visible = 'on';
    cbx159.Visible = 'on';
    cbx169.Visible = 'on';
    
    cbx109.Enable = 'on';
    cbx119.Enable = 'on';
    cbx129.Enable = 'on';
    cbx139.Enable = 'on';
    cbx98.Enable =  'off';
    cbx99.Enable =  'off';
    cbx159.Enable = 'off';
    cbx169.Enable = 'on';
    
    handles.uipanel12.Visible = 'on';
    handles.uipanel20.Visible = 'off';
    hObject.UserData = [] ;
    handles.pushbutton44.Enable = 'on';
    handles.pushbutton43.Enable = 'on';
    handles.pushbutton42.Enable = 'on';
    handles.pushbutton47.Enable = 'on';
    handles.pushbutton48.Enable = 'on';
    edit2.Visible = 'on';
    edit1.Visible = 'on';
    edit3.Visible = 'on';
    edit4.Visible = 'on';
    edit5.Visible = 'on';
    edit6.Visible = 'on';
    edit7.Visible = 'on';
    text1.Visible = 'on';
    text2.Visible = 'on';
    text3.Visible = 'on';
    text4.Visible = 'on';
    text5.Visible = 'on';
    text6.Visible = 'on';
    text7.Visible = 'on';
    cbox101.Visible = 'off';
    % reset buttons to zero when finish burst detection is pressed
    if cbox1.Value == 1
        cbox1.Value = 0;
        cbox2.Enable = 'on';
        
        
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        edit6.Enable = 'off';
        edit7.Enable = 'off';
        
        
    end
    if cbox2.Value == 1
        cbox2.Value  = 0 ;
        cbox1.Enable = 'on';
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        edit6.Enable = 'off';
        edit7.Enable = 'off';
        
    end
    
    if cbox101.Value == 1
        cbox1.Value = 0;
        cbox1.Enable = 'off';
        cbox2.Value = 0;
        cbox2.Enable = 'off';
        edit2.Enable = 'off';
        edit1.Enable = 'off';
        edit3.Enable = 'off';
        edit4.Enable = 'off';
        edit5.Enable = 'off';
        edit6.Enable = 'off';
        edit7.Enable = 'off';
    end
end

end


% ---
function pushbutton45_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.601 0.096 0.048];
hObject.Visible = 'off';
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.92 0.89 0.655];
hObject.String = 'Rerun Network Burst Detection';
hObject.FontWeight = 'bold';

end


% --- Data Cursor mode
function pushbutton46_Callback(hObject, eventdata, handles)

if hObject.Value == 1 && isempty(hObject.UserData)
    datacursormode on
    hObject.UserData = 1;
else
    datacursormode off
    hObject.UserData = [];
end

end

% --- Data cursor Mode
function pushbutton46_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.524 0.096 0.048];
hObject.Visible = 'off';
end


% --- Zoom in to specific bursts
function pushbutton47_Callback(hObject, eventdata, handles)
global yutp timesss axes1 axes2 axes3 burst6 burst7 X2 Imax axes4 filteredData1

prompt = {'Enter Burstnumber to zoom in     0 = Zoom Out','Select Burst method         1 = Max interval     2 = log ISI'};
title = 'Zoom in Bursts' ;
dims = [1 75];
definput = {'1','1'};
yutp = inputdlg(prompt,title,dims,definput);


if isempty(yutp)
    return
end

% check if there are any bursts


if str2double(yutp{1}) == 0 && timesss > 100
    handles.uipanel11.Children.XLim = [0 timesss];
    handles.uipanel11.Children.YLim = [min(filteredData1(Imax,:))  max(filteredData1(Imax,:))];
    %     axes2.XLim = [0 300];
    %     axes2.YLim = [-300 300];
    %     axes3.XLim = [0 300];
    %     axes3.YLim = [-300 300];
    %     axes4.XLim = [0 300];
    %     axes4.YLim = [-300 300];
elseif str2double(yutp{1}) == 0 && timesss < 100
    handles.uipanel11.Children.XLim = [0 timesss];
    handles.uipanel11.Children.YLim = [min(filteredData1(Imax,:))  max(filteredData1(Imax,:))];
    %     axes2.XLim = [0 60];
    %     axes2.YLim = [-300 300];
    %     axes3.XLim = [0 60];
    %     axes3.YLim = [-300 300];
    %     axes4.XLim = [0 60];
    %     axes4.YLim = [-300 300];
elseif str2double(yutp{1}) >= 1 && str2double(yutp{2}) == 1
    % check if burst 7 has some bursts else switch to burst6
    if isempty(burst6{Imax})
        errordlg('There are no bursts found!','Error');
    else
        handles.uipanel11.Children.XLim=[(X2(find(X2 == burst6{Imax,1}{1,str2double(yutp{1})}(1,1)))-0.2) (X2(find(X2 == burst6{Imax,1}{1,str2double(yutp{1})}(end)))+0.2)];
    end
    
elseif  str2double(yutp{1}) >= 1 && str2double(yutp{2}) == 2
    if isempty(burst7{Imax})
        errordlg('There are no bursts found!','Error');
    else
        handles.uipanel11.Children.XLim=[(X2(find(X2 == burst7{Imax,1}{1,str2double(yutp{1})}(1,1)))-0.2) (X2(find(X2 == burst7{Imax,1}{1,str2double(yutp{1})}(end)))+0.2)];
    end
end

end


% --- Zoom in to specific bursts
function pushbutton47_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.333 0.096 0.048];
hObject.Visible = 'off';

end


% --- statistics
function pushbutton48_Callback(hObject, eventdata, handles)
global burstsinfor networkburstttt Tablennbursts table4 Imax Exburst logburst overlapburst table1 table2 table5 table3 table681 Table680 Table139 Table679 Exburst1


% first check if there any bursts

if isempty(Exburst{Imax}.fr_of_bursts)
    errordlg('There are no bursts found!','Error');
else
    
    figure('units','normalized','outerposition',[0 0 1 1]);
    fig = gcf;
    set(gcf,'color','white')
    
    % networkbursts
    networkbursttable = networkburstttt;
    networkbursttable.amount = 1:networkbursttable.amount;
    networkbursttable.networkburstnumber = networkbursttable.amount';
    networkbursttable  = rmfield(networkbursttable,'amount');
    networkbursttable  = rmfield(networkbursttable,'nburst_rate');
    networkbursttable  = rmfield(networkbursttable,'CVIBI');
    P = [7 1 2 3 4 5 6 ];
    networkbursttable = orderfields(networkbursttable,P);
    
    if isempty(networkbursttable.networkburstnumber)
        networkbursttable.networkburstnumber =0;
    end
    % change the orientation of the fr_of_bursts
    
    if size(Exburst{Imax}.fr_of_bursts,1) == 1
        Exburst{Imax}.fr_of_bursts = Exburst{Imax}.fr_of_bursts';
    end
    
    if size(logburst{Imax}.fr_of_bursts,1) == 1
        logburst{Imax}.fr_of_bursts = logburst{Imax}.fr_of_bursts';
    end
    
    if size(overlapburst{Imax}.fr_of_bursts,1) == 1
        overlapburst{Imax}.fr_of_bursts = overlapburst{Imax}.fr_of_bursts';
    end
    %remove the IBI field because its not the same lengh for now
    
    Exburst1= rmfield(Exburst{Imax},'IBI');
    overlapburst1= rmfield(overlapburst{Imax},'IBI');
    Tablennbursts = struct2table(networkbursttable);
    Table680=struct2table(logburst{Imax});
    Table679=struct2table(Exburst1);
    table681=struct2table(overlapburst1);
    %     Table139=struct2table(burstsinfor{Imax,1});
    
    %     table1 = uitable('Parent', fig, 'Units', 'normal', 'Position', [0 .05 1/4 .9], 'Data', Table139{:,:},'ColumnName',Table139.Properties.VariableNames,...
    %         'RowName',Table139.Properties.RowNames);
    %     text(-0.08, 1.06,'Statistics of BD Bursts')
    table2 = uitable('Parent', fig, 'Units', 'normal', 'Position', [1/10 .05 1/5 .9], 'Data', Table679{:,:},'ColumnName',Table679.Properties.VariableNames,...
        'RowName',Table679.Properties.RowNames);
    text(0.03, 1.06,'Statistics of Max Interval Bursts')
    table3 = uitable('Parent', fig, 'Units', 'normal', 'Position', [3/10 .05 1/5 .9], 'Data', Table680{:,:},'ColumnName',Table680.Properties.VariableNames,...
        'RowName',Table680.Properties.RowNames);
    text(0.28, 1.06,'Statistics of log ISI Bursts')
    table5 = uitable('Parent', fig, 'Units', 'normal', 'Position', [5/10 .05 1/5 .9], 'Data', table681{:,:},'ColumnName',table681.Properties.VariableNames,...
        'RowName',table681.Properties.RowNames);
    text(0.55, 1.06,'Statistics of Overlapping Bursts')
    table4 = uitable('Parent', fig, 'Units', 'normal', 'Position', [7/10 .05 1/5 .9], 'Data', Tablennbursts{:,:},'ColumnName',Tablennbursts.Properties.VariableNames,...
        'RowName',Tablennbursts.Properties.RowNames);
    text(0.8, 1.06,'Statistics of Network Bursts')
    set(gca,'visible','off')
    %
    %     c = uicontrol;
    %     c.Position = [1535,888,175,67];
    %     c.FontWeight = 'bold';
    %     c.ForegroundColor = [0.861,0.832,0.096,0.048];
    %     c.CData = imread('color_button.png');
    %     c.String = 'Save Table';
    %     c.Callback = @savetable;
end

    function savetable(src,event)
        
        
        list = {'Save Table 1','Save Table 2','Save Table 3'};
        [indx23,~] = listdlg('PromptString','Select which table to save','SelectionMode','single','ListString',list);
        if isempty(indx23)
            return
        else
            if indx23 == 1
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table139,uiputfile(filter),'WriteRowNames',true);
            elseif indx23 == 2
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table679,uiputfile(filter),'WriteRowNames',true);
                
            else
                filter={'*.xlsx'};
                % writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);
                writetable(Table680,uiputfile(filter),'WriteRowNames',true);
            end
        end
        
    end

end


% statistics
function pushbutton48_CreateFcn(hObject, eventdata, handles)
hObject.Position=[0.861 0.256 0.096 0.048];
hObject.Visible = 'off';
hObject.String = 'Statistics';
end


function uipanel11_ButtonDownFcn(hObject, eventdata, handles)
end

function uipanel12_ButtonDownFcn(hObject, eventdata, handles)
end

% function uipanel20_ButtonDownFcn(hObject, eventdata, handles)
% end
%% Spike analysis section


% --- Executes during object creation, after setting all properties.
function uipanel15_CreateFcn(hObject, eventdata, handles)
global handles1 parameters

%The code is from B. C. Souza,
% Brain Institute, Natal, Brazil,
% Adapted to fit inside the toolbox


% maximum number of gaussians to fit in one dimension.
parameters.maxGauss         = 8;

% maximum number of iterations of (exp maximization) EM algorithm
parameters.optgmfit.max_iter    = 10000;
parameters.optgmfit.conv_factor = 1e-6;

% number of models to calculate to check robustness
parameters.nof_replicates	= 10;

% maximum number of gaussians to overfit in multidim space. 12 for
% single-wire. 20 for tetrodes.
parameters.ngaussovfit      = 12;




hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position = [0.01 0.037 0.398 0.358];
handles1.Figures.Waveforms.main = handles;
handles1=[];
handles1.chid = 0;
handles1.data.waveforms = {};

handles1.Figures.Waveforms.main = hObject;

handles1.Figures.Waveforms.LoadData = ...
    uicontrol ('Style', 'pushbutton', 'String', 'Load','Units','normalized',...
    'Position', ...
    [0.861 0.832 0.096 0.048],...
    'Callback', @GMM_loaddata,...
    'BackgroundColor', [0.343 0.465 0.575],'ForegroundColor', [0.992 0.89 0.655],'Visible','off','FontWeight','bold');
set(handles1.Figures.Waveforms.LoadData,'FontName','Arial')
set(handles1.Figures.Waveforms.LoadData,'fontsize',14,'CData',imread('color_button.png'))


handles1.Figures.Waveforms.SaveData = ...
    uicontrol ('Style', 'pushbutton', 'String', 'Save','Units','normalized',...
    'Position', ...
    [0.861 0.755 0.096 0.048],...
    'Callback', @GMM_savedata,...
    'BackgroundColor', [0.343 0.465 0.575],'ForegroundColor', [0.992 0.89 0.655],...
    'FontName','Arial',...
    'fontsize',14,'Visible','off','FontWeight','bold','CData',imread('color_button.png'));


%  maintextbox = [0.138 .494 .204 .030];
maintextbox = [0.118 .494 .204 .040];
handles1.Figures.Waveforms.maintext = ...
    uicontrol('Style','text','Units','normalized',...
    'Position',...
    maintextbox,...
    'String','Please load some data... ',...
    'BackgroundColor', [0.97 0.98 0.98],...
    'ForegroundColor', [1 1 1]*0,...
    'horizontalAlignment', 'left',...
    'fontsize',15,'Visible','off');

positionaux = [0.8 .93 .19 .04];
handles1.Figures.Waveforms.filename = ...
    uicontrol('Style','text','Units','normalized',...
    'Position',...
    positionaux,...
    'String',' No file loaded. ',...
    'BackgroundColor', [1 1 1]*.99,...
    'ForegroundColor', [1 1 1]*0,...
    'horizontalAlignment', 'right',...
    'fontsize',15,'Visible','off');

handles1.Figures.Waveforms.ch_id_txtbox  = uicontrol('Style', 'text',...
    'Units','normalized',...
    'String','Ch id: ',...
    'Position', [.017 .494 .085 .039],...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'horizontalAlignment', 'left',...
    'fontsize',14, 'Visible' ,'off');

handles1.Figures.Waveforms.ch_id= ...
    uicontrol('Style', 'popup',...
    'Units','normalized',...
    'String', '-',...
    'Position', [.017 .494 .035 .039],...
    'BackgroundColor', [1 1 1]*1,...
    'ForegroundColor', [1 1 1]*0,...
    'Callback',@GMM_setCHid,...
    'horizontalAlignment', 'center',...
    'fontsize',14,'Visible', 'off');

handles1.Figures.Waveforms.runSorting = uicontrol ('Style', 'pushbutton', ...
    'String', 'Run Sorting',...
    'Units','normalized',...
    'Position', ...
    [0.861 0.678 0.096 0.048],...
    'Callback', @GMM_runSorting,...
    'BackgroundColor', [0.343 0.465 0.575],'ForegroundColor', [0.992 0.89 0.655],...
    'fontsize',14, 'Visible' ,'off','FontWeight','bold','CData',imread('color_button.png'));




handles1.Figures.Waveforms.resetSorting = uicontrol ('Style', 'pushbutton', ...
    'String', 'Reset',...
    'Units','normalized',...
    'Position', ...
    [0.861 .256 .096 .048],...
    'Callback', @GMM_resetSorting,...
    'BackgroundColor', [0.343 0.465 0.575],'ForegroundColor', [0.992 0.89 0.655],...
    'fontsize',14,'Visible','off','FontWeight','bold','CData',imread('color_button.png'));



positionaux = [0.0825 0.8875 0.08 0.04];
positionaux(1) = sum(positionaux([1,3]))+0.01;
handles1.Figures.Waveforms.DispClustersTOGGLE = ...
    uicontrol('Style', 'togglebutton',...
    'Units','normalized',...
    'Position', [0.861 0.333 0.096 0.048],...
    'String','Clusters',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_ClusterDisplayONOFF,...
    'fontsize',14, 'Visible' ,'off',...
    'horizontalAlignment', 'center','FontWeight','bold');


positionaux(1) = sum(positionaux([1,3]))+0.02;
handles1.Figures.Waveforms.RunSortingAllchs = ...
    uicontrol('Style', 'pushbutton',...
    'Units','normalized',...
    'Position', [0.861 0.601 0.096 0.048],...
    'String','Run ALL Chs',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_SSallCHs,...
    'fontsize',14, 'Visible' ,'off',...
    'horizontalAlignment', 'center','FontWeight','bold','CData',imread('color_button.png'));



positionaux(1) = sum(positionaux([1,3]))+0.01;
% positionaux = [0.245 0.8875 0.07 0.04];
handles1.Figures.Waveforms.EditUnsorted = ...
    uicontrol('Style', 'pushbutton',...
    'Units','normalized',...
    'Position', [0.861 0.179 0.096 0.048],...
    'String','Edit Unsorted',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_EditUnsorted,...
    'fontsize',14,...
    'horizontalAlignment', 'center','Visible','off','FontWeight','bold','CData',imread('color_button.png'));


positionaux(1) = sum(positionaux([1,3]))+0.01;
% positionaux = [0.245 0.8875 0.07 0.04];
handles1.Figures.Waveforms.DiscardUnsorted = ...
    uicontrol('Style', 'pushbutton',...
    'Units','normalized',...
    'Position', [0.861 0.029 0.096 0.048],...
    'String','Discard Unsorted',...
    'BackgroundColor', [0.343 0.465 0.575],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_DiscardUnsorted,...
    'fontsize',14,...
    'horizontalAlignment', 'center','Visible','off','FontWeight','bold','CData',imread('color_button.png'));

positionaux(1) = sum(positionaux([1,3]))+0.01;
% positionaux = [0.105+class_i*0.25 .875 .02 .026];
% positionaux=positionaux-positionmod;
handles1.Config.Plot = 1;
handles1.Figures.Waveforms.PlotAllTOGGLE = ...
    uicontrol('Style', 'togglebutton',...
    'String','Plot all waveforms',...
    'Value',handles1.Config.Plot,...
    'Units','normalized',...
    'Position', [0.861 0.102 0.096 0.048],...
    'BackgroundColor', [1 1 1],...
    'ForegroundColor', [0.992 0.89 0.655],...
    'Callback',@GMM_ChangePlotAll,...
    'horizontalAlignment', 'center','Visible','off','FontWeight','bold','CData',imread('color_button.png'));



positionaux1 = [0.01 0.54 0.396 0.365];
handles1.Figures.Waveforms.UnsortedPanel = ...
    uipanel('Title','Unsorted Waveforms','FontSize',13,...
    'BackgroundColor',[0.98 0.97 0.97],...
    'bordertype','etchedout',...
    'ShadowColor',[1 1 1]*.8,...
    'highlightcolor',[1 1 1]*.5,...
    'Position',positionaux1,'Visible' ,'off');


% positionaux = [0.025 .5 .18 .325];
positionaux = [0.08 .08 .9 .9];
handles1.Figures.Waveforms.unsortedspikes = ...
    axes('Parent',handles1.Figures.Waveforms.UnsortedPanel,'Position',positionaux);
subplot('Position',positionaux);



for class_i = 1:6
    
    
    if class_i<4
        positionmod=[0.03 0.03 0 0];
        
        %         positionaux = [0.05+class_i*0.25 .5 .22 .375];
        positionaux = [0.08+(class_i-1)*0.35 .6 .22 .375];
        positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.cluster{class_i} = ...
            axes('Parent',hObject,'Position',positionaux,'Visible','off');
        
        %         positionaux = [0.055+class_i*0.15 .4 .025 .026];
        %         positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.clusterNUMB{class_i} = ...
            uicontrol('Style', 'edit',...
            'Units','normalized',...
            'String', '',...
            'Position', [0.015+(class_i-1)*0.135 .36 .025 .026],...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeClusterNumber,...
            'horizontalAlignment', 'center','Visible','off');
        set(handles1.Figures.Waveforms.clusterNUMB{class_i},'String',...
            num2str(class_i))
        
        %         positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.clusterPOPUP{class_i} = ...
            uicontrol('Style', 'popup',...
            'Units','normalized',...
            'String', ' ',...
            'Position', [0.015+(class_i-1)*0.135 .365 .025 .026],...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeDisplayedCluster,...
            'horizontalAlignment', 'center','Visible','off');
        %         set(handles1.Figures.Waveforms.clusterPOPUP{class_i},'Value',...
        %             class_i)
        
        positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.clusterTOGGLE{class_i} = ...
            uicontrol('Style', 'togglebutton',...
            'String','%',...
            'Units','normalized',...
            'Position', positionaux,...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeVisualization,...
            'horizontalAlignment', 'center','Visible','off');
        
        %         positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.delBUTTON{class_i} = ...
            uicontrol('Style', 'pushbutton',...
            'Units','normalized',...
            'Position', [0.045+(class_i-1)*0.135 .365 .025 .026],...
            'String','DEL',...
            'BackgroundColor', [1 .5 .5]*.8,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_deletecluster,...
            'horizontalAlignment', 'center','Visible','off');
        
        positionaux = [0.10+(class_i-1)*0.14 .40 .04 .02];
        positionaux=positionaux-positionmod;
        %         nspikes = sum(handles1.data.class_id{handles1.chid}==class_i);
        handles1.Figures.Waveforms.ch_id_txtbox(class_i) = ...
            uicontrol('Style', 'text',...
            'Units','normalized',...
            'String',' ',...
            'Position', positionaux,...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'horizontalAlignment', 'left',...
            'fontsize',8,'Visible','off');
        
    elseif class_i>=4 && class_i<8
        positionmod(2)=0.015;
        
        
        positionaux = [0.08+(class_i-4)*0.35 .06 .22 .375];
        positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.cluster{class_i} = ...
            axes('Parent',hObject,'Position',positionaux,'Visible','off');
        
        
        %         positionaux = [0.055+(class_i-4)*0.25 .2 .025 .026];
        %         positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.clusterNUMB{class_i} = ...
            uicontrol('Style', 'edit',...
            'Units','normalized',...
            'String', '',...
            'Position', [0.015+(class_i-4)*0.135 .18 .025 .026],...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeClusterNumber,...
            'horizontalAlignment', 'center','Visible','off');
        set(handles1.Figures.Waveforms.clusterNUMB{class_i},'String',...
            num2str(class_i))
        %
        %         positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.clusterPOPUP{class_i} = ...
            uicontrol('Style', 'popup',...
            'Units','normalized',...
            'String', ' ',...
            'Position', [0.015+(class_i-4)*0.135 .18 .025 .026],...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeDisplayedCluster,...
            'horizontalAlignment', 'center','Visible','off');
        
        positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.clusterTOGGLE{class_i} = ...
            uicontrol('Style', 'togglebutton',...
            'String','%',...
            'Units','normalized',...
            'Position', positionaux,...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_ChangeVisualization,...
            'horizontalAlignment', 'center','Visible','off');
        
        %         positionaux(1) = sum(positionaux([1,3])) + .005;
        handles1.Figures.Waveforms.delBUTTON{class_i} = ...
            uicontrol('Style', 'pushbutton',...
            'Units','normalized',...
            'Position', [0.045+(class_i-4)*0.135 .18 .025 .026],...
            'String','DEL',...
            'BackgroundColor', [1 .5 .5]*.8,...
            'ForegroundColor', [1 1 1]*0,...
            'Callback',@GMM_deletecluster,...
            'horizontalAlignment', 'center','Visible','off');
        
        positionaux = [0.10+(class_i-4)*0.14 .19 .040 .02];
        positionaux=positionaux-positionmod;
        handles1.Figures.Waveforms.ch_id_txtbox(class_i) = ...
            uicontrol('Style', 'text',...
            'Units','normalized',...
            'String',' ',...
            'Position', positionaux,...
            'BackgroundColor', [1 1 1]*1,...
            'ForegroundColor', [1 1 1]*0,...
            'horizontalAlignment', 'right',...
            'fontsize',8,'Visible','off');
        
    end
end

end


% --- Executes during object creation, after setting all properties.
function uipanel17_CreateFcn(hObject, eventdata, handles)
global plotforclusters handles1

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position = [0.418 0.54 0.398 0.358];
plotforclusters = axes('Parent',hObject);
end


% --- Executes during object creation, after setting all properties.
function uipanel18_CreateFcn(hObject, eventdata, handles)
global plotforclusterstability

hObject.Title={};
hObject.Visible = 'off';
hObject.BackgroundColor=[1 1 1];
hObject.Position = [0.418 0.037 0.398 0.358];
plotforclusterstability = axes('Parent',hObject);



end


% --- Executes during object creation, after setting all properties.
function pushbutton12_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
hObject.Position = [0.861 0.333 0.096 0.048];
end


% --- Executes during object creation, after setting all properties.
function pushbutton23_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
end


% --- Executes during object creation, after setting all properties.
function pushbutton37_CreateFcn(hObject, eventdata, handles)
hObject.Visible = 'off';
end


% --- Executes during object creation, after setting all properties.
function pushbutton32_CreateFcn(hObject, eventdata, handles)
hObject.Visible ='off';
end


% --- Executes during object creation, after setting all properties.
function pushbutton26_CreateFcn(hObject, eventdata, handles)
hObject.Visible ='off';
end
%% removal of channels
% --- to remove channels
function pushbutton64_Callback(hObject, eventdata, handles)
global HITS M2 burst6 burst7 xpoints ypoints T joost selecteddata Exburst M88 logburst burst6indx burst7indx ISI58 unitpersecond Spikeform3 Spikeform4 timesss fs
error1 = errordlg('The selected channel will be permanently removed and if you want to regain the deleted data, the analysis will have to be redone','Warning!!!');
uiwait(error1)
prompt = {'Enter Channel name for removal'};
title = 'Annihilation of Artifacts';
dims = [1 75];
definput = {'A8'};
Totoro = inputdlg(prompt,title,dims,definput);

if isempty(Totoro)
    return
end

Imax=find(strcmp(HITS,Totoro{1}));
%delete it in HITS and M2 burst6 and burst7 and xpoints and T
HITS{Imax,2} = 0;
xpoints(find(ypoints==Imax)) = [];
ypoints(ypoints ==Imax) =[];
M2{Imax} = [];
burst6{Imax} = [];
burst7{Imax} = [];
ColIndex = find(strcmp(T.Properties.RowNames,Totoro{1}), 1);
T(ColIndex,:) =[];
% recreate variable T

T.Spikes(end) = sum(T.Spikes(1:end-1))/(size(T,1)-1);
if iscell(T.mean_ISI(1:end-1))
    T.mean_ISI{end} = sum(cell2mat(T.mean_ISI(1:end-1)))/(size(T,1)-1);
else
    T.mean_ISI(end) = sum(T.mean_ISI(1:end-1))/(size(T,1)-1);
end
T.median_ISI(end) = sum(T.median_ISI(1:end-1))/(size(T,1)-1);
if iscell(T.std_ISI(1:end-1))
    T.std_ISI{end} = sum(cell2mat(T.std_ISI(1:end-1)))/(size(T,1)-1);
else
    T.std_ISI(end) = sum(T.std_ISI(1:end-1))/(size(T,1)-1);
end
T.Bursts_max_interval(end) = sum(T.Bursts_max_interval(1:end-1))/(size(T,1)-1);
T.Bursts_log_ISI(end) = sum(T.Bursts_log_ISI(1:end-1))/(size(T,1)-1);
T.Fire_rate(end) = sum(T.Fire_rate(1:end-1))/(size(T,1)-1);
T.mean_ifr(end) = sum(T.mean_ifr(1:end-1))/(size(T,1)-1);
T.mean_CV_ISI(end) = sum(T.mean_CV_ISI(1:end-1))/(size(T,1)-1);
T.mean_CV2_ISI(end) = sum(T.mean_CV2_ISI(1:end-1))/(size(T,1)-1);
T.threshold_value(end) = sum(T.threshold_value(1:end-1))/(size(T,1)-1);

M88{Imax} =[];
if isempty(Exburst{Imax}.number_of_bursts)
else
    Exburst{Imax}.number_of_bursts =[];
    Exburst{Imax}.duration_of_bursts =[];
    Exburst{Imax}.spikes_of_bursts =[];
    Exburst{Imax}.fr_of_bursts =[];
    Exburst{Imax}.mean_ISI_bursts =[];
    Exburst{Imax}.std_ISI_bursts =[];
    Exburst{Imax}.IBI =[];
end
if isempty(logburst{Imax}.number_of_bursts)
    logburst{Imax}.number_of_bursts =[];
    logburst{Imax}.duration_of_bursts =[];
    logburst{Imax}.spikes_of_bursts =[];
    logburst{Imax}.fr_of_bursts =[];
    logburst{Imax}.mean_ISI_bursts =[];
    logburst{Imax}.std_ISI_bursts =[];
end
burst6indx{Imax} =[];
burst7indx{Imax}=[];
ISI58{Imax} =[];
unitpersecond{Imax} =zeros(1,length(unitpersecond{Imax}));
if joost == 1
else
    Spikeform4{Imax} = 0;
end
Spikeform3{Imax}=0;

% set the deleted channel to white
set(handles.(sprintf('Toggle_%s',HITS{Imax,1})),'BackgroundColor',[1 1 1]);
%save the changes

% selecteddata1 = strcat(selecteddata,'.mat');
%% rerun networkburst detection


starttimesbursts2 = [];
for i = 1:length(burst6)
    for j = 1:length(burst6{i})
        starttimesbursts = burst6{i}{j}(1);
        starttimesbursts2 = [starttimesbursts2;starttimesbursts]; %contains all the starttimes of the detected bursts
    end
end

uniquestarttimesbursts = unique(starttimesbursts2); %these are the unqiue starttimes

%now we need to put all the times in a giant matrix so we can
%search in this matrix with the unique burst start times

%convert all the cells into vectors
% all the vectors are made equal in length by adding in nans
temp = cell(1,length(burst6))';
for i = 1:length(burst6)
    temp{i} = cell2mat(burst6{i});
end

newc = cellfun(@(v) [v, nan(1, max(cellfun(@length,temp))-numel(v))], temp, 'UniformOutput', false);
newc=cell2mat(newc);


% now we need to find if there are multiple channels that start
% bursting at the same time
channelnumbernnbursts =cell(1,length(burst6))';
timeofnnbursts =cell(1,length(burst6))';
for i = 1:length(uniquestarttimesbursts)
    [channelnumbernnbursts{i}, timeofnnbursts{i}] = find(newc > uniquestarttimesbursts(i) - fs.networkburstdetection.synchronizedtimewindow & newc < uniquestarttimesbursts(i) + fs.networkburstdetection.synchronizedtimewindow );
end


% check for duplicate channelnumbers if so remove them
for i =1:length(channelnumbernnbursts)
    if isempty(channelnumbernnbursts{i})
    else
        if length(unique(channelnumbernnbursts{i})) == 1 % if the length is the same that means that there are no repeats
            channelnumbernnbursts{i} = [];
            timeofnnbursts{i}=[];
        else
            
        end
    end
end


% now that we the channels that are synchronzied in their bursting
% we need to remove the channels that do not fullfull our
% requirements of have atleast 2 synchronized channels and atleast
% 50% of the otal amount of channels should participate in the
% nnburst or else it gets removed


for i = 1:length(channelnumbernnbursts)
    if length(channelnumbernnbursts{i}) <  fs.networkburstdetection.minimumsynchronizedburstcount % if there are less than 2 synchronzied bursts it is not a nnburst and gets removed
        channelnumbernnbursts{i} = [];
        timeofnnbursts{i} = [];
        uniquestarttimesbursts(i) = nan;
    end
end

%clean up by removing empty cells and nan values
uniquestarttimesbursts(isnan(uniquestarttimesbursts)) =[];
channelnumbernnbursts = channelnumbernnbursts(~cellfun('isempty',channelnumbernnbursts));
timeofnnbursts = timeofnnbursts(~cellfun('isempty',timeofnnbursts));

% now we need to find the bursts that are part of the synchronized
% bursts (so we can have the endtimes of the bursts) and merge bursts that fall within  the time window of the
% synchronzied bursts in other channels and then we can see how
% many channels are participating

burst6length =burst6; % create a cell array that is equal to burst6 but instead contains the length of each cell array tpo speed up the calucaltions in the next part
for i = 1:length(burst6)
    for j = 1:length(burst6{i})
        burst6length{i}{j} = length(burst6{i}{j});
    end
end

for i = 1:length(burst6) % convert the cell arrays in vectors
    burst6length{i} = cell2mat(burst6length{i});
end


potentialnnbursts = cell(1,length(channelnumbernnbursts))';
burstsindexcount=[];
for i = 1:length(potentialnnbursts)
    for j = 1:length(channelnumbernnbursts{i})
        for k = 1:cellfun(@length,(burst6(channelnumbernnbursts{i}(j))))
            %figure out which bursts the indexes belong to
            
            %                      burstsindexcount = cellfun(@length,burst6{channelnumbernnbursts{i}(j)}); % old version that was slower
            %                      burstsindexcount = cumsum( burstsindexcount); % old version
            burstsindexcount = cumsum( burst6length{channelnumbernnbursts{i}(j)});
            if timeofnnbursts{i}(j) < burstsindexcount(k)   % if the number in timeofnnburst is smaller than the length of the burst than we found the burst is synchronized
                correctburst = k;
                potentialnnbursts{i}{j} = burst6{channelnumbernnbursts{i}(j)}{correctburst}; % this cell contains all the bursts associated with the syncrhonzied brusts that wer efound based on their start times
                break
            end
        end
    end
end

% we have to check if the times of the bursts are within
% acceptable ranges

% create variable that is the exact same varible as potentialnnbursts
% but intead each cell contains the mean + std of that channel to
% improve the speed

potentialnnburstsmean = potentialnnbursts;
for i =1 :length(potentialnnbursts)
    potentialnnburstsmean{i} = nanmedian(cellfun(@nanmedian,potentialnnbursts{i}))+ 25*nanmedian(cellfun(@nanstd,potentialnnbursts{i})) ;
end

for i = 1:length(potentialnnbursts)
    for j = 1:length(potentialnnbursts{i})
        %                 referencenumber = nanmean(cell2mat(potentialnnbursts{1}));
        if potentialnnburstsmean{i} < nanmedian(potentialnnbursts{i}{j}) %if its smaller that means that the times is so far removed from the median that most liekly its not feasible to be part of the nnburst
            potentialnnbursts{i}{j} = [];
        end
    end
end


% now we need to use the synscho bursts to find if there are bursts that
% fall within the same duration as the synchronized bursts. if they do then
% they are part of the  potential network bursts
% we loop through both synchronized bursts just to extra certain we do not
% miss anything because the starttimes might be the same but the ending
% time might not be.

mergeburstchannel = cell(1,length(potentialnnbursts))';
mergeburstnumber  = cell(1,length(potentialnnbursts))';
tobemergedbursts  = cell(1,length(potentialnnbursts))';

% create vaiable of potneialnnbursts that have all the cells converted into
% vectors to improve the performance
potentialnnburstsvector = potentialnnbursts;
potentialnnburstsvector = cellfun(@cell2mat,potentialnnburstsvector,'UniformOutput',0);

for i = 1:length(potentialnnburstsvector)
    potentialnnburstsvector{i,2}(1) = min(potentialnnburstsvector{i});
    potentialnnburstsvector{i,2}(2) = max(potentialnnburstsvector{i});
end

for i =1:length(potentialnnbursts)
    for k = 1:length(burst6)
        for l = 1:length(burst6{k})
            if ~isempty(find(burst6{k}{l} > potentialnnburstsvector{i,2}(1) & burst6{k}{l} < potentialnnburstsvector{i,2}(2))) % if there are no numbers found then the bursts doenst match with the potential nnburst
                tobemergedbursts{i}{k} =cell2mat(burst6{k}(l)) ;
                mergeburstchannel{i}{k} = k;
                mergeburstnumber{i}{k} = l;
            end
        end
    end
end

% clean up the empty  cells

for i =1:length(tobemergedbursts)
    tobemergedbursts{i}  = tobemergedbursts{i}(~cellfun('isempty',tobemergedbursts{i}));
    mergeburstchannel{i} = mergeburstchannel{i}(~cellfun('isempty',mergeburstchannel{i}));
    mergeburstnumber{i}  = mergeburstnumber{i} (~cellfun('isempty',mergeburstnumber{i} ));
end

%now we need remove the nnbursts that have less than 50% of the whole wwell
%participating in the nnbursts

% find the number of active channels
amountactivechannels = length(find(~cellfun(@isempty,M2)));

mergeburstchannel(cellfun('length',mergeburstchannel)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
tobemergedbursts(cellfun('length',tobemergedbursts)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
mergeburstnumber(cellfun('length',mergeburstnumber)<amountactivechannels* fs.networkburstdetection.minimumchannelparticipation) = [];
% channelnumbernnbursts(cellfun('length',channelnumbernnbursts)<length(M2)*0.5) = [];
% timeofnnbursts(cellfun('length',timeofnnbursts)<length(M2)*0.5) = [];
% potentialnnbursts(cellfun('length',potentialnnbursts)<length(M2)*0.5) = [];

%the last step is to find duplicates and merge them together
findoverlappingnnbursts = cell(1,length(tobemergedbursts))';

for i = 1:length(tobemergedbursts)
    findoverlappingnnbursts{i} = [min(cell2mat(tobemergedbursts{i})), max(cell2mat(tobemergedbursts{i}))];
end





for i = 1:length(tobemergedbursts)
    if isempty(findoverlappingnnbursts{i})
        continue
    else
        for k = 2:length(tobemergedbursts)
            if isempty(findoverlappingnnbursts{k}) || k == i
                continue
            else
                if ~isempty(find(findoverlappingnnbursts{k} > (findoverlappingnnbursts{i}(1)-  1) & (findoverlappingnnbursts{k} < findoverlappingnnbursts{i}(2)+1)))
                    % if this is true than there is overlap. so we need to find out
                    % which one is longer and that will be the one remaining.
                    if findoverlappingnnbursts{i}(2) >= findoverlappingnnbursts{k}(2) % check for which endtime is the longest
                        findoverlappingnnbursts{k} = [];
                    else
                        findoverlappingnnbursts{i}(2) = findoverlappingnnbursts{k}(2);
                        findoverlappingnnbursts{k} = [];
                    end
                else
                    
                    
                end
            end
        end
    end
end


%lets use logical indezing to get rid of the overlapping nnbursts and
%finally get our actual nnbursts

tobemergedbursts(cellfun('isempty',findoverlappingnnbursts)) =[];
mergeburstchannel(cellfun('isempty',findoverlappingnnbursts)) =[];
mergeburstnumber(cellfun('isempty',findoverlappingnnbursts)) =[];
findoverlappingnnbursts(cellfun('isempty',findoverlappingnnbursts)) =[];

% now that we have our nnbursts we can extract the ifnroamtion about the
% nnbursts

%struct for networkbursts
networkburstttt =[];
for i = 1:length(mergeburstnumber)
    
    networkburstttt.starttime(i,1) = findoverlappingnnbursts{i}(1); %time (s) at which the networkburst starts
    networkburstttt.endtime(i,1) = findoverlappingnnbursts{i}(2); %time (s) at which the nnburst ends
    networkburstttt.amount = length(mergeburstnumber);
    networkburstttt.duration(i,1) = networkburstttt.endtime(i) - networkburstttt.starttime(i); %duration of networkbursts in seconds
    networkburstttt.spikesfr_in_nbursts(i,1) = length(find(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))/networkburstttt.duration(i,1); %total spikes inside of bursts
    networkburstttt.nburst_rate = length(mergeburstnumber)/timesss; % per second
    networkburstttt.ISI(i,1) = mean(abs(diff(xpoints(xpoints>networkburstttt.starttime(i) & xpoints<networkburstttt.endtime(i)))));
end

for i = 1:length(mergeburstnumber)
    if i == length(mergeburstnumber) % we have to skip the last iteration because there is no next networkburst after the last one
        networkburstttt.IBI(i,1) = 0;
        continue
    else
        networkburstttt.IBI(i,1) = abs(networkburstttt.endtime(i) - networkburstttt.starttime(i+1)); %IBI in seconds
    end
end

% added the CV of IBI of nnbursts
if isempty(networkburstttt)
    networkburstttt.starttime = 0;
    networkburstttt.endtime = 0;
    networkburstttt.amount = 0;
    networkburstttt.duration = 0;
    networkburstttt.spikesfr_in_nbursts = 0;
    networkburstttt.nburst_rate = 0;
    networkburstttt.ISI = 0;
    networkburstttt.IBI = 0;
    networkburstttt.CVIBI= 0;
else
    networkburstttt.CVIBI = std(networkburstttt.IBI) / mean(networkburstttt.IBI);
end








save(selecteddata,'networkburstttt','HITS','xpoints','ypoints','M2','burst6','burst7','T','M88','burst6indx','burst7indx','Exburst','logburst','unitpersecond','Spikeform3','Spikeform4','-append');

end

% --- to remove channels
function pushbutton64_CreateFcn(hObject, eventdata, handles)

hObject.Position = [0.861 0.601 0.096 0.048];
hObject.CData = imread('color_button.png');
hObject.ForegroundColor = [0.992 0.89 0.655];
hObject.String = 'Remove Channels';





end
%% display used parameters
% --- Executes during object creation, after setting all properties.
function text85_CreateFcn(hObject, eventdata, handles)
global fs

hObject.FontWeight = 'bold';
hObject.String =  ['High Pass Butterworth filter Parameters used:',...
    newline 'Cuttoff Frequency : ',mat2str(fs.filtersettings.cut_off_frequency), ' Hz',...
    newline 'Order of fit : ',mat2str(fs.filtersettings.filter_order),...
    newline 'Sampling frequency : ',mat2str(fs.filtersettings.sampling_frequency), 'Hz',...
    newline ,...
    newline 'Baseline Noise Detection Parameters used:',...
    newline 'Window : ',mat2str(fs.baselinenoise.window),' (ms)',...
    newline 'Pure noise window : ',mat2str(fs.baselinenoise.purenoisewindow),' (s)',...
    newline 'Root Mean Square level : ',mat2str(fs.baselinenoise.RMS),...
    newline,...
    newline 'Spike Detection Parameters used:',...
    newline 'Min Peak Distance : ',mat2str(fs.unitdetection.minpeakdistance),' (ms)',...
    newline 'Min Peak Prominence : ',mat2str(fs.unitdetection.minpeakprominence),' (',char(181),'V)',...
    newline 'Minimum Fire frequency: ',mat2str(fs.standardsettings.minimum_activity_channel),' (Hz)'];
% hObject.Position = [0.586 0.525 0.186 0.181]; % old position
hObject.Position =[0.529 0.605 0.186 0.181];
hObject.BackgroundColor = [.97,.98,.98];
end
