

function [ ] = GMM_ChangeVisualization( A,B )

global handles1

% aux = cell2mat(handles1.Figures.Waveforms.clusterTOGGLE)==A;
myfun = @(x) isequal(x,A);
aux = cellfun(myfun, handles1.Figures.Waveforms.clusterTOGGLE);

class_i = get(handles1.Figures.Waveforms.clusterPOPUP{aux},'value');

axes(handles1.Figures.Waveforms.cluster{aux})
cla
if class_i>size(handles1.dataaux.class_colors,1)
    return;
else

    switch get(A,'value')

        case false
            GMM_PlotAllSpikes( class_i )
            set(A,'String','%')

        case true
            GMM_PlotPrctiles( class_i )
            set(A,'String','=')
    end
end
end
