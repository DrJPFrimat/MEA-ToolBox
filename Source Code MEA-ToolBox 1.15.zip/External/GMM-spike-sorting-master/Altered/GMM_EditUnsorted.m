
function GMM_EditUnsorted(A,B)

global handles1

clusterid = handles1.data.class_id{handles1.chid};
clusterid = clusterid+1;

clusterid(isnan(clusterid)) = 1;
% clusterid(clusterid==class_i)=nan;

handles1.data.class_id{handles1.chid}=clusterid;
if isfield(handles1.data.model{handles1.chid},'class')
    handles1.data.model{handles1.chid}.class= handles1.data.model{handles1.chid}.class+1;
end
GMM_plotwaveforms

if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
    GMM_showclusters
end

end