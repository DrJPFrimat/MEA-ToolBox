
function [ ] = GMM_deletecluster(A,B )

global handles1

% aux = cell2mat(handles1.Figures.Waveforms.delBUTTON)==A;
myfun = @(x) isequal(x,A);
aux = cellfun(myfun, handles1.Figures.Waveforms.delBUTTON);


class_i = get(handles1.Figures.Waveforms.clusterPOPUP{aux},'value');
try
    handles1.data.model{handles1.chid}.class(handles1.data.model{handles1.chid}.class==class_i)=nan;
end
clusterid = handles1.data.class_id{handles1.chid};
clusterid(clusterid==class_i)=nan;

clusterlabels = unique(clusterid(~isnan(clusterid)));

for i = 1:length(clusterlabels)
    
    clusspikes = clusterid==clusterlabels(i);
    handles1.data.class_id{handles1.chid}(clusspikes) = i;
    try
        handles1.data.model{handles1.chid}.class(handles1.data.model{handles1.chid}.class==clusterlabels(i))=i;
    end
end
handles1.data.class_id{handles1.chid}(isnan(clusterid))=nan;

GMM_plotwaveforms(0)

if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
    GMM_showclusters
end

end