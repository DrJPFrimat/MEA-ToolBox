function [v] = minmax(x)
    
    v = [min(x'); max(x')]';
end