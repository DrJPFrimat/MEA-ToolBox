function GMM_ClusterDisplayONOFF( A,B )

global handles1

% get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value');

% switch get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
%     
%     case false
%         try
%             delete(handles1.Figures.Clusters.main)
%             handles1.Figures.Clusters = rmfield(handles1.Figures.Clusters,'main');
%         catch
%            display('Cluster figure already closed!') 
%         end
%     case true
        GMM_showclusters
        
% end

end
