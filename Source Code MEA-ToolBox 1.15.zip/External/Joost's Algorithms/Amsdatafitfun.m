function Y=Amsdatafitfun(X,P);
% function Y=fitfun(X,P);
% 
% Deze functie berekent een aangepaste cauchy verdeling, uitgaande van de waarden in
% X, en met parameters P. P=[M;v;t;offset]. M is de schaal parameter, v de vorm parameter, t de locatie
% parameter en offset lijkt me duidelijk.
M=P(1); v=P(2); t=P(3); offset=P(4);
Y=((((X-t)/v).^2+1)).\M + offset;