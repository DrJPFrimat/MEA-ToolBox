
    mapping=[   12 13 14 15 16 17,...
        21 22 23 24 25 26 27 28,...
        31 32 33 34 35 36 37 38,...
        41 42 43 44 45 46 47 48,...
        51 52 53 54 55 56 57 58,...
        61 62 63 64 65 66 67 68,...
        71 72 73 74 75 76 77 78,...
        82 83 84 85 86 87    ];
MeetPeriode = max(Ts)/FileInfo.samplefrequency;
bingrootte = 0.001; 
Fs = FileInfo.samplefrequency;
delay=(1:ceil(MeetPeriode/bingrootte))'*1000*(bingrootte/Fs); % delay in msec
t = MeetPeriode;
% meetduur=(round((max(t)-min(t))/(60*Fs))); % in minuten
meetduur = t/60;
M=zeros(60,60); T=zeros(60,60); OFFSET=zeros(60,60); VORM=zeros(60,60);
OPP=zeros(60,60); TC=zeros(60,60); % in deze matrices gaat het model
% i is het eerst vurende neuron, j het dan vurende neuron

tekenen=0;
%tekenen=1;   % zet tekenen op 1 om te grafieken te bekijken

% Set "tekenen" to 1 to watch all curves and fits. 0 skips the drawing


AantSpikes = ones(1,max(Cs))';
for i =1:max(Cs)
    AantSpikes(i,1) = length(Cs(Cs ==i));
    
end


actiefdrempel=250; %threshold for active electrodes
a=find(AantSpikes>=actiefdrempel); % bekijk alleen kanalen met minstens 250 spikes


% a=[<type channel numbers> ]

Ts = Ts ./FileInfo.samplefrequency; % Ts now displays the spike timings

M2 = cell(1,60)';

for i = 1:length(M2)
    M2{i} = Ts(Cs == i);
end



% Here the active channels are selected.  "actiefdrempel" sets the
% threshold number of spikes recorded in an active channel
% a is an array that contains the numbers of all active electrodes (1-60)
% you can set i and j to the indices of a that refer to the channels that
% you're interested in.


for i=1:length(a)
     disp(i);
    for j=1:length(a)
        AA = (supa{a(i)}(a(j),:));
        %         AA=squeeze(K(a(i),a(j),:));
        %         AA=A./AantSpikes(a(i));
        if tekenen==1
            plotSD(delay,AA,5);
            grid on;
        end
        if i~=j
            if tekenen==1
                hold on; V=axis; misfit=0; axis normal;
            end
            
            test=find(AA==max(AA))*(bingrootte/10);
            Po=[max(AA) 10 test(1) 0]; % eerste gok
            options=optimset('MaxFunEvals',1e9,'TolFun',1e-20);
            P=Po; 
            P=fminsearch(@(P) errorfun(delay,AA,P),Po,options);
            Mtekst=''; tctekst='';
            if P(3)<1; P(3)=0; end
            if P(1)<P(4) % M<offset
                Mtekst='/ aangepast.      SNR te laag';
                tctekst=['/ niet van belang; M=0'];
                P(1)=0; P(4)=mean(AA); misfit=1;
            end
            if ((P(2)<2) | (P(2)>250)) % v moet liggen tussen 10 en 250 msec
                misfit=1; P(1)=0; P(4)=mean(AA);
                Mtekst='/ aangepast.   v buiten grenzen.';
            end
            if (P(3)>250)  % tau-c > 250
                misfit=1;  P(1)=0; P(4)=mean(AA);
                Mtekst='/ aangepast.   tc > 250.';
            end
            M(a(i),a(j))=P(1); VORM(a(i),a(j))=P(2);
            T(a(i),a(j))=P(3); OFFSET(a(i),a(j))=P(4);
            OPP(a(i),a(j))=sum((Amsdatafitfun(delay,P)-P(4))*(bingrootte/10));
            if tekenen==1 % om de fit te tekenen: 1 invullen.
                if misfit axis square; end
                %                 plot(delay,Amsdatafitfun(delay,P),'r');
                text(400,0.7*V(4),['OPP: ' num2str(OPP(a(i),a(j)))]);
                text(400,.95*V(4),['M = ' num2str(P(1)) Mtekst]);
                text(400,.9*V(4),['tc = ' num2str(P(3)) tctekst]);
                text(400,.85*V(4),['offset = ' num2str(P(4))]);
                text(400,.8*V(4),['v = ' num2str(P(2))]);
                hold off
            end
        end
        if tekenen==1
            xlabel('Delay [msec]');
            ylabel(['CFP electr.' num2str(mapping(a(j))) ' (' num2str(AantSpikes(a(j))) ' sp) | electr.' num2str(mapping(a(i))) ' (' num2str(AantSpikes(a(i))) 'sp)']);
            %             ylabel(['CFP electr.' num2str((a(j))) ' (' num2str(AantSpikes(a(j))) ' sp) | electr.' num2str((a(i))) ' (' num2str(AantSpikes(a(i))) 'sp)']);
            title(['Conditional firing probability (' datafile ')']);pause
        end
    end
end

clear A AA Cy V tekenen a i j test DT Mtekst tctekst TotalChance options
clear AlBekeken Po P V C Xm Xn b h k m n nn status tc x3 misfit 


extensie=num2str(verschuiving);
if verschuiving<1000; extensie=['0' extensie]; end
if verschuiving<100; extensie=['0' extensie]; end
if verschuiving<10; extensie=['0' extensie]; end

Timestamps=Ts;

Begintijd_uur=min(t)/(16000*3600);
%clear Cfiles Tfiles
extensie=['_' extensie];
disp(['save ' datafile 'CFP' extensie]);
eval(['save ' datafile 'CFP' extensie ' Timestamps M']);


% clear Begintijd_uur AantSpikes T actiefdrempel delay meetduur OFFSET TC 
% clear extensie K OPP Tstim filename t M Stim VORM datafile  verschuiving
% 








