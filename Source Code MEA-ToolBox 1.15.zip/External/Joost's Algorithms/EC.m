function [ ec ] = EC( burstTs1, burstCs1, burstTs2, burstCs2 )
%EC Summary of this function goes here
%   Detailed explanation goes here

    len = 200;
    sigma = 5;
    siz = 6 * sigma;
    linS = linspace(-siz/2, siz/2, siz);
    gFilter = exp(-linS .^ 2 / (2 * sigma^2));
    %gFilter = gFilter / sum(gFilter);

    burstTs1 = burstTs1 - burstTs1(1);
    burstTs2 = burstTs2 - burstTs2(1);

    s = 0;
    for e = 1:100
        t1 = burstTs1(burstCs1 == (e-1));
        t2 = burstTs2(burstCs2 == (e-1));
        
        if isempty(t1) || isempty(t2)
            continue;
        end
              
        t1Hist = histc(t1, 0:len);
        t1Hist = conv(t1Hist, gFilter);
        
        t2Hist = histc(t2, 0:len);
        t2Hist = conv(t2Hist, gFilter);
        
        cor = xcorr(t1Hist, t2Hist, 'coeff');
        s = s + cor(:);
    end
    
     ec = max(s)/100;
end
% 
% burstTs1 = Ts(Cs == 1) ;
% burstCs1 = Cs(Cs == 1) ;
% 
% burstTs2 = Ts(Cs == 2) ;
% burstCs2 = Cs(Cs == 2) ;