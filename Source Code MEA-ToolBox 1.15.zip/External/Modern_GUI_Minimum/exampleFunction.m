function [handles,hObject] = exampleFunction(Tag,handles,hObject)
global h h1 h2 h3 handles1 clustertag multiwell1 ax
if hObject.UserData == 1
    handles.pushbutton64.Visible ='on';
    handles.checkbox3.Visible = 'off';
    handles.pushbutton61.Visible = 'off';
    handles.pushbutton60.Visible ='off';
    handles.checkbox2.Visible = 'off';
    handles.pushbutton34.Visible = 'off';
    handles.pushbutton37.Visible = 'off'; %test
    handles.pushbutton33.Visible = 'on';
    handles.pushbutton32.Visible = 'off'; %test
    handles.pushbutton28.Visible = 'on';
    handles.pushbutton31.Visible = 'off';
    handles.pushbutton26.Visible = 'off'; %test
    handles.pushbutton24.Visible = 'on';
    handles.pushbutton23.Visible = 'off'; %test
    handles.pushbutton18.Visible = 'off';
    handles.pushbutton17.Visible = 'on';
    handles.pushbutton16.Visible = 'on';
    handles.pushbutton15.Visible = 'on';
    handles.pushbutton14.Visible = 'on';
    handles.pushbutton12.Visible = 'off'; % cross correlations test
    handles.pushbutton10.Visible = 'on';
    handles.pushbutton8.Visible = 'on';
    handles.pushbutton6.Visible = 'on';
    handles.pushbutton3.Visible = 'off';
    handles.pushbutton2.Visible = 'off';
    handles.pushbutton1.Visible = 'on';
    handles.pushbutton38.Visible = 'off';
    handles.pushbutton39.Visible = 'off';
    handles.pushbutton42.Visible = 'off';
    handles.pushbutton43.Visible = 'off';
    handles.pushbutton44.Visible = 'off';
    handles.pushbutton45.Visible = 'off';
    handles.pushbutton46.Visible = 'off';
    handles.pushbutton47.Visible = 'off';
    handles.pushbutton48.Visible = 'off';
    handles.pushbutton58.Visible = 'off';
    handles.pushbutton41.Visible = 'off';
    handles.pushbutton65.Visible = 'off';
    handles.pushbutton66.Visible = 'off';
    handles.pushbutton67.Visible = 'off';
    handles.pushbutton68.Visible = 'off';
    handles.uipanel20.Visible = 'off';
    handles.pushbutton63.Visible = 'off';
    handles.pushbutton62.Visible = 'off';
  
    handles1.Figures.Clusters.stability.Visible = 'off';
    handles1.Figures.Waveforms.unsortedspikes.Visible = 'off';
    handles1.Figures.Waveforms.UnsortedPanel.Visible = 'off';
    handles1.Figures.Waveforms.RunSortingAllchs.Visible = 'off';
    handles1.Figures.Waveforms.DispClustersTOGGLE.Visible = 'off';
    handles1.Figures.Waveforms.runSorting.Visible = 'off';
    handles1.Figures.Waveforms.ch_id.Visible = 'off';
    handles1.Figures.Clusters.stability.Visible = 'off';
    handles1.Figures.Waveforms.maintext.Visible = 'off';
    handles1.Figures.Waveforms.LoadData.Visible ='off';
    handles1.Figures.Waveforms.SaveData.Visible = 'off';
    handles1.Figures.Waveforms.filename.Visible = 'off';
    handles1.Figures.Waveforms.resetSorting.Visible = 'off';
    handles1.Figures.Waveforms.EditUnsorted.Visible = 'off';
    handles1.Figures.Waveforms.DiscardUnsorted.Visible = 'off';
    handles1.Figures.Waveforms.PlotAllTOGGLE.Visible = 'off';
    
   
    if  isfield(handles1.Figures.Clusters,'viewspikesList') && clustertag == 1
        handles1.Figures.Clusters.viewspikesList.Visible = 'off';
        handles1.Figures.Clusters.changemodeBUTTON.Visible = 'off';
        handles1.Figures.Clusters.recalculateButton.Visible = 'off';
        handles1.Figures.Clusters.deleteButton.Visible = 'off';
    end
    
    for i = 1:length( handles1.Figures.Waveforms.cluster)
        handles1.Figures.Waveforms.cluster{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterNUMB)
        handles1.Figures.Waveforms.clusterNUMB{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterPOPUP)
        handles1.Figures.Waveforms.clusterPOPUP{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterTOGGLE)
        handles1.Figures.Waveforms.clusterTOGGLE{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.delBUTTON)
        handles1.Figures.Waveforms.delBUTTON{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.ch_id_txtbox)
        handles1.Figures.Waveforms.ch_id_txtbox(i).Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.ch_id_txtbox)
        handles1.Figures.Waveforms.ch_id_txtbox(i).Visible = 'off';
    end
    
    try
        if exist('h','var')
            h.Visible = 'off';
        end
        
        if strcmp(h.Visible,'on')
            h.Visible = 'off';
        end
        
        if exist('h1','var')
            h1.Visible = 'off';
        end
        
        if strcmp(h1.Visible,'on')
            h1.Visible = 'off';
        end
        
        if exist('h2','var')
            h2.Visible = 'off';
        end
        
        if strcmp(h2.Visible,'on')
            h2.Visible = 'off';
        end
        
        if exist('h3','var')
            h3.Visible = 'off';
        end
        
        if strcmp(h3.Visible,'on')
            h3.Visible = 'off';
        end
    catch
    end
    
    handles.Toggle_J12.Visible='on';
    handles.Toggle_H12.Visible='on';
    handles.Toggle_G12.Visible='on';
    handles.Toggle_F12.Visible='on';
    handles.Toggle_E12.Visible='on';
    handles.Toggle_D12.Visible='on';
    handles.Toggle_K11.Visible='on';
    handles.Toggle_J11.Visible='on';
    handles.Toggle_H11.Visible='on';
    handles.Toggle_G11.Visible='on';
    handles.Toggle_F11.Visible='on';
    handles.Toggle_E11.Visible='on';
    handles.Toggle_D11.Visible='on';
    handles.Toggle_C11.Visible='on';
    handles.Toggle_L10.Visible='on';
    handles.Toggle_K10.Visible='on';
    handles.Toggle_J10.Visible='on';
    handles.Toggle_H10.Visible='on';
    handles.Toggle_G10.Visible='on';
    handles.Toggle_F10.Visible='on';
    handles.Toggle_E10.Visible='on';
    handles.Toggle_D10.Visible='on';
    handles.Toggle_C10.Visible='on';
    handles.Toggle_B10.Visible='on';
    handles.Toggle_M9.Visible='on';
    handles.Toggle_L9.Visible='on';
    handles.Toggle_K9.Visible='on';
    handles.Toggle_J9.Visible='on';
    handles.Toggle_H9.Visible='on';
    handles.Toggle_G9.Visible='on';
    handles.Toggle_F9.Visible='on';
    handles.Toggle_E9.Visible='on';
    handles.Toggle_D9.Visible='on';
    handles.Toggle_C9.Visible='on';
    handles.Toggle_B9.Visible='on';
    handles.Toggle_A9.Visible='on';
    handles.Toggle_M8.Visible='on';
    handles.Toggle_L8.Visible='on';
    handles.Toggle_K8.Visible='on';
    handles.Toggle_J8.Visible='on';
    handles.Toggle_H8.Visible='on';
    handles.Toggle_G8.Visible='on';
    handles.Toggle_F8.Visible='on';
    handles.Toggle_E8.Visible='on';
    handles.Toggle_D8.Visible='on';
    handles.Toggle_C8.Visible='on';
    handles.Toggle_B8.Visible='on';
    handles.Toggle_A8.Visible='on';
    handles.Toggle_M7.Visible='on';
    handles.Toggle_L7.Visible='on';
    handles.Toggle_K7.Visible='on';
    handles.Toggle_J7.Visible='on';
    handles.Toggle_H7.Visible='on';
    handles.Toggle_G7.Visible='on';
    handles.Toggle_F7.Visible='on';
    handles.Toggle_E7.Visible='on';
    handles.Toggle_D7.Visible='on';
    handles.Toggle_C7.Visible='on';
    handles.Toggle_B7.Visible='on';
    handles.Toggle_A7.Visible='on';
    handles.Toggle_M6.Visible='on';
    handles.Toggle_L6.Visible='on';
    handles.Toggle_K6.Visible='on';
    handles.Toggle_J6.Visible='on';
    handles.Toggle_H6.Visible='on';
    handles.Toggle_G6.Visible='on';
    handles.Toggle_F6.Visible='on';
    handles.Toggle_E6.Visible='on';
    handles.Toggle_D6.Visible='on';
    handles.Toggle_C6.Visible='on';
    handles.Toggle_B6.Visible='on';
    handles.Toggle_A6.Visible='on';
    handles.Toggle_M5.Visible='on';
    handles.Toggle_L5.Visible='on';
    handles.Toggle_K5.Visible='on';
    handles.Toggle_J5.Visible='on';
    handles.Toggle_H5.Visible='on';
    handles.Toggle_G5.Visible='on';
    handles.Toggle_F5.Visible='on';
    handles.Toggle_E5.Visible='on';
    handles.Toggle_D5.Visible='on';
    handles.Toggle_C5.Visible='on';
    handles.Toggle_B5.Visible='on';
    handles.Toggle_A5.Visible='on';
    handles.Toggle_M4.Visible='on';
    handles.Toggle_L4.Visible='on';
    handles.Toggle_K4.Visible='on';
    handles.Toggle_J4.Visible='on';
    handles.Toggle_H4.Visible='on';
    handles.Toggle_G4.Visible='on';
    handles.Toggle_F4.Visible='on';
    handles.Toggle_E4.Visible='on';
    handles.Toggle_D4.Visible='on';
    handles.Toggle_C4.Visible='on';
    handles.Toggle_B4.Visible='on';
    handles.Toggle_A4.Visible='on';
    handles.Toggle_L3.Visible='on';
    handles.Toggle_K3.Visible='on';
    handles.Toggle_J3.Visible='on';
    handles.Toggle_H3.Visible='on';
    handles.Toggle_G3.Visible='on';
    handles.Toggle_F3.Visible='on';
    handles.Toggle_E3.Visible='on';
    handles.Toggle_D3.Visible='on';
    handles.Toggle_C3.Visible='on';
    handles.Toggle_B3.Visible='on';
    handles.Toggle_K2.Visible='on';
    handles.Toggle_J2.Visible='on';
    handles.Toggle_H2.Visible='on';
    handles.Toggle_G2.Visible='on';
    handles.Toggle_F2.Visible='on';
    handles.Toggle_E2.Visible='on';
    handles.Toggle_D2.Visible='on';
    handles.Toggle_C2.Visible='on';
    handles.Toggle_J1.Visible='on';
    handles.Toggle_H1.Visible='on';
    handles.Toggle_G1.Visible='on';
    handles.Toggle_F1.Visible='on';
    handles.Toggle_E1.Visible='on';
    handles.Toggle_D1.Visible='on';
    
    
    
    
    
    
    
    handles.Pannel_2.Visibility='on';
    handles.Pannel_1.Visibility='on';
    handles.Pannel_3.Visibility='on';
    handles.Pannel_4.Visibility='on';
    handles.Pannel_5.Visibility='on';
    handles.Pannel_6.Visibility='on';
    
    handles.uitable10.Visible='off';
    
    handles.text5.Visible='off';
    handles.text8.Visible='on';
    handles.text10.Visible='on';
    handles.text9.Visible='on';
    handles.text3.Visible='on';
    handles.text18.Visible='off';
    handles.text82.Visible='off';
    handles.text83.Visible='off';
    handles.text84.Visible='off';
    handles.uipanel4.Visible='on';
    handles.uipanel15.Visible = 'off';
    handles.uipanel16.Visible = 'off';
    handles.uipanel17.Visible = 'off';
    handles.uipanel18.Visible = 'off';
    %     handles.uipanel4.Position=[0.01, 0.037, 0.398, 0.358];
    
    handles.uipanel3.Visible='on';
    handles.uipanel2.Visible='on';
    
    % for multiwell
    if multiwell1 == 1
        handles.uipanel4.Visible = 'on';
        handles.uipanel2.Visible = 'off';
        handles.uipanel3.Visible = 'on';
        handles.popupmenu1.Visible = 'on';
        handles.pushbutton368.Visible = 'on';
        handles.pushbutton371.Visible = 'on';
        handles.pushbutton370.Visible = 'on';
        handles.pushbutton366.Visible = 'on';
        handles.pushbutton364.Visible = 'on';
        handles.pushbutton367.Visible = 'on';
        handles.pushbutton380.Visible = 'off';
        handles.pushbutton377.Visible = 'off';
        handles.pushbutton376.Visible = 'off';
        handles.pushbutton365.Visible = 'off';
        handles.pushbutton372.Visible = 'on';
        handles.pushbutton373.Visible = 'on';
        handles.pushbutton383.Visible = 'on';
        handles.pushbutton374.Visible = 'on';
        handles.pushbutton384.Visible = 'on';
        handles.pushbutton381.Visible = 'on';
        handles.pushbutton375.Visible = 'off';
        handles.pushbutton382.Visible = 'off';
        handles.pushbutton388.Visible = 'off';
        handles.pushbutton402.Visible = 'on';
        handles.pushbutton403.Visible = 'on';
        handles.pushbutton404.Visible = 'on';
        handles.pushbutton405.Visible = 'on';
        handles.pushbutton406.Visible = 'on';
        handles.pushbutton407.Visible = 'on';
        handles.pushbutton408.Visible = 'on';
        handles.pushbutton409.Visible = 'on';
        handles.pushbutton410.Visible = 'on';
        handles.pushbutton411.Visible = 'on';
        handles.pushbutton412.Visible = 'on';
        handles.pushbutton413.Visible = 'on';
        handles.pushbutton414.Visible = 'on';
        handles.pushbutton415.Visible = 'on';
        handles.pushbutton416.Visible = 'on';
        handles.pushbutton417.Visible = 'on';
        handles.pushbutton418.Visible = 'on';
        handles.pushbutton419.Visible = 'on';
        handles.pushbutton420.Visible = 'on';
        handles.pushbutton421.Visible = 'on';
        handles.pushbutton422.Visible = 'on';
        handles.pushbutton423.Visible = 'on';
        handles.pushbutton424.Visible = 'on';
        handles.pushbutton425.Visible = 'on';
        
        handles.text43.Visible ='on';
        handles.text2.Visible = 'off';  handles.text3.Visible = 'off';  handles.text4.Visible = 'off';  handles.text5.Visible = 'off';  handles.text6.Visible = 'off';
        handles.text7.Visible = 'off';  handles.text8.Visible = 'off';  handles.text9.Visible = 'off';  handles.text10.Visible = 'off';  handles.text11.Visible = 'off';
        handles.text12.Visible = 'off';  handles.text13.Visible = 'off';  handles.text14.Visible = 'off';  handles.text15.Visible = 'off';  handles.text16.Visible = 'off';
        handles.text17.Visible = 'off';  handles.text18.Visible = 'off';  handles.text19.Visible = 'off';  handles.text20.Visible = 'off';  handles.text21.Visible = 'off';
        handles.text22.Visible = 'off';  handles.text23.Visible = 'off';  handles.text24.Visible = 'off';  handles.text25.Visible = 'off';  handles.text26.Visible = 'off';
        handles.text27.Visible = 'on';  handles.text28.Visible = 'on';  handles.text29.Visible = 'on';  handles.text30.Visible = 'on';
        
        handles.uitable1.Visible = 'off';
        handles.checkbox4.Visible ='off';
        handles.togglebutton1.Visible = 'on'; handles.togglebutton2.Visible = 'on'; handles.togglebutton3.Visible = 'on'; handles.togglebutton4.Visible = 'on'; handles.togglebutton5.Visible = 'on';
        handles.togglebutton6.Visible = 'on'; handles.togglebutton7.Visible = 'on'; handles.togglebutton8.Visible = 'on'; handles.togglebutton9.Visible = 'on'; handles.togglebutton10.Visible = 'on';
        handles.togglebutton11.Visible = 'on'; handles.togglebutton12.Visible = 'on'; handles.togglebutton13.Visible = 'on'; handles.togglebutton14.Visible = 'on'; handles.togglebutton15.Visible = 'on';
        handles.togglebutton16.Visible = 'on'; handles.togglebutton17.Visible = 'on'; handles.togglebutton18.Visible = 'on'; handles.togglebutton19.Visible = 'on'; handles.togglebutton20.Visible = 'on';
        handles.togglebutton21.Visible = 'on'; handles.togglebutton22.Visible = 'on'; handles.togglebutton23.Visible = 'on'; handles.togglebutton24.Visible = 'on'; handles.togglebutton25.Visible = 'on';
        handles.togglebutton26.Visible = 'on'; handles.togglebutton27.Visible = 'on'; handles.togglebutton28.Visible = 'on'; handles.togglebutton29.Visible = 'on'; handles.togglebutton30.Visible = 'on';
        handles.togglebutton31.Visible = 'on'; handles.togglebutton32.Visible = 'on'; handles.togglebutton33.Visible = 'on'; handles.togglebutton34.Visible = 'on'; handles.togglebutton35.Visible = 'on';
        handles.togglebutton36.Visible = 'on'; handles.togglebutton37.Visible = 'on'; handles.togglebutton38.Visible = 'on'; handles.togglebutton39.Visible = 'on'; handles.togglebutton40.Visible = 'on';
        handles.togglebutton41.Visible = 'on'; handles.togglebutton42.Visible = 'on'; handles.togglebutton43.Visible = 'on'; handles.togglebutton44.Visible = 'on'; handles.togglebutton45.Visible = 'on';
        handles.togglebutton46.Visible = 'on'; handles.togglebutton47.Visible = 'on'; handles.togglebutton48.Visible = 'on'; handles.togglebutton49.Visible = 'on'; handles.togglebutton50.Visible = 'on';
        handles.togglebutton51.Visible = 'on'; handles.togglebutton52.Visible = 'on'; handles.togglebutton53.Visible = 'on'; handles.togglebutton54.Visible = 'on'; handles.togglebutton55.Visible = 'on';
        handles.togglebutton56.Visible = 'on'; handles.togglebutton57.Visible = 'on'; handles.togglebutton58.Visible = 'on'; handles.togglebutton59.Visible = 'on'; handles.togglebutton60.Visible = 'on';
        handles.togglebutton61.Visible = 'on'; handles.togglebutton62.Visible = 'on'; handles.togglebutton63.Visible = 'on'; handles.togglebutton64.Visible = 'on'; handles.togglebutton65.Visible = 'on';
        handles.togglebutton66.Visible = 'on'; handles.togglebutton67.Visible = 'on'; handles.togglebutton68.Visible = 'on'; handles.togglebutton69.Visible = 'on'; handles.togglebutton70.Visible = 'on';
        handles.togglebutton71.Visible = 'on'; handles.togglebutton72.Visible = 'on'; handles.togglebutton73.Visible = 'on'; handles.togglebutton74.Visible = 'on'; handles.togglebutton75.Visible = 'on';
        handles.togglebutton76.Visible = 'on'; handles.togglebutton77.Visible = 'on'; handles.togglebutton78.Visible = 'on'; handles.togglebutton79.Visible = 'on'; handles.togglebutton80.Visible = 'on';
        handles.togglebutton81.Visible = 'on'; handles.togglebutton82.Visible = 'on'; handles.togglebutton83.Visible = 'on'; handles.togglebutton84.Visible = 'on'; handles.togglebutton85.Visible = 'on';
        handles.togglebutton86.Visible = 'on'; handles.togglebutton87.Visible = 'on'; handles.togglebutton88.Visible = 'on'; handles.togglebutton89.Visible = 'on'; handles.togglebutton90.Visible = 'on';
        handles.togglebutton91.Visible = 'on'; handles.togglebutton92.Visible = 'on'; handles.togglebutton93.Visible = 'on'; handles.togglebutton94.Visible = 'on'; handles.togglebutton95.Visible = 'on';
        handles.togglebutton96.Visible = 'on'; handles.togglebutton97.Visible = 'on'; handles.togglebutton98.Visible = 'on'; handles.togglebutton99.Visible = 'on'; handles.togglebutton100.Visible = 'on';
        handles.togglebutton101.Visible = 'on'; handles.togglebutton102.Visible = 'on'; handles.togglebutton103.Visible = 'on'; handles.togglebutton104.Visible = 'on'; handles.togglebutton105.Visible = 'on';
        handles.togglebutton106.Visible = 'on'; handles.togglebutton107.Visible = 'on'; handles.togglebutton108.Visible = 'on'; handles.togglebutton109.Visible = 'on'; handles.togglebutton110.Visible = 'on';
        handles.togglebutton111.Visible = 'on'; handles.togglebutton112.Visible = 'on'; handles.togglebutton113.Visible = 'on'; handles.togglebutton114.Visible = 'on'; handles.togglebutton115.Visible = 'on';
        handles.togglebutton116.Visible = 'on'; handles.togglebutton117.Visible = 'on'; handles.togglebutton118.Visible = 'on'; handles.togglebutton119.Visible = 'on'; handles.togglebutton120.Visible = 'on';
        handles.togglebutton121.Visible = 'on'; handles.togglebutton122.Visible = 'on'; handles.togglebutton123.Visible = 'on'; handles.togglebutton124.Visible = 'on'; handles.togglebutton125.Visible = 'on';
        handles.togglebutton126.Visible = 'on'; handles.togglebutton127.Visible = 'on'; handles.togglebutton128.Visible = 'on'; handles.togglebutton129.Visible = 'on'; handles.togglebutton130.Visible = 'on';
        handles.togglebutton131.Visible = 'on'; handles.togglebutton132.Visible = 'on'; handles.togglebutton133.Visible = 'on'; handles.togglebutton134.Visible = 'on'; handles.togglebutton135.Visible = 'on';
        handles.togglebutton136.Visible = 'on'; handles.togglebutton137.Visible = 'on'; handles.togglebutton138.Visible = 'on'; handles.togglebutton139.Visible = 'on'; handles.togglebutton140.Visible = 'on';
        handles.togglebutton141.Visible = 'on'; handles.togglebutton142.Visible = 'on'; handles.togglebutton143.Visible = 'on'; handles.togglebutton144.Visible = 'on'; handles.togglebutton145.Visible = 'on';
        handles.togglebutton146.Visible = 'on'; handles.togglebutton147.Visible = 'on'; handles.togglebutton148.Visible = 'on'; handles.togglebutton149.Visible = 'on'; handles.togglebutton150.Visible = 'on';
        handles.togglebutton151.Visible = 'on'; handles.togglebutton152.Visible = 'on'; handles.togglebutton153.Visible = 'on'; handles.togglebutton154.Visible = 'on'; handles.togglebutton155.Visible = 'on';
        handles.togglebutton156.Visible = 'on'; handles.togglebutton157.Visible = 'on'; handles.togglebutton158.Visible = 'on'; handles.togglebutton159.Visible = 'on'; handles.togglebutton160.Visible = 'on';
        handles.togglebutton161.Visible = 'on'; handles.togglebutton162.Visible = 'on'; handles.togglebutton163.Visible = 'on'; handles.togglebutton164.Visible = 'on'; handles.togglebutton165.Visible = 'on';
        handles.togglebutton166.Visible = 'on'; handles.togglebutton167.Visible = 'on'; handles.togglebutton168.Visible = 'on'; handles.togglebutton169.Visible = 'on'; handles.togglebutton170.Visible = 'on';
        handles.togglebutton171.Visible = 'on'; handles.togglebutton172.Visible = 'on'; handles.togglebutton173.Visible = 'on'; handles.togglebutton174.Visible = 'on'; handles.togglebutton175.Visible = 'on';
        handles.togglebutton176.Visible = 'on'; handles.togglebutton177.Visible = 'on'; handles.togglebutton178.Visible = 'on'; handles.togglebutton179.Visible = 'on'; handles.togglebutton180.Visible = 'on';
        handles.togglebutton181.Visible = 'on'; handles.togglebutton182.Visible = 'on'; handles.togglebutton183.Visible = 'on'; handles.togglebutton184.Visible = 'on'; handles.togglebutton185.Visible = 'on';
        handles.togglebutton186.Visible = 'on'; handles.togglebutton187.Visible = 'on'; handles.togglebutton188.Visible = 'on'; handles.togglebutton189.Visible = 'on'; handles.togglebutton190.Visible = 'on';
        handles.togglebutton191.Visible = 'on'; handles.togglebutton192.Visible = 'on'; handles.togglebutton193.Visible = 'on'; handles.togglebutton194.Visible = 'on'; handles.togglebutton195.Visible = 'on';
        handles.togglebutton196.Visible = 'on'; handles.togglebutton197.Visible = 'on'; handles.togglebutton198.Visible = 'on'; handles.togglebutton199.Visible = 'on'; handles.togglebutton200.Visible = 'on';
        handles.togglebutton201.Visible = 'on'; handles.togglebutton202.Visible = 'on'; handles.togglebutton203.Visible = 'on'; handles.togglebutton204.Visible = 'on'; handles.togglebutton205.Visible = 'on';
        handles.togglebutton206.Visible = 'on'; handles.togglebutton207.Visible = 'on'; handles.togglebutton208.Visible = 'on'; handles.togglebutton209.Visible = 'on'; handles.togglebutton210.Visible = 'on';
        handles.togglebutton211.Visible = 'on'; handles.togglebutton212.Visible = 'on'; handles.togglebutton213.Visible = 'on'; handles.togglebutton214.Visible = 'on'; handles.togglebutton215.Visible = 'on';
        handles.togglebutton216.Visible = 'on'; handles.togglebutton217.Visible = 'on'; handles.togglebutton218.Visible = 'on'; handles.togglebutton219.Visible = 'on'; handles.togglebutton220.Visible = 'on';
        handles.togglebutton221.Visible = 'on'; handles.togglebutton222.Visible = 'on'; handles.togglebutton223.Visible = 'on'; handles.togglebutton224.Visible = 'on'; handles.togglebutton225.Visible = 'on';
        handles.togglebutton226.Visible = 'on'; handles.togglebutton227.Visible = 'on'; handles.togglebutton228.Visible = 'on'; handles.togglebutton229.Visible = 'on'; handles.togglebutton230.Visible = 'on';
        handles.togglebutton231.Visible = 'on'; handles.togglebutton232.Visible = 'on'; handles.togglebutton233.Visible = 'on'; handles.togglebutton234.Visible = 'on'; handles.togglebutton235.Visible = 'on';
        handles.togglebutton236.Visible = 'on'; handles.togglebutton237.Visible = 'on'; handles.togglebutton238.Visible = 'on'; handles.togglebutton239.Visible = 'on'; handles.togglebutton240.Visible = 'on';
        handles.togglebutton241.Visible = 'on'; handles.togglebutton242.Visible = 'on'; handles.togglebutton243.Visible = 'on'; handles.togglebutton244.Visible = 'on'; handles.togglebutton245.Visible = 'on';
        handles.togglebutton246.Visible = 'on'; handles.togglebutton247.Visible = 'on'; handles.togglebutton248.Visible = 'on'; handles.togglebutton249.Visible = 'on'; handles.togglebutton250.Visible = 'on';
        handles.togglebutton251.Visible = 'on'; handles.togglebutton252.Visible = 'on'; handles.togglebutton253.Visible = 'on'; handles.togglebutton254.Visible = 'on'; handles.togglebutton255.Visible = 'on';
        handles.togglebutton256.Visible = 'on'; handles.togglebutton257.Visible = 'on'; handles.togglebutton258.Visible = 'on'; handles.togglebutton259.Visible = 'on'; handles.togglebutton260.Visible = 'on';
        handles.togglebutton261.Visible = 'on'; handles.togglebutton262.Visible = 'on'; handles.togglebutton263.Visible = 'on'; handles.togglebutton264.Visible = 'on'; handles.togglebutton265.Visible = 'on';
        handles.togglebutton266.Visible = 'on'; handles.togglebutton267.Visible = 'on'; handles.togglebutton268.Visible = 'on'; handles.togglebutton269.Visible = 'on'; handles.togglebutton270.Visible = 'on';
        handles.togglebutton271.Visible = 'on'; handles.togglebutton272.Visible = 'on'; handles.togglebutton273.Visible = 'on'; handles.togglebutton274.Visible = 'on'; handles.togglebutton275.Visible = 'on';
        handles.togglebutton276.Visible = 'on'; handles.togglebutton277.Visible = 'on'; handles.togglebutton278.Visible = 'on'; handles.togglebutton279.Visible = 'on'; handles.togglebutton280.Visible = 'on';
        handles.togglebutton281.Visible = 'on'; handles.togglebutton282.Visible = 'on'; handles.togglebutton283.Visible = 'on'; handles.togglebutton284.Visible = 'on'; handles.togglebutton285.Visible = 'on';
        handles.togglebutton286.Visible = 'on'; handles.togglebutton287.Visible = 'on'; handles.togglebutton288.Visible = 'on';
        
    end
    
    
    
    %% panels for connections
    %     handles.Pannel_7.Visibility='off';
    %     handles.Pannel_8.Visibility='off';
    %     handles.Pannel_9.Visibility='off';
    %     handles.Pannel_10.Visibility='off';
    %     handles.Pannel_11.Visibility='off';
    %     handles.Pannel_12.Visibility='off';
    handles.uipanel6.Visible = 'off';
    handles.uipanel7.Visible = 'off';
    handles.uipanel8.Visible = 'off';
    handles.uipanel9.Visible = 'off';
    
    %% panels for bursts
    %     handles.Pannel_13.Visibility='off';
    %     handles.Pannel_14.Visibility='off';
    %     handles.Pannel_15.Visibility='off';
    %     handles.Pannel_16.Visibility='off';
    %     handles.Pannel_17.Visibility='off';
    %     handles.Pannel_18.Visibility='off';
    
    handles.uipanel11.Visible = 'off';
    handles.uipanel12.Visible = 'off';
    handles.uipanel13.Visible = 'off';
    handles.uipanel14.Visible = 'off';
    
elseif hObject.UserData == 2
    %burst section
    handles.pushbutton65.Visible = 'off';
    handles.pushbutton66.Visible = 'off';
    handles.pushbutton67.Visible = 'off';
    handles.pushbutton68.Visible = 'off';
    handles.pushbutton64.Visible ='off';
    handles.pushbutton63.Visible = 'off';
    handles.pushbutton62.Visible = 'off';
    handles.uipanel20.Visible = 'off';
    handles.checkbox3.Visible = 'off';
    handles.pushbutton61.Visible = 'off';
    handles.pushbutton60.Visible ='off';
    handles.checkbox2.Visible = 'off';
    handles.pushbutton34.Visible='off';
    handles.pushbutton37.Visible='off';
    handles.pushbutton33.Visible='off';
    handles.pushbutton32.Visible='off';
    handles.pushbutton28.Visible='off';
    handles.pushbutton31.Visible='off';
    handles.pushbutton26.Visible='off';
    handles.pushbutton24.Visible='off';
    handles.pushbutton23.Visible='off';
    handles.pushbutton18.Visible='off';
    handles.pushbutton17.Visible='off';
    handles.pushbutton16.Visible='off';
    handles.pushbutton15.Visible='off';
    handles.pushbutton14.Visible='off';
    handles.pushbutton12.Visible='off';
    handles.pushbutton10.Visible='off';
    handles.pushbutton8.Visible='off';
    handles.pushbutton6.Visible='off';
    handles.pushbutton3.Visible='off';
    handles.pushbutton2.Visible='off';
    handles.pushbutton1.Visible='off';
    handles.pushbutton38.Visible = 'off';
    handles.pushbutton39.Visible = 'off';
    handles.pushbutton42.Visible = 'on';
    handles.pushbutton43.Visible = 'off';
    handles.pushbutton44.Visible = 'off';
    handles.pushbutton45.Visible = 'off';
    handles.pushbutton46.Visible = 'off';
    handles.pushbutton47.Visible = 'off';
    handles.pushbutton48.Visible = 'off';
    handles.pushbutton58.Visible = 'off';
    handles.pushbutton41.Visible = 'off';
    
    handles1.Figures.Clusters.stability.Visible = 'off';
    handles1.Figures.Waveforms.unsortedspikes.Visible = 'off';
    handles1.Figures.Waveforms.UnsortedPanel.Visible = 'off';
    handles1.Figures.Waveforms.RunSortingAllchs.Visible = 'off';
    handles1.Figures.Waveforms.DispClustersTOGGLE.Visible = 'off';
    handles1.Figures.Waveforms.runSorting.Visible = 'off';
    handles1.Figures.Waveforms.ch_id.Visible = 'off';
    handles1.Figures.Clusters.stability.Visible = 'off';
    handles1.Figures.Waveforms.maintext.Visible = 'off';
    handles1.Figures.Waveforms.LoadData.Visible ='off';
    handles1.Figures.Waveforms.SaveData.Visible='off';
    handles1.Figures.Waveforms.filename.Visible = 'off';
    handles1.Figures.Waveforms.resetSorting.Visible = 'off';
    handles1.Figures.Waveforms.EditUnsorted.Visible = 'off';
    handles1.Figures.Waveforms.DiscardUnsorted.Visible = 'off';
    handles1.Figures.Waveforms.PlotAllTOGGLE.Visible = 'off';
    
    if isfield(handles1.Figures.Clusters,'viewspikesList') && clustertag == 1
        handles1.Figures.Clusters.viewspikesList.Visible = 'off';
        handles1.Figures.Clusters.changemodeBUTTON.Visible = 'off';
        handles1.Figures.Clusters.recalculateButton.Visible = 'off';
        handles1.Figures.Clusters.deleteButton.Visible = 'off';
    end
    
    for i = 1:length( handles1.Figures.Waveforms.cluster)
        handles1.Figures.Waveforms.cluster{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterNUMB)
        handles1.Figures.Waveforms.clusterNUMB{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterPOPUP)
        handles1.Figures.Waveforms.clusterPOPUP{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterTOGGLE)
        handles1.Figures.Waveforms.clusterTOGGLE{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.delBUTTON)
        handles1.Figures.Waveforms.delBUTTON{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.ch_id_txtbox)
        handles1.Figures.Waveforms.ch_id_txtbox(i).Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.ch_id_txtbox)
        handles1.Figures.Waveforms.ch_id_txtbox(i).Visible = 'off';
    end
    
    handles.Toggle_J12.Visible='off';
    handles.Toggle_H12.Visible='off';
    handles.Toggle_G12.Visible='off';
    handles.Toggle_F12.Visible='off';
    handles.Toggle_E12.Visible='off';
    handles.Toggle_D12.Visible='off';
    handles.Toggle_K11.Visible='off';
    handles.Toggle_J11.Visible='off';
    handles.Toggle_H11.Visible='off';
    handles.Toggle_G11.Visible='off';
    handles.Toggle_F11.Visible='off';
    handles.Toggle_E11.Visible='off';
    handles.Toggle_D11.Visible='off';
    handles.Toggle_C11.Visible='off';
    handles.Toggle_L10.Visible='off';
    handles.Toggle_K10.Visible='off';
    handles.Toggle_J10.Visible='off';
    handles.Toggle_H10.Visible='off';
    handles.Toggle_G10.Visible='off';
    handles.Toggle_F10.Visible='off';
    handles.Toggle_E10.Visible='off';
    handles.Toggle_D10.Visible='off';
    handles.Toggle_C10.Visible='off';
    handles.Toggle_B10.Visible='off';
    handles.Toggle_M9.Visible='off';
    handles.Toggle_L9.Visible='off';
    handles.Toggle_K9.Visible='off';
    handles.Toggle_J9.Visible='off';
    handles.Toggle_H9.Visible='off';
    handles.Toggle_G9.Visible='off';
    handles.Toggle_F9.Visible='off';
    handles.Toggle_E9.Visible='off';
    handles.Toggle_D9.Visible='off';
    handles.Toggle_C9.Visible='off';
    handles.Toggle_B9.Visible='off';
    handles.Toggle_A9.Visible='off';
    handles.Toggle_M8.Visible='off';
    handles.Toggle_L8.Visible='off';
    handles.Toggle_K8.Visible='off';
    handles.Toggle_J8.Visible='off';
    handles.Toggle_H8.Visible='off';
    handles.Toggle_G8.Visible='off';
    handles.Toggle_F8.Visible='off';
    handles.Toggle_E8.Visible='off';
    handles.Toggle_D8.Visible='off';
    handles.Toggle_C8.Visible='off';
    handles.Toggle_B8.Visible='off';
    handles.Toggle_A8.Visible='off';
    handles.Toggle_M7.Visible='off';
    handles.Toggle_L7.Visible='off';
    handles.Toggle_K7.Visible='off';
    handles.Toggle_J7.Visible='off';
    handles.Toggle_H7.Visible='off';
    handles.Toggle_G7.Visible='off';
    handles.Toggle_F7.Visible='off';
    handles.Toggle_E7.Visible='off';
    handles.Toggle_D7.Visible='off';
    handles.Toggle_C7.Visible='off';
    handles.Toggle_B7.Visible='off';
    handles.Toggle_A7.Visible='off';
    handles.Toggle_M6.Visible='off';
    handles.Toggle_L6.Visible='off';
    handles.Toggle_K6.Visible='off';
    handles.Toggle_J6.Visible='off';
    handles.Toggle_H6.Visible='off';
    handles.Toggle_G6.Visible='off';
    handles.Toggle_F6.Visible='off';
    handles.Toggle_E6.Visible='off';
    handles.Toggle_D6.Visible='off';
    handles.Toggle_C6.Visible='off';
    handles.Toggle_B6.Visible='off';
    handles.Toggle_A6.Visible='off';
    handles.Toggle_M5.Visible='off';
    handles.Toggle_L5.Visible='off';
    handles.Toggle_K5.Visible='off';
    handles.Toggle_J5.Visible='off';
    handles.Toggle_H5.Visible='off';
    handles.Toggle_G5.Visible='off';
    handles.Toggle_F5.Visible='off';
    handles.Toggle_E5.Visible='off';
    handles.Toggle_D5.Visible='off';
    handles.Toggle_C5.Visible='off';
    handles.Toggle_B5.Visible='off';
    handles.Toggle_A5.Visible='off';
    handles.Toggle_M4.Visible='off';
    handles.Toggle_L4.Visible='off';
    handles.Toggle_K4.Visible='off';
    handles.Toggle_J4.Visible='off';
    handles.Toggle_H4.Visible='off';
    handles.Toggle_G4.Visible='off';
    handles.Toggle_F4.Visible='off';
    handles.Toggle_E4.Visible='off';
    handles.Toggle_D4.Visible='off';
    handles.Toggle_C4.Visible='off';
    handles.Toggle_B4.Visible='off';
    handles.Toggle_A4.Visible='off';
    handles.Toggle_L3.Visible='off';
    handles.Toggle_K3.Visible='off';
    handles.Toggle_J3.Visible='off';
    handles.Toggle_H3.Visible='off';
    handles.Toggle_G3.Visible='off';
    handles.Toggle_F3.Visible='off';
    handles.Toggle_E3.Visible='off';
    handles.Toggle_D3.Visible='off';
    handles.Toggle_C3.Visible='off';
    handles.Toggle_B3.Visible='off';
    handles.Toggle_K2.Visible='off';
    handles.Toggle_J2.Visible='off';
    handles.Toggle_H2.Visible='off';
    handles.Toggle_G2.Visible='off';
    handles.Toggle_F2.Visible='off';
    handles.Toggle_E2.Visible='off';
    handles.Toggle_D2.Visible='off';
    handles.Toggle_C2.Visible='off';
    handles.Toggle_J1.Visible='off';
    handles.Toggle_H1.Visible='off';
    handles.Toggle_G1.Visible='off';
    handles.Toggle_F1.Visible='off';
    handles.Toggle_E1.Visible='off';
    handles.Toggle_D1.Visible='off';
    
    handles.Pannel_2.Visibility='off';
    handles.Pannel_1.Visibility='off';
    handles.Pannel_3.Visibility='off';
    handles.Pannel_4.Visibility='off';
    handles.Pannel_5.Visibility='off';
    handles.Pannel_6.Visibility='off';
    handles.Pannel_7.Visibility='on';
    handles.Pannel_8.Visibility='off';
    handles.Pannel_9.Visibility='off';
    handles.Pannel_10.Visibility='off';
    handles.Pannel_11.Visibility='off';
    handles.Pannel_12.Visibility='off';
    
    handles.Pannel_13.Visibility='off';
    handles.Pannel_14.Visibility='off';
    handles.Pannel_15.Visibility='off';
    handles.Pannel_16.Visibility='off';
    handles.Pannel_17.Visibility='off';
    handles.Pannel_18.Visibility='off';
    handles.Pannel_25.Visibility='on';
    handles.Pannel_26.Visibility='on';
    handles.Pannel_27.Visibility='on';
    handles.Pannel_28.Visibility='on';
    handles.Pannel_29.Visibility='on';
    handles.Pannel_30.Visibility='on';
    
    %     h.Visible = 'on';
    
    handles.uitable10.Visible='off';
    
    handles.text5.Visible='off';
    handles.text8.Visible='off';
    handles.text10.Visible='off';
    handles.text9.Visible='off';
    handles.text3.Visible='off';
    handles.text18.Visible='off';
    handles.text82.Visible='off';
    handles.text83.Visible='off';
    handles.text84.Visible='off';
    
    handles.uipanel4.Visible='off';
    handles.uipanel3.Visible='off';
    handles.uipanel2.Visible='off';
    handles.uipanel6.Visible = 'off';
    handles.uipanel7.Visible = 'off';
    handles.uipanel8.Visible = 'off';
    handles.uipanel9.Visible = 'off';
    handles.uipanel11.Visible = 'on'; % filtered channel
    
    handles.uipanel12.Visible = 'on';  % max interval
    handles.uipanel13.Visible = 'off';  % log ISI
    handles.uipanel14.Visible = 'off';  % BD
    handles.uipanel15.Visible = 'off';
    handles.uipanel16.Visible = 'off';
    handles.uipanel17.Visible = 'off';
    handles.uipanel18.Visible = 'off';
    
    
    % for multiwell
    if multiwell1 == 1
         handles.text43.Visible ='off';
        handles.popupmenu1.Visible = 'off';
        handles.Pannel_2.Visibility='off';
        handles.Pannel_1.Visibility='off';
        handles.Pannel_3.Visibility='off';
        handles.Pannel_4.Visibility='off';
        handles.Pannel_5.Visibility='off';
        handles.Pannel_6.Visibility='off';
        handles.Pannel_7.Visibility='on';
        handles.Pannel_8.Visibility='off';
        handles.Pannel_9.Visibility='off';
        handles.Pannel_10.Visibility='off';
        handles.Pannel_11.Visibility='off';
        handles.Pannel_12.Visibility='off';
        handles.Pannel_13.Visibility='off';
        handles.Pannel_14.Visibility='off';
        handles.Pannel_15.Visibility='off';
        handles.Pannel_16.Visibility='off';
        handles.Pannel_17.Visibility='off';
        handles.Pannel_18.Visibility='off';
        handles.Pannel_25.Visibility='on';
        handles.Pannel_26.Visibility='on';
        handles.Pannel_27.Visibility='on';
        handles.Pannel_28.Visibility='on';
        handles.Pannel_29.Visibility='on';
        handles.Pannel_30.Visibility='on';
        
        handles.uipanel4.Visible='off';
        handles.uipanel3.Visible='off';
        handles.uipanel2.Visible='off';
        handles.uipanel6.Visible = 'off';
        handles.uipanel7.Visible = 'off';
        handles.uipanel8.Visible = 'off';
        handles.uipanel9.Visible = 'off';
        handles.uipanel11.Visible = 'on'; % filtered channel
        handles.uipanel12.Visible = 'on';  % max interval
        handles.uipanel13.Visible = 'off';  % log ISI
        handles.uipanel14.Visible = 'off';  % BD
        handles.uipanel15.Visible = 'off';
        handles.uipanel16.Visible = 'off';
        handles.uipanel17.Visible = 'off';
        handles.uipanel18.Visible = 'off';
        
        handles.pushbutton368.Visible = 'off';
        handles.pushbutton371.Visible = 'off';
        handles.pushbutton370.Visible = 'off';
        handles.pushbutton366.Visible = 'off';
        handles.pushbutton364.Visible = 'off';
        handles.pushbutton367.Visible = 'off';
        handles.pushbutton380.Visible = 'off';
        handles.pushbutton377.Visible = 'off';
        handles.pushbutton376.Visible = 'off';
        handles.pushbutton365.Visible = 'off';
        handles.pushbutton372.Visible = 'off';
        handles.pushbutton373.Visible = 'off';
        handles.pushbutton383.Visible = 'off';
        handles.pushbutton374.Visible = 'off';
        handles.pushbutton384.Visible = 'off';
        handles.pushbutton381.Visible = 'off';
        handles.pushbutton375.Visible = 'off';
        handles.pushbutton382.Visible = 'off';
        handles.pushbutton388.Visible = 'on';
        handles.pushbutton402.Visible = 'off';
        handles.pushbutton403.Visible = 'off';
        handles.pushbutton404.Visible = 'off';
        handles.pushbutton405.Visible = 'off';
        handles.pushbutton406.Visible = 'off';
        handles.pushbutton407.Visible = 'off';
        handles.pushbutton408.Visible = 'off';
        handles.pushbutton409.Visible = 'off';
        handles.pushbutton410.Visible = 'off';
        handles.pushbutton411.Visible = 'off';
        handles.pushbutton412.Visible = 'off';
        handles.pushbutton413.Visible = 'off';
        handles.pushbutton414.Visible = 'off';
        handles.pushbutton415.Visible = 'off';
        handles.pushbutton416.Visible = 'off';
        handles.pushbutton417.Visible = 'off';
        handles.pushbutton418.Visible = 'off';
        handles.pushbutton419.Visible = 'off';
        handles.pushbutton420.Visible = 'off';
        handles.pushbutton421.Visible = 'off';
        handles.pushbutton422.Visible = 'off';
        handles.pushbutton423.Visible = 'off';
        handles.pushbutton424.Visible = 'off';
        handles.pushbutton425.Visible = 'off';
        
        
        handles.text2.Visible = 'off';  handles.text3.Visible = 'off';  handles.text4.Visible = 'off';  handles.text5.Visible = 'off';  handles.text6.Visible = 'off';
        handles.text7.Visible = 'off';  handles.text8.Visible = 'off';  handles.text9.Visible = 'off';  handles.text10.Visible = 'off';  handles.text11.Visible = 'off';
        handles.text12.Visible = 'off';  handles.text13.Visible = 'off';  handles.text14.Visible = 'off';  handles.text15.Visible = 'off';  handles.text16.Visible = 'off';
        handles.text17.Visible = 'off';  handles.text18.Visible = 'off';  handles.text19.Visible = 'off';  handles.text20.Visible = 'off';  handles.text21.Visible = 'off';
        handles.text22.Visible = 'off';  handles.text23.Visible = 'off';  handles.text24.Visible = 'off';  handles.text25.Visible = 'off';  handles.text26.Visible = 'off';
        handles.text27.Visible = 'off';  handles.text28.Visible = 'off';  handles.text29.Visible = 'off';  handles.text30.Visible = 'off';
        
        handles.uitable1.Visible = 'off';
        handles.uitable10.Visible='off';
        handles.checkbox4.Visible ='off';
        handles.togglebutton1.Visible = 'off'; handles.togglebutton2.Visible = 'off'; handles.togglebutton3.Visible = 'off'; handles.togglebutton4.Visible = 'off'; handles.togglebutton5.Visible = 'off';
        handles.togglebutton6.Visible = 'off'; handles.togglebutton7.Visible = 'off'; handles.togglebutton8.Visible = 'off'; handles.togglebutton9.Visible = 'off'; handles.togglebutton10.Visible = 'off';
        handles.togglebutton11.Visible = 'off'; handles.togglebutton12.Visible = 'off'; handles.togglebutton13.Visible = 'off'; handles.togglebutton14.Visible = 'off'; handles.togglebutton15.Visible = 'off';
        handles.togglebutton16.Visible = 'off'; handles.togglebutton17.Visible = 'off'; handles.togglebutton18.Visible = 'off'; handles.togglebutton19.Visible = 'off'; handles.togglebutton20.Visible = 'off';
        handles.togglebutton21.Visible = 'off'; handles.togglebutton22.Visible = 'off'; handles.togglebutton23.Visible = 'off'; handles.togglebutton24.Visible = 'off'; handles.togglebutton25.Visible = 'off';
        handles.togglebutton26.Visible = 'off'; handles.togglebutton27.Visible = 'off'; handles.togglebutton28.Visible = 'off'; handles.togglebutton29.Visible = 'off'; handles.togglebutton30.Visible = 'off';
        handles.togglebutton31.Visible = 'off'; handles.togglebutton32.Visible = 'off'; handles.togglebutton33.Visible = 'off'; handles.togglebutton34.Visible = 'off'; handles.togglebutton35.Visible = 'off';
        handles.togglebutton36.Visible = 'off'; handles.togglebutton37.Visible = 'off'; handles.togglebutton38.Visible = 'off'; handles.togglebutton39.Visible = 'off'; handles.togglebutton40.Visible = 'off';
        handles.togglebutton41.Visible = 'off'; handles.togglebutton42.Visible = 'off'; handles.togglebutton43.Visible = 'off'; handles.togglebutton44.Visible = 'off'; handles.togglebutton45.Visible = 'off';
        handles.togglebutton46.Visible = 'off'; handles.togglebutton47.Visible = 'off'; handles.togglebutton48.Visible = 'off'; handles.togglebutton49.Visible = 'off'; handles.togglebutton50.Visible = 'off';
        handles.togglebutton51.Visible = 'off'; handles.togglebutton52.Visible = 'off'; handles.togglebutton53.Visible = 'off'; handles.togglebutton54.Visible = 'off'; handles.togglebutton55.Visible = 'off';
        handles.togglebutton56.Visible = 'off'; handles.togglebutton57.Visible = 'off'; handles.togglebutton58.Visible = 'off'; handles.togglebutton59.Visible = 'off'; handles.togglebutton60.Visible = 'off';
        handles.togglebutton61.Visible = 'off'; handles.togglebutton62.Visible = 'off'; handles.togglebutton63.Visible = 'off'; handles.togglebutton64.Visible = 'off'; handles.togglebutton65.Visible = 'off';
        handles.togglebutton66.Visible = 'off'; handles.togglebutton67.Visible = 'off'; handles.togglebutton68.Visible = 'off'; handles.togglebutton69.Visible = 'off'; handles.togglebutton70.Visible = 'off';
        handles.togglebutton71.Visible = 'off'; handles.togglebutton72.Visible = 'off'; handles.togglebutton73.Visible = 'off'; handles.togglebutton74.Visible = 'off'; handles.togglebutton75.Visible = 'off';
        handles.togglebutton76.Visible = 'off'; handles.togglebutton77.Visible = 'off'; handles.togglebutton78.Visible = 'off'; handles.togglebutton79.Visible = 'off'; handles.togglebutton80.Visible = 'off';
        handles.togglebutton81.Visible = 'off'; handles.togglebutton82.Visible = 'off'; handles.togglebutton83.Visible = 'off'; handles.togglebutton84.Visible = 'off'; handles.togglebutton85.Visible = 'off';
        handles.togglebutton86.Visible = 'off'; handles.togglebutton87.Visible = 'off'; handles.togglebutton88.Visible = 'off'; handles.togglebutton89.Visible = 'off'; handles.togglebutton90.Visible = 'off';
        handles.togglebutton91.Visible = 'off'; handles.togglebutton92.Visible = 'off'; handles.togglebutton93.Visible = 'off'; handles.togglebutton94.Visible = 'off'; handles.togglebutton95.Visible = 'off';
        handles.togglebutton96.Visible = 'off'; handles.togglebutton97.Visible = 'off'; handles.togglebutton98.Visible = 'off'; handles.togglebutton99.Visible = 'off'; handles.togglebutton100.Visible = 'off';
        handles.togglebutton101.Visible = 'off'; handles.togglebutton102.Visible = 'off'; handles.togglebutton103.Visible = 'off'; handles.togglebutton104.Visible = 'off'; handles.togglebutton105.Visible = 'off';
        handles.togglebutton106.Visible = 'off'; handles.togglebutton107.Visible = 'off'; handles.togglebutton108.Visible = 'off'; handles.togglebutton109.Visible = 'off'; handles.togglebutton110.Visible = 'off';
        handles.togglebutton111.Visible = 'off'; handles.togglebutton112.Visible = 'off'; handles.togglebutton113.Visible = 'off'; handles.togglebutton114.Visible = 'off'; handles.togglebutton115.Visible = 'off';
        handles.togglebutton116.Visible = 'off'; handles.togglebutton117.Visible = 'off'; handles.togglebutton118.Visible = 'off'; handles.togglebutton119.Visible = 'off'; handles.togglebutton120.Visible = 'off';
        handles.togglebutton121.Visible = 'off'; handles.togglebutton122.Visible = 'off'; handles.togglebutton123.Visible = 'off'; handles.togglebutton124.Visible = 'off'; handles.togglebutton125.Visible = 'off';
        handles.togglebutton126.Visible = 'off'; handles.togglebutton127.Visible = 'off'; handles.togglebutton128.Visible = 'off'; handles.togglebutton129.Visible = 'off'; handles.togglebutton130.Visible = 'off';
        handles.togglebutton131.Visible = 'off'; handles.togglebutton132.Visible = 'off'; handles.togglebutton133.Visible = 'off'; handles.togglebutton134.Visible = 'off'; handles.togglebutton135.Visible = 'off';
        handles.togglebutton136.Visible = 'off'; handles.togglebutton137.Visible = 'off'; handles.togglebutton138.Visible = 'off'; handles.togglebutton139.Visible = 'off'; handles.togglebutton140.Visible = 'off';
        handles.togglebutton141.Visible = 'off'; handles.togglebutton142.Visible = 'off'; handles.togglebutton143.Visible = 'off'; handles.togglebutton144.Visible = 'off'; handles.togglebutton145.Visible = 'off';
        handles.togglebutton146.Visible = 'off'; handles.togglebutton147.Visible = 'off'; handles.togglebutton148.Visible = 'off'; handles.togglebutton149.Visible = 'off'; handles.togglebutton150.Visible = 'off';
        handles.togglebutton151.Visible = 'off'; handles.togglebutton152.Visible = 'off'; handles.togglebutton153.Visible = 'off'; handles.togglebutton154.Visible = 'off'; handles.togglebutton155.Visible = 'off';
        handles.togglebutton156.Visible = 'off'; handles.togglebutton157.Visible = 'off'; handles.togglebutton158.Visible = 'off'; handles.togglebutton159.Visible = 'off'; handles.togglebutton160.Visible = 'off';
        handles.togglebutton161.Visible = 'off'; handles.togglebutton162.Visible = 'off'; handles.togglebutton163.Visible = 'off'; handles.togglebutton164.Visible = 'off'; handles.togglebutton165.Visible = 'off';
        handles.togglebutton166.Visible = 'off'; handles.togglebutton167.Visible = 'off'; handles.togglebutton168.Visible = 'off'; handles.togglebutton169.Visible = 'off'; handles.togglebutton170.Visible = 'off';
        handles.togglebutton171.Visible = 'off'; handles.togglebutton172.Visible = 'off'; handles.togglebutton173.Visible = 'off'; handles.togglebutton174.Visible = 'off'; handles.togglebutton175.Visible = 'off';
        handles.togglebutton176.Visible = 'off'; handles.togglebutton177.Visible = 'off'; handles.togglebutton178.Visible = 'off'; handles.togglebutton179.Visible = 'off'; handles.togglebutton180.Visible = 'off';
        handles.togglebutton181.Visible = 'off'; handles.togglebutton182.Visible = 'off'; handles.togglebutton183.Visible = 'off'; handles.togglebutton184.Visible = 'off'; handles.togglebutton185.Visible = 'off';
        handles.togglebutton186.Visible = 'off'; handles.togglebutton187.Visible = 'off'; handles.togglebutton188.Visible = 'off'; handles.togglebutton189.Visible = 'off'; handles.togglebutton190.Visible = 'off';
        handles.togglebutton191.Visible = 'off'; handles.togglebutton192.Visible = 'off'; handles.togglebutton193.Visible = 'off'; handles.togglebutton194.Visible = 'off'; handles.togglebutton195.Visible = 'off';
        handles.togglebutton196.Visible = 'off'; handles.togglebutton197.Visible = 'off'; handles.togglebutton198.Visible = 'off'; handles.togglebutton199.Visible = 'off'; handles.togglebutton200.Visible = 'off';
        handles.togglebutton201.Visible = 'off'; handles.togglebutton202.Visible = 'off'; handles.togglebutton203.Visible = 'off'; handles.togglebutton204.Visible = 'off'; handles.togglebutton205.Visible = 'off';
        handles.togglebutton206.Visible = 'off'; handles.togglebutton207.Visible = 'off'; handles.togglebutton208.Visible = 'off'; handles.togglebutton209.Visible = 'off'; handles.togglebutton210.Visible = 'off';
        handles.togglebutton211.Visible = 'off'; handles.togglebutton212.Visible = 'off'; handles.togglebutton213.Visible = 'off'; handles.togglebutton214.Visible = 'off'; handles.togglebutton215.Visible = 'off';
        handles.togglebutton216.Visible = 'off'; handles.togglebutton217.Visible = 'off'; handles.togglebutton218.Visible = 'off'; handles.togglebutton219.Visible = 'off'; handles.togglebutton220.Visible = 'off';
        handles.togglebutton221.Visible = 'off'; handles.togglebutton222.Visible = 'off'; handles.togglebutton223.Visible = 'off'; handles.togglebutton224.Visible = 'off'; handles.togglebutton225.Visible = 'off';
        handles.togglebutton226.Visible = 'off'; handles.togglebutton227.Visible = 'off'; handles.togglebutton228.Visible = 'off'; handles.togglebutton229.Visible = 'off'; handles.togglebutton230.Visible = 'off';
        handles.togglebutton231.Visible = 'off'; handles.togglebutton232.Visible = 'off'; handles.togglebutton233.Visible = 'off'; handles.togglebutton234.Visible = 'off'; handles.togglebutton235.Visible = 'off';
        handles.togglebutton236.Visible = 'off'; handles.togglebutton237.Visible = 'off'; handles.togglebutton238.Visible = 'off'; handles.togglebutton239.Visible = 'off'; handles.togglebutton240.Visible = 'off';
        handles.togglebutton241.Visible = 'off'; handles.togglebutton242.Visible = 'off'; handles.togglebutton243.Visible = 'off'; handles.togglebutton244.Visible = 'off'; handles.togglebutton245.Visible = 'off';
        handles.togglebutton246.Visible = 'off'; handles.togglebutton247.Visible = 'off'; handles.togglebutton248.Visible = 'off'; handles.togglebutton249.Visible = 'off'; handles.togglebutton250.Visible = 'off';
        handles.togglebutton251.Visible = 'off'; handles.togglebutton252.Visible = 'off'; handles.togglebutton253.Visible = 'off'; handles.togglebutton254.Visible = 'off'; handles.togglebutton255.Visible = 'off';
        handles.togglebutton256.Visible = 'off'; handles.togglebutton257.Visible = 'off'; handles.togglebutton258.Visible = 'off'; handles.togglebutton259.Visible = 'off'; handles.togglebutton260.Visible = 'off';
        handles.togglebutton261.Visible = 'off'; handles.togglebutton262.Visible = 'off'; handles.togglebutton263.Visible = 'off'; handles.togglebutton264.Visible = 'off'; handles.togglebutton265.Visible = 'off';
        handles.togglebutton266.Visible = 'off'; handles.togglebutton267.Visible = 'off'; handles.togglebutton268.Visible = 'off'; handles.togglebutton269.Visible = 'off'; handles.togglebutton270.Visible = 'off';
        handles.togglebutton271.Visible = 'off'; handles.togglebutton272.Visible = 'off'; handles.togglebutton273.Visible = 'off'; handles.togglebutton274.Visible = 'off'; handles.togglebutton275.Visible = 'off';
        handles.togglebutton276.Visible = 'off'; handles.togglebutton277.Visible = 'off'; handles.togglebutton278.Visible = 'off'; handles.togglebutton279.Visible = 'off'; handles.togglebutton280.Visible = 'off';
        handles.togglebutton281.Visible = 'off'; handles.togglebutton282.Visible = 'off'; handles.togglebutton283.Visible = 'off'; handles.togglebutton284.Visible = 'off'; handles.togglebutton285.Visible = 'off';
        handles.togglebutton286.Visible = 'off'; handles.togglebutton287.Visible = 'off'; handles.togglebutton288.Visible = 'off';
        
    end
    
    
    
    % connections panel
elseif hObject.UserData == 3
    handles.pushbutton65.Visible = 'off';
    handles.pushbutton66.Visible = 'off';
    handles.pushbutton67.Visible = 'off';
    handles.pushbutton68.Visible = 'off';
    handles.pushbutton64.Visible ='off';
    handles.pushbutton63.Visible = 'off';
    handles.pushbutton62.Visible = 'off';
    handles.uipanel20.Visible = 'off';
    handles.checkbox3.Visible = 'off';
    handles.pushbutton61.Visible = 'off';
    handles.pushbutton60.Visible ='off';
    handles.checkbox2.Visible = 'off';
    handles.pushbutton34.Visible='off';
    handles.pushbutton37.Visible='off';
    handles.pushbutton33.Visible='off';
    handles.pushbutton32.Visible='off';
    handles.pushbutton28.Visible='off';
    handles.pushbutton31.Visible='off';
    handles.pushbutton26.Visible='off';
    handles.pushbutton24.Visible='off';
    handles.pushbutton23.Visible='off';
    handles.pushbutton18.Visible='off';
    handles.pushbutton17.Visible='off';
    handles.pushbutton16.Visible='off';
    handles.pushbutton15.Visible='off';
    handles.pushbutton14.Visible='off';
    handles.pushbutton12.Visible='off';
    handles.pushbutton10.Visible='off';
    handles.pushbutton8.Visible='off';
    handles.pushbutton6.Visible='off';
    handles.pushbutton3.Visible='off';
    handles.pushbutton2.Visible='off';
    handles.pushbutton1.Visible='off';
    handles.pushbutton38.Visible = 'on';
    handles.pushbutton39.Visible = 'off';
    handles.pushbutton41.Visible = 'off';
    handles.pushbutton42.Visible = 'off';
    handles.pushbutton43.Visible = 'off';
    handles.pushbutton44.Visible = 'off';
    handles.pushbutton45.Visible = 'off';
    handles.pushbutton46.Visible = 'off';
    handles.pushbutton47.Visible = 'off';
    handles.pushbutton48.Visible = 'off';
    handles.pushbutton58.Visible = 'off';
    
    handles1.Figures.Clusters.stability.Visible = 'off';
    handles1.Figures.Waveforms.unsortedspikes.Visible = 'off';
    handles1.Figures.Waveforms.UnsortedPanel.Visible = 'off';
    handles1.Figures.Waveforms.RunSortingAllchs.Visible = 'off';
    handles1.Figures.Waveforms.DispClustersTOGGLE.Visible = 'off';
    handles1.Figures.Waveforms.runSorting.Visible = 'off';
    handles1.Figures.Waveforms.ch_id.Visible = 'off';
    handles1.Figures.Clusters.stability.Visible = 'off';
    handles1.Figures.Waveforms.maintext.Visible = 'off';
    handles1.Figures.Waveforms.LoadData.Visible ='off';
    handles1.Figures.Waveforms.SaveData.Visible = 'off';
    handles1.Figures.Waveforms.filename.Visible = 'off';
    handles1.Figures.Waveforms.resetSorting.Visible = 'off';
    handles1.Figures.Waveforms.EditUnsorted.Visible = 'off';
    handles1.Figures.Waveforms.DiscardUnsorted.Visible = 'off';
    handles1.Figures.Waveforms.PlotAllTOGGLE.Visible = 'off';
    
    if  isfield(handles1.Figures.Clusters,'viewspikesList') && clustertag == 1
        handles1.Figures.Clusters.viewspikesList.Visible = 'off';
        handles1.Figures.Clusters.changemodeBUTTON.Visible = 'off';
        handles1.Figures.Clusters.recalculateButton.Visible = 'off';
        handles1.Figures.Clusters.deleteButton.Visible = 'off';
    end
    
    
    for i = 1:length( handles1.Figures.Waveforms.cluster)
        handles1.Figures.Waveforms.cluster{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterNUMB)
        handles1.Figures.Waveforms.clusterNUMB{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterPOPUP)
        handles1.Figures.Waveforms.clusterPOPUP{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterTOGGLE)
        handles1.Figures.Waveforms.clusterTOGGLE{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.delBUTTON)
        handles1.Figures.Waveforms.delBUTTON{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.ch_id_txtbox)
        handles1.Figures.Waveforms.ch_id_txtbox(i).Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.ch_id_txtbox)
        handles1.Figures.Waveforms.ch_id_txtbox(i).Visible = 'off';
    end
    
    handles.Toggle_J12.Visible='off';
    handles.Toggle_H12.Visible='off';
    handles.Toggle_G12.Visible='off';
    handles.Toggle_F12.Visible='off';
    handles.Toggle_E12.Visible='off';
    handles.Toggle_D12.Visible='off';
    handles.Toggle_K11.Visible='off';
    handles.Toggle_J11.Visible='off';
    handles.Toggle_H11.Visible='off';
    handles.Toggle_G11.Visible='off';
    handles.Toggle_F11.Visible='off';
    handles.Toggle_E11.Visible='off';
    handles.Toggle_D11.Visible='off';
    handles.Toggle_C11.Visible='off';
    handles.Toggle_L10.Visible='off';
    handles.Toggle_K10.Visible='off';
    handles.Toggle_J10.Visible='off';
    handles.Toggle_H10.Visible='off';
    handles.Toggle_G10.Visible='off';
    handles.Toggle_F10.Visible='off';
    handles.Toggle_E10.Visible='off';
    handles.Toggle_D10.Visible='off';
    handles.Toggle_C10.Visible='off';
    handles.Toggle_B10.Visible='off';
    handles.Toggle_M9.Visible='off';
    handles.Toggle_L9.Visible='off';
    handles.Toggle_K9.Visible='off';
    handles.Toggle_J9.Visible='off';
    handles.Toggle_H9.Visible='off';
    handles.Toggle_G9.Visible='off';
    handles.Toggle_F9.Visible='off';
    handles.Toggle_E9.Visible='off';
    handles.Toggle_D9.Visible='off';
    handles.Toggle_C9.Visible='off';
    handles.Toggle_B9.Visible='off';
    handles.Toggle_A9.Visible='off';
    handles.Toggle_M8.Visible='off';
    handles.Toggle_L8.Visible='off';
    handles.Toggle_K8.Visible='off';
    handles.Toggle_J8.Visible='off';
    handles.Toggle_H8.Visible='off';
    handles.Toggle_G8.Visible='off';
    handles.Toggle_F8.Visible='off';
    handles.Toggle_E8.Visible='off';
    handles.Toggle_D8.Visible='off';
    handles.Toggle_C8.Visible='off';
    handles.Toggle_B8.Visible='off';
    handles.Toggle_A8.Visible='off';
    handles.Toggle_M7.Visible='off';
    handles.Toggle_L7.Visible='off';
    handles.Toggle_K7.Visible='off';
    handles.Toggle_J7.Visible='off';
    handles.Toggle_H7.Visible='off';
    handles.Toggle_G7.Visible='off';
    handles.Toggle_F7.Visible='off';
    handles.Toggle_E7.Visible='off';
    handles.Toggle_D7.Visible='off';
    handles.Toggle_C7.Visible='off';
    handles.Toggle_B7.Visible='off';
    handles.Toggle_A7.Visible='off';
    handles.Toggle_M6.Visible='off';
    handles.Toggle_L6.Visible='off';
    handles.Toggle_K6.Visible='off';
    handles.Toggle_J6.Visible='off';
    handles.Toggle_H6.Visible='off';
    handles.Toggle_G6.Visible='off';
    handles.Toggle_F6.Visible='off';
    handles.Toggle_E6.Visible='off';
    handles.Toggle_D6.Visible='off';
    handles.Toggle_C6.Visible='off';
    handles.Toggle_B6.Visible='off';
    handles.Toggle_A6.Visible='off';
    handles.Toggle_M5.Visible='off';
    handles.Toggle_L5.Visible='off';
    handles.Toggle_K5.Visible='off';
    handles.Toggle_J5.Visible='off';
    handles.Toggle_H5.Visible='off';
    handles.Toggle_G5.Visible='off';
    handles.Toggle_F5.Visible='off';
    handles.Toggle_E5.Visible='off';
    handles.Toggle_D5.Visible='off';
    handles.Toggle_C5.Visible='off';
    handles.Toggle_B5.Visible='off';
    handles.Toggle_A5.Visible='off';
    handles.Toggle_M4.Visible='off';
    handles.Toggle_L4.Visible='off';
    handles.Toggle_K4.Visible='off';
    handles.Toggle_J4.Visible='off';
    handles.Toggle_H4.Visible='off';
    handles.Toggle_G4.Visible='off';
    handles.Toggle_F4.Visible='off';
    handles.Toggle_E4.Visible='off';
    handles.Toggle_D4.Visible='off';
    handles.Toggle_C4.Visible='off';
    handles.Toggle_B4.Visible='off';
    handles.Toggle_A4.Visible='off';
    handles.Toggle_L3.Visible='off';
    handles.Toggle_K3.Visible='off';
    handles.Toggle_J3.Visible='off';
    handles.Toggle_H3.Visible='off';
    handles.Toggle_G3.Visible='off';
    handles.Toggle_F3.Visible='off';
    handles.Toggle_E3.Visible='off';
    handles.Toggle_D3.Visible='off';
    handles.Toggle_C3.Visible='off';
    handles.Toggle_B3.Visible='off';
    handles.Toggle_K2.Visible='off';
    handles.Toggle_J2.Visible='off';
    handles.Toggle_H2.Visible='off';
    handles.Toggle_G2.Visible='off';
    handles.Toggle_F2.Visible='off';
    handles.Toggle_E2.Visible='off';
    handles.Toggle_D2.Visible='off';
    handles.Toggle_C2.Visible='off';
    handles.Toggle_J1.Visible='off';
    handles.Toggle_H1.Visible='off';
    handles.Toggle_G1.Visible='off';
    handles.Toggle_F1.Visible='off';
    handles.Toggle_E1.Visible='off';
    handles.Toggle_D1.Visible='off';
    
    %     handles.Pannel_2.Visibility='off';
    %     handles.Pannel_1.Visibility='off';
    %     handles.Pannel_3.Visibility='off';
    %     handles.Pannel_4.Visibility='off';
    %     handles.Pannel_5.Visibility='off';
    %     handles.Pannel_6.Visibility='off';
    handles.Pannel_7.Visibility='on';
    handles.Pannel_8.Visibility='on';
    handles.Pannel_9.Visibility='on';
    handles.Pannel_10.Visibility='on';
    handles.Pannel_11.Visibility='on';
    handles.Pannel_12.Visibility='on';
    %     handles.Pannel_13.Visibility='off';
    %     handles.Pannel_14.Visibility='off';
    %     handles.Pannel_15.Visibility='off';
    %     handles.Pannel_16.Visibility='off';
    %     handles.Pannel_17.Visibility='off';
    %     handles.Pannel_18.Visibility='off';
    
    handles.uitable10.Visible='off';
    
    handles.text5.Visible='off';
    handles.text8.Visible='off';
    handles.text10.Visible='off';
    handles.text9.Visible='off';
    handles.text3.Visible='off';
    handles.text18.Visible='off';
    handles.text82.Visible='on';
    handles.text83.Visible='on';
    handles.text84.Visible='on';
    handles.uipanel4.Visible='off';
    handles.uipanel3.Visible='off';
    handles.uipanel2.Visible='off';
    handles.uipanel6.Visible = 'on';
    handles.uipanel7.Visible = 'on';
    handles.uipanel8.Visible = 'on';
    handles.uipanel9.Visible = 'on';
    handles.uipanel11.Visible = 'off';
    handles.uipanel12.Visible = 'off';
    handles.uipanel13.Visible = 'off';
    handles.uipanel14.Visible = 'off';
    handles.uipanel15.Visible = 'off';
    handles.uipanel16.Visible = 'off';
    handles.uipanel17.Visible = 'off';
    handles.uipanel18.Visible = 'off';
    try
        if exist('h','var')
            h.Visible = 'off';
        end
        
        if strcmp(h.Visible,'on')
            h.Visible = 'off';
        end
        
        if exist('h1','var')
            h1.Visible = 'off';
        end
        
        if strcmp(h1.Visible,'on')
            h1.Visible = 'off';
        end
        
        if exist('h2','var')
            h2.Visible = 'off';
        end
        
        if strcmp(h2.Visible,'on')
            h2.Visible = 'off';
        end
        
        if exist('h3','var')
            h3.Visible = 'off';
        end
        
        if strcmp(h3.Visible,'on')
            h3.Visible = 'off';
        end
    catch
    end
    
    % for multiwell
    if multiwell1 == 1
        
        handles.text43.Visible ='off';
        handles.popupmenu1.Visible = 'off';
        handles.pushbutton368.Visible = 'off';
        handles.pushbutton371.Visible = 'off';
        handles.pushbutton370.Visible = 'off';
        handles.pushbutton366.Visible = 'off';
        handles.pushbutton364.Visible = 'off';
        handles.pushbutton367.Visible = 'off';
        handles.pushbutton380.Visible = 'off';
        handles.pushbutton377.Visible = 'off';
        handles.pushbutton376.Visible = 'off';
        handles.pushbutton365.Visible = 'off';
        handles.pushbutton372.Visible = 'off';
        handles.pushbutton373.Visible = 'off';
        handles.pushbutton383.Visible = 'off';
        handles.pushbutton374.Visible = 'off';
        handles.pushbutton384.Visible = 'off';
        handles.pushbutton381.Visible = 'off';
        handles.pushbutton375.Visible = 'off';
        handles.pushbutton382.Visible = 'off';
        handles.pushbutton388.Visible = 'off';
        handles.pushbutton402.Visible = 'off';
        handles.pushbutton403.Visible = 'off';
        handles.pushbutton404.Visible = 'off';
        handles.pushbutton405.Visible = 'off';
        handles.pushbutton406.Visible = 'off';
        handles.pushbutton407.Visible = 'off';
        handles.pushbutton408.Visible = 'off';
        handles.pushbutton409.Visible = 'off';
        handles.pushbutton410.Visible = 'off';
        handles.pushbutton411.Visible = 'off';
        handles.pushbutton412.Visible = 'off';
        handles.pushbutton413.Visible = 'off';
        handles.pushbutton414.Visible = 'off';
        handles.pushbutton415.Visible = 'off';
        handles.pushbutton416.Visible = 'off';
        handles.pushbutton417.Visible = 'off';
        handles.pushbutton418.Visible = 'off';
        handles.pushbutton419.Visible = 'off';
        handles.pushbutton420.Visible = 'off';
        handles.pushbutton421.Visible = 'off';
        handles.pushbutton422.Visible = 'off';
        handles.pushbutton423.Visible = 'off';
        handles.pushbutton424.Visible = 'off';
        handles.pushbutton425.Visible = 'off';
        
        
        handles.text2.Visible = 'off';  handles.text3.Visible = 'off';  handles.text4.Visible = 'off';  handles.text5.Visible = 'off';  handles.text6.Visible = 'off';
        handles.text7.Visible = 'off';  handles.text8.Visible = 'off';  handles.text9.Visible = 'off';  handles.text10.Visible = 'off';  handles.text11.Visible = 'off';
        handles.text12.Visible = 'off';  handles.text13.Visible = 'off';  handles.text14.Visible = 'off';  handles.text15.Visible = 'off';  handles.text16.Visible = 'off';
        handles.text17.Visible = 'off';  handles.text18.Visible = 'off';  handles.text19.Visible = 'off';  handles.text20.Visible = 'off';  handles.text21.Visible = 'off';
        handles.text22.Visible = 'off';  handles.text23.Visible = 'off';  handles.text24.Visible = 'off';  handles.text25.Visible = 'off';  handles.text26.Visible = 'off';
        handles.text27.Visible = 'off';  handles.text28.Visible = 'off';  handles.text29.Visible = 'off';  handles.text30.Visible = 'off';
        
        handles.uitable1.Visible = 'off';
        handles.checkbox4.Visible ='off';
        handles.togglebutton1.Visible = 'off'; handles.togglebutton2.Visible = 'off'; handles.togglebutton3.Visible = 'off'; handles.togglebutton4.Visible = 'off'; handles.togglebutton5.Visible = 'off';
        handles.togglebutton6.Visible = 'off'; handles.togglebutton7.Visible = 'off'; handles.togglebutton8.Visible = 'off'; handles.togglebutton9.Visible = 'off'; handles.togglebutton10.Visible = 'off';
        handles.togglebutton11.Visible = 'off'; handles.togglebutton12.Visible = 'off'; handles.togglebutton13.Visible = 'off'; handles.togglebutton14.Visible = 'off'; handles.togglebutton15.Visible = 'off';
        handles.togglebutton16.Visible = 'off'; handles.togglebutton17.Visible = 'off'; handles.togglebutton18.Visible = 'off'; handles.togglebutton19.Visible = 'off'; handles.togglebutton20.Visible = 'off';
        handles.togglebutton21.Visible = 'off'; handles.togglebutton22.Visible = 'off'; handles.togglebutton23.Visible = 'off'; handles.togglebutton24.Visible = 'off'; handles.togglebutton25.Visible = 'off';
        handles.togglebutton26.Visible = 'off'; handles.togglebutton27.Visible = 'off'; handles.togglebutton28.Visible = 'off'; handles.togglebutton29.Visible = 'off'; handles.togglebutton30.Visible = 'off';
        handles.togglebutton31.Visible = 'off'; handles.togglebutton32.Visible = 'off'; handles.togglebutton33.Visible = 'off'; handles.togglebutton34.Visible = 'off'; handles.togglebutton35.Visible = 'off';
        handles.togglebutton36.Visible = 'off'; handles.togglebutton37.Visible = 'off'; handles.togglebutton38.Visible = 'off'; handles.togglebutton39.Visible = 'off'; handles.togglebutton40.Visible = 'off';
        handles.togglebutton41.Visible = 'off'; handles.togglebutton42.Visible = 'off'; handles.togglebutton43.Visible = 'off'; handles.togglebutton44.Visible = 'off'; handles.togglebutton45.Visible = 'off';
        handles.togglebutton46.Visible = 'off'; handles.togglebutton47.Visible = 'off'; handles.togglebutton48.Visible = 'off'; handles.togglebutton49.Visible = 'off'; handles.togglebutton50.Visible = 'off';
        handles.togglebutton51.Visible = 'off'; handles.togglebutton52.Visible = 'off'; handles.togglebutton53.Visible = 'off'; handles.togglebutton54.Visible = 'off'; handles.togglebutton55.Visible = 'off';
        handles.togglebutton56.Visible = 'off'; handles.togglebutton57.Visible = 'off'; handles.togglebutton58.Visible = 'off'; handles.togglebutton59.Visible = 'off'; handles.togglebutton60.Visible = 'off';
        handles.togglebutton61.Visible = 'off'; handles.togglebutton62.Visible = 'off'; handles.togglebutton63.Visible = 'off'; handles.togglebutton64.Visible = 'off'; handles.togglebutton65.Visible = 'off';
        handles.togglebutton66.Visible = 'off'; handles.togglebutton67.Visible = 'off'; handles.togglebutton68.Visible = 'off'; handles.togglebutton69.Visible = 'off'; handles.togglebutton70.Visible = 'off';
        handles.togglebutton71.Visible = 'off'; handles.togglebutton72.Visible = 'off'; handles.togglebutton73.Visible = 'off'; handles.togglebutton74.Visible = 'off'; handles.togglebutton75.Visible = 'off';
        handles.togglebutton76.Visible = 'off'; handles.togglebutton77.Visible = 'off'; handles.togglebutton78.Visible = 'off'; handles.togglebutton79.Visible = 'off'; handles.togglebutton80.Visible = 'off';
        handles.togglebutton81.Visible = 'off'; handles.togglebutton82.Visible = 'off'; handles.togglebutton83.Visible = 'off'; handles.togglebutton84.Visible = 'off'; handles.togglebutton85.Visible = 'off';
        handles.togglebutton86.Visible = 'off'; handles.togglebutton87.Visible = 'off'; handles.togglebutton88.Visible = 'off'; handles.togglebutton89.Visible = 'off'; handles.togglebutton90.Visible = 'off';
        handles.togglebutton91.Visible = 'off'; handles.togglebutton92.Visible = 'off'; handles.togglebutton93.Visible = 'off'; handles.togglebutton94.Visible = 'off'; handles.togglebutton95.Visible = 'off';
        handles.togglebutton96.Visible = 'off'; handles.togglebutton97.Visible = 'off'; handles.togglebutton98.Visible = 'off'; handles.togglebutton99.Visible = 'off'; handles.togglebutton100.Visible = 'off';
        handles.togglebutton101.Visible = 'off'; handles.togglebutton102.Visible = 'off'; handles.togglebutton103.Visible = 'off'; handles.togglebutton104.Visible = 'off'; handles.togglebutton105.Visible = 'off';
        handles.togglebutton106.Visible = 'off'; handles.togglebutton107.Visible = 'off'; handles.togglebutton108.Visible = 'off'; handles.togglebutton109.Visible = 'off'; handles.togglebutton110.Visible = 'off';
        handles.togglebutton111.Visible = 'off'; handles.togglebutton112.Visible = 'off'; handles.togglebutton113.Visible = 'off'; handles.togglebutton114.Visible = 'off'; handles.togglebutton115.Visible = 'off';
        handles.togglebutton116.Visible = 'off'; handles.togglebutton117.Visible = 'off'; handles.togglebutton118.Visible = 'off'; handles.togglebutton119.Visible = 'off'; handles.togglebutton120.Visible = 'off';
        handles.togglebutton121.Visible = 'off'; handles.togglebutton122.Visible = 'off'; handles.togglebutton123.Visible = 'off'; handles.togglebutton124.Visible = 'off'; handles.togglebutton125.Visible = 'off';
        handles.togglebutton126.Visible = 'off'; handles.togglebutton127.Visible = 'off'; handles.togglebutton128.Visible = 'off'; handles.togglebutton129.Visible = 'off'; handles.togglebutton130.Visible = 'off';
        handles.togglebutton131.Visible = 'off'; handles.togglebutton132.Visible = 'off'; handles.togglebutton133.Visible = 'off'; handles.togglebutton134.Visible = 'off'; handles.togglebutton135.Visible = 'off';
        handles.togglebutton136.Visible = 'off'; handles.togglebutton137.Visible = 'off'; handles.togglebutton138.Visible = 'off'; handles.togglebutton139.Visible = 'off'; handles.togglebutton140.Visible = 'off';
        handles.togglebutton141.Visible = 'off'; handles.togglebutton142.Visible = 'off'; handles.togglebutton143.Visible = 'off'; handles.togglebutton144.Visible = 'off'; handles.togglebutton145.Visible = 'off';
        handles.togglebutton146.Visible = 'off'; handles.togglebutton147.Visible = 'off'; handles.togglebutton148.Visible = 'off'; handles.togglebutton149.Visible = 'off'; handles.togglebutton150.Visible = 'off';
        handles.togglebutton151.Visible = 'off'; handles.togglebutton152.Visible = 'off'; handles.togglebutton153.Visible = 'off'; handles.togglebutton154.Visible = 'off'; handles.togglebutton155.Visible = 'off';
        handles.togglebutton156.Visible = 'off'; handles.togglebutton157.Visible = 'off'; handles.togglebutton158.Visible = 'off'; handles.togglebutton159.Visible = 'off'; handles.togglebutton160.Visible = 'off';
        handles.togglebutton161.Visible = 'off'; handles.togglebutton162.Visible = 'off'; handles.togglebutton163.Visible = 'off'; handles.togglebutton164.Visible = 'off'; handles.togglebutton165.Visible = 'off';
        handles.togglebutton166.Visible = 'off'; handles.togglebutton167.Visible = 'off'; handles.togglebutton168.Visible = 'off'; handles.togglebutton169.Visible = 'off'; handles.togglebutton170.Visible = 'off';
        handles.togglebutton171.Visible = 'off'; handles.togglebutton172.Visible = 'off'; handles.togglebutton173.Visible = 'off'; handles.togglebutton174.Visible = 'off'; handles.togglebutton175.Visible = 'off';
        handles.togglebutton176.Visible = 'off'; handles.togglebutton177.Visible = 'off'; handles.togglebutton178.Visible = 'off'; handles.togglebutton179.Visible = 'off'; handles.togglebutton180.Visible = 'off';
        handles.togglebutton181.Visible = 'off'; handles.togglebutton182.Visible = 'off'; handles.togglebutton183.Visible = 'off'; handles.togglebutton184.Visible = 'off'; handles.togglebutton185.Visible = 'off';
        handles.togglebutton186.Visible = 'off'; handles.togglebutton187.Visible = 'off'; handles.togglebutton188.Visible = 'off'; handles.togglebutton189.Visible = 'off'; handles.togglebutton190.Visible = 'off';
        handles.togglebutton191.Visible = 'off'; handles.togglebutton192.Visible = 'off'; handles.togglebutton193.Visible = 'off'; handles.togglebutton194.Visible = 'off'; handles.togglebutton195.Visible = 'off';
        handles.togglebutton196.Visible = 'off'; handles.togglebutton197.Visible = 'off'; handles.togglebutton198.Visible = 'off'; handles.togglebutton199.Visible = 'off'; handles.togglebutton200.Visible = 'off';
        handles.togglebutton201.Visible = 'off'; handles.togglebutton202.Visible = 'off'; handles.togglebutton203.Visible = 'off'; handles.togglebutton204.Visible = 'off'; handles.togglebutton205.Visible = 'off';
        handles.togglebutton206.Visible = 'off'; handles.togglebutton207.Visible = 'off'; handles.togglebutton208.Visible = 'off'; handles.togglebutton209.Visible = 'off'; handles.togglebutton210.Visible = 'off';
        handles.togglebutton211.Visible = 'off'; handles.togglebutton212.Visible = 'off'; handles.togglebutton213.Visible = 'off'; handles.togglebutton214.Visible = 'off'; handles.togglebutton215.Visible = 'off';
        handles.togglebutton216.Visible = 'off'; handles.togglebutton217.Visible = 'off'; handles.togglebutton218.Visible = 'off'; handles.togglebutton219.Visible = 'off'; handles.togglebutton220.Visible = 'off';
        handles.togglebutton221.Visible = 'off'; handles.togglebutton222.Visible = 'off'; handles.togglebutton223.Visible = 'off'; handles.togglebutton224.Visible = 'off'; handles.togglebutton225.Visible = 'off';
        handles.togglebutton226.Visible = 'off'; handles.togglebutton227.Visible = 'off'; handles.togglebutton228.Visible = 'off'; handles.togglebutton229.Visible = 'off'; handles.togglebutton230.Visible = 'off';
        handles.togglebutton231.Visible = 'off'; handles.togglebutton232.Visible = 'off'; handles.togglebutton233.Visible = 'off'; handles.togglebutton234.Visible = 'off'; handles.togglebutton235.Visible = 'off';
        handles.togglebutton236.Visible = 'off'; handles.togglebutton237.Visible = 'off'; handles.togglebutton238.Visible = 'off'; handles.togglebutton239.Visible = 'off'; handles.togglebutton240.Visible = 'off';
        handles.togglebutton241.Visible = 'off'; handles.togglebutton242.Visible = 'off'; handles.togglebutton243.Visible = 'off'; handles.togglebutton244.Visible = 'off'; handles.togglebutton245.Visible = 'off';
        handles.togglebutton246.Visible = 'off'; handles.togglebutton247.Visible = 'off'; handles.togglebutton248.Visible = 'off'; handles.togglebutton249.Visible = 'off'; handles.togglebutton250.Visible = 'off';
        handles.togglebutton251.Visible = 'off'; handles.togglebutton252.Visible = 'off'; handles.togglebutton253.Visible = 'off'; handles.togglebutton254.Visible = 'off'; handles.togglebutton255.Visible = 'off';
        handles.togglebutton256.Visible = 'off'; handles.togglebutton257.Visible = 'off'; handles.togglebutton258.Visible = 'off'; handles.togglebutton259.Visible = 'off'; handles.togglebutton260.Visible = 'off';
        handles.togglebutton261.Visible = 'off'; handles.togglebutton262.Visible = 'off'; handles.togglebutton263.Visible = 'off'; handles.togglebutton264.Visible = 'off'; handles.togglebutton265.Visible = 'off';
        handles.togglebutton266.Visible = 'off'; handles.togglebutton267.Visible = 'off'; handles.togglebutton268.Visible = 'off'; handles.togglebutton269.Visible = 'off'; handles.togglebutton270.Visible = 'off';
        handles.togglebutton271.Visible = 'off'; handles.togglebutton272.Visible = 'off'; handles.togglebutton273.Visible = 'off'; handles.togglebutton274.Visible = 'off'; handles.togglebutton275.Visible = 'off';
        handles.togglebutton276.Visible = 'off'; handles.togglebutton277.Visible = 'off'; handles.togglebutton278.Visible = 'off'; handles.togglebutton279.Visible = 'off'; handles.togglebutton280.Visible = 'off';
        handles.togglebutton281.Visible = 'off'; handles.togglebutton282.Visible = 'off'; handles.togglebutton283.Visible = 'off'; handles.togglebutton284.Visible = 'off'; handles.togglebutton285.Visible = 'off';
        handles.togglebutton286.Visible = 'off'; handles.togglebutton287.Visible = 'off'; handles.togglebutton288.Visible = 'off';
        
    end
    
    
elseif hObject.UserData == 4
    % spikes section
    handles.pushbutton65.Visible = 'off';
    handles.pushbutton66.Visible = 'off';
    handles.pushbutton67.Visible = 'off';
    handles.pushbutton68.Visible = 'off';
    handles.pushbutton64.Visible ='off';
    handles.pushbutton63.Visible = 'off';
    handles.pushbutton62.Visible = 'off';
    handles.uipanel20.Visible = 'off';
    handles.checkbox3.Visible = 'off';
    handles.pushbutton61.Visible = 'off';
    handles.pushbutton60.Visible ='off';
    handles.checkbox2.Visible = 'off';
    handles.pushbutton34.Visible='off';
    handles.pushbutton37.Visible='off';
    handles.pushbutton33.Visible='off';
    handles.pushbutton32.Visible='off';
    handles.pushbutton28.Visible='off';
    handles.pushbutton31.Visible='off';
    handles.pushbutton26.Visible='off';
    handles.pushbutton24.Visible='off';
    handles.pushbutton23.Visible='off';
    handles.pushbutton18.Visible='off';
    handles.pushbutton17.Visible='off';
    handles.pushbutton16.Visible='off';
    handles.pushbutton15.Visible='off';
    handles.pushbutton14.Visible='off';
    handles.pushbutton12.Visible='off';
    handles.pushbutton10.Visible='off';
    handles.pushbutton8.Visible='off';
    handles.pushbutton6.Visible='off';
    handles.pushbutton3.Visible='off';
    handles.pushbutton2.Visible='off';
    handles.pushbutton1.Visible='off';
    handles.pushbutton38.Visible = 'off';
    handles.pushbutton39.Visible = 'off';
    handles.pushbutton42.Visible = 'off';
    handles.pushbutton43.Visible = 'off';
    handles.pushbutton44.Visible = 'off';
    handles.pushbutton45.Visible = 'off';
    handles.pushbutton46.Visible = 'off';
    handles.pushbutton47.Visible = 'off';
    handles.pushbutton48.Visible = 'off';
    handles.pushbutton41.Visible = 'off';
    
    handles.Toggle_J12.Visible='off';
    handles.Toggle_H12.Visible='off';
    handles.Toggle_G12.Visible='off';
    handles.Toggle_F12.Visible='off';
    handles.Toggle_E12.Visible='off';
    handles.Toggle_D12.Visible='off';
    handles.Toggle_K11.Visible='off';
    handles.Toggle_J11.Visible='off';
    handles.Toggle_H11.Visible='off';
    handles.Toggle_G11.Visible='off';
    handles.Toggle_F11.Visible='off';
    handles.Toggle_E11.Visible='off';
    handles.Toggle_D11.Visible='off';
    handles.Toggle_C11.Visible='off';
    handles.Toggle_L10.Visible='off';
    handles.Toggle_K10.Visible='off';
    handles.Toggle_J10.Visible='off';
    handles.Toggle_H10.Visible='off';
    handles.Toggle_G10.Visible='off';
    handles.Toggle_F10.Visible='off';
    handles.Toggle_E10.Visible='off';
    handles.Toggle_D10.Visible='off';
    handles.Toggle_C10.Visible='off';
    handles.Toggle_B10.Visible='off';
    handles.Toggle_M9.Visible='off';
    handles.Toggle_L9.Visible='off';
    handles.Toggle_K9.Visible='off';
    handles.Toggle_J9.Visible='off';
    handles.Toggle_H9.Visible='off';
    handles.Toggle_G9.Visible='off';
    handles.Toggle_F9.Visible='off';
    handles.Toggle_E9.Visible='off';
    handles.Toggle_D9.Visible='off';
    handles.Toggle_C9.Visible='off';
    handles.Toggle_B9.Visible='off';
    handles.Toggle_A9.Visible='off';
    handles.Toggle_M8.Visible='off';
    handles.Toggle_L8.Visible='off';
    handles.Toggle_K8.Visible='off';
    handles.Toggle_J8.Visible='off';
    handles.Toggle_H8.Visible='off';
    handles.Toggle_G8.Visible='off';
    handles.Toggle_F8.Visible='off';
    handles.Toggle_E8.Visible='off';
    handles.Toggle_D8.Visible='off';
    handles.Toggle_C8.Visible='off';
    handles.Toggle_B8.Visible='off';
    handles.Toggle_A8.Visible='off';
    handles.Toggle_M7.Visible='off';
    handles.Toggle_L7.Visible='off';
    handles.Toggle_K7.Visible='off';
    handles.Toggle_J7.Visible='off';
    handles.Toggle_H7.Visible='off';
    handles.Toggle_G7.Visible='off';
    handles.Toggle_F7.Visible='off';
    handles.Toggle_E7.Visible='off';
    handles.Toggle_D7.Visible='off';
    handles.Toggle_C7.Visible='off';
    handles.Toggle_B7.Visible='off';
    handles.Toggle_A7.Visible='off';
    handles.Toggle_M6.Visible='off';
    handles.Toggle_L6.Visible='off';
    handles.Toggle_K6.Visible='off';
    handles.Toggle_J6.Visible='off';
    handles.Toggle_H6.Visible='off';
    handles.Toggle_G6.Visible='off';
    handles.Toggle_F6.Visible='off';
    handles.Toggle_E6.Visible='off';
    handles.Toggle_D6.Visible='off';
    handles.Toggle_C6.Visible='off';
    handles.Toggle_B6.Visible='off';
    handles.Toggle_A6.Visible='off';
    handles.Toggle_M5.Visible='off';
    handles.Toggle_L5.Visible='off';
    handles.Toggle_K5.Visible='off';
    handles.Toggle_J5.Visible='off';
    handles.Toggle_H5.Visible='off';
    handles.Toggle_G5.Visible='off';
    handles.Toggle_F5.Visible='off';
    handles.Toggle_E5.Visible='off';
    handles.Toggle_D5.Visible='off';
    handles.Toggle_C5.Visible='off';
    handles.Toggle_B5.Visible='off';
    handles.Toggle_A5.Visible='off';
    handles.Toggle_M4.Visible='off';
    handles.Toggle_L4.Visible='off';
    handles.Toggle_K4.Visible='off';
    handles.Toggle_J4.Visible='off';
    handles.Toggle_H4.Visible='off';
    handles.Toggle_G4.Visible='off';
    handles.Toggle_F4.Visible='off';
    handles.Toggle_E4.Visible='off';
    handles.Toggle_D4.Visible='off';
    handles.Toggle_C4.Visible='off';
    handles.Toggle_B4.Visible='off';
    handles.Toggle_A4.Visible='off';
    handles.Toggle_L3.Visible='off';
    handles.Toggle_K3.Visible='off';
    handles.Toggle_J3.Visible='off';
    handles.Toggle_H3.Visible='off';
    handles.Toggle_G3.Visible='off';
    handles.Toggle_F3.Visible='off';
    handles.Toggle_E3.Visible='off';
    handles.Toggle_D3.Visible='off';
    handles.Toggle_C3.Visible='off';
    handles.Toggle_B3.Visible='off';
    handles.Toggle_K2.Visible='off';
    handles.Toggle_J2.Visible='off';
    handles.Toggle_H2.Visible='off';
    handles.Toggle_G2.Visible='off';
    handles.Toggle_F2.Visible='off';
    handles.Toggle_E2.Visible='off';
    handles.Toggle_D2.Visible='off';
    handles.Toggle_C2.Visible='off';
    handles.Toggle_J1.Visible='off';
    handles.Toggle_H1.Visible='off';
    handles.Toggle_G1.Visible='off';
    handles.Toggle_F1.Visible='off';
    handles.Toggle_E1.Visible='off';
    handles.Toggle_D1.Visible='off';
    
    %     handles.Pannel_2.Visibility='off';
    %     handles.Pannel_1.Visibility='off';
    %     handles.Pannel_3.Visibility='off';
    %     handles.Pannel_4.Visibility='off';
    %     handles.Pannel_5.Visibility='off';
    %     handles.Pannel_6.Visibility='off';
    %     handles.Pannel_7.Visibility='off';
    %     handles.Pannel_8.Visibility='off';
    %     handles.Pannel_9.Visibility='off';
    %     handles.Pannel_10.Visibility='off';
    %     handles.Pannel_11.Visibility='off';
    %     handles.Pannel_12.Visibility='off';
    %     handles.Pannel_13.Visibility='off';
    %     handles.Pannel_14.Visibility='off';
    %     handles.Pannel_15.Visibility='off';
    %     handles.Pannel_16.Visibility='off';
    %     handles.Pannel_17.Visibility='off';
    %     handles.Pannel_18.Visibility='off';
    handles.Pannel_19.Visibility='on';
    handles.Pannel_20.Visibility='on';
    handles.Pannel_21.Visibility='on';
    handles.Pannel_22.Visibility='on';
    handles.Pannel_23.Visibility='on';
    handles.Pannel_24.Visibility='on';
    
    handles.uitable10.Visible='off';
    
    handles.text5.Visible = 'off';
    handles.text8.Visible = 'off';
    handles.text10.Visible = 'off';
    handles.text9.Visible = 'off';
    handles.text3.Visible = 'off';
    handles.text18.Visible = 'off';
    handles.text82.Visible = 'off';
    handles.text83.Visible = 'off';
    handles.text84.Visible = 'off';
    
    handles.uipanel4.Visible = 'off';
    handles.uipanel3.Visible = 'off';
    handles.uipanel2.Visible = 'off';
    handles.uipanel6.Visible = 'off';
    handles.uipanel7.Visible = 'off';
    handles.uipanel8.Visible = 'off';
    handles.uipanel9.Visible = 'off';
    handles.uipanel11.Visible = 'off';
    handles.uipanel12.Visible = 'off';
    handles.uipanel13.Visible = 'off';
    handles.uipanel14.Visible = 'off';
    handles.uipanel15.Visible = 'on';
    handles.uipanel16.Visible = 'on';
    handles.uipanel17.Visible = 'on';
    handles.uipanel18.Visible = 'on';
    
    handles1.Figures.Clusters.stability.Visible = 'on';
    handles1.Figures.Waveforms.unsortedspikes.Visible = 'on';
    handles1.Figures.Waveforms.UnsortedPanel.Visible = 'on';
    handles1.Figures.Waveforms.RunSortingAllchs.Visible = 'on';
    handles1.Figures.Waveforms.DispClustersTOGGLE.Visible = 'off';
    handles1.Figures.Waveforms.runSorting.Visible = 'on';
    handles1.Figures.Waveforms.ch_id.Visible = 'on';
    handles1.Figures.Waveforms.maintext.Visible = 'on';
    handles1.Figures.Waveforms.LoadData.Visible ='on';
    handles1.Figures.Waveforms.SaveData.Visible = 'on';
    handles1.Figures.Waveforms.filename.Visible = 'off';
    handles1.Figures.Waveforms.resetSorting.Visible = 'off';
    handles1.Figures.Waveforms.EditUnsorted.Visible = 'off';
    handles1.Figures.Waveforms.DiscardUnsorted.Visible = 'off';
    handles1.Figures.Waveforms.PlotAllTOGGLE.Visible = 'off';
    
    if handles1.Figures.Waveforms.runSorting.UserData == 1
        handles1.Figures.Waveforms.DispClustersTOGGLE.Visible = 'on';
        handles1.Figures.Waveforms.resetSorting.Visible = 'on';
        handles1.Figures.Waveforms.EditUnsorted.Visible = 'on';
        handles1.Figures.Waveforms.DiscardUnsorted.Visible = 'on';
        handles1.Figures.Waveforms.PlotAllTOGGLE.Visible = 'on';
    end
    
    
    
    if isfield(handles1.Figures.Clusters,'viewspikesList') && clustertag == 1
        handles1.Figures.Clusters.stability.Visible = 'on';
        handles1.Figures.Clusters.viewspikesList.Visible = 'on';
        handles1.Figures.Clusters.changemodeBUTTON.Visible = 'on';
        handles1.Figures.Clusters.recalculateButton.Visible = 'on';
        handles1.Figures.Clusters.deleteButton.Visible = 'on';
    end
    
    for i = 1:length( handles1.Figures.Waveforms.cluster)
        handles1.Figures.Waveforms.cluster{i}.Visible = 'on';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterNUMB)
        handles1.Figures.Waveforms.clusterNUMB{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterPOPUP)
        handles1.Figures.Waveforms.clusterPOPUP{i}.Visible = 'on';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.clusterTOGGLE)
        handles1.Figures.Waveforms.clusterTOGGLE{i}.Visible = 'off';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.delBUTTON)
        handles1.Figures.Waveforms.delBUTTON{i}.Visible = 'on';
    end
    
    for i = 1:length(handles1.Figures.Waveforms.ch_id_txtbox)
        handles1.Figures.Waveforms.ch_id_txtbox(i).Visible = 'on';
    end
    
    
    
    try
        if exist('h','var')
            h.Visible = 'off';
        end
        
        if strcmp(h.Visible,'on')
            h.Visible = 'off';
        end
        
        if exist('h1','var')
            h1.Visible = 'off';
        end
        
        if strcmp(h1.Visible,'on')
            h1.Visible = 'off';
        end
        
        if exist('h2','var')
            h2.Visible = 'off';
        end
        
        if strcmp(h2.Visible,'on')
            h2.Visible = 'off';
        end
        
        if exist('h3','var')
            h3.Visible = 'off';
        end
        
        if strcmp(h3.Visible,'on')
            h3.Visible = 'off';
        end
    catch
    end
    
    % for multiwell
    if multiwell1 == 1
        handles.text43.Visible ='off';
        handles.popupmenu1.Visible = 'off';
        handles.pushbutton368.Visible = 'off';
        handles.pushbutton371.Visible = 'off';
        handles.pushbutton370.Visible = 'off';
        handles.pushbutton366.Visible = 'off';
        handles.pushbutton364.Visible = 'off';
        handles.pushbutton367.Visible = 'off';
        handles.pushbutton380.Visible = 'off';
        handles.pushbutton377.Visible = 'off';
        handles.pushbutton376.Visible = 'off';
        handles.pushbutton365.Visible = 'off';
        handles.pushbutton372.Visible = 'off';
        handles.pushbutton373.Visible = 'off';
        handles.pushbutton383.Visible = 'off';
        handles.pushbutton374.Visible = 'off';
        handles.pushbutton384.Visible = 'off';
        handles.pushbutton381.Visible = 'off';
        handles.pushbutton375.Visible = 'off';
        handles.pushbutton382.Visible = 'off';
        handles.pushbutton388.Visible = 'off';
        handles.pushbutton402.Visible = 'off';
        handles.pushbutton403.Visible = 'off';
        handles.pushbutton404.Visible = 'off';
        handles.pushbutton405.Visible = 'off';
        handles.pushbutton406.Visible = 'off';
        handles.pushbutton407.Visible = 'off';
        handles.pushbutton408.Visible = 'off';
        handles.pushbutton409.Visible = 'off';
        handles.pushbutton410.Visible = 'off';
        handles.pushbutton411.Visible = 'off';
        handles.pushbutton412.Visible = 'off';
        handles.pushbutton413.Visible = 'off';
        handles.pushbutton414.Visible = 'off';
        handles.pushbutton415.Visible = 'off';
        handles.pushbutton416.Visible = 'off';
        handles.pushbutton417.Visible = 'off';
        handles.pushbutton418.Visible = 'off';
        handles.pushbutton419.Visible = 'off';
        handles.pushbutton420.Visible = 'off';
        handles.pushbutton421.Visible = 'off';
        handles.pushbutton422.Visible = 'off';
        handles.pushbutton423.Visible = 'off';
        handles.pushbutton424.Visible = 'off';
        handles.pushbutton425.Visible = 'off';
        
        
        handles.text2.Visible = 'off';  handles.text3.Visible = 'off';  handles.text4.Visible = 'off';  handles.text5.Visible = 'off';  handles.text6.Visible = 'off';
        handles.text7.Visible = 'off';  handles.text8.Visible = 'off';  handles.text9.Visible = 'off';  handles.text10.Visible = 'off';  handles.text11.Visible = 'off';
        handles.text12.Visible = 'off';  handles.text13.Visible = 'off';  handles.text14.Visible = 'off';  handles.text15.Visible = 'off';  handles.text16.Visible = 'off';
        handles.text17.Visible = 'off';  handles.text18.Visible = 'off';  handles.text19.Visible = 'off';  handles.text20.Visible = 'off';  handles.text21.Visible = 'off';
        handles.text22.Visible = 'off';  handles.text23.Visible = 'off';  handles.text24.Visible = 'off';  handles.text25.Visible = 'off';  handles.text26.Visible = 'off';
        handles.text27.Visible = 'off';  handles.text28.Visible = 'off';  handles.text29.Visible = 'off';  handles.text30.Visible = 'off';
        
        handles.uitable1.Visible = 'off';
        handles.checkbox4.Visible ='on';
        handles.togglebutton1.Visible = 'off'; handles.togglebutton2.Visible = 'off'; handles.togglebutton3.Visible = 'off'; handles.togglebutton4.Visible = 'off'; handles.togglebutton5.Visible = 'off';
        handles.togglebutton6.Visible = 'off'; handles.togglebutton7.Visible = 'off'; handles.togglebutton8.Visible = 'off'; handles.togglebutton9.Visible = 'off'; handles.togglebutton10.Visible = 'off';
        handles.togglebutton11.Visible = 'off'; handles.togglebutton12.Visible = 'off'; handles.togglebutton13.Visible = 'off'; handles.togglebutton14.Visible = 'off'; handles.togglebutton15.Visible = 'off';
        handles.togglebutton16.Visible = 'off'; handles.togglebutton17.Visible = 'off'; handles.togglebutton18.Visible = 'off'; handles.togglebutton19.Visible = 'off'; handles.togglebutton20.Visible = 'off';
        handles.togglebutton21.Visible = 'off'; handles.togglebutton22.Visible = 'off'; handles.togglebutton23.Visible = 'off'; handles.togglebutton24.Visible = 'off'; handles.togglebutton25.Visible = 'off';
        handles.togglebutton26.Visible = 'off'; handles.togglebutton27.Visible = 'off'; handles.togglebutton28.Visible = 'off'; handles.togglebutton29.Visible = 'off'; handles.togglebutton30.Visible = 'off';
        handles.togglebutton31.Visible = 'off'; handles.togglebutton32.Visible = 'off'; handles.togglebutton33.Visible = 'off'; handles.togglebutton34.Visible = 'off'; handles.togglebutton35.Visible = 'off';
        handles.togglebutton36.Visible = 'off'; handles.togglebutton37.Visible = 'off'; handles.togglebutton38.Visible = 'off'; handles.togglebutton39.Visible = 'off'; handles.togglebutton40.Visible = 'off';
        handles.togglebutton41.Visible = 'off'; handles.togglebutton42.Visible = 'off'; handles.togglebutton43.Visible = 'off'; handles.togglebutton44.Visible = 'off'; handles.togglebutton45.Visible = 'off';
        handles.togglebutton46.Visible = 'off'; handles.togglebutton47.Visible = 'off'; handles.togglebutton48.Visible = 'off'; handles.togglebutton49.Visible = 'off'; handles.togglebutton50.Visible = 'off';
        handles.togglebutton51.Visible = 'off'; handles.togglebutton52.Visible = 'off'; handles.togglebutton53.Visible = 'off'; handles.togglebutton54.Visible = 'off'; handles.togglebutton55.Visible = 'off';
        handles.togglebutton56.Visible = 'off'; handles.togglebutton57.Visible = 'off'; handles.togglebutton58.Visible = 'off'; handles.togglebutton59.Visible = 'off'; handles.togglebutton60.Visible = 'off';
        handles.togglebutton61.Visible = 'off'; handles.togglebutton62.Visible = 'off'; handles.togglebutton63.Visible = 'off'; handles.togglebutton64.Visible = 'off'; handles.togglebutton65.Visible = 'off';
        handles.togglebutton66.Visible = 'off'; handles.togglebutton67.Visible = 'off'; handles.togglebutton68.Visible = 'off'; handles.togglebutton69.Visible = 'off'; handles.togglebutton70.Visible = 'off';
        handles.togglebutton71.Visible = 'off'; handles.togglebutton72.Visible = 'off'; handles.togglebutton73.Visible = 'off'; handles.togglebutton74.Visible = 'off'; handles.togglebutton75.Visible = 'off';
        handles.togglebutton76.Visible = 'off'; handles.togglebutton77.Visible = 'off'; handles.togglebutton78.Visible = 'off'; handles.togglebutton79.Visible = 'off'; handles.togglebutton80.Visible = 'off';
        handles.togglebutton81.Visible = 'off'; handles.togglebutton82.Visible = 'off'; handles.togglebutton83.Visible = 'off'; handles.togglebutton84.Visible = 'off'; handles.togglebutton85.Visible = 'off';
        handles.togglebutton86.Visible = 'off'; handles.togglebutton87.Visible = 'off'; handles.togglebutton88.Visible = 'off'; handles.togglebutton89.Visible = 'off'; handles.togglebutton90.Visible = 'off';
        handles.togglebutton91.Visible = 'off'; handles.togglebutton92.Visible = 'off'; handles.togglebutton93.Visible = 'off'; handles.togglebutton94.Visible = 'off'; handles.togglebutton95.Visible = 'off';
        handles.togglebutton96.Visible = 'off'; handles.togglebutton97.Visible = 'off'; handles.togglebutton98.Visible = 'off'; handles.togglebutton99.Visible = 'off'; handles.togglebutton100.Visible = 'off';
        handles.togglebutton101.Visible = 'off'; handles.togglebutton102.Visible = 'off'; handles.togglebutton103.Visible = 'off'; handles.togglebutton104.Visible = 'off'; handles.togglebutton105.Visible = 'off';
        handles.togglebutton106.Visible = 'off'; handles.togglebutton107.Visible = 'off'; handles.togglebutton108.Visible = 'off'; handles.togglebutton109.Visible = 'off'; handles.togglebutton110.Visible = 'off';
        handles.togglebutton111.Visible = 'off'; handles.togglebutton112.Visible = 'off'; handles.togglebutton113.Visible = 'off'; handles.togglebutton114.Visible = 'off'; handles.togglebutton115.Visible = 'off';
        handles.togglebutton116.Visible = 'off'; handles.togglebutton117.Visible = 'off'; handles.togglebutton118.Visible = 'off'; handles.togglebutton119.Visible = 'off'; handles.togglebutton120.Visible = 'off';
        handles.togglebutton121.Visible = 'off'; handles.togglebutton122.Visible = 'off'; handles.togglebutton123.Visible = 'off'; handles.togglebutton124.Visible = 'off'; handles.togglebutton125.Visible = 'off';
        handles.togglebutton126.Visible = 'off'; handles.togglebutton127.Visible = 'off'; handles.togglebutton128.Visible = 'off'; handles.togglebutton129.Visible = 'off'; handles.togglebutton130.Visible = 'off';
        handles.togglebutton131.Visible = 'off'; handles.togglebutton132.Visible = 'off'; handles.togglebutton133.Visible = 'off'; handles.togglebutton134.Visible = 'off'; handles.togglebutton135.Visible = 'off';
        handles.togglebutton136.Visible = 'off'; handles.togglebutton137.Visible = 'off'; handles.togglebutton138.Visible = 'off'; handles.togglebutton139.Visible = 'off'; handles.togglebutton140.Visible = 'off';
        handles.togglebutton141.Visible = 'off'; handles.togglebutton142.Visible = 'off'; handles.togglebutton143.Visible = 'off'; handles.togglebutton144.Visible = 'off'; handles.togglebutton145.Visible = 'off';
        handles.togglebutton146.Visible = 'off'; handles.togglebutton147.Visible = 'off'; handles.togglebutton148.Visible = 'off'; handles.togglebutton149.Visible = 'off'; handles.togglebutton150.Visible = 'off';
        handles.togglebutton151.Visible = 'off'; handles.togglebutton152.Visible = 'off'; handles.togglebutton153.Visible = 'off'; handles.togglebutton154.Visible = 'off'; handles.togglebutton155.Visible = 'off';
        handles.togglebutton156.Visible = 'off'; handles.togglebutton157.Visible = 'off'; handles.togglebutton158.Visible = 'off'; handles.togglebutton159.Visible = 'off'; handles.togglebutton160.Visible = 'off';
        handles.togglebutton161.Visible = 'off'; handles.togglebutton162.Visible = 'off'; handles.togglebutton163.Visible = 'off'; handles.togglebutton164.Visible = 'off'; handles.togglebutton165.Visible = 'off';
        handles.togglebutton166.Visible = 'off'; handles.togglebutton167.Visible = 'off'; handles.togglebutton168.Visible = 'off'; handles.togglebutton169.Visible = 'off'; handles.togglebutton170.Visible = 'off';
        handles.togglebutton171.Visible = 'off'; handles.togglebutton172.Visible = 'off'; handles.togglebutton173.Visible = 'off'; handles.togglebutton174.Visible = 'off'; handles.togglebutton175.Visible = 'off';
        handles.togglebutton176.Visible = 'off'; handles.togglebutton177.Visible = 'off'; handles.togglebutton178.Visible = 'off'; handles.togglebutton179.Visible = 'off'; handles.togglebutton180.Visible = 'off';
        handles.togglebutton181.Visible = 'off'; handles.togglebutton182.Visible = 'off'; handles.togglebutton183.Visible = 'off'; handles.togglebutton184.Visible = 'off'; handles.togglebutton185.Visible = 'off';
        handles.togglebutton186.Visible = 'off'; handles.togglebutton187.Visible = 'off'; handles.togglebutton188.Visible = 'off'; handles.togglebutton189.Visible = 'off'; handles.togglebutton190.Visible = 'off';
        handles.togglebutton191.Visible = 'off'; handles.togglebutton192.Visible = 'off'; handles.togglebutton193.Visible = 'off'; handles.togglebutton194.Visible = 'off'; handles.togglebutton195.Visible = 'off';
        handles.togglebutton196.Visible = 'off'; handles.togglebutton197.Visible = 'off'; handles.togglebutton198.Visible = 'off'; handles.togglebutton199.Visible = 'off'; handles.togglebutton200.Visible = 'off';
        handles.togglebutton201.Visible = 'off'; handles.togglebutton202.Visible = 'off'; handles.togglebutton203.Visible = 'off'; handles.togglebutton204.Visible = 'off'; handles.togglebutton205.Visible = 'off';
        handles.togglebutton206.Visible = 'off'; handles.togglebutton207.Visible = 'off'; handles.togglebutton208.Visible = 'off'; handles.togglebutton209.Visible = 'off'; handles.togglebutton210.Visible = 'off';
        handles.togglebutton211.Visible = 'off'; handles.togglebutton212.Visible = 'off'; handles.togglebutton213.Visible = 'off'; handles.togglebutton214.Visible = 'off'; handles.togglebutton215.Visible = 'off';
        handles.togglebutton216.Visible = 'off'; handles.togglebutton217.Visible = 'off'; handles.togglebutton218.Visible = 'off'; handles.togglebutton219.Visible = 'off'; handles.togglebutton220.Visible = 'off';
        handles.togglebutton221.Visible = 'off'; handles.togglebutton222.Visible = 'off'; handles.togglebutton223.Visible = 'off'; handles.togglebutton224.Visible = 'off'; handles.togglebutton225.Visible = 'off';
        handles.togglebutton226.Visible = 'off'; handles.togglebutton227.Visible = 'off'; handles.togglebutton228.Visible = 'off'; handles.togglebutton229.Visible = 'off'; handles.togglebutton230.Visible = 'off';
        handles.togglebutton231.Visible = 'off'; handles.togglebutton232.Visible = 'off'; handles.togglebutton233.Visible = 'off'; handles.togglebutton234.Visible = 'off'; handles.togglebutton235.Visible = 'off';
        handles.togglebutton236.Visible = 'off'; handles.togglebutton237.Visible = 'off'; handles.togglebutton238.Visible = 'off'; handles.togglebutton239.Visible = 'off'; handles.togglebutton240.Visible = 'off';
        handles.togglebutton241.Visible = 'off'; handles.togglebutton242.Visible = 'off'; handles.togglebutton243.Visible = 'off'; handles.togglebutton244.Visible = 'off'; handles.togglebutton245.Visible = 'off';
        handles.togglebutton246.Visible = 'off'; handles.togglebutton247.Visible = 'off'; handles.togglebutton248.Visible = 'off'; handles.togglebutton249.Visible = 'off'; handles.togglebutton250.Visible = 'off';
        handles.togglebutton251.Visible = 'off'; handles.togglebutton252.Visible = 'off'; handles.togglebutton253.Visible = 'off'; handles.togglebutton254.Visible = 'off'; handles.togglebutton255.Visible = 'off';
        handles.togglebutton256.Visible = 'off'; handles.togglebutton257.Visible = 'off'; handles.togglebutton258.Visible = 'off'; handles.togglebutton259.Visible = 'off'; handles.togglebutton260.Visible = 'off';
        handles.togglebutton261.Visible = 'off'; handles.togglebutton262.Visible = 'off'; handles.togglebutton263.Visible = 'off'; handles.togglebutton264.Visible = 'off'; handles.togglebutton265.Visible = 'off';
        handles.togglebutton266.Visible = 'off'; handles.togglebutton267.Visible = 'off'; handles.togglebutton268.Visible = 'off'; handles.togglebutton269.Visible = 'off'; handles.togglebutton270.Visible = 'off';
        handles.togglebutton271.Visible = 'off'; handles.togglebutton272.Visible = 'off'; handles.togglebutton273.Visible = 'off'; handles.togglebutton274.Visible = 'off'; handles.togglebutton275.Visible = 'off';
        handles.togglebutton276.Visible = 'off'; handles.togglebutton277.Visible = 'off'; handles.togglebutton278.Visible = 'off'; handles.togglebutton279.Visible = 'off'; handles.togglebutton280.Visible = 'off';
        handles.togglebutton281.Visible = 'off'; handles.togglebutton282.Visible = 'off'; handles.togglebutton283.Visible = 'off'; handles.togglebutton284.Visible = 'off'; handles.togglebutton285.Visible = 'off';
        handles.togglebutton286.Visible = 'off'; handles.togglebutton287.Visible = 'off'; handles.togglebutton288.Visible = 'off';
        
    end
    
end





end

