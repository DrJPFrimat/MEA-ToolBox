function callbackfn(source,eventdata)


set(axes3,'xlim',get(gcbo,'value')+[0 num2str(dx)]);
end