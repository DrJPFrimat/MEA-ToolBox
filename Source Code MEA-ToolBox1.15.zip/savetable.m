
function savetable(src,event)
global  cbx32 CVISI InterBurstInterval Connextions BurstCount MaxAmplitude ratioISI InterISI IBI BurstDur SpikeCount PercentageSpikes flag BurstRate ArrayFiringRate AllData CVIBITt cbx15 cbx14 connectionst cbx13 networkburstt burstNt maxamp cbx10 cbx11 cbx12 meanISI medianISI fireT burstTt cbx cbx1 spikeTt cbx2 cbx3 perspikesburstTt CVTt burstdurTt cbx4 cbx5 total31 IBITt MAD cbx9 cbx8 cbx6 cbx7 synchronicity
filter={'*.xlsx'};
% writetable(T,[selecteddata,'.xlsx'],'WriteRowNames',true);

% if cbx.Value == 1 && flag == 1
%     writetable(ArrayFiringRate,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx1.Value == 1 && flag == 1
%     writetable(BurstRate,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx2.Value == 1 && flag == 1
%     writetable(SpikeCount,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx3.Value == 1 && flag == 1
%     writetable(PercentageSpikes,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx4.Value == 1 && flag == 1
%     writetable(CVISI,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx5.Value == 1 && flag == 1
%     writetable(BurstDur,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx6.Value == 1 && flag == 1
%     writetable(IBI,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% 
% if cbx9.Value == 1 && flag == 1
%     writetable(ratioISI,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% 
% if cbx10.Value == 1 && flag == 1
%     writetable(InterISI,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx11.Value == 1 && flag == 1
%     writetable(MaxAmplitude,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx12.Value == 1 && flag == 1
%     writetable(BurstCount,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% 
% if cbx14.Value == 1 && flag == 1
%     writetable(Connextions,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% 
% if cbx15.Value == 1 && flag == 1
%     writetable(InterBurstInterval,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% if cbx.Value == 1
%     writetable(fireT,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx1.Value == 1
%     writetable(burstTt,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx2.Value == 1
%     writetable(spikeTt,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx3.Value == 1
%     writetable(perspikesburstTt,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx4.Value == 1
%     writetable(CVTt,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx5.Value == 1
%     writetable(burstdurTt,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx6.Value == 1
%     writetable(IBITt,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx7.Value == 1
%     writetable(synchronicity,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx8.Value == 1
%     writetable(MAD,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx9.Value == 1
%     writetable(total31,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx10.Value == 1 && cbx26.Value == 1
%     writetable(meanISI,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx10.Value == 1 && cbx27.Value == 1
%     writetable(medianISI,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx11.Value == 1
%     writetable(maxamp,uiputfile(filter),'WriteRowNames',true);
% end
% 
% 
% if cbx12.Value == 1
%     writetable(burstNt,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx13.Value == 1
%     writetable(networkburstt,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx14.Value == 1
%     writetable(connectionst,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx15.Value == 1
%     writetable(CVIBITt,uiputfile(filter),'WriteRowNames',true);
% end
% 
% if cbx32.Value == 1
    writetable(AllData,uiputfile(filter),'WriteRowNames',true);
% end




end