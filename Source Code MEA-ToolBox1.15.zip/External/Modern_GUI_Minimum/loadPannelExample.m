% Create Pannel Structures:
global textstrings Ghibli


%% panel setup for home
% New demo Pannel Design
str    = {'Statistics of the Whole Array'};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_1';
%Position = [.45,.475,.398,.518];
Position = [.417,.451,.398,.49]; % use to be 0.475
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Home');
handles = funControl('panel',handles,DemoPanel);

str    = {'Overall Activity of the whole array'};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_2';
%Position = [0.009,.475,.398,.518];
Position = [0.009,.451,.398,.49];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Home');
handles = funControl('panel',handles,DemoPanel);

str    = {'Top 5 most active channels'};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_3';
Position = [0.009,0.009,.398,.429]; 
%Position = [0.009,0.419,.398,.051]; %it used to be 0.031
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Home');
handles = funControl('panel',handles,DemoPanel);

str    = {'Generic Tools'};
strSub = {'Press H for Help'};
Tag      = 'Pannel_4';
%Position = [0.888,0.475,.099,.518];
Position = [0.825,0.451,.166,.49];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Home');
handles = funControl('panel',handles,DemoPanel);

str    = {'Heatmap & Rasterplot for a quick overview'};
strSub = {'Click on buttons for an enlarged view'};
Tag      = 'Pannel_5';
Position = [0.417,0.009,.398,.429];
%Position = [0.45,0.419,.398,.051];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Home');
handles = funControl('panel',handles,DemoPanel);

str    = {'Advanced Tools'};
strSub = {'Press H for Help'};
Tag      = 'Pannel_6';
Position = [0.825,0.009,.166,.429];
%Position = [0.888,0.419,.099,.051];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Home');
handles = funControl('panel',handles,DemoPanel);



%% panel setup for connectivity maps

str    = {'The Strongest 60 Connections'};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_7';
%Position = [.45,.475,.398,.518];
Position = [.417,.451,.398,.49]; % use to be 0.475
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Connections');
handles = funControl('panel',handles,DemoPanel);

str    = {'All Detected Functional Connections'};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_8';
%Position = [0.009,.475,.398,.518];
Position = [0.009,.451,.398,.49];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Connections');
handles = funControl('panel',handles,DemoPanel);

str    = {['The Connectivity Map for Channel ']};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_9';
Position = [0.009,0.009,.398,.429]; 
%Position = [0.009,0.419,.398,.051]; %it used to be 0.031
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Connections');
handles = funControl('panel',handles,DemoPanel);

str    = {'Generic Tools'};
strSub = {'Press H for Help'};
Tag      = 'Pannel_10';
%Position = [0.888,0.475,.099,.518];
Position = [0.825,0.451,.166,.49];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Connections');
handles = funControl('panel',handles,DemoPanel);

str    = {'The Connectivity Map for Channel '};
strSub = {'Click on buttons for an enlarged view'};
Tag      = 'Pannel_11';
Position = [0.417,0.009,.398,.429];
%Position = [0.45,0.419,.398,.051];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Connections');
handles = funControl('panel',handles,DemoPanel);

str    = {'Advanced Tools'};
strSub = {'Press H for Help'};
Tag      = 'Pannel_12';
Position = [0.825,0.009,.166,.429];
%Position = [0.888,0.419,.099,.051];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Connections');
handles = funControl('panel',handles,DemoPanel);



%% Spikes


str    = {'Clusters'};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_19';
%Position = [.45,.475,.398,.518];
Position = [.417,.451,.398,.49]; % use to be 0.475
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Spikes');
handles = funControl('panel',handles,DemoPanel);

str    = {'Unsorted Waveforms'};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_20';
%Position = [0.009,.475,.398,.518];
Position = [0.009,.451,.398,.49];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Spikes');
handles = funControl('panel',handles,DemoPanel);

str    = {'Sorted Waveforms'};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_21';
Position = [0.009,0.009,.398,.429]; 
%Position = [0.009,0.419,.398,.051]; %it used to be 0.031
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Spikes');
handles = funControl('panel',handles,DemoPanel);

str    = {'Generic Tools'};
strSub = {'Press H for Help'};
Tag      = 'Pannel_22';
%Position = [0.888,0.475,.099,.518];
Position = [0.825,0.451,.166,.49];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Spikes');
handles = funControl('panel',handles,DemoPanel);

str    = {'Cluster Stability'};
strSub = {'Click on buttons for an enlarged view'};
Tag      = 'Pannel_23';
Position = [0.417,0.009,.398,.429];
%Position = [0.45,0.419,.398,.051];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Spikes');
handles = funControl('panel',handles,DemoPanel);

str    = {'Advanced Tools'};
strSub = {'Press H for Help'};
Tag      = 'Pannel_24';
Position = [0.825,0.009,.166,.429];
%Position = [0.888,0.419,.099,.051];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Spikes');
handles = funControl('panel',handles,DemoPanel);


%% burst2.0

str    = {'Channel '};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_25';
% Position = [.45,.475,.398,.518];
% Position = [.009,.785,.806,.156]; % use to be 0.475 
% Position = [.009,.451,.806,.49]; % save point
Position = [.009,.296,.806,.646]; 
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Bursts');
handles = funControl('panel',handles,DemoPanel);

str    = {'Bursts Detected with Max interval Method'};
strSub = {'Click on buttons for detailed information on each channel'};
Tag      = 'Pannel_26';
%Position = [0.009,.475,.398,.518];
Position = [0.009,.009,.806,.26];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Bursts');
handles = funControl('panel',handles,DemoPanel);
% 
% str    = {'Bursts Detected with log ISI Method'};
% strSub = {'Click on buttons for detailed information on each channel'};
% Tag      = 'Pannel_27';
% Position = [0.009,0.371,.806,.156]; 
% %Position = [0.009,0.419,.398,.051]; %it used to be 0.031
% Color    = [.97,.98,.98];
% Callback = {'exampleFunction'}; 
% 
% DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Bursts');
% handles = funControl('panel',handles,DemoPanel);

% str    = {'Bursts Detected with BD method'};
% strSub = {'Click on buttons for an enlarged view'};
% Tag      = 'Pannel_29';
% Position = [0.009,0.164,.806,.156];
% %Position = [0.45,0.419,.398,.051];
% Color    = [.97,.98,.98];
% Callback = {'exampleFunction'}; 
% 
% DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Bursts');
% handles = funControl('panel',handles,DemoPanel);

str    = {'Generic Tools'};
strSub = {'Press H for Help'};
Tag      = 'Pannel_28';
%Position = [0.888,0.475,.099,.518];
Position = [0.825,0.451,.166,.49];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Bursts');
handles = funControl('panel',handles,DemoPanel);

str    = {'Advanced Tools'};
strSub = {'Press H for Help'};
Tag      = 'Pannel_30';
Position = [0.825,0.009,.166,.429];
%Position = [0.888,0.419,.099,.051];
Color    = [.97,.98,.98];
Callback = {'exampleFunction'}; 

DemoPanel = funBuildo('panel',Tag,Position,'String',str,'SubString',strSub,'FaceColor',Color,'Fontsize',50,'SubFontSize',9,'Callback',Callback,'Page','Bursts');
handles = funControl('panel',handles,DemoPanel);





