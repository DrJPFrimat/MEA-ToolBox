addpath(genpath('pwd'))
addpath(genpath('cSPIKEmex'))
addpath(genpath('PopulationAnalysis'))
addpath(genpath('SpikeTrainOrder'))