function GMM_resetSorting(A,B)

global handles1

handles1.data.class_id{handles1.chid} = ...
    handles1.dataaux.class_id{handles1.chid};
handles1.data.model{handles1.chid} = ...
    handles1.dataaux.model{handles1.chid};

handles1.Figures.Clusters.viewspikesVector=unique(handles1.data.class_id{handles1.chid});

GMM_plotwaveforms
if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
    GMM_showclusters
end
% figure(handles1.Figures.Waveforms.main)

end