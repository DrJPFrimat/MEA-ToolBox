
function [ ] = GMM_ChangeDisplayedCluster( A,B )

global handles1

% aux = cell2mat(handles1.Figures.Waveforms.clusterPOPUP)==A;
myfun = @(x) isequal(x,A);
aux = cellfun(myfun, handles1.Figures.Waveforms.clusterPOPUP);

axes(handles1.Figures.Waveforms.cluster{aux}),cla

GMM_ChangeVisualization(handles1.Figures.Waveforms.clusterTOGGLE{aux})
set(handles1.Figures.Waveforms.clusterNUMB{aux},'String',num2str(get(handles1.Figures.Waveforms.clusterPOPUP{aux},'value')))

axis tight
ylim(handles1.Figures.Waveforms.ylim)
box off

end
