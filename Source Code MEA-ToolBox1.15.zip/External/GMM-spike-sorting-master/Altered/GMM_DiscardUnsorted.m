
function GMM_DiscardUnsorted(A,B)
global handles1


clusterid = handles1.data.class_id{handles1.chid};
keep = find(~isnan(clusterid));


handles1.data.waveforms{handles1.chid} = handles1.data.waveforms{handles1.chid}(keep,:);
handles1.data.class_id{handles1.chid} = handles1.data.class_id{handles1.chid}(keep,:);
handles1.dataaux.class_id{handles1.chid} = handles1.dataaux.class_id{handles1.chid}(keep,:);
handles1.data.clustering_space{handles1.chid} = handles1.data.clustering_space{handles1.chid}(keep,:);
handles1.data.classification_uncertainty{handles1.chid} = handles1.data.classification_uncertainty{handles1.chid}(keep,:);
handles1.data.spiketimes{handles1.chid} = handles1.data.spiketimes{handles1.chid}(keep,:);

GMM_plotwaveforms(1,-1)

if get(handles1.Figures.Waveforms.DispClustersTOGGLE,'value')
    GMM_showclusters
end

end



