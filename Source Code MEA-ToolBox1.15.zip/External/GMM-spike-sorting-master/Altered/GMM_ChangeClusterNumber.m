
function [ ] = GMM_ChangeClusterNumber( A,B )

global handles1

% aux = cell2mat(handles1.Figures.Waveforms.clusterNUMB)==A;
myfun = @(x) isequal(x,A);
aux = cellfun(myfun, handles1.Figures.Waveforms.clusterNUMB);

new_class = str2num(get(handles1.Figures.Waveforms.clusterNUMB{aux},'string'));
old_class = (get(handles1.Figures.Waveforms.clusterPOPUP{aux},'value'));

new_class_idx = handles1.data.class_id{handles1.chid}==new_class;
old_class_idx = handles1.data.class_id{handles1.chid}==old_class;


handles1.data.class_id{handles1.chid}(old_class_idx) = new_class;
handles1.data.class_id{handles1.chid}(new_class_idx) = old_class;

model_old = find(handles1.data.model{handles1.chid}.class==old_class);
model_new = find(handles1.data.model{handles1.chid}.class==new_class);

handles1.data.model{handles1.chid}.class(model_old) = new_class;
handles1.data.model{handles1.chid}.class(model_new) = old_class;


% cellfun(@(x) str2num(get(x,'string')) ,handles1.Figures.Waveforms.clusterNUMB)
aux_new = find(cellfun(@(x) (get(x,'value')) ,handles1.Figures.Waveforms.clusterPOPUP)==new_class);
aux_old = find(cellfun(@(x) (get(x,'value')) ,handles1.Figures.Waveforms.clusterPOPUP)==old_class);

cellfun(@(x) (set(x,'string',num2str(old_class))),handles1.Figures.Waveforms.clusterNUMB(aux_old))
cellfun(@(x) (set(x,'string',num2str(new_class))),handles1.Figures.Waveforms.clusterNUMB(aux_new))
aux = [aux_new aux_old];
for iaux=aux(:)'
    GMM_ChangeVisualization(handles1.Figures.Waveforms.clusterTOGGLE{iaux})
end

axis tight
ylim(handles1.Figures.Waveforms.ylim)
box off

end
